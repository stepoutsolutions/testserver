<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * This model is used for common function
 * @package    common_model
 * @author     Vinod patidar  <vinod@vinfotech.com>
 * @version    1.0
 *
 */

class Common_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/*common function used to get single row from any table
	* @param String $select
	* @param String $table
	* @param Array/String $where
	*/
	function get_single_row($select = '*', $table, $where = "", $group_by = "", $order_by = "", $offset = '', $limit = '')
	{
		$this->db->select($select);
		$this->db->from($table);
		if ($where != "") {
			$this->db->where($where);
		}
		if ($group_by != "") {
			$this->db->group_by($group_by);
		}
		if ($order_by != "") {
			$this->db->order_by($order_by);
		}
		if ($limit != "") {
			$this->db->limit($offset, $limit);
		}
		$query = $this->db->get();
		return $query->row_array();
	}

	/*common function used to get all data from any table
	* @param String $select
	* @param String $table
	* @param Array/String $where
	*/
	function get_all_table_data($select = '*', $table, $where = "", $group_by = "", $order_by = "", $offset = '', $limit = '')
	{
		//echo $offset;exit;

		$this->db->select($select);
		$this->db->from($table);
		if ($where != "") {
			$this->db->where($where);
		}
		if ($group_by != "") {
			$this->db->group_by($group_by);
		}
		if ($order_by != "") {
			$this->db->order_by($order_by);
		}
		if ($limit != "") {
			$this->db->limit($offset, $limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		return $query->result_array();
	}

	/**
	 * Updates whole row [unlike update_field()]
	 * @param Array $data
	 * @param Integer $id
	 */
	public function update($table = "", $data, $where = "")
	{

		if (!is_array($data)) {
			log_message('error', 'Supposed to get an array!');
			return FALSE;
		} else if ($table == "") {
			log_message('error', 'Got empty table name');
			return FALSE;
		} else if ($where == "") {
			return false;
		} else {
			$this->db->where($where);
			$this->db->update($table, $data);
			return true;
		}
	}

	/* insert data in table
	* @param String $table
	* @param String $data
	* @param String $return
	*/
	function insert_data($table_name, $data_array, $return = 'id')
	{
		if ($table_name && is_array($data_array)) {
			$columns = $this->getTableFields($table_name);
			foreach ($columns as $coloumn_data)
				$column_name[] = $coloumn_data['Field'];

			foreach ($data_array as $key => $val) {
				if (in_array(trim($key), $column_name)) {
					$data[$key] = trim($val);
				}
			}
			$this->db->insert($table_name, $data);
			$id = $this->db->insert_id();
			if ($return == 'id') {
				return $id;
			} else {
				$arr[$return] = $id;
				// return $this->get_single_row('*', $table_name, array($arr));
			}
		}
	}

	function getTableFields($table_name)
	{
		$query = "SHOW COLUMNS FROM " . $this->db->dbprefix . "$table_name";
		$rs = $this->db->query($query);
		return $rs->result_array();
	}

	/**
	 * Delete row
	 * @param String $table
	 * @param Array/String $where
	 */
	public function delete($table = "", $where = "")
	{

		if ($table == "") {
			log_message('error', 'Got empty table name');
			return FALSE;
		} else if ($where == "") {
			return false;
		} else {
			$this->db->where($where);
			$this->db->delete($table);
		}
	}

   /**
	 * Replace into statement
	 *
	 * Generates a replace into string from the supplied data
	 *
	 * @access    public
	 * @param    string    the table name
	 * @param    array    the update data
	 * @return    string
	 */
	public function replace_into($table, $data)
	{
		$column_name   = array();
		$coloumn_data  = array();
		$update_fields = array();

		foreach ($data as $key => $val) {
			$column_name[]   = "`" . $key . "`";
			$update_fields[] = "`" . $key . "`" .'=VALUES(`'.$key.'`)';

			if (is_numeric($val)) {
				$coloumn_data[] = $val;
			} else {
				$coloumn_data[] = "'" . $val . "'";
			}

		}
		// $sql = "REPLACE INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES ( " . implode(', ', $coloumn_data) . " )";
		$sql = "INSERT INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES ( " . implode(', ', $coloumn_data) . " ) ON DUPLICATE KEY UPDATE " .implode(', ', $update_fields);
		$this->db->query($sql);
	}

	/**
	 * Replace into Batch statement
	 *
	 * Generates a replace into string from the supplied data
	 *
	 * @access    public
	 * @param    string    the table name
	 * @param    array    the update data
	 * @return    string
	 */
	public function replace_into_batch($table, $data)
	{
		$column_name	= array();
		$update_fields	= array();
		$append			= array();
		foreach($data as $i=>$outer)
		{
			$column_name = array_keys($outer);
			$coloumn_data = array();
			foreach ($outer as $key => $val) 
			{

				if($i == 0)
				{
					// $column_name[]   = "`" . $key . "`";
					$update_fields[] = "`" . $key . "`" .'=VALUES(`'.$key.'`)';
				}

				if (is_numeric($val)) 
				{
					$coloumn_data[] = $val;
				} 
				else 
				{
					$coloumn_data[] = "'" . replace_quotes($val) . "'";
				}
			}
			$append[] = " ( ".implode(', ', $coloumn_data). " ) ";
		}

		/*

			INSERT INTO `vi_player_temp` (`player_unique_id`, `salary`, `weightage`) VALUES ('000bc6c6-c9a8-4631-92d6-1cea5aaa1644',0,'')
			ON DUPLICATE KEY UPDATE `player_unique_id`=VALUES(`player_unique_id`), `salary`=VALUES(`salary`), `weightage`=VALUES(`weightage`)
		*/

		// $sql = "REPLACE INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES " . implode(', ', $append) ;

		$sql = "INSERT INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES " . implode(', ', $append) . " ON DUPLICATE KEY UPDATE " .implode(', ', $update_fields);
		// $sql = "INSERT INTO ". $this->db->dbprefix($table) ." (".implode(', ', $keys).") VALUES (".implode(', ', $values).") ON DUPLICATE KEY UPDATE ".implode(', ', $update_fields);

		
		$this->db->query($sql);
	} 

	public function prize_details_by_size_fee_prizing($size,$fee,$league_number_of_winner_id,$prize_pool = '0')
	{  
		$collected_amount = $size*$fee;
		$sql = "SELECT 
					site_rake
				FROM 
					".$this->db->dbprefix(MASTER_SITE_RAKE)."   
				WHERE
					lower_limit_of_entry_fee <= ".$fee."
				AND 
					upper_limit_of_entry_fee >= ".$fee."
			   ";
		$rs = $this->db->query($sql);

		$site_rake = $rs->row('site_rake'); 
		
		$site_rake_amount = ($collected_amount * $site_rake)/100; 
		$prize_pool_amount = $collected_amount - $site_rake_amount;
		if($prize_pool != '0')
		{
			$prize_pool_amount = $prize_pool;
		}    
		//$league_number_of_winner_id = "2";
		//echo $prize_pool_amount;die;
		
		$sql = "SELECT 
					MNOW.number_of_winner_id,MNOW.number_of_winner_desc,MNOW.places
				FROM 
					".$this->db->dbprefix(MASTER_NUMBER_OF_WINNER)." AS MNOW    
				WHERE
					MNOW.master_contest_type_id = ".$league_number_of_winner_id."
				";
		$rs = $this->db->query($sql);
		$result = $rs->row_array('');
		//$winner_id = trim($result['number_of_winner_id']);
		//echo "<pre>";print_r($result);die;
		 
		$file           = prize_json();
		$winner_array   = json_decode($file,true);

		//echo "<pre>";print_r($winner_array);die;
		$prize_details = array();
		
		//for Top 1 Place
		if($result['number_of_winner_id'] == 1)
		{
			$prize_percent          = $winner_array[$result['number_of_winner_desc']];
			$amt                    = (($prize_pool_amount*$prize_percent['1'])/100);
			$prize_details[0]       = number_format($amt,2);
		}
		//Top 2,3,5,10 Place
		elseif( $result['number_of_winner_id'] == 2 || $result['number_of_winner_id'] == 3
				|| $result['number_of_winner_id'] == 4 || $result['number_of_winner_id'] == 5 
				) 
		{
			$prize_percent = $winner_array[$result['number_of_winner_desc']];
			//print_r($prize_percent);die;
			for($i=0;$i<count($prize_percent);$i++)
			{
				$amt                    = (($prize_pool_amount*$prize_percent[$i+1])/100);
				$prize_details[$i]      = number_format($amt,2);
			}
		}
		//for Top 30% 0r 50%
		elseif($result['number_of_winner_id'] == 6 || $result['number_of_winner_id'] == 7) 
		{
			$prize_percent = $winner_array[$result['number_of_winner_desc']];

			if($prize_percent['30'] == 100 || $prize_percent['50'] == 100)
			{
				$place = floor(($size*$result['places'])/100);
				
				for($i=0;$i<$place;$i++)
				{
					$amt                    = $prize_pool_amount/$place;
					$prize_details[$i]      = $amt;
				}
			} 

		}
		else {
			$prize_details = "";
		}   
			
		return  $prize_details;
	}

	// get entry fee or size list for game creation
	public function get_all_fee_size($argument_array = array()) {
	   $condition =  $table = $field = "";
	   $field = ($argument_array['action_for'] == "size") ? 'size' : 'entry_fee' ;
	   $table = ($argument_array['action_for'] == "size") ? $this->db->dbprefix(MASTER_SIZE):$this->db->dbprefix(MASTER_ENTRY_FEE);
	   $condition = ($argument_array['action_from'] == "user") ? " user='1' ": " admin='1' ";        
		$sql   = "SELECT 
				   ".$field."
				FROM 
					".$table." 
				WHERE
					".$condition."
				ORDER BY
					".$field." ASC
				"; 
	   return $this->db->query( $sql )->result_array(); 
	}

	/**
	 * @Summary: This function for return current week from current date.
	 * @access: public
	 * @param:
	 * @return:
	 */
	 
	public function get_current_week($league_id  , $date)
	{
		$sql =  $this->db->select('season_week')
						->from(SEASON_WEEK)
						->where('league_id',$league_id)
						->where('season_week_close_date_time > ',$date)
						->limit('1')
						->get();
		$res = $sql->row_array();      
		return $res['season_week'];
	}

	
		/*INSERT IGNORE FOR ROSTER INSERT UPDATE WITH DIFF PARA*/
	public function insert_ignore_into_batch($table, $data)
	{
		$column_name   = array();
		$update_fields = array();
		$append        = array();

		foreach($data as $i=>$outer)
		{

			$coloumn_data = array();
			foreach ($outer as $FLEXey => $val) 
			{

				if($i == 0)
				{
					$column_name[]   = "`" . $FLEXey . "`";
					$update_fields[] = "`" . $FLEXey . "`" .'=VALUES(`'.$FLEXey.'`)';
				}

				if (is_numeric($val))
				{
					$coloumn_data[] = $val;
				}
				else
				 {
					$coloumn_data[] = "'" . replace_quotes($val) . "'";
				}
			}

			$append[] = " ( ".implode(', ', $coloumn_data). " ) ";
		}

		$sql = "INSERT IGNORE INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES " . implode(', ', $append)  ;
		$this->db->query($sql);
	} 

	
}