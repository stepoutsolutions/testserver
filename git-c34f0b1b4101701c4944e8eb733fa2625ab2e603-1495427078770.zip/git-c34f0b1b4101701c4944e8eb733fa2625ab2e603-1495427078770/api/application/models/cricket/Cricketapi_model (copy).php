<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
set_time_limit(0);

require_once "../package/Api_credential_model.php";

class Cricketapi_model extends MY_Model
{

    private $api;

    function __construct()
    {
        parent::__construct();
        $this->load->model('api_credential_model');
        $this->load->model('Common_model');
        //$this->check_url_hit();
        $this->api = $this->api_credential_model->cricket_cricketapi();
    }

    public function get_access_token()
    {

        $param = array(
            'access_key' => $this->api['access_key'],
            'secret_key' => $this->api['secret_key'],
            'app_id' => $this->api['app_id'],
            'device_id' => $this->api['device_id']
        );

        $ch = curl_init($this->api['api_url'] . 'auth/');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);
        $result = json_decode($response, true);

        return $result['auth']['access_token'];
    }

    /**
     * @Summary: This function used to get all recent seasons (series) list
     * database.
     * @access: public
     * @param:$sports_id
     * @return:
     */
    public function get_recent_league($sports_id)
    {

        $access_token = $this->get_access_token();

        $url = $this->api['api_url'] . 'recent_seasons/?access_token=' . $access_token;

        $series_data = @file_get_contents($url);

        if (!$series_data)
        {
            exit;
        }

        $series_array = @json_decode(gzdecode($series_data), TRUE);

        $league_data = array();

        if ($series_array['status_code'] == 200 && !empty($series_array['data']))
        {
            foreach ($series_array['data'] as $series)
            {

                $series_date_iso = $series['start_date']['iso'];

                $series_scheduled_date = date('Y-m-d H:i:s', strtotime($series_date_iso));
                $series_year = date('Y', strtotime($series_date_iso));

                // Skip this series data if it does not have key or it was past date series
                if ($series['start_date']['iso'] == '' || $series['key'] == '' || $series_year < $this->api['year'])
                {
                    continue;
                }

                $league_data[] = array(
                    "league_uid" => $series['key'],
                    "league_abbr" => $series['short_name'],
                    "league_name" => $series['name'],
                    "sports_id" => $sports_id,
                    "active" => 1,
                    "max_player_per_team" => 6,
                    "league_schedule_date" => $series_scheduled_date
                );
            }
            // Save league (series) data
            if (!empty($league_data))
            {
                //echo "<pre>";print_r($league_data);  die;
                $this->Common_model->replace_into_batch(LEAGUE, $league_data);
                echo "All leagues (series) are inserted.";
            }
        }
        exit();
    }

    /**
     * @Summary: This function for use get match details and teams by leagues (series)
     * database.
     * @access: public
     * @param: $sports_id
     * @return:
     */
    public function get_season_and_team($sports_id)
    {
        if (!empty($sports_id))
        {

            $league_data = $this->get_all_table_data("league_id, league_uid, sports_id", LEAGUE, array('sports_id' => $sports_id));
            //echo "<pre>";print_r( $league_data);die;
            if (!empty($league_data))
            {

                // Get access Token
                $access_token = $this->get_access_token();

                foreach ($league_data as $league)
                {

                    // Get Match list and Teams of this league (series) from API

                    $url = $this->api['api_url'] . "season/" . $league['league_uid'] . "/?access_token=$access_token";

                    $season_data = @file_get_contents($url);

                    if (!$season_data)
                    {
                        exit;
                    }

                    $season_array = @json_decode(gzdecode($season_data), TRUE);

                    $team_data = $team_league = $team_keys = array();


                    if ($season_array['status_code'] == 200 && !empty($season_array['data']))
                    {
                        // Prepare All Teams Data
                        if (!empty($season_array['data']['season']['teams']))
                        {

                            foreach ($season_array['data']['season']['teams'] as $t_key => $team)
                            {
                                if ($team['key'] == '')
                                {
                                    continue;
                                }

                                // Prepare team Data
                                $team_data[] = array(
                                    "sports_id" => $league['sports_id'],
                                    "team_abbr" => $team['board_team_key'],
                                    "team_name" => $team['name'],
                                    "year" => $this->api['year']
                                );

                                // Prepare team League Data
                                $team_league[$league['sports_id'] . '|' . $team['board_team_key'] . '|' . $this->api['year']] = array(
                                    "team_id" => 0,
                                    "team_uid" => $team['key'],
                                    "league_id" => $league['league_id']
                                );

                                // This will be used to set team_uid in season table
                                $team_keys[$team['board_team_key']] = $team['key'];
                            }

                            // Now save Team_Data and Team_League_Data

                            if (!empty($team_data))
                            {

                                // Insert Team data 
                                $this->Common_model->replace_into_batch(TEAM, $team_data);

                                // Get all Team of this sports of current year to map team_id in Team_League relation
                                $team_data = $this->get_all_table_data("team_id, sports_id, team_abbr, year", TEAM, array('sports_id' => $sports_id, 'year' => $this->api['year']));

                                $team_league_data = array();

                                if (!empty($team_data))
                                {

                                    foreach ($team_data as $team)
                                    {

                                        // Map team_id with Team_League data
                                        if (!empty($team_league[$team['sports_id'] . '|' . $team['team_abbr'] . '|' . $team['year']]))
                                        {

                                            $team_league_arr = $team_league[$team['sports_id'] . '|' . $team['team_abbr'] . '|' . $team['year']];
                                            $team_league_arr['team_id'] = $team['team_id'];

                                            $team_league_data[] = $team_league_arr;
                                        }
                                    }
                                }
                                // Insert Team League Data
                                if (!empty($team_league_data))
                                {
                                    $this->Common_model->replace_into_batch(TEAM_LEAGUE, $team_league_data);
                                }

                                echo "<br>League " . $league['league_uid'] . " Teams inserted.";
                            }
                        } // END of All Team Data
                        // Prepare All Matches Data
                        if (!empty($season_array['data']['season']['matches']))
                        {

                            $match_data = array();

                            foreach ($season_array['data']['season']['matches'] as $m_key => $match)
                            {

                                //echo $match['Date'];die;
                                $match_date_iso = $match['start_date']['iso'];

                                $match_scheduled_date = date('Y-m-d H:i:s', strtotime($match_date_iso));
                                $match_year = date('Y', strtotime($match_date_iso));
                                $match_date = date('Y-m-d', strtotime($match_date_iso));

                                if ($match_date_iso == '' || $match['key'] == '')
                                {
                                    continue;
                                }
                                
                                $match_format = CRICKET_ONE_DAY;
                                if($match['format'] == 'one-day')
                                {
                                    $match_format = CRICKET_ONE_DAY;
                                }
                                else if($match['format'] == 'test')
                                {
                                    $match_format = CRICKET_TEST;
                                } 
                                else if($match['format'] == 't20')
                                {
                                    $match_format = CRICKET_T20;
                                }
                                
                                $match_data[] = array(
                                    "league_id" => $league['league_id'],
                                    "season_game_uid" => $match['key'],
                                    "year" => $match_year,
                                    "type" => 'REG',
                                    "format" => $match_format,
                                    "feed_date_time" => $match_date_iso,
                                    "season_scheduled_date" => $match_scheduled_date,
                                    "scheduled_date" => $match_date,
                                    "home_uid" => !empty($team_keys[$match['teams']['a']['key']]) ? $team_keys[$match['teams']['a']['key']] : '', // a team uid 
                                    "away_uid" => !empty($team_keys[$match['teams']['b']['key']]) ? $team_keys[$match['teams']['b']['key']] : '', // b team uid 
                                    "home" => $match['teams']['a']['key'],
                                    "away" => $match['teams']['b']['key'],
                                    "status" => $match['status']
                                );
                            }

                            // Insert All Season match Data

                            if (!empty($match_data))
                            {
                               // echo "<pre>";print_r($match_data); die;

                                $this->Common_model->replace_into_batch(SEASON, $match_data);

                                echo "<br>League " . $league['league_uid'] . " Matches (seasons) inserted.<br>";
                            }
                        }//END of Season Match Data
                    }
                }
            }
        }
        exit();
    }

    /**
     * @Summary: This function for use get player details which is play current year
     * database.
     * @access: public
     * @param:$league_id
     * @return:
     */
    public function get_players($sports_id)
    {

        $team_league = $this->get_team_and_league_by_sports_id($sports_id);

        if (!empty($team_league))
        {

            $access_token = $this->get_access_token();

            foreach ($team_league as $tl)
            {

                //echo '<br>'.$tl['team_uid'].' => '.$tl['league_uid'];

                $url = $this->api['api_url'] . "season/" . $tl['league_uid'] . "/team/" . $tl['team_uid'] . "/?access_token=$access_token";

                $team_data = @file_get_contents($url);

                if (!$team_data)
                {
                    exit;
                }

                $team_array = @json_decode(gzdecode($team_data), TRUE);

                if (!$team_array)
                {
                    exit();
                }

                $data = array();

                if ($team_array['status_code'] == 200 && !empty($team_array['data']))
                {

                    if (!empty($team_array['data']['players']))
                    {

                        //$allowed_positions = $this->get_league_position(8); // $league_id = 8
                        $player_data = $player_team = array();

                        foreach ($team_array['data']['players'] as $p_key => $player)
                        {

                            $position = '';

                            if ($player['identified_roles']['keeper'])
                            {
                                $position = 'WK';
                            }
                            else if ($player['identified_roles']['batsman'] && $player['identified_roles']['bowler'])
                            {
                                $position = 'AR';
                            }
                            else if ($player['identified_roles']['batsman'])
                            {
                                $position = 'BAT';
                            }
                            else if ($player['identified_roles']['bowler'])
                            {
                                $position = 'BOW';
                            }

                            //if (in_array($position, $allowed_positions) && $position != '' && $player['key'] != '' )
                            if ($position != '' && $player['key'] != '')
                            {
                                // Prepare Player data
                                $player_data[] = array(
                                    "player_uid" => $player['key'],
                                    "sports_id" => $sports_id,
                                    "full_name" => $player['full_name'],
                                    "first_name" => $player['name'],
                                    "nick_name" => $player['card_name'],
                                        //"injury_status"     => ''
                                );

                                // Prepare Player Team Relation Data
                                $player_team[$player['key'] . '|' . $sports_id] = array(
                                    "player_id" => 0,
                                    "team_league_id" => $tl['team_league_id'],
                                    "position" => $position,
                                    //"jersey_number"   => $league['league_id'],
                                    //"rank_number"     => $league['league_id'],
                                    //"bye_week"        => $league['league_id'],
                                    //"salary"          => $league['league_id'],
                                    "player_status"   => 1,
                                    "is_deleted" => 0
                                );
                            }
                        }

                        //echo '<pre>'; print_r($player_data); print_r($player_team); die;

                        if (!empty($player_data))
                        {
                            $this->Common_model->replace_into_batch(PLAYER, $player_data);

                            // Get all Team of this sports of current year to map team_id in Team_League relation
                            $player_data = $this->get_all_table_data("player_id, sports_id, player_uid", PLAYER, array('sports_id' => $sports_id));

                            $player_team_data = array();

                            if (!empty($player_data))
                            {

                                $this->mark_player_is_deleted($tl['team_league_id']);

                                foreach ($player_data as $player)
                                {

                                    // Map team_id with Team_League data
                                    if (!empty($player_team[$player['player_uid'] . '|' . $player['sports_id']]))
                                    {

                                        $player_team_arr = $player_team[$player['player_uid'] . '|' . $player['sports_id']];
                                        $player_team_arr['player_id'] = $player['player_id'];

                                        $player_team_data[] = $player_team_arr;
                                    }
                                }
                            }
                            // Insert Team League Data
                            if (!empty($player_team_data))
                            {
                                $this->Common_model->replace_into_batch(PLAYER_TEAM, $player_team_data);
                            }

                            echo "<br>Team [<b>" . $tl['team_uid'] . " (" . $tl['league_uid'] . ")</b>] Players inserted.";
                        }
                    }
                }
            }
        }
        exit;
    }

    public function mark_player_is_deleted($team_league_id)
    {
        $this->db->where("team_league_id", $team_league_id)->update(PLAYER_TEAM, array("is_deleted" => '1'));
    }

    public function get_team_and_league_by_sports_id($sports_id)
    {

        $sql = $this->db->select('T.team_id, TL.team_uid, TL.team_league_id, L.league_id, L.league_uid, , ')
                ->from(TEAM . " AS T")
                ->join(TEAM_LEAGUE . " AS TL", "TL.team_id = T.team_id", 'INNER')
                ->join(LEAGUE . " AS L", "L.league_id = TL.league_id", 'LEFT')
                ->where('T.sports_id', $sports_id)
                ->where('T.year', $this->api['year'])
                ->get();
        //echo $this->db->last_query(); die;

        $result = $sql->result_array();
        return $result;
    }

    /**
     * @Summary: This function for use get game statistics from API which is cuurent played in the field
     * And update database
     * 
     * @access: public
     * @param: $sports_id
     * @return:
     */
    public function get_scores($sports_id)
    {
        $current_game = $this->get_current_season_match($sports_id);

        //echo '<pre>Live Match : ';print_r($current_game);die;

        if (!empty($current_game))
        {

            // Get access token
            $access_token = $this->get_access_token();

            foreach ($current_game as $season_game)
            {

                $season_game_uid = $season_game['season_game_uid'];
                $league_id = $season_game['league_id'];

                $url = $this->api['api_url'] . "match/$season_game_uid/?access_token=$access_token";
                //echo $url;die;

                $match_data = @file_get_contents($url);

                if (!$match_data)
                {
                    exit;
                }

                $match_stats = @json_decode(gzdecode($match_data), TRUE);

                if (!$match_stats)
                {
                    exit();
                }

                $data = array();

                if ($match_stats['status_code'] == 200 && !empty($match_stats['data']))
                {

                    if ($match_stats['data']['card']['status'] != 'notstarted')
                    {

                        // Get Common data and Current stats of match

                        $current_stat = $match_stats['data']['card']['now'];
                        $all_innings = $match_stats['data']['card']['innings'];

                        $current_inning = $current_stat['innings']; // return 1 or 2
                                                
                        $home_team_score = $all_innings['a_'.$current_inning]['runs'];
                        $away_team_score = $all_innings['b_'.$current_inning]['runs'];

                        $comm_data = array(
                            "league_id" => $league_id,
                            "season_game_uid" => $season_game_uid,
                            "week" => 0,
                            "scheduled_date" => $season_game['season_scheduled_date'],
                            "home_team_score" => $home_team_score,
                            "away_team_score" => $away_team_score,
                            "innings" => $current_inning,
                            "minute" => "0"
                        );

                        // Get Player-Team relation 

                        $teams = $match_stats['data']['card']['teams'];

                        $playing_players_a = $playing_players_b = array();
                        $captains = array();

                        if (!empty($teams['a']['match']['playing_xi']))
                        {
                            $playing_players_a = array_fill_keys($teams['a']['match']['playing_xi'], $teams['a']['match']['season_team_key']);
                            $captains[] = $teams['a']['match']['captain'];
                        }
                        if (!empty($teams['b']['match']['playing_xi']))
                        {
                            $playing_players_b = array_fill_keys($teams['b']['match']['playing_xi'], $teams['b']['match']['season_team_key']);
                            $captains[] = $teams['b']['match']['captain'];
                        }
                        $playing_players = array_merge($playing_players_a, $playing_players_b);

                        $palyers_stats = $match_stats['data']['card']['players'];

                        //$allowed_positions = $this->get_league_position(8); // $league_id = 8
                        //$this->change_player_is_deleted(8); // $league_id = 8

                        $stats_data = array();

                        foreach ($palyers_stats as $p_key => $player)
                        {

                            if (!in_array($p_key, array_keys($playing_players)))
                            {
                                continue;
                            }

                            $score_data = array();

                            $plyr_data = array(
                                "team_uid" => $playing_players[$p_key],
                                "player_uid" => $p_key,
                                'is_captain' => ((in_array($p_key, $captains)) ? 1 : 0),
                                "updated_at" => date('Y-m-d H:i:s')
                            );

                            if (!empty($player['match']['innings'][$current_inning]))
                            {

                                $curr_inn_stat = $player['match']['innings'][$current_inning];

                                $score_data = array(
                                    "catch" => !empty($curr_inn_stat['fielding']['catches']) ? $curr_inn_stat['fielding']['catches'] : 0,
                                    "stumping" => !empty($curr_inn_stat['fielding']['stumbeds']) ? $curr_inn_stat['fielding']['stumbeds'] : 0,
                                    "run_out" => !empty($curr_inn_stat['fielding']['runouts']) ? $curr_inn_stat['fielding']['runouts'] : 0,
                                    //"run_out_throw"     => $curr_inn_stat['fielding'][''],
                                    //"run_out_catch"     => $curr_inn_stat['fielding']['']
                                    "batting_runs" => !empty($curr_inn_stat['batting']['runs']) ? $curr_inn_stat['batting']['runs'] : 0,
                                    "batting_dots" => !empty($curr_inn_stat['batting']['dots']) ? $curr_inn_stat['batting']['dots'] : 0,
                                    "batting_balls_faced" => !empty($curr_inn_stat['batting']['balls']) ? $curr_inn_stat['batting']['balls'] : 0,
                                    "batting_fours" => !empty($curr_inn_stat['batting']['fours']) ? $curr_inn_stat['batting']['fours'] : 0,
                                    "batting_sixes" => !empty($curr_inn_stat['batting']['sixes']) ? $curr_inn_stat['batting']['sixes'] : 0,
                                    "batting_strike_rate" => !empty($curr_inn_stat['batting']['strike_rate']) ? $curr_inn_stat['batting']['strike_rate'] : 0.0,
                                    "bowling_overs" => !empty($curr_inn_stat['bowling']['overs']) ? $curr_inn_stat['bowling']['overs'] : 0.0,
                                    "bowling_runs_given" => !empty($curr_inn_stat['bowling']['runs']) ? $curr_inn_stat['bowling']['runs'] : 0,
                                    "bowling_runs_extra" => !empty($curr_inn_stat['bowling']['extras']) ? $curr_inn_stat['bowling']['extras'] : 0,
                                    "bowling_balls_delivered" => !empty($curr_inn_stat['bowling']['balls']) ? $curr_inn_stat['bowling']['balls'] : 0,
                                    "bowling_maiden_overs" => !empty($curr_inn_stat['bowling']['maiden_overs']) ? $curr_inn_stat['bowling']['maiden_overs'] : 0,
                                    "bowling_wickets" => !empty($curr_inn_stat['bowling']['wickets']) ? $curr_inn_stat['bowling']['wickets'] : 0,
                                    //"bowling_wides"         => $curr_inn_stat['bowling'][''],
                                    //"bowling_noballs"       => $curr_inn_stat['bowling'][''],
                                    "bowling_strike_rate" => !empty($curr_inn_stat['bowling']['economy']) ? $curr_inn_stat['bowling']['economy'] : 0.0
                                );
                            }

                            if (!empty($score_data))
                            {
                                $stats_data[] = array_merge($comm_data, $plyr_data, $score_data);
                            }
                        }

                        //echo '<pre>'; print_r($stats_data); die;

                        if (!empty($stats_data))
                        {
                            $this->Common_model->replace_into_batch(GAME_STATISTICS_CRICKET, $stats_data);

                            echo "Match [<b>$season_game_uid</b>] Score Saved.<br>";
                        }
                    }
                }
            }
        }
        exit();
    }


    /**
     * [get_game_statistics_by_game_id :- GET GAME STATICS FROM DATABASE FOR PARTICULAR GAME ID ]
     * @param  [type] $season_game_uid [description]
     * @return [type]          [description]
     */
    private function get_game_statistics_by_game_id($season_game_uid,$sports_id,$league_id)
    {
        $rs = $this->db->select("GSC.*,PT.position", FALSE)
                ->from(GAME_STATISTICS_CRICKET . " AS GSC")
                ->join(PLAYER . " AS P", "P.player_uid = GSC.player_uid", 'LEFT')
                ->join(PLAYER_TEAM . " AS PT", "PT.player_id = P.player_id", 'LEFT')
                ->join(TEAM_LEAGUE . " AS TL", "TL.team_league_id = PT.team_league_id", 'LEFT')
                ->where("GSC.season_game_uid", $season_game_uid)
                ->where("GSC.league_id", $league_id)
                ->where("TL.league_id", $league_id)
                //->where("P.sports_id", $sports_id)
                ->get();
        //echo $this->db->last_query(); die;
        $res = $rs->result_array();
        return $res;
    }

    //Calculate player score after score ad in database through API
    /**
     * @Summary: This function for use calculate player fantasy score with the help of fetch actual player score fron API
     *           or football NFL
     * database.
     * @access: public
     * @param:
     * @return:
     */
    public function calculated_fantasy_score($sports_id)
    {
        // Get All Live Games List 
        $current_game = $this->get_current_season_match($sports_id);

        //echo "<pre>"; print_r($current_game);die;

        if (!empty($current_game))
        {
            
            //print_r($formulas);

            foreach ($current_game as $season_game)
            {   
                // Get All Scoring Rules
                

                $season_game_uid = $season_game['season_game_uid'];
                $league_id = $season_game['league_id'];

                $all_player_scores = array();

                $all_player_testing_var = array();
                
                // Get Match Scoring Statistics to Calculate Fantasy Score
                $game_stats = $this->get_game_statistics_by_game_id($season_game_uid,$season_game['sports_id'],$season_game['league_id']);
                //echo "<pre>";print_r($game_stats);continue;die;
                if (!empty($game_stats))
                {

                    foreach ($game_stats as $player_stats)
                    {
                        $formulas = $this->get_scoring_rules($sports_id, $season_game['format']);
                        //echo "<pre>"; print_r($formulas);continue;die;
                        if(empty($formulas))
                        {
                            continue;
                        }

                        $each_player_score = array(
                                    "season_game_uid" => $player_stats['season_game_uid'],
                                    "player_uid" => $player_stats['player_uid'],
                                    "week" => $player_stats['week'],
                                    "scheduled_date" => $player_stats['scheduled_date'],
                                    "league_id" => $league_id,
                                    "normal_score" => $normal_score = 0,
                                    "bonus_score" => $bonus_score = 0,
                                    "economy_rate_score" => $economy_rate_score = 0,
                                    "strike_rate_score" => $strike_rate_score = 0,
                                    "score" => $score = 0
                        );
                        //echo "<pre>";print_r($each_player_score);continue;
                        $normal_testing_var = $bonus_testing_var = $economy_rate_testing_var = $strike_rate_testing_var = array();

                        /* ####### NORMAL SCORING RULE ########### */

                        // Playing 11
                        if ($player_stats['player_uid'])
                        {
                            $normal_score = $normal_score + (1 * $formulas['normal']['PLAYING_X1'] );
                            $normal_testing_var['Playing'] = ( 1 * $formulas['normal']['PLAYING_X1'] );
                        }
                        // Runs
                        if ($player_stats['batting_runs'] > 0)
                        {
                            $normal_score = $normal_score + ($player_stats['batting_runs'] * $formulas['normal']['EVERY_RUN'] );
                            $normal_testing_var['Runs'] = ( $player_stats['batting_runs'] * $formulas['normal']['EVERY_RUN'] );
                        }
                        //Wickets
                        if ($player_stats['bowling_wickets'] > 0)
                        {
                            $normal_score = $normal_score + ($player_stats['bowling_wickets'] * $formulas['normal']['WICKET'] );
                            $normal_testing_var['Wickets'] = ( $player_stats['bowling_wickets'] * $formulas['normal']['WICKET'] );
                        }
                        //Catch
                        if ($player_stats['catch'] > 0)
                        {
                            $normal_score = $normal_score + ($player_stats['catch'] * $formulas['normal']['CATCH'] );
                            $normal_testing_var['Catch'] = ( $player_stats['catch'] * $formulas['normal']['CATCH'] );
                        }

                        //Stumping
                        if ($player_stats['stumping'] > 0)
                        {
                            $normal_score = $normal_score + ($player_stats['stumping'] * $formulas['normal']['STUMPING'] );
                            $normal_testing_var['Stumping'] = ( $player_stats['stumping'] * $formulas['normal']['STUMPING'] );
                        }

                        //Runout 
                        if ($player_stats['run_out'] > 0)
                        {
                            $normal_score = $normal_score + ($player_stats['run_out'] * $formulas['normal']['RUN_OUT'] );
                            $normal_testing_var['Runout'] = ( $player_stats['run_out'] * $formulas['normal']['RUN_OUT'] );
                        }

                        //Dismissal for duck (batsmen, wicket-keeper and all-rounders)
                        if ($player_stats['batting_runs'] == 0 && $player_stats['position'] != 'BOW')
                        {
                            $normal_score = $normal_score + (1 * $formulas['normal']['DUCK'] );
                            $normal_testing_var['Duck'] = ( 1 * $formulas['normal']['DUCK'] );
                        }
                        //echo $normal_score;die;
                        /* ####### NORMAL SCORING RULE END ########### */

                        /* ####### Bonus SCORING ########### */

                        // Fours Bonus
                        if ($player_stats['batting_fours'] > 0)
                        {
                            $bonus_score = $bonus_score + ($player_stats['batting_fours'] * $formulas['bonus']['EVERY_FOUR'] );
                            $bonus_testing_var['Fours'] = ( $player_stats['batting_fours'] * $formulas['bonus']['EVERY_FOUR'] );
                        }
                        // Sixes Bonus
                        if ($player_stats['batting_sixes'] > 0)
                        {
                            $bonus_score = $bonus_score + ($player_stats['batting_sixes'] * $formulas['bonus']['EVERY_SIX'] );
                            $bonus_testing_var['Sixes'] = ( $player_stats['batting_sixes'] * $formulas['bonus']['EVERY_SIX'] );
                        }

                        // Century Runs Bonus
                        if ($player_stats['batting_runs'] >= 50 && $player_stats['batting_runs'] < 100)
                        {
                            $bonus_score = $bonus_score + ( $formulas['bonus']['HALF_CENTURY'] );
                            $bonus_testing_var['Half Century'] = ( $formulas['bonus']['HALF_CENTURY'] );
                        }
                        else if ($player_stats['batting_runs'] >= 100 && $player_stats['batting_runs'] < 150)
                        {
                            $bonus_score = $bonus_score + ( $formulas['bonus']['CENTURY'] );
                            $bonus_testing_var['Century'] = ( $formulas['bonus']['CENTURY'] );
                        }
                        else if ($player_stats['batting_runs'] >= 150 && $player_stats['batting_runs'] < 200)
                        {
                            $bonus_score = $bonus_score + ( $formulas['bonus']['CENTURY'] + $formulas['bonus']['HALF_CENTURY'] );
                            $bonus_testing_var['Century+50'] = ( $formulas['bonus']['CENTURY'] );
                        }
                        else if ($player_stats['batting_runs'] >= 200)
                        {
                            $bonus_score = $bonus_score + ( $formulas['bonus']['CENTURY'] + $formulas['bonus']['CENTURY'] );
                            $bonus_testing_var['Century+100'] = ( $formulas['bonus']['CENTURY'] );
                        }

                        // Maiden Overs Bonus
                        if($season_game['format'] != CRICKET_TEST)
                        {
                            if ($player_stats['bowling_maiden_overs'] > 0)
                            {
                                $bonus_score = $bonus_score + ($player_stats['bowling_maiden_overs'] * $formulas['bonus']['MAIDEN_OVER'] );
                                $bonus_testing_var['Maiden Over'] = ( $player_stats['bowling_maiden_overs'] * $formulas['bonus']['MAIDEN_OVER'] );
                            }
                        }    
                        

                        // Wickets Bonus
                        if ($player_stats['bowling_wickets'] == 4)
                        {
                            $bonus_score = $bonus_score + ( $formulas['bonus']['FOUR_WICKET'] );
                            $bonus_testing_var['Four wickets'] = ( $formulas['bonus']['FOUR_WICKET'] );
                        }
                        else if ($player_stats['bowling_wickets'] >= 5)
                        {
                            $bonus_score = $bonus_score + ( $formulas['bonus']['FIVE_WICKET'] );
                            $bonus_testing_var['Five Wickets'] = ( $formulas['bonus']['FIVE_WICKET'] );
                        }

                        /* ####### Bonus SCORING END  ########### */

                          /* ###### ECONOMY RATE  ########## */
                        // FOR T20
                        if($season_game['format'] == CRICKET_T20)
                        {
                            if ($player_stats['bowling_overs'] >= $formulas['economy_rate']['MINIMUM_BOWLING_OVER'])
                            {
                                if ($player_stats['bowling_strike_rate'] < 4)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BELOW_4'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BELOW_4'] );
                                }                               
                                elseif ($player_stats['bowling_strike_rate'] >= 4 && $player_stats['bowling_strike_rate'] <= 4.99)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_4_499'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BETWEEN_4_499'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] >= 5 && $player_stats['bowling_strike_rate'] <= 6)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_5_6'] );
                                    $economy_rate_testing_var['Economy Rrate'] = ( $formulas['economy_rate']['BETWEEN_5_6'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] >= 9 && $player_stats['bowling_strike_rate'] <= 10)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_9_10'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BETWEEN_9_10'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] >= 10.1 && $player_stats['bowling_strike_rate'] <= 11)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_101_11'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BETWEEN_101_11'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] > 11)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['ABOVE_11'] );
                                    $economy_rate_testing_var['Economyrate'] = ( $formulas['economy_rate']['ABOVE_11'] );
                                }
                            } 
                        } 

                        // FOR ODI
                        if($season_game['format'] == CRICKET_ONE_DAY)
                        {
                            if ($player_stats['bowling_overs'] >= $formulas['economy_rate']['MINIMUM_BOWLING_OVER'])
                            {
                                if ($player_stats['bowling_strike_rate'] < 2.5)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BELOW_25'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BELOW_25'] );
                                }                               
                                elseif ($player_stats['bowling_strike_rate'] >= 2.5 && $player_stats['bowling_strike_rate'] <= 3.49)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_25_349'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BETWEEN_25_349'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] >= 3.5 && $player_stats['bowling_strike_rate'] <= 4.5)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_35_45'] );
                                    $economy_rate_testing_var['Economy Rrate'] = ( $formulas['economy_rate']['BETWEEN_35_45'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] >= 7 && $player_stats['bowling_strike_rate'] <= 8)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_7_8'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BETWEEN_7_8'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] >= 8.1 && $player_stats['bowling_strike_rate'] <= 9)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['BETWEEN_81_9'] );
                                    $economy_rate_testing_var['Economy Rate'] = ( $formulas['economy_rate']['BETWEEN_81_9'] );
                                }
                                elseif ($player_stats['bowling_strike_rate'] > 9)
                                {
                                    $economy_rate_score = $economy_rate_score + ( $formulas['economy_rate']['ABOVE_9'] );
                                    $economy_rate_testing_var['Economyrate'] = ( $formulas['economy_rate']['ABOVE_9'] );
                                }
                            } 
                        }   
                        
                        /* ###### ECONOMY RATE END  ########## */


                        /* ###### STRIKE RATE  ########## */
                        // FOR T20
                        if($season_game['format'] == CRICKET_T20)
                        {  
                            if ($player_stats['batting_balls_faced'] >= $formulas['strike_rate']['MINIMUM_BALL'])
                            {
                                if ($player_stats['batting_strike_rate'] < 50)
                                {
                                    $strike_rate_score = $strike_rate_score + ( $formulas['strike_rate']['BELOW_50'] );
                                    $economy_rate_testing_var['Strike Rate'] = ( $formulas['strike_rate']['BELOW_50'] );
                                }
                                elseif ($player_stats['batting_strike_rate'] >= 50 && $player_stats['batting_strike_rate'] <= 59.9)
                                {
                                    $strike_rate_score = $strike_rate_score + ( $formulas['strike_rate']['BETWEEN_50_599'] );
                                    $economy_rate_testing_var['Strike Rate'] = ( $formulas['strike_rate']['BETWEEN_50_599'] );
                                }
                                elseif ($player_stats['batting_strike_rate'] >= 60 && $player_stats['batting_strike_rate'] <= 70)
                                {
                                    $strike_rate_score = $strike_rate_score + ( $formulas['strike_rate']['BETWEEN_60_70'] );
                                    $economy_rate_testing_var['Strike Rate'] = ( $formulas['strike_rate']['BETWEEN_60_70'] );
                                }
                            }
                        } 

                        if($season_game['format'] == CRICKET_ONE_DAY)
                        {  
                            if ($player_stats['batting_balls_faced'] >= $formulas['strike_rate']['MINIMUM_BALL'])
                            {
                                if ($player_stats['batting_strike_rate'] < 40)
                                {
                                    $strike_rate_score = $strike_rate_score + ( $formulas['strike_rate']['BELOW_50'] );
                                    $economy_rate_testing_var['Strike Rate'] = ( $formulas['strike_rate']['BELOW_50'] );
                                }
                                elseif ($player_stats['batting_strike_rate'] >= 40 && $player_stats['batting_strike_rate'] <= 49.9)
                                {
                                    $strike_rate_score = $strike_rate_score + ( $formulas['strike_rate']['BETWEEN_40_499'] );
                                    $economy_rate_testing_var['Strike Rate'] = ( $formulas['strike_rate']['BETWEEN_40_499'] );
                                }
                                elseif ($player_stats['batting_strike_rate'] >= 50 && $player_stats['batting_strike_rate'] <= 60)
                                {
                                    $strike_rate_score = $strike_rate_score + ( $formulas['strike_rate']['BETWEEN_50_60'] );
                                    $economy_rate_testing_var['Strike Rate'] = ( $formulas['strike_rate']['BETWEEN_50_60'] );
                                }
                            }
                        }   
                        /* ###### STRIKE RATE END  ########## */

                      

                        $each_player_score['normal_score'] = floatval($normal_score);
                        $each_player_score['bonus_score'] = floatval($bonus_score);
                        $each_player_score['economy_rate_score'] = floatval($economy_rate_score);
                        $each_player_score['strike_rate_score'] = floatval($strike_rate_score);

                        $all_player_testing_var[$player_stats['player_uid']]['normal'][$player_stats['innings']] = $normal_testing_var;
                        $all_player_testing_var[$player_stats['player_uid']]['bonus'][$player_stats['innings']] = $bonus_testing_var;
                        $all_player_testing_var[$player_stats['player_uid']]['economy_rate'][$player_stats['innings']] = $economy_rate_testing_var;
                        $all_player_testing_var[$player_stats['player_uid']]['strike_rate'][$player_stats['innings']] = $strike_rate_testing_var;

                        if (array_key_exists($player_stats['player_uid'], $all_player_scores) && array_key_exists('normal_score', $all_player_scores[$player_stats['player_uid']]))
                        {
                            $each_player_score['normal_score'] = $all_player_scores[$player_stats['player_uid']]['normal_score'] = $all_player_scores[$player_stats['player_uid']]['normal_score'] + $each_player_score['normal_score'];
                        }
                        
                        if (array_key_exists($player_stats['player_uid'], $all_player_scores) && array_key_exists('bonus_score', $all_player_scores[$player_stats['player_uid']]))
                        {
                            $each_player_score['bonus_score'] = $all_player_scores[$player_stats['player_uid']]['bonus_score'] = $all_player_scores[$player_stats['player_uid']]['bonus_score'] + $each_player_score['bonus_score'];
                        }

                        if (array_key_exists($player_stats['player_uid'], $all_player_scores) && array_key_exists('economy_rate_score', $all_player_scores[$player_stats['player_uid']]))
                        {
                            $each_player_score['economy_rate_score'] = $all_player_scores[$player_stats['player_uid']]['economy_rate_score'] = $all_player_scores[$player_stats['player_uid']]['economy_rate_score'] + $each_player_score['economy_rate_score'];
                        }

                        if (array_key_exists($player_stats['player_uid'], $all_player_scores) && array_key_exists('strike_rate_score', $all_player_scores[$player_stats['player_uid']]))
                        {
                            $each_player_score['strike_rate_score'] = $all_player_scores[$player_stats['player_uid']]['strike_rate_score'] = $all_player_scores[$player_stats['player_uid']]['strike_rate_score'] + $each_player_score['strike_rate_score'];
                        }

                        $all_player_scores[$player_stats['player_uid']] = $each_player_score;
                         //echo "<pre>";print_r($all_player_scores);//die;
                        $all_player_scores[$player_stats['player_uid']]['break_down'] = json_encode($all_player_testing_var[$player_stats['player_uid']]);
                    }
                    //echo "<pre>";print_r($all_player_scores);die;
                }// End  of  Empty of game_ stats
               //echo "<pre>";print_r($all_player_scores);die;
                if(!empty($all_player_scores))
                {
                    $this->save_player_scoring($all_player_scores);
                    echo "Calculate fantasy Point for Match [<b>$season_game_uid</b>]<br>";
                }    
            }// End of Team loop  
        } // End of Empty team check

        exit();
    }

    /* Save individual player score on table based on game id */

    protected function save_player_scoring($player_score)
    {
        $table_value = array();
        $sql = "REPLACE INTO " . $this->db->dbprefix(GAME_PLAYER_SCORING) . " (season_game_uid, player_uid, week, scheduled_date, normal_score, bonus_score, economy_rate_score, strike_rate_score, score, league_id, break_down)
                            VALUES ";

        foreach ($player_score as $player_unique_id => $value)
        {
            $main_score = $value['normal_score'] + $value['bonus_score'] + $value['economy_rate_score'] + $value['strike_rate_score'];

            $str = " ('" . $value['season_game_uid'] . "','" . $value['player_uid'] . "','" . $value['week'] . "','" . $value['scheduled_date'] . "','" . $value['normal_score'] . "','" . $value['bonus_score'] . "','" . $value['economy_rate_score'] . "','" . $value['strike_rate_score'] . "','" . $main_score . "','" . $value['league_id'] . "','" . $value['break_down'] . "' )";

            $table_value[] = $str;
        }

        $sql .= implode(", ", $table_value);

        $this->db->query($sql);
    }



}
