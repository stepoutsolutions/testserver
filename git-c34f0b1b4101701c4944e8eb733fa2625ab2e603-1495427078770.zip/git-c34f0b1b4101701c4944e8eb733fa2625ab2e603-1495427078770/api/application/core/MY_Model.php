<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MY_Model extends CI_Model {

	public function __construct()
	{
		// Call the Model constructor
		parent::__construct();		
	}

	public function insert_batch( $data )
	{
		$this->db->insert_batch( $this->table_name , $data );         
		if ($this->db->affected_rows() > 0 )
		{
			return TRUE;
		}
		
		return FALSE;       
	}

	public function get_all_table_data($column,$table,$league_id)
	{
		$sql = $this->db->select($column)
						->from($table)
						->where($league_id)
						->get();
		return $sql->result_array();
	}
/**********************USE IN SPORTS MODEL************************************************/

	/**
	 * @Summary: This function for use check attribute existing on array or not
	 * @access: protected
	 * @param:$key, $arry
	 * @return: return exist value or assing value
	 */
	protected function check_value_exist($key, $arry)
	{
		if(array_key_exists($key,$arry))
		{
			return floatval($arry[$key]);
		}else
		{
			return "0.00";
		}
	}
	
	/**
	 * @Summary: This function for use check URL hit by Webbrowser or schedular by cron(wget)
	 * @access: protected
	 * @param:
	 * @return: true or false
	 */
	protected function check_url_hit()
	{
		return TRUE;
		//Check url hit by server or manual
		if ( ENVIRONMENT == 'production'  )
		{
			$http_user_agent = substr($_SERVER['HTTP_USER_AGENT'],0,4);
			if(strtolower($http_user_agent) != 'wget')
			{
				redirect('');
			}
		}	
		return TRUE;
	}
	
	
	public function get_current_season_match($sports_id = '')
    {
        $interval = game_interval($sports_id); // for default interval

        $current_date_time = format_date();
        // $current_date_time =  '2014-08-16 11:45:00';
        $this->db->select("S.home, S.home_uid, S.away, S.away_uid, S.api_week, S.week, S.season_game_uid, S.league_id, S.feed_date_time, S.season_scheduled_date, S.format, L.sports_id")
                ->from(SEASON . " AS S")
                ->join(LEAGUE . " AS L", "L.league_id = S.league_id", "left");
                //->join(TEAM_LEAGUE." AS TLH","TLH.team_id = S.home_id and TLH.league_id = '".$league_id."'","left")
                //->join(TEAM_LEAGUE." AS TLA","T2.team_id = S.away_id and T.league_id = '".$league_id."'","left")
        $this->db->where("DATE_FORMAT ( S.season_scheduled_date ,'%Y-%m-%d %H:%i:%s' ) <='" . $current_date_time . "'");
        $this->db->where("L.active", '1');
        if($sports_id == 7)
        {
            $this->db->where("DATE_FORMAT ( S.season_scheduled_date ,'%Y-%m-%d %H:%i:%s' ) >= DATE_SUB('" . $current_date_time . "' , INTERVAL (CASE WHEN (S.format = ".CRICKET_ONE_DAY.") THEN " . game_interval('7_1') . " WHEN (S.format = ".CRICKET_TEST.") THEN " . game_interval('7_2') . " WHEN (S.format = ".CRICKET_T20.") THEN " . game_interval('7_3') . " END) HOUR)");
        } 
        else 
        {
            $this->db->where("DATE_FORMAT ( S.season_scheduled_date ,'%Y-%m-%d %H:%i:%s' ) >= DATE_SUB('" . $current_date_time . "' , INTERVAL " . $interval . " HOUR)");
        }
                
        if(!empty($sports_id))
        {
            $this->db->where("L.sports_id", $sports_id);
        }
        $this->db->group_by("S.season_game_uid");
        $sql = $this->db->get();
        //echo $this->db->last_query(); die;
        $matches = $sql->result_array();
        return $matches;
    }

      /**
     * @Summary: This function for use get scoring formula wich is store in master_scoring_category table    
     * @access: protected
     * @param: $league_id 
     * @return: resuly array
     */
    protected function get_scoring_rules($sports_id, $format = '')
    {

        $this->db->select('ms.score_points, ms.master_scoring_category_id, ms.format, ms.meta_key, msc.scoring_category_name')
                ->from(MASTER_SCORING_RULES . " AS ms")
                ->join(MASTER_SCORING_CATEGORY . " AS msc", "msc.master_scoring_category_id= ms.master_scoring_category_id", "left")
                ->where('msc.sports_id', $sports_id);

        if (!empty($format))
        {
            $this->db->where('ms.format', $format);
        }

        $rs = $this->db->get();

        $raw_formula_data = $rs->result_array();
        //echo $this->db->last_query();die;

        $formula = array();
        foreach ($raw_formula_data as $val)
        {
            $formula[$val['scoring_category_name']][$val['meta_key']] = $val['score_points'];
        }

        return $formula;
    }


	/**
	 * @Summary: This function for use set season week in season_week table  as per our requirement like Thusday-Wednesday
	 * @access: protected
	 * @param: $league_id,$season_type,$season_year
	 * @return: 
	 */
	protected function set_season_week($league_id,$season_type,$season_year)
	{
		
		$sql = $this->db->select("MAX(scheduled_date) AS max_date ,MIN(scheduled_date) AS min_date")
						->from(SEASON)
						->where("league_id",$league_id)
						->where("type",$season_type)
						->where("year",$season_year) 
						->get();	
		$result = $sql->row_array();		
		// echo "<pre>";print_r($result);die;   
		//echo "<pre>";print_r($result['min_date']);
		//echo "<pre>";print_r($result['max_date']);
		//delete week from table
		if(!empty($result))
		{
			$this->db->delete(SEASON_WEEK,array('league_id' => $league_id,'type'=>$season_type));
			
			$start_day = '';
			$end_day = '';
			//get start & end day in week from DB
			$query = $this->db->get_where(MASTER_LEAGUE_WEEK,array('league_id'=>$league_id));
			if($query->num_rows() > 0)
			{
				$res = $query->row_array();
				$start_day = $res['start_week_day'];
				$end_day = $res['end_week_day'];
			}
			
			$predate = strtotime($result['min_date']);
			$nextdate = strtotime($result['max_date']);
			//echo strtoupper(date('l', $predate));die;
			if(strtoupper(date('l', $predate)) != strtoupper($start_day))
				$previous_date = date('Y-m-d', strtotime('previous '.$start_day, strtotime($result['min_date'])));
			else
				$previous_date = $result['min_date'];
			if(strtoupper(date('l', $nextdate)) != strtoupper($end_day))		
				$next_date = date('Y-m-d', strtotime('next '.$end_day, strtotime($result['max_date'])));
			else
				$next_date = $result['max_date'];

			$startdate = strtotime($previous_date);
			$enddate = strtotime($next_date);
			
			$weeks = array();
			
			while ($startdate < $enddate)
			{  
				$weeks[] = date('W', $startdate); 
				$startdate += strtotime('+1 week', 0);
			}
			
			$season_week 					= 1;
			$season_week_start_date_time 	= date('Y-m-d 00:00:00',strtotime($previous_date));
			$season_week_end_date_time 		= date('Y-m-d 23:59:59', strtotime('next '.$end_day, strtotime($previous_date)));
			$season_week_close_date_time	= date('Y-m-d 23:59:59', strtotime('next '.$end_day, strtotime($previous_date)));
			//echo "<pre>";print_r($weeks);die; 
			for($i=1;$i <= count($weeks);$i++)
			{
				//echo "<pre>";
				//echo $season_week.'-'.$season_week_start_date_time.'-'.$season_week_end_date_time.'-'.$season_week_close_date_time;
				$data = array(
								'type'          			    => trim($season_type),
								'season_week'          			=> trim($season_week),
								'season_week_start_date_time' 	=> trim($season_week_start_date_time),
								'season_week_end_date_time'     => trim($season_week_end_date_time),
								'season_week_close_date_time'   => trim($season_week_close_date_time),
								'league_id'         			=> $league_id
							);	
				
				//Insert data into database
				$this->db->insert(SEASON_WEEK, $data);
				
				$season_week 					= $season_week+1;
				$season_week_start_date_time	= date('Y-m-d 00:00:00', strtotime('next '.$start_day, 
																		 strtotime($season_week_start_date_time)));
				$season_week_end_date_time 		= date('Y-m-d 23:59:59', strtotime('next '.$end_day, 
																		 strtotime($season_week_end_date_time)));
				$season_week_close_date_time	= date('Y-m-d 23:59:59', strtotime('next '.$end_day, 
																		 strtotime($season_week_close_date_time)));
			}
		}	
	}

	//for soccer only now
	protected function create_season_week($league_id , $season , $year )
	{
		$sql = $this->db->select("MAX(scheduled_date) AS max_date ,MIN(scheduled_date) AS min_date")
						->from(SEASON)
						->where("league_id",$league_id)
						->where("type",$season)
						->where("year",$year) 
						->group_by('api_week')
						->order_by('api_week','ASC')
						->get();	
		$result = $sql->result_array();		
		//echo "<pre>";print_r($result);die;
		if(!empty($result))
		{
			foreach ($result as $key => $value) 
			{
				$data[] = array(
									'type'          			    => trim($season),
									'season_week'          			=> trim($key+1),
									'season_week_start_date_time' 	=> trim($value['min_date'].' 00:00:00'),
									'season_week_end_date_time'     => trim($value['max_date'].' 23:59:59'),
									'season_week_close_date_time'   => trim($value['max_date'].' 23:59:59'),
									'league_id'         			=> $league_id
								);
			}							
		} 

		if(!empty($data))
		{
			//echo "<pre>";print_r($data);die;
			$this->db->delete(SEASON_WEEK,array('league_id' => $league_id,'type'=>$season));
			$this->Common_model->replace_into_batch(SEASON_WEEK, $data);
		}	
	}			
	
	/**
	 * @Summary: This function for use update season week in season table from season_week table  
	 * @access: protected
	 * @param: $league_id,$season_type,$season_year
	 * @return: 
	 */
	protected function update_season_week($league_id,$season_type,$season_year)
	{		
		$sql = $this->db->select("DATE_FORMAT(season_week_start_date_time,'%Y-%m-%d') AS start_date,DATE_FORMAT(season_week_end_date_time,'%Y-%m-%d') AS end_date",FALSE)
						->from(SEASON_WEEK)
						->where("league_id",$league_id)
						->where("type","$season_type")
						->order_by("season_week","ASC")
						->get();

		$result = $sql->result_array();
		//echo "<pre>";print_r($result);	
		if(!empty($result))
		{
			foreach($result as $key=>$value)
			{
				$sql = $this->db->select("season_game_unique_id")
								->from(SEASON)
								->where("league_id",$league_id)
								->where("scheduled_date BETWEEN '".$value['start_date']."' AND '".$value['end_date']."'")
								->where("type","$season_type")
								->where("year","$season_year")
								->get();

				$result2 = $sql->result_array();
				//echo "<pre>";print_r($result2);	
				if(!empty($result2))
				{
					$season_game_unique_id = array();
					for($i=0;$i<count($result2);$i++)
					{
						$season_game_unique_id[] =  $result2[$i]['season_game_unique_id'];
					}
					$i = $key+1;

					$this->db->where("league_id",$league_id)
							->where("type","$season_type")
							->where("year","$season_year")
							->where("season_game_unique_id in (".implode( ',' , array_map( function( $n ){ return '\''.$n.'\''; } , $season_game_unique_id ) ).")")
							->update(SEASON,array("week"=>$i));
					$rs = $this->db->affected_rows();
				}
			}
		}
	}


	//for soccer only now
	protected function update_season_week_rescheduled($league_id , $season , $year )
	{
		$sql = $this->db->select("season_week_start_date_time AS start_date,season_week_end_date_time AS end_date")
						->from(SEASON_WEEK)
						->where("league_id",$league_id)
						->where("type",$season)
						->order_by('season_week','ASC')
						->get();	
		$result = $sql->result_array();		
		//echo "<pre>";print_r($result);die;
		if(!empty($result))
		{
			$previoid_end_date = "";
			foreach ($result as $key => $value) 
			{
				//echo $key.'-';echo $value['start_date'];echo "--";print_r($value['end_date']);echo "<pre>" ;
				//echo $previoid_end_date.'-'.$value['end_date'];echo "<pre>";
				if(strtotime($previoid_end_date) > strtotime($value['start_date']))
				{
					//echo "<pre>" ;echo $key;echo "<pre>";die;
					$sql = "SELECT 
								scheduled_date
							FROM 
								".$this->db->dbprefix(SEASON)."	
							WHERE
								league_id = $league_id	
							AND
								type = 	'".$season."'
							AND
								year = 	$year	
							AND
								week = $key
							AND
								season_scheduled_date < '".$value['start_date']."'
							ORDER BY
								season_scheduled_date DESC
							LIMIT 1			
						   ";
					//echo $sql;
					//echo "<pre>";	   
					$rs = $this->db->query($sql);
					$result1 = $rs->row_array();
					//print_r($result1);echo "<pre>";//continue;die;	 
					if(!empty($result1))
					{	
					  $update_sql = "UPDATE 
										".$this->db->dbprefix(SEASON_WEEK)." 
									SET 
										season_week_end_date_time 	= '".trim($result1['scheduled_date'].' 23:59:59')."',
										season_week_close_date_time = '".trim($result1['scheduled_date'].' 23:59:59')."' 
									WHERE
										`type` =  '".$season."' 
									AND 
										`season_week` = $key
									AND  
										`league_id` = $league_id
									";
						//echo "<pre>";
						$this->db->query($update_sql);
						//echo "<pre>";print_r($result);die;
					}
				 	
				}
				$previoid_end_date = $value['end_date'];	
			}							
		} 
			
	}

	/**
	 * @Summary: This function for use get scoring formula wich is store in master_scoring_category table    
	 * @access: protected
	 * @param: $league_id 
	 * @return: resuly array
	 */
	protected function get_scoring_formula($league_id)
	{

		$rs = $this->db->select("MS.score_position, MS.score_points, MS.master_scoring_category_id,
									MS.meta_key, MSC.scoring_category_name")
						->from($this->db->dbprefix(MASTER_SCORING_RULES). " AS MS")
						->join($this->db->dbprefix(MASTER_SCORING_CATEGORY) . " AS MSC","MSC.master_scoring_category_id = MS.master_scoring_category_id", "LEFT")
						->join($this->db->dbprefix(LEAGUE) . " AS L","L.sports_id = MSC.sports_id")
						->where("L.league_id", $league_id)
						->get();
		// echo $this->db->last_query();
		$res = $rs->result_array();
		
		//return $res;
		
		$raw_formula_data = $res;

		$formula = array();
		foreach ($raw_formula_data as $val) {
			$formula[$val['scoring_category_name']][$val['meta_key']] = $val['score_points'];
		}
		//echo "<pre>";print_r($formula);
		return $formula;
		
	}

	/**
	 * @Summary: This function for use for update node client server to update score run time    
	 * @access: protected
	 * @param: $teams
	 * @return: 
	 */
	protected function update_node_client( $teams )
	{
		//send_email("vinod@vinfotech.com","Test update_node_client cron","Yes (fantasycentrepro LIVE), update_node_client cron working fine");
		debug($teams);//die;
		$FinalScoreResult = array();
		$games            = array();
		foreach ($teams as $key => $team)
		{			
			$sql = $this->db->select("G.game_unique_id")
							->from(GAME." AS G")
							->where("FIND_IN_SET( '".$team['season_game_unique_id']."', G.selected_matches)")
							->where("is_cancel",'0')
							->where("prize_distributed",'0')
							->get();

			$games = $sql->result_array();
			
			if($games&&is_array($games))
			{
				foreach ($games as $games_key => $games_value)
				{
					$game_unique_id = $games_value['game_unique_id'];					
					$sql = $this->db->select("LM.lineup_master_id")
									->from(LINEUP_MASTER." AS LM")
									->where("LM.game_unique_id","$game_unique_id")
									->get();
					$result = $sql->result_array();
					if( $result && isset( $result[0]['lineup_master_id'] ) )
					{
						if( !isset( $FinalScoreResult[$game_unique_id] ) )
						{
							$FinalScoreResult[$game_unique_id] = array();
						}
						foreach( $result as $k => $val )
						{
							$games[$game_unique_id] = $game_unique_id;

							if( !isset( $FinalScoreResult[$game_unique_id][$val['lineup_master_id']] ) )
							{
								$FinalScoreResult[$game_unique_id][$val['lineup_master_id']] = array();
							}
							// $FinalScoreResult[$val['game_unique_id']][$val['lineup_master_id']][$val['player_unique_id']] = $val['score'];
							$sql = "SELECT 
										`L`.`player_unique_id`,`L`.`score` 
									FROM 
										`".$this->db->dbprefix(LINEUP)."` AS `L` 
									WHERE 
										`lineup_master_id` = ".$val['lineup_master_id'];
							$total_score = $this->run_query($sql);
							$FinalScoreResult[$game_unique_id][$val['lineup_master_id']] = $total_score;
						}
					}
					$sqls = "SELECT
								CASE 
									WHEN (`U`.`user_name` IS NULL OR `U`.`user_name` = '' )
									THEN 
									CONCAT(`U`.`first_name`, ' ', `U`.`last_name`) 
									ELSE 
									`U`.`user_name` 
									END AS `name`,`U`.`image`,`U`.`user_id`,`LM`.`lineup_master_id`,`U`.`email`,`LM`.`total_score` 
							FROM 
								`".$this->db->dbprefix(USER)."` AS `U`
							INNER JOIN 
								`".$this->db->dbprefix(LINEUP_MASTER)."` AS `LM` ON `LM` . `user_id` = `U` . `user_id` 
							WHERE 
								`LM`.`game_unique_id` = '" . $game_unique_id . "' 
							ORDER BY 
								`LM`.`total_score` DESC
							";
					$res = $this->run_query($sqls);
					$FinalScoreResult[$game_unique_id]['user_detail'] = $res;

					if( $FinalScoreResult )
					{
						$data_string = json_encode($FinalScoreResult);

						$curlUrl = NODE_ADDR."/recieveScore";
						debug($curlUrl);
						debug($FinalScoreResult);
						$curl = curl_init();
						curl_setopt_array($curl, array(
							CURLOPT_POST           => 1,
							CURLOPT_POSTFIELDS     => $data_string,
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_URL            => $curlUrl,
							CURLOPT_SSL_VERIFYPEER => false
						));
						$result = curl_exec($curl);
						curl_close($curl);
						echo $result;
						$FinalScoreResult = array();
					}
				}
			}
		}
		exit();
	}

	/**
	 * @Summary: This function for use for save player scoring in game player scoring table after calculation of fantasy point    
	 * @access: protected
	 * @param: $game_id, $week, $player_score,$scheduled_date,$league_id
	 * @return: 
	 */
/*	protected function save_player_scoring($game_id, $week, $player_score,$scheduled_date,$league_id)
	{

		//echo "<pre>";print_r($player_score);die;
		$table_value = array();
		$sql = "REPLACE INTO ".$this->db->dbprefix(GAME_PLAYER_SCORING)." (season_game_unique_id, player_unique_id, week, score, scheduled_date,league_id)
				VALUES ";

		foreach ($player_score as $player_id => $value) {

			$str = " ('" . $game_id . "','" . $player_id . "','" . $week . "','" . $value. "','" . $scheduled_date. "','" . $league_id. "' )";

			$table_value[] = $str;
		}

		$sql .= implode(", ", $table_value);

		$this->db->query($sql);
	}*/

	


	protected function get_league_position($league_id ='')
	{
		$rs = $this->db->select('position_name, position_display_name')
						->from(LEAGUE_LINEUP_POSITION ." AS LP")
						->where('LP.league_id', $league_id)
						->get();
		$result = $rs->result_array();

		if(!empty($result)){
			$positions = array();
			foreach($result as $val){
				$positions[] = $val['position_name'];
			}

			return $positions;

		} else {
			return array();
		}


	}

	function isTimeValid($time)
	{
		return is_object(DateTime::createFromFormat('H:i a', $time));
	}

	

	protected function update_player_teamname($league_id )
	{
		$sql = "UPDATE 
						".$this->db->dbprefix(PLAYER)." AS P 
				   	INNER JOIN 
						".$this->db->dbprefix(TEAM)." AS T ON T.team_abbr = P.team_abbreviation AND P.league_id = T.league_id
				   SET 
						P.team_name   = T.team_name, 
						P.team_market = T.team_market
				   WHERE 
						P.league_id = $league_id
				   AND
						T.league_id = $league_id
				  ";
			$this->db->query($sql); 
	}

	public function add_feed_raw_data($data_arr)
	{
		$sql = $this->db->insert(FEED_RAW_DATA,$data_arr);
	}

	public function change_player_is_deleted($league_id)
	{
		$this->db->where("league_id", $league_id)
				->update(PLAYER,array("is_deleted" => '1'));
	}

}
//End of file