<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cricketapi extends MY_Controller
{

    public $sports_id = 7;

    function __construct()
    {

        parent::__construct();

        $this->load->helper('cron');
        $this->load->model('cricket/cricketapi_model', 'cricketapi');
        //$this->load->model('common_model');
        set_time_limit(0);
    }

    public function index()
    {
        redirect('');
    }

    /**
     * @Summary: This function used to get all recent leagues (series) list
     * database.
     * @access: public
     * @return:
     */
    public function get_recent_league()
    {
        $this->cricketapi->get_recent_league($this->sports_id);
    }

    /**
     * @Summary: This function is used to get all league (series) match and its teams
     * database.
     * @access: public
     * @return:
     */
    public function get_season_and_team()
    {
        $this->cricketapi->get_season_and_team($this->sports_id);
    }

    /**
     * @Summary: This function for use get player details which is play current year
     * database.
     * @access: public
     * get_players @return:
     */
    public function get_players()
    {
        $this->cricketapi->get_players($this->sports_id);
    }

    /**
     * @Summary: This function for use get score details of live matches
     * database.
     * @access: public
     * get_players @return:
     */
    public function get_scores()
    {
        $this->cricketapi->get_scores($this->sports_id);
    }

    /**
     * @Summary: This function for use to calculated fantasy score
     * database.
     * @access: public
     * get_players @return:
     */
    public function calculated_fantasy_score()
    {
        $this->cricketapi->calculated_fantasy_score($this->sports_id);
    }


       /**
     * @Summary: This function for use get match status and update in season table by leagues (series)
     * database.
     * @access: public
     * @param: null
     * @return:
     */
    public function update_season_status()
    {
        $this->cricketapi->update_season_status();
    }

}

/* End of file cron.php */
/* Location: ./application/controllers/cron.php */

