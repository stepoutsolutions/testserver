<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once('../config/config.php');
//require_once('../config/redis.php');
switch (ENVIRONMENT) {
	case 'production':
		$config['base_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/api/';
	break;

	case 'testing':
		$config['base_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/api/';
	break;

	default:
		$config['base_url'] = '';
	break;
}