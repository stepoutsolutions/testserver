var vfantasy = angular.module('vfantasy', [
		'ui.router',
		'oc.lazyLoad',
		'ui.bootstrap',
		'ui.bootstrap.pagination',
		'googlechart',
		'angular.filter'
	]);

/* Setup global settings */
vfantasy.factory('settings', ['$rootScope', function($rootScope) {
	// supported languages
	var settings = {
		layout: {
			pageSidebarClosed: false, // sidebar menu state
			pageBodyFullWidth: true, // solid body color state
			pageAutoScrollOnLoad: 1000 // auto scroll to top on page load
		}
	};

	$rootScope.settings = settings;

	return settings;
}]);

// Pagination Config
vfantasy.constant('paginationConfig', {
	boundaryLinks: false,
	directionLinks: true,
	maxSize: 3,
	rotate: true
});

vfantasy.config(['$stateProvider', '$locationProvider', '$httpProvider', '$urlRouterProvider', '$ocLazyLoadProvider', function($stateProvider, $locationProvider, $httpProvider, $urlRouterProvider, $ocLazyLoadProvider) {

	$ocLazyLoadProvider.config({
		debug: true
		// global configs go here
	});

	$urlRouterProvider.otherwise(function($injector){
		$injector.invoke(['$state', function($state) {
			$state.go('404', {}, { location: false } );
		}]);
	});

	$stateProvider.state('404',{
		templateUrl: site_url+'template/errors/_404',
		data: {pageTitle:'404', lang:['_404.js']},
		controller:'CommonCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/_404.js'
					]
				});
			}]
		}
	})
	.state('root',{
		url:'/',
		templateUrl: site_url+'template/auth/login',
		data: {pageTitle:'Site Admin Login', lang:['login.js']},
		controller:'LoginCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/login.js',
						'assets/js/controller/loginController.js'
					]
				});
			}]
		}
	})
	.state('login',{
		url:'/auth/login',
		templateUrl: site_url+'template/auth/login',
		data: {pageTitle:'Site Admin Login', lang:['login.js']},
		controller:'LoginCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/login.js',
						'assets/js/controller/loginController.js'
					]
				});
			}]
		}
	})
	.state('dashboard',{
		url:'/dashboard',
		templateUrl:site_url+'template/dashboard/dashboard',
		data: {pageTitle:'Dashboard', routename:'dashboard', lang:['dashboard.js']},
		controller:'DashboardCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/dashboard.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
						'assets/js/controller/dashboardController.js'
					]
				});
			}]
		}
	})
	.state('roster',{
		url:'/roster',
		templateUrl:site_url+'template/roster/roster',
		data: {pageTitle:'Roster Management', routename:'roster', lang:['roster.js']},
		controller:'RosterCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/uploader/plupload.full.min.js',
						'assets/js/plugins/forms/uploader/plupload.queue.min.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
						'utility/javascript_var/roster.js',
						'assets/js/controller/rosterController.js'
					],
					serie: true
				});
			}]
		}
	})
	.state('import_player',{
		url:'/import_player_roster/:file_name',
		templateUrl:site_url+'template/roster/import_player_roster',
		data: {pageTitle:'Import Player Roster', routename:'import_player_roster', lang:['roster.js']},
		controller:'RosterCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/roster.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
						'assets/js/controller/rosterController.js'
					],
					serie: true
				});
			}]
		}
	})
	.state('user',{
		url:'/user',
		templateUrl:site_url+'template/user/user',
		data: {pageTitle:'Manage User', routename:'user', lang:['user.js']},
		controller:'UserCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/user.js',
						'assets/js/controller/userController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					],
					serie: true
				});
			}]
		}
	})
	.state('user_detail',{
		url:'/user_detail/:user_id',
		templateUrl:site_url+'template/user/user_detail/',
		data: {pageTitle:'User Detail', routename:'user', lang:['user.js']},
		controller:'UserCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/user.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
						'assets/js/controller/userController.js'
					]
				});
			}]
		}
	})
	.state('withdrawal_list',{
		url:'/withdrawal_list',
		templateUrl:site_url+'template/withdrawal/withdrawal_list',
		data: {pageTitle:'Withdrawal List', routename:'withdrawal_list', lang:['withdrawal.js']},
		controller:'WithdrawalCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/withdrawal.js',
						'assets/js/controller/withdrawalController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('transaction_list',{
		url:'/transaction_list',
		templateUrl:site_url+'template/transaction/transaction_list',
		data: {pageTitle:'Transaction List', routename:'transaction_list', lang:['transaction.js']},
		controller:'TransactionCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/transaction.js',
						'assets/js/controller/transactionController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('season',{
		url:'/season',
		templateUrl:site_url+'template/season/season_list',
		data: {pageTitle:'Season Schedule', routename:'season', lang:['season.js']},
		controller:'SeasonCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
                                                'assets/js/plugins/forms/uploader/plupload.full.min.js',
						'assets/js/plugins/forms/uploader/plupload.queue.min.js',
						'utility/javascript_var/season.js',
						'assets/js/controller/seasonController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('seasonstats',{
		url:'/seasonstats/:game_unique_id/:league_id',
		templateUrl:site_url+'template/season/season_stats',
		data: {pageTitle:'Season Stats', routename:'season_stats', lang:['season.js']},
		controller:'SeasonCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/season.js',
						'assets/js/controller/seasonController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
        // for NFL (league 5), seasonstats->statslist
        .state('statslist',{
		url:'/statslist/:game_unique_id/:league_id',
		templateUrl:site_url+'template/stats_feed/stats_list',
		data: {pageTitle:'Season Stats', routename:'season_stats', lang:['season.js']},
		controller:'SeasonCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
                                                'assets/js/plugins/forms/uploader/plupload.full.min.js',
						'assets/js/plugins/forms/uploader/plupload.queue.min.js',
						'utility/javascript_var/season.js',
						'assets/js/controller/seasonController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('new_contest',{
		url:'/new_contest',
		templateUrl:site_url+'template/contest/new_contest',
		data: {pageTitle:'Create Contest', routename:'new_contest', lang:['contest.js']},
		controller:'ContestCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/uploader/plupload.full.min.js',
						'assets/js/plugins/forms/uploader/plupload.queue.min.js',
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/contest.js',
						'assets/js/controller/contestController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
						
					]
				});
			}]
		}
	})
        /*.state('new_turbo_contest',{
		url:'/new_turbo_contest',
		templateUrl:site_url+'template/contest/new_turbo_contest',
		data: {pageTitle:'Create Turbo Lineup Contest', routename:'new_turbo_contest', lang:['contest.js']},
		controller:'ContestCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/uploader/plupload.full.min.js',
						'assets/js/plugins/forms/uploader/plupload.queue.min.js',
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/contest.js',
						'assets/js/controller/contestController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
						
					]
				});
			}]
		}
	})*/
	.state('contest',{
		url:'/contest',
		templateUrl:site_url+'template/contest/contest',
		data: {pageTitle:'Contest List', routename:'contest', lang:['contest.js']},
		controller:'ContestCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/contest.js',
						'assets/js/controller/contestController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('contest_detail',{
		url:'/contest_detail/:game_unique_id',
		templateUrl:site_url+'template/contest/contest_detail',
		data: {pageTitle:'Contest Detail', routename:'contest_detail', lang:['contest.js']},
		controller:'ContestCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/contest.js',
						'assets/js/plugins/forms/validate.min.js',
						'assets/js/controller/contestController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	}) 
	.state('team_roster',{
		url:'/teamroster',
		templateUrl:site_url+'template/team_roster/team_roster',
		data: {pageTitle:'Team Roster', routename:'team_roster', lang:['teamroster.js']},
		controller:'TeamrosterCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/teamroster.js',
						'assets/js/controller/teamrosterController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js',
                                                'assets/js/plugins/forms/uploader/plupload.full.min.js',
						'assets/js/plugins/forms/uploader/plupload.queue.min.js',
					]
				});
			}]
		}
	})
	.state('league',{
		url:'/league',
		templateUrl:site_url+'template/league/league',
		data: {pageTitle:'Leagues', routename:'league', lang:['league.js']},
		controller:'LeagueCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/league.js',
						'assets/js/controller/leagueController.js',
						'assets/js/plugins/forms/uniform.min.js',
						//'assets/js/plugins/forms/select2.min.js',
                        //'assets/js/plugins/forms/uploader/plupload.full.min.js',
						//'assets/js/plugins/forms/uploader/plupload.queue.min.js',
					]
				});
			}]
		}
	})
	.state('change_password',{
		url:'/change_password',
		templateUrl:site_url+'template/setting/change_password',
		data: {pageTitle:'Setting', routename:'change_password', lang:['setting.js']},
		controller:'SettingCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/setting.js',
						'assets/js/controller/settingController.js',
					]
				});
			}]
		}
	})
	.state('change_dates',{
		url:'/change_date',
		templateUrl:site_url+'template/setting/change_date',
		data: {pageTitle:'Setting', routename:'change_date', lang:['setting.js']},
		controller:'SettingCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/setting.js',
						'assets/js/controller/settingController.js',
					]
				});
			}]
		}
	})	
	.state('feed_list',{
		url:'/feeds_list',
		templateUrl:site_url+'template/feeds/raw_feeds',
		data: {pageTitle:'Feed List', routename:'feeds_list', lang:['feeds.js']},
		controller:'FeedsCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/css/json-formatter.min.css',
						'utility/javascript_var/feeds.js',
						'assets/js/plugins/angular/angular-sanitize.min.js.map',
						'assets/js/plugins/angular/angular-sanitize.min.js',
						'assets/js/controller/feedsController.js',
						'assets/js/directive/json-formatter.min.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('user_report',{
		url:'/user_report',
		templateUrl:site_url+'template/report/user_report',
		data: {pageTitle:'User Report', routename:'user_report', lang:['report.js']},
		controller:'ReportCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('user_location',{
		url:'/user_location',
		templateUrl:site_url+'template/report/user_location',
		data: {pageTitle:'User Location', routename:'user_location', lang:['report.js']},
		controller:'UserLocationCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('user_activity',{
		url:'/user_activity',
		templateUrl:site_url+'template/report/user_activity',
		data: {pageTitle:'User Activity Track', routename:'user_activity', lang:['report.js']},
		controller:'UserActivityCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('usersmoneypaid',{
		url:'/user_money_paid',
		templateUrl:site_url+'template/report/user_money_paid',
		data: {pageTitle:'User Money Paid By Users', routename:'user_money_paid', lang:['report.js']},
		controller:'UserMoneyPaidCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('user_deposit_amount',{
		url:'/user_deposit_amount',
		templateUrl:site_url+'template/report/user_deposit_amount',
		data: {pageTitle:'User Deposit Amount', routename:'user_deposit_amount', lang:['report.js']},
		controller:'UserDepositAmountCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('contest_report',{
		url:'/contest_report',
		templateUrl:site_url+'template/report/contest_report',
		data: {pageTitle:'Contest Report', routename:'contest_report', lang:['report.js']},
		controller:'ReportCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('contest_users_report',{
		url:'/contest_users_report',
		templateUrl:site_url+'template/report/contest_users_report',
		data: {pageTitle:'Contest Users Report', routename:'contest_users_report', lang:['report.js']},
		controller:'ReportCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/report.js',
						'assets/js/controller/reportController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('new_advertisement',{
		url:'/new_advertisement',
		templateUrl:site_url+'template/advertisement/new_advertisement',
		data: {pageTitle:'New Advertisement', routename:'new_advertisement', lang:['advertisement.js']},
		controller:'AdvertisementCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'assets/js/plugins/ajaxupload.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/controller/advertisementController.js',
						'assets/js/plugins/forms/uniform.min.js',
						'utility/javascript_var/advertisement.js',
					]
				});
			}]
		}
	})
	.state('advertisement',{
		url:'/advertisement',
		templateUrl:site_url+'template/advertisement/advertisement',
		data: {pageTitle:'Advertisement List', routename:'advertisement', lang:['advertisement.js']},
		controller:'AdvertisementCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/advertisement.js',
						'assets/js/controller/advertisementController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('sales_persons',{
		url:'/sales_person',
		templateUrl:site_url+'template/promo_code/sales_person',
		data: {pageTitle:'Promo Code', routename:'sales_person', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('new_sales_persons',{
		url:'/new_sales_person',
		templateUrl:site_url+'template/promo_code/new_sales_person',
		data: {pageTitle:'Create Sales Person', routename:'new_sales_person', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('edit_sales_person',{
		url:'/edit_sales_person/:sales_person_id',
		templateUrl:site_url+'template/promo_code/edit_sales_person',
		data: {pageTitle:'Edit Sales Person', routename:'edit_sales_person', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('sales_person_detail',{
		url:'/sales_person_detail/:sales_person_id',
		templateUrl:site_url+'template/promo_code/sales_person_detail',
		data: {pageTitle:'Sales Person Detail', routename:'sales_person_detail', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('promo_code',{
		url:'/promo_code',
		templateUrl:site_url+'template/promo_code/promo_code',
		data: {pageTitle:'Promo Code', routename:'promo_code', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('new_promo_codes',{
		url:'/new_promo_code',
		templateUrl:site_url+'template/promo_code/new_promo_code',
		data: {pageTitle:'Create New Promo Code', routename:'new_promo_code', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('promo_code_details',{
		url:'/promo_code_detail/:promo_code',
		templateUrl:site_url+'template/promo_code/promo_code_detail',
		data: {pageTitle:'PromoCode Detail', routename:'promo_code_detail', lang:['promo_code.js']},
		controller:'PromocodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/promo_code.js',
						'assets/js/controller/promocodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})	
	.state('bonus_code',{
		url:'/bonus_code',
		templateUrl:site_url+'template/bonus_code/bonus_code',
		data: {pageTitle:'Bonus Code', routename:'bonus_code', lang:['bonus_code.js']},
		controller:'BonuscodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/bonus_code.js',
						'assets/js/controller/bonuscodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('new_bonus_codes',{
		url:'/new_bonus_code',
		templateUrl:site_url+'template/bonus_code/new_bonus_code',
		data: {pageTitle:'Create New Promo Code', routename:'new_bonus_code', lang:['bonus_code.js']},
		controller:'BonuscodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/bonus_code.js',
						'assets/js/controller/bonuscodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('bonus_code_details',{
		url:'/bonus_code_detail/:bonus_code',
		templateUrl:site_url+'template/bonus_code/bonus_code_detail',
		data: {pageTitle:'PromoCode Detail', routename:'bonus_code_detail', lang:['bonus_code.js']},
		controller:'BonuscodeCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/bonus_code.js',
						'assets/js/controller/bonuscodeController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('manage_referrals',{
		url:'/manage_referrals',
		templateUrl:site_url+'template/setting/manage_referrals',
		data: {pageTitle:'Setting', routename:'manage_referrals', lang:['setting.js']},
		controller:'SettingCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/setting.js',
						'assets/js/controller/settingController.js'
					]
				});
			}]
		}
	})
	.state('update_referral_amounts',{
		url:'/update_referral_amount',
		templateUrl:site_url+'template/setting/update_referral_amount',
		data: {pageTitle:'Setting', routename:'update_referral_amount', lang:['setting.js']},
		controller:'SettingCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/setting.js',
						'assets/js/controller/settingController.js'
					]
				});
			}]
		}
	})
	.state('description_list',{
		url:'/description_list',
		templateUrl:site_url+'template/description/description_list',
		data: {pageTitle:'Description List', routename:'description_list', lang:['description_list.js']},
		controller:'DescriptionListCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
						'utility/javascript_var/description_list.js',
						'assets/js/controller/descriptionListController.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	/*.state('payment_setting',{
		url:'/payment_setting',
		templateUrl:site_url+'template/setting/payment_setting',
		data: {pageTitle:'Payment setting', routename:'payment_setting', lang:['setting.js']},
		controller:'SettingCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
					    'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/setting.js',
						'assets/js/controller/settingController.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})*/
	.state('create_admin',{
		url:'/create_admin',
		templateUrl:site_url+'template/subadmin/create_admin',
		data: {pageTitle:'Create Admin', routename:'create_admin', lang:['setting.js']},
		controller:'SubadminCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
					    'utility/javascript_var/user.js',
					    'assets/js/plugins/forms/validate.min.js',
					    'assets/js/plugins/forms/select2.min.js',
						'assets/js/controller/subadminController.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('manageadmin',{
		url:'/manageadmin',
		templateUrl:site_url+'template/subadmin/admin_list',
		data: {pageTitle:'Manage Admin', routename:'manageadmin', lang:['setting.js']},
		controller:'SubadminCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [					    
						'utility/javascript_var/user.js',
						'assets/js/plugins/forms/validate.min.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/controller/subadminController.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('edit_admin',{
		url:'/edit_admin/:editId',
		templateUrl:site_url+'template/subadmin/edit_admin',
		data: {pageTitle:'Edit Admin', routename:'edit_admin', lang:['setting.js']},
		controller:'SubadminCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [					    
						'utility/javascript_var/user.js',
						'assets/js/plugins/forms/validate.min.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/controller/subadminController.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('send_email_to_admins',{
		url:'/send_email_to_admins',
		templateUrl:site_url+'template/subadmin/send_email_to_admins',
		data: {pageTitle:'Payment setting', routename:'send_email_to_admins', lang:['setting.js']},
		controller:'SubadminCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [					    
						'utility/javascript_var/user.js',
						'assets/js/plugins/forms/validate.min.js',
						'assets/js/controller/subadminController.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})	
	.state('manage_scoring',{
		url:'/manage_scoring',
		templateUrl:site_url+'template/scoring/manage_scoring',
		data: {pageTitle:'Manage scoring', routename:'manage_scoring', lang:['scoring.js']},
		controller:'ScoringCtrl',
		controllerAs: 'sc',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
					    'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/scoring.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/controller/manage_scoring.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	.state('manage_signup_bonus',{
		url:'/manage_signup_bonus',
		templateUrl:site_url+'template/setting/manage_signup_bonus',
		data: {pageTitle:'Manage Signup Bonus', routename:'manage_signup_bonus', lang:['setting.js']},
		controller:'SettingCtrl',
		resolve:{
			deps: ['$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load({
					insertBefore: '#ng_load_plugins_before',
					files: [
					    'assets/js/plugins/forms/validate.min.js',
						'utility/javascript_var/setting.js',
						'assets/js/plugins/forms/select2.min.js',
						'assets/js/controller/settingController.js',
						'assets/js/plugins/forms/uniform.min.js'
					]
				});
			}]
		}
	})
	;

	$httpProvider.interceptors.push(['$q', '$location', '$rootScope', function($q, $location, $rootScope) {
		return {
			request: function(config) {
				angular.element('.page-content').addClass('loader');
				angular.element('.page-spinner-bar').removeClass('hide').show();
				
				/*************************** Loader Button Icon Remove *********************/
				if($rootScope.current_loader!="")
				{
					angular.element($rootScope.current_loader).addClass('disabled');
					angular.element($rootScope.current_loader+' i').addClass('loading-spinner');
				}				
				/*******************************************************************/
				var key = sessionStorage.getItem(AUTH_KEY);
				if(key == null)
				{
					config.headers[AUTH_KEY] = '';
				}
				else 
				{
					config.headers[AUTH_KEY] = key;
				}
				return config;
			},

			response: function(response) {
				/*************************** Loader Button Icon Remove *********************/
				angular.element($rootScope.current_loader).removeClass('disabled');
				angular.element($rootScope.current_loader+' i').removeClass('loading-spinner');
				angular.element('.page-content').removeClass('loader');
				angular.element('.page-spinner-bar').addClass('hide');
				$rootScope.lang = SERVER_GLOBAL;
				$rootScope.current_loader = "";
				/*******************************************************************/
				return response || $q.state(response);
			},

			responseError: function(rejection) {
				angular.element($rootScope.current_loader).removeClass('disabled');
				angular.element($rootScope.current_loader+' i').removeClass('loading-spinner');
				angular.element('.page-content').removeClass('loader');
				angular.element('.page-spinner-bar').addClass('hide');
				$rootScope.current_loader = "";

				if(rejection.status == 401)
				{
					$rootScope.is_logged_in = false;
					sessionStorage.clear();
					$rootScope.$state.go('root');
				}
				if(rejection.status == 500)
				{
					// $rootScope.is_login = false;
					// sessionStorage.clear();					
					$rootScope.alert_error= rejection.data.message;
					setTimeout(function(){
						if (rejection.data.next_uri != undefined) 
						{							
							window.location.href=site_url+rejection.data.next_uri;	
						}else{
							//window.location.href=base_url; // comment to prevent redirection when any error comes at any action
						}
						
					}, 2000);					
				}
				return $q.reject(rejection);
			}
		};
	}]);

	$httpProvider.defaults.headers.common["X-Requested-With"] = 'XMLHttpRequest';

	$locationProvider.html5Mode(true);
}]);

vfantasy.run(['$rootScope', '$location', '$state','$timeout', function ($rootScope, $location, $state, $timeout) {

	$rootScope.alert_success='';
	$rootScope.alert_warning='';
	$rootScope.alert_error='';
	$rootScope.graph_data = [];
	$rootScope.$state = $state; // state to be accessed from view
	$rootScope.routename;

	$rootScope.is_logged_in = true;

	$rootScope.lang = SERVER_GLOBAL;

	$rootScope.notSorted = function(obj){
		if (!obj) {
			return [];
		}
		return Object.keys(obj);
	};

	$rootScope.updateUi = function() {
		$timeout(function(){$.uniform.update();}, 50);
	};
}]);
