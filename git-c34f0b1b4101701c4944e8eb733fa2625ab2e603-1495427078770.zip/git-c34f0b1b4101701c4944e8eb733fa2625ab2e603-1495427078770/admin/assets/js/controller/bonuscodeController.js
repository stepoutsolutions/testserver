'use strict';

angular.module("vfantasy").controller('BonuscodeCtrl', ['$scope', '$timeout', '$filter', '$state', '$location', '$rootScope', 'settings', 'dataSavingHttp', 'showServerError', function($scope, $timeout, $filter, $state, $location, $rootScope, settings, dataSavingHttp, showServerError){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	$scope.countryList				= {};
	$scope.stateList				= {};
	$scope.salesPersonList			= {};
	$scope.bonusCodeList			= {};
	$scope.userList					= {};
	$scope.commissionPayoutList		= {};
	$scope.promoCodeDetailList		= {};
	$scope.salesPersonDetail		= [];
	$scope.salesPersonEarningList	= [];
	$scope.salerPersonEarning = {};
	$scope.is_panel = 0;
	$scope.salerPersonEarning.amount = 0;

	$scope.salesPersonParam						= {};
	$scope.salesPersonParam.address				= "";
	$scope.salesPersonParam.zip_code			= "";
	$scope.salesPersonParam.city				= "";
	$scope.salesPersonParam.master_country_id	= "";
	$scope.salesPersonParam.master_state_id		= "";

	$scope.isLoading = false;
	$scope.personsParam					= {};
	$scope.personsParam.items_perpage	= 10;
	$scope.personsParam.total_items		= 0;
	$scope.personsParam.current_page	= 1;
	$scope.personsParam.sort_order		= "ASC";
	$scope.personsParam.sort_field		= "first_name";


	$scope.isPromoCodeLoading = false;
	$scope.bonusCodeParam				= {};
	$scope.bonusCodeParam.items_perpage	= 10;
	$scope.bonusCodeParam.total_items	= 0;
	$scope.bonusCodeParam.current_page	= 1;
	$scope.bonusCodeParam.sort_order	= "DESC";
	$scope.bonusCodeParam.sort_field	= "expiry_date";

	$scope.newBonusCodeParam			= {};
	$scope.newBonusCodeParam.user_type	= 0;
	$scope.newBonusCodeParam.cycle	= 0;
	$scope.newBonusCodeParam.sales_person = "";
	$scope.search_key = "";

	$scope.isBonusCodePayoutDetailLoading = false;
	$scope.bonusCodeDetailParam					= {};
	$scope.bonusCodeDetailParam.items_perpage	= 10;
	$scope.bonusCodeDetailParam.total_items		= 0;
	$scope.bonusCodeDetailParam.current_page		= 1;
	$scope.bonusCodeDetailParam.sort_order		= "DESC";
	$scope.bonusCodeDetailParam.sort_field		= "PCE.added_date";

	/*-----------------------------Promo Code---------------------------*/

	$scope.newBonusCodeParam.bonus_code = $filter('uppercase')(random_string(7));

	$scope.newBonusCode = function() {
		$rootScope.current_loader = '.btn-success';

		$scope.newBonusCodeParam.sales_person = angular.element("#sales_person").val();
		dataSavingHttp({
			url: site_url+"bonus_code/new_bonus_code",
			data: $scope.newBonusCodeParam,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			$timeout(function(){
				$location.path('/bonus_code');
			},1000);
		}).error(function(error){
			if(error.hasOwnProperty("message"))
				$rootScope.alert_error = error.message;	
			else
				showServerError(error);
		});
	};

	$scope.getBonusCodes = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;

		dataSavingHttp({
			url: site_url+"bonus_code/get_bonus_codes",
			data: $scope.bonusCodeParam,
		}).success(function (response) {
			$scope.bonusCodeList				= response.data.result;
			$scope.bonusCodeParam.total_items	= response.data.total;
			$scope.isLoading					= false;
		}).error(function(error){
			showServerError(error);
		});
	};

	$scope.sortBonusCodesList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.bonusCodeParam.sort_field){
			sort_order = ($scope.bonusCodeParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.bonusCodeParam.sort_field	= sort_field;
		$scope.bonusCodeParam.sort_order	= sort_order;
		$scope.bonusCodeParam.total_items	= 0;
		$scope.bonusCodeParam.current_page	= 1;
		$scope.getBonusCodes();
	};
	/*------------------------------------------------------------------*/

	/*-----------------------------Promo Code DETAIL---------------------------*/

	$scope.getBonusCodeDetail = function() {
		if($scope.isBonusCodeLoading) return;
		$scope.isBonusCodeLoading = true;

		$scope.bonusCodeDetailParam.bonus_code = $state.params.bonus_code;
		dataSavingHttp({
			url: site_url+"bonus_code/get_bonus_code_detail",
			data: $scope.bonusCodeDetailParam,
		}).success(function (response) {
			$scope.bonusCodeDetailList				= response.data.result;
			$scope.bonusCodeDetailParam.total_items	= response.data.total;
			$scope.isBonusCodeLoading				= false;
		}).error(function(error){
			showServerError(error);
		});
	};

	$scope.sortbonusCodeDetailList = function(sort_field) {
		if($scope.isBonusCodeLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.bonusCodeDetailParam.sort_field){
			sort_order = ($scope.bonusCodeDetailParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.bonusCodeDetailParam.sort_field		= sort_field;
		$scope.bonusCodeDetailParam.sort_order		= sort_order;
		$scope.bonusCodeDetailParam.total_items		= 0;
		$scope.bonusCodeDetailParam.current_page	= 1;
		$scope.getBonusCodeDetail();
	};
	/*------------------------------------------------------------------*/
	$rootScope.updateUi();
}]);