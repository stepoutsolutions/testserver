'use strict';

angular.module("vfantasy").controller('UserCtrl', ['$scope', '$timeout', '$rootScope', '$stateParams','settings', 'dataSavingHttp', 'showServerError', '$location','paginationss',function($scope, $timeout, $rootScope, $stateParams,settings, dataSavingHttp, showServerError, $location,paginationss){

	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.userList		= [];
	$scope.isLoading	= false;
	$scope.userDetail 	= {};
	$scope.userObj					= {};
	$scope.userObj.user_unique_id	= [];
	$scope.userObj.action			= "";
	$scope.userObj.reason			= "";
	$scope.user_unique_id			= [];
	$scope.userDetailLength			= 0;

	$scope.transParam				= {};
	$scope.transParam.items_perpage	= 50;
	$scope.transParam.total_items	= 0;
	$scope.transParam.current_page	= 1;
	$scope.transParam.sort_order	= 'DESC';
	$scope.transParam.sort_field	= 'created_date';
	$scope.istransLoading			= false;
	$scope.userTransactions			= [];

	$scope.gameParam				= {};
	$scope.gameParam.items_perpage	= 50;
	$scope.gameParam.total_items	= 0;
	$scope.gameParam.current_page	= 1;
	$scope.gameParam.sort_order		= 'DESC';
	$scope.gameParam.sort_field		= 'season_scheduled_date';
	$scope.gameList					= [];
	$scope.isgameLoading			= false;

	$scope.userBalance = {};
	$scope.userBalance.transaction_type = "CREDIT"

	$scope.country_list = [];
	$scope.keyword;

	$scope.min_balance_value     = 0;
	$scope.max_balance_value     = 0;

	/* Start User History Section */

	$scope.initObject = function(filter) {
		
		$scope.userParam				= {}
		$scope.userParam.items_perpage	= 50;
		$scope.userParam.total_items	= 0;
		$scope.userParam.current_page	= 1;
		$scope.userParam.sort_order		= 'DESC';
		$scope.userParam.sort_field		= 'added_date';
		$scope.userParam.frombalance;
		$scope.userParam.tobalance;
		$scope.userParam.country		= "";
		$scope.userParam.keyword		= "";
		$scope.max_balance				= 100;
		$scope.min_balance				= 0;
		if(filter=='clear')
		{
			$scope.getFilterData();
			$location.search($scope.userParam);
		}
		else
		{
			var query_data = $location.search();
			$scope.userParam = angular.extend($scope.userParam, query_data);
		}
		$timeout(function(){
			angular.element("#country").select2("val", $scope.userParam.country);
		}, 1000);
		$scope.getUserList();
	};

	$scope.getFilterData = function() {
		dataSavingHttp({
			url: site_url+"user/get_filter_data",
			data: {}
		}).success(function (response) {
			$scope.country_list = response.data.country;
			$scope.max_balance_value = response.data.max_value;
			$scope.min_balance_value = response.data.min_value;

			$scope.userParam.frombalance = response.data.min_value;
			$scope.userParam.tobalance = $scope.max_balance_value;
			/*if($scope.userParam.tobalance=='0'||$scope.userParam.tobalance < $scope.max_balance_value)
			{
				$scope.userParam.tobalance = response.data.max_value;
			}
			if($scope.userParam.frombalance > $scope.max_balance_value)
			{
				$scope.userParam.frombalance = 0;
			}*/
			/*if($scope.userParam.frombalance===undefined)
			{
				$scope.userParam.frombalance = 0;
			}
			if($scope.userParam.tobalance===undefined)
			{				
				$scope.userParam.tobalance = $scope.max_balance_value;
			}*/
		});
	};

	$scope.getUserList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.userParam);

		if(Number($scope.userParam.frombalance) > Number($scope.userParam.tobalance))
		{
			$rootScope.alert_error	= $rootScope.lang.BALANCE_GREATER_FROM_TO;
			return false;
		}
		dataSavingHttp({
			url: site_url+"users",
			data: $scope.userParam,
		}).success(function (response) {
			$scope.userList            = response.data.result;
			$scope.userParam.total_items = response.data.total;
			$scope.deselectUser();
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortUesrList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.userParam.sort_field){
			sort_order = ($scope.userParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.userParam.sort_field  = sort_field;
		$scope.userParam.sort_order  = sort_order;
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
		$scope.deselectUser();
	};

	$scope.searchByEmailOrName = function() {
		var textLen = $scope.userParam.keyword.length;
		if(textLen<2 && textLen!==0)
		{
			return;
		}

		if($scope.isLoading)
		{
			$scope.userParam.keyword = $scope.keyword;
			return;
		}
		$scope.keyword = $scope.userParam.keyword;
		
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
	};

	$scope.filterBalance = function(event, ui) {
		$scope.userParam.frombalance	= ui.values[0];
		$scope.userParam.tobalance		= ui.values[1];
		
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
	};

	$scope.filterCountry = function(){
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
	}

	$scope.getUserDetail = function(user_id,index) {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"get_user_detail",
			data: {'user_unique_id':user_id},
		}).success(function (response) {

			$scope.manage_balance_form.$setPristine();
			$scope.manage_balance_form.$setUntouched();
	        angular.element('#manage_balance_form .form-group').find('label.error').addClass('hide');

	     	$scope.userBalance					= {};
			$scope.userBalance.transaction_type	= "CREDIT";
	     	 angular.element("#credit").attr('checked','checked');
	     	 $scope.changeBalanceButtonText();
			angular.element("#add_balance_modal").modal('show');
			$scope.userDetail		= response.data;
			$scope.userDetail.index	= index;
			$scope.isLoading		= false;
			$rootScope.updateUi();
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.addUserBalance = function(index) {
		$rootScope.current_loader = '.btn-primary';
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$scope.userBalance.user_unique_id = $scope.userDetail.user_unique_id;
		dataSavingHttp({
			url: site_url+"user/add_user_balance",
			data: $scope.userBalance,
		}).success(function (response) {
			$scope.userList[$scope.userDetail.index].balance		= response.data.balance;
			$rootScope.alert_success			= response.message;
			$scope.userBalance					= {};
			$scope.userBalance.transaction_type	= "CREDIT";

			angular.element("#add_balance_modal").modal('hide');
			$scope.isLoading	= false;
			$scope.getFilterData();
			$timeout(function(){
				$location.search($scope.userParam);
			});
		}).error(function (error) {
			$rootScope.alert_error	= error.message;
			$scope.isLoading = false;
		});
	};

	$scope.changeUserStatus = function(user_unique_id,status,index) {
		$rootScope.current_loader = '.btn-primary';
		if($scope.isLoading) return;
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"user/change_user_status",
			data: {'user_unique_id':user_unique_id,'reason':$scope.userObj.reason,'status': status},
		}).success(function (response) {
			$rootScope.alert_success	= response.message;
			$scope.userList[index].status = status;
			$scope.userObj.reason = "";
			angular.element("#user_inactive_modal").modal('hide');
			$scope.isLoading	= false;
		}).error(function (error) {
			$rootScope.alert_success	= error.message;
			$scope.isLoading = false;
		});
	};

	$scope.userInactive = function(user_unique_id, status, index) {
		angular.element("#user_inactive_modal").modal('show');
		$scope.userObj.user_unique_id	= user_unique_id;
		$scope.userObj.status			= status;
		$scope.userObj.index			= index;
	};

	$scope.updateInactveUser = function() {
		angular.element("#all_user_inactive_modal").modal('show');
	};

	$scope.changeSelectedUserStatus = function() {
		$rootScope.current_loader = '.btn-primary';
		if($scope.isLoading) return;
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"user/change_all_user_status",
			data: {'user_unique_id':$scope.userObj.user_unique_id,'reason':$scope.userObj.reason,'status': $scope.userObj.action},
		}).success(function (response) {
			$rootScope.alert_success		= response.message;
			angular.forEach($scope.user_unique_id, function(value, key) {
				$scope.userList[key].status	= $scope.userObj.action;
			});
			$scope.userObj.reason			= "";
			$scope.deselectUser();
			angular.element("#all_user_inactive_modal").modal('hide');
			$scope.isLoading	= false;
		}).error(function (error) {
			$rootScope.alert_success	= error.message;
			$scope.isLoading = false;
		});
	};
	/* End User History Section */

	/* Start User Detail Section */
	$scope.getUserDetailByID = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"get_user_detail",
			data: {'user_unique_id':$stateParams.user_id},
		}).success(function (response) {
			$scope.userDetail	= response.data;
			$scope.userDetailLength = Object.keys($scope.userDetail).length;
			if($scope.userDetailLength > 0)
			{
				$scope.userTransactionHistory();
				$scope.getGameList();
				$scope.isLoading	= false;
			}
			
		}).error(function (error) {
			$scope.isLoading = false;
		});	
	};

	$scope.userTransactionHistory = function() {
		if($scope.istransLoading) return;
		$scope.istransLoading = true;
		$scope.transParam.user_id = $scope.userDetail.user_id;
		dataSavingHttp({
			url: site_url+"user/user_transaction_history",
			data: $scope.transParam,
		}).success(function (response) {
			$scope.userTransactions    = response.data.result;
			$scope.transParam.total_items = response.data.total;
			$scope.istransLoading = false;
		}).error(function (error) {
			$scope.istransLoading = false;
		});
	};

	$scope.sortUserTransaction = function(sort_field) {
		if($scope.istransLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.transParam.sort_field){
			sort_order = ($scope.transParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.transParam.sort_field  = sort_field;
		$scope.transParam.sort_order  = sort_order;
		$scope.transParam.total_items  = 0;
		$scope.transParam.current_page = 1;
		$scope.userTransactionHistory();
	};

	$scope.getGameList = function() {	
		
		if($scope.isgameLoading) return;
		$scope.isgameLoading = true;
		$scope.gameParam.user_id = $scope.userDetail.user_id;
		dataSavingHttp({
			url: site_url+"user/user_game_history/",
			data: $scope.gameParam,
		}).success(function (response) {
			$scope.gameList            = response.data.result;
			$scope.gameParam.total_items = response.data.total;
			$scope.isgameLoading = false;
		}).error(function (error) {
			$scope.isgameLoading = false;
		});
	};

	$scope.sortGameList = function(sort_field) {
		if($scope.isgameLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.gameParam.sort_field){
			sort_order = ($scope.gameParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.gameParam.sort_field  = sort_field;
		$scope.gameParam.sort_order  = sort_order;
		$scope.gameParam.total_items  = 0;
		$scope.gameParam.current_page = 1;
		$scope.getGameList();
	};

	/* Start Extra Function */
	$scope.toggleUser = function($event){
		$scope.userObj.user_unique_id = [];
		$scope.user_unique_id	= $scope.user_unique_id = Array.apply(null, Array($scope.userList.length)).map(function() { return $event.target.checked; });
		if($event.target.checked){
			for (var i = 0; i < $scope.userList.length; i++) {
				$scope.userObj.user_unique_id.push($scope.userList[i].user_unique_id);
			};
		}
		$rootScope.updateUi();
	};

	$scope.deselectUser = function() {
		$scope.userObj					= {};
		$scope.user_unique_id			= {};
		$scope.userObj.action			= "";
		$scope.userObj.reason			= "";
		$scope.userObj.user_unique_id	= [];
		$scope.userObj.selectall		= false;
		$rootScope.updateUi();
	};

	$scope.selectUser = function($event) {

		var user_unique_id = $event.target.value;
		var index = $scope.userObj.user_unique_id.indexOf(user_unique_id);
		
		($event.target.checked)?$scope.userObj.user_unique_id.push(user_unique_id):$scope.userObj.user_unique_id.splice(index, 1);

		if($scope.userObj.user_unique_id.length==$scope.userList.length)
		{
			$scope.userObj.selectall = true;
		}
		else
		{
			$scope.userObj.selectall = false;
		}
		$rootScope.updateUi();
	};

	$scope.showBanUserModel = function(user_id,index) {
		$scope.userObj.user_unique_id = user_id;
		$scope.userObj.index = index;
		angular.element("#ban_user_modal").modal('show');
	};

	$scope.showSendEmailAllModel = function() {
		angular.element("#send_email_all_model").modal('show');
	};
	$scope.showSendEmailSelectedModel = function() {
		if($scope.userObj.user_unique_id.length>0)
		{
			$scope.userObj.emails = [];
			angular.forEach($scope.user_unique_id, function(value, key) {
				$scope.userObj.emails.push($scope.userList[key].email);
			});
			$scope.userObj.selected_emails = $scope.userObj.emails.toString();
			angular.element("#send_email_selected_model").modal('show');
		}
		else
		{
			$rootScope.alert_error	= $rootScope.lang.SELECT_USER;
		}
	};

	$scope.sendEmailSelectedUser = function() {
		angular.element("#send_email_selected_model").modal('hide');
		dataSavingHttp({
			url: site_url+"user/send_email_selected_user/",
			data: $scope.userObj,
		}).success(function (response) {
			$rootScope.alert_success	= response.message;
			$scope.userObj={};
			$scope.userObj.user_unique_id=[];
			$scope.deselectUser();
		}).error(function (error) {
			$rootScope.alert_error	= error.message;
			angular.element("#send_email_selected_model").modal('hide');
		});
	};

	$scope.sendEmailAllUsers = function() {
		angular.element("#send_email_all_model").modal('hide');
		dataSavingHttp({
			url: site_url+"user/send_email_all_user/",
			data: $scope.userObj,
		}).success(function (response) {
			$rootScope.alert_success	= response.message;
			$scope.userObj={};
			$scope.userObj.user_unique_id=[];
		}).error(function (error) {
			$rootScope.alert_error	= error.message;
			angular.element("#send_email_all_model").modal('hide');
		});
	};
	/* End Extra Function*/


	$scope.changeBalanceButtonText = function(){
		if($scope.userBalance.transaction_type	== "CREDIT"){
			angular.element("#manage_balance_btn").html($rootScope.lang.add_balance)
		} else {
			angular.element("#manage_balance_btn").html($rootScope.lang.debit_balance)
		}
	}

	$scope.exportUser = function() {

		window.open(site_url+'user/export_users', '_blank');



		/*dataSavingHttp({
			url: site_url+"user/export_users",
			data: {},
		}).success(function (response) {
			var anchor = angular.element('<a/>');
			anchor.attr({
				href: 'data:attachment/csv;charset=utf-8,' + encodeURI(response),
				target: '_blank',
				download: 'User List.csv'
			})[0].click(); 
		}).error(function (error) {
		});*/
	};

	$scope.removeCPF = function (user_unique_id, i) {
		var c = confirm("Are you sure. You want to remove CPF No for this user?");
		if(!c)
		{
			return c;
		}
		dataSavingHttp({
			url: site_url+"user/remove_cpf",
			data: {user_unique_id:user_unique_id},
		}).success(function (response) {
			$scope.userList[i].cpf_no = null;
			if(response.message)
			{
				$rootScope.alert_success = response.message;
			}
		}).error(function (error) {
			if(error.message)
			{
				$rootScope.alert_error	= error.message;
			}
		});
		return c;
	};

	$scope.VerifyPANCard = function(user_unique_id,index)
	{
		dataSavingHttp({
			url: site_url+"user/verify_user_pancard/",
			data: {user_unique_id:user_unique_id},
		}).success(function (response) {
			$rootScope.alert_success		= response.message;
			$scope.userList[index].verify   = response.data.verify;
		}).error(function (error) {
			$rootScope.alert_error	= error.message;
		});
	}
}]);