'use strict';
angular.module("vfantasy").controller('DashboardCtrl', ['$scope', '$rootScope','$state', 'settings', 'dataSavingHttp', 'showServerError', function($scope, $rootScope,$state, settings, dataSavingHttp, showServerError){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	$scope.generalGraphData			= {};
	$scope.contestPPGraphData		= {};
	$scope.contestAUGraphData		= {};
	$scope.earningPPGraphData		= {};
	$scope.earningAUGraphData		= {};
	$scope.prizePPGraphData			= {};
	$scope.prizeAUGraphData			= {};
	$scope.dashboardDetail			= [];
	$scope.contestDetail			= [];
	$scope.earningDetail			= [];
	$scope.prizeDetail				= [];
	$scope.siteCommissionDetail		= [];
	$scope.generalGraph				= [];
	$scope.contestGraph				= [];
	$scope.earningGraphData			= [];
	$scope.prizeGraphData			= [];
	$scope.siteCommissionGraphData	= [];
	$scope.filter					= "";
	$scope.getDashboard = function() {
		dataSavingHttp({
			url: site_url+"dashboard/dashboard",
			data: {filter:$scope.filter},
		}).success(function (response) {
			var graph_data = response.data.dashboard_graph_detail;
			$scope.dashboardDetail		= response.data.dashboard_detail;
			$scope.contestDetail		= graph_data.contest_graph.contest_detail;
			$scope.earningDetail		= graph_data.entry_fee.entry_fee_detail;
			$scope.prizeDetail			= graph_data.prize_chart.prize_detail;
			$scope.siteCommissionDetail	= graph_data.site_commission.site_commission_detail;
			// $scope.graph_data = response;
			$scope.generalGraph				= graph_data.general_graph;
			$scope.contestGraph				= graph_data.contest_graph;
			$scope.earningGraphData			= graph_data.entry_fee;
			$scope.prizeGraphData			= graph_data.prize_chart;
			$scope.siteCommissionGraphData	= graph_data.site_commission;
			// $scope.generalGraph(general_graph);
			$scope.generateGeneralGraph($scope.generalGraph);
			$scope.generateContestGraph($scope.contestGraph);
			$scope.generateEarningGraph($scope.earningGraphData);
			$scope.generatePrizeGraph($scope.prizeGraphData);
			$scope.generateSiteCommissionGraph($scope.siteCommissionGraphData);
		});
	};

	$scope.generateGeneralGraph = function (generalGraphData) {
		var color = {0: {color: '#40BEE8'}, 1: {color: '#B38EDB'}};
		var chartdata = [["Date", "Contest", "Earning"]];
		generalGraphData.forEach(function (value,key) {
			chartdata.push([value['date'],parseInt(value['contest']),parseFloat(value['earning'])])
		});
		var chart1 = {};
		chart1.type = "LineChart";
		chart1.data = chartdata;
		chart1.options = {
							chart: {title: ''},
							
							pointSize: 9,
							titleTextStyle: {color: 'red'},
							hAxis: {
									textStyle: {color: '#ffffff'},
									titleTextStyle: {color: '#ffffff'}
								},
							vAxis: {
								textStyle: {color: '#ffffff'},
								titleTextStyle: {color: '#ffffff'}
							},
							legend: {
								textStyle: {color: '#ffffff'}
							},
							animation: {
									startup: true,
									duration: 1000
								},
							backgroundColor: '#2d3133',
							'slices': color,
							vAxes:[
									{title: 'Earning in $', maxValue: 10}, // Left axis
									{title: '# Games',  maxValue: 20} // Right axis
								],
							series:[
									{targetAxisIndex:1,color:'#28D0C8'},
									{targetAxisIndex:0,color:'#FF7D81'}
								]
						};
	  
		chart1.formatters = {
								number: [{
											columnNum: 2,
											pattern: '$ #,##0.00'
										}]
							};
		$scope.generalGraphData = chart1;
	};

	$scope.generateContestGraph = function (contestGraphData) 
	{
		var color = {0: {color: '#40BEE8'}, 1: {color: '#B38EDB'}};
		console.log(contestGraphData.contest_chart_public_private);
		var contestPP = {};
		var contestPPData = [["Type", "Contest"],
								["Private", parseInt(contestGraphData.contest_chart_public_private.private)],
								["Public", parseInt(contestGraphData.contest_chart_public_private.public)]
							];
		contestPP.type = "PieChart";
		contestPP.data = contestPPData;
		contestPP.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							width:'100%',
							height:'100%',
							slices: color,
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
							animation: {
									startup: true,
									duration: 5000,
									eeasing: 'out'
							}
						};

		contestPP.formatters = {
							number: [{
										columnNum: 1,
										pattern: "#,##0.00"
									}]
							};

		$scope.contestPPGraphData = contestPP;

		var contestAU = {};
		var contestAUData = [
								["Type", "Contest"],
								['User', parseInt(contestGraphData.contest_chart_user_admin.user)],
								['Admin', parseInt(contestGraphData.contest_chart_user_admin.admin)]];
		contestAU.type = "PieChart";
		contestAU.data = contestAUData;
		contestAU.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
						};

		contestAU.formatters = {
							number: [{
										columnNum: 1,
										pattern:"#,##0.00"
									}]
							};

		$scope.contestAUGraphData = contestAU;
	}

	$scope.generateEarningGraph = function(earningGraphData) {

		var color = {0: {color: '#28D0C8'}, 1: {color: '#FF7D81'}};
		var earningPP = {};
		var earningPPData = [["Type", "Earning"],
								["Private", parseInt(earningGraphData.entry_fee_chart_public_private.private)],
								["Public", parseInt(earningGraphData.entry_fee_chart_public_private.public)]
							];
		earningPP.type = "PieChart";
		earningPP.data = earningPPData;
		earningPP.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
							animation: {
									startup: true,
									duration: 5000,
									eeasing: 'out'
							}
						};

		earningPP.formatters = {
							number: [{
										columnNum: 1,
										pattern: "$ #,##0.00"
									}]
							};

		$scope.earningPPGraphData = earningPP;

		var earningAU = {};
		var earningAUData = [
								["Type", "Earning"],
								['User', parseInt(earningGraphData.entry_fee_chart_user_admin.user)],
								['Admin', parseInt(earningGraphData.entry_fee_chart_user_admin.admin)]];
		earningAU.type = "PieChart";
		earningAU.data = earningAUData;
		earningAU.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
						};

		earningAU.formatters = {
							number: [{
										columnNum: 1,
										pattern:"$ #,##0.00"
									}]
							};

		$scope.earningAUGraphData = earningAU;
	};

	$scope.generatePrizeGraph = function(prizeGraphData) {
		var color = {0: {color: '#0053A0'}, 1: {color: '#F7D460'}};
		var prizePP = {};
		var prizePPData = [["Type", "Earning"],
								["Private", parseInt(prizeGraphData.prize_chart_public_private.private)],
								["Public", parseInt(prizeGraphData.prize_chart_public_private.public)]
							];
		prizePP.type = "PieChart";
		prizePP.data = prizePPData;
		prizePP.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
							animation: {
									startup: true,
									duration: 5000,
									eeasing: 'out'
							}
						};

		prizePP.formatters = {
							number: [{
										columnNum: 1,
										pattern: "$ #,##0.00"
									}]
							};

		$scope.prizePPGraphData = prizePP;

		var prizeAU = {};
		var prizeAUData = [
								["Type", "Prize"],
								['User', parseInt(prizeGraphData.prize_chart_user_admin.user)],
								['Admin', parseInt(prizeGraphData.prize_chart_user_admin.admin)]];
		prizeAU.type = "PieChart";
		prizeAU.data = prizeAUData;
		prizeAU.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
						};

		prizeAU.formatters = {
							number: [{
										columnNum: 1,
										pattern:"$ #,##0.00"
									}]
							};

		$scope.prizeAUGraphData = prizeAU;
	};

	$scope.generateSiteCommissionGraph = function(siteCommissionGraphData) {
		console.log(siteCommissionGraphData);
		var color = {1: {color: '#28D0C8'}, 0: {color: '#FF7D81'}};
		var siteCommissionPP = {};
		var siteCommissionPPData = [["Type", "Earning"],
								["Private", parseFloat(siteCommissionGraphData.site_commission_chart_public_private.private)],
								["Public", parseFloat(siteCommissionGraphData.site_commission_chart_public_private.public)]
							];
		siteCommissionPP.type = "PieChart";
		siteCommissionPP.data = siteCommissionPPData;
		siteCommissionPP.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,    
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
							animation: {
									startup: true,
									duration: 5000,
									eeasing: 'out'
							}
						};

		siteCommissionPP.formatters = {
							number: [{
										columnNum: 1,
										pattern: "$ #,##0.00"
									}]
							};

		$scope.siteCommissionPPGraphData = siteCommissionPP;

		var siteCommissionAU = {};
		var siteCommissionAUData = [
								["Type", "Prize"],
								['User', parseFloat(siteCommissionGraphData.site_commission_chart_user_admin.user)],
								['Admin', parseFloat(siteCommissionGraphData.site_commission_chart_user_admin.admin)]];
		siteCommissionAU.type = "PieChart";
		siteCommissionAU.data = siteCommissionAUData;
		siteCommissionAU.options ={
							displayExactValues: false,
							backgroundColor: '#2d3133',
							slices: color,    
							sliceVisibilityThreshold:0,
							legend: {
								textStyle: {color: '#ffffff'}
							},
						};

		siteCommissionAU.formatters = {
							number: [{
										columnNum: 1,
										pattern:"$ #,##0.00"
									}]
							};

		$scope.siteCommissionAUGraphData = siteCommissionAU;
	};
}]);