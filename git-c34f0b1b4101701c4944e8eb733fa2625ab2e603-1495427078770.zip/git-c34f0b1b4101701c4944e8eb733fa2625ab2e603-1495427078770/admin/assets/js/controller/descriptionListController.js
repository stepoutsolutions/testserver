'use strict';

angular.module("vfantasy").controller('DescriptionListCtrl', ['$scope','$rootScope','settings', 'dataSavingHttp', 'showServerError', '$location', function($scope,$rootScope,settings, dataSavingHttp, showServerError, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.DescriptionList     = [];
	$scope.isLoading    = false;
	
	/* Start User History Section */
	$scope.initObject = function(filter) {
		
		$scope.DesParam             	= {}
		$scope.DesParam.items_perpage   = 10;
		$scope.DesParam.total_items 	= 0;
		$scope.DesParam.current_page    = 1;
		$scope.DesParam.sort_order      = 'DESC';
		$scope.DesParam.sort_field      = 'added_date';
		$scope.getDescriptionList();
	};

	$scope.getDescriptionList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.DesParam);

		
		dataSavingHttp({
			url: site_url+"payment_transaction/get_all_descriptions",
			data: $scope.DesParam,
		}).success(function (response) {
			$scope.DescriptionList              = response.data.result;
			$scope.DesParam.total_items 		= response.data.total;
			
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortDescriptionList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.DesParam.sort_field){
			sort_order = ($scope.DesParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.DesParam.sort_field  = sort_field;
		$scope.DesParam.sort_order  = sort_order;
		$scope.DesParam.total_items  = 0;
		$scope.DesParam.current_page = 1;
		$scope.getDescriptionList();
		
	};


}]);
