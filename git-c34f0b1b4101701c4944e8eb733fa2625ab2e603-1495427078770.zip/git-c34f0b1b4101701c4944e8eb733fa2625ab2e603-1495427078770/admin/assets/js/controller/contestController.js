'use strict';

angular.module("vfantasy").controller('ContestCtrl', ['$scope', '$location', '$state','$timeout','$rootScope', 'settings', 'dataSavingHttp', 'showServerError', 'paginationss', function($scope, $location, $state, $timeout, $rootScope, settings, dataSavingHttp, showServerError, paginationss){
	
	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.leagues					= {};
        $scope.duration_ids                  = {};
	$scope.matches_list				= {};
	$scope.drafting_style			= {};
	$scope.tournament_list			= {};
	$scope.site_rake_list			= {};
	$scope.contest					= {};
	$scope.all_duration				= {};
	$scope.contest_types			= {};
	$scope.contest_list				= [];
	$scope.all_position				= [];
	$scope.prize_type_validation	= [];
	$scope.LineupDetail				= [];
	$scope.mindate					= "";
	$scope.prizePool				= "";
	$scope.contest_name = "";
	$scope.gameDetailParam					= {};
	$scope.gameDetailParam.items_perpage	= 50;
	$scope.gameDetailParam.total_items		= 0;
	$scope.gameDetailParam.current_page		= 1;
	$scope.gameDetail						= [];
	$scope.contest_names 					= [];
	$scope.gameLineupPrize 					= [];
	$scope.playerSalaryDetailParam					= {};
	$scope.playerSalaryDetailParam.items_perpage	= 50;
	$scope.playerSalaryDetailParam.total_items		= 0;
	$scope.playerSalaryDetailParam.current_page		= 1;
	$scope.playerSalaryDetailParam.sort_order		= "DESC";
	$scope.playerSalaryDetailParam.sort_field		= "full_name";
	$scope.playerSalaryDetail						= [];

	$scope.contestObj					= {};
	$scope.contestObj.showSaveContest	= "";
	$scope.contestObj.selectall			= false;

	$scope.contestParam							= {};
	$scope.contestParam.league_duration_id		= "";
	$scope.contestParam.duration_id             = "";
	$scope.contestParam.custom_name				= false;
	$scope.contestParam.entry_fee				= "";
	$scope.contestParam.size  					= "";
	$scope.contestParam.size_min				= "";
	$scope.contestParam.salary_cap				= "";
	$scope.contestParam.game_name				= "";
	$scope.contestParam.season_scheduled_date	= "";
	$scope.contestParam.is_multiple_lineup		= false;
	$scope.contestParam.multiple_lineup			= 0;
	$scope.contestParam.contest_type			= "";
	$scope.contestParam.prize_selection			= "auto";
	$scope.contestParam.site_rake			    = $rootScope.lang.default_site_rake;


	$scope.promoCodeDetailParam					= {};
	$scope.promoCodeDetailParam.items_perpage	= 50;
	$scope.promoCodeDetailParam.total_items		= 0;
	$scope.promoCodeDetailParam.current_page	= 1;
	$scope.promoCodeDetailParam.sort_order		= "DESC";
	$scope.promoCodeDetailParam.sort_field		= "full_name";
	$scope.promoCodeDetail						= [];
	$scope.uncappedPrizePool 					= '';
	$scope.contestParam.is_uncapped = false;
	$scope.contestParam.no_of_game					= "";
	$scope.contestParam.is_auto_recurrent			= "";
	$scope.contestParam.period_of_recurrent			= "";
	$scope.contestParam.is_period_of_recurrent		= 1;
	$scope.contestParam.period_of_recurrent_value	= "";
	$scope.contestParam.auto_recurrent_stop_type	= "";
	$scope.contestParam.auto_recurrent_stop_value	= "";
	$scope.feature_img								= "";
	$scope.autorecurrenteditmode = false;
	$scope.autorecurrentupdateForm = [];
	$scope.autorecurrentupdateForm.is_period_of_recurrent = 0;
	$scope.is_valid_size = true;

	$scope.all_season_scheduled_date 		= [];
	$scope.custom_weeks = [];
	$scope.leagueTeams = [];
	$scope.autoRecurrentDetail = []

	$scope.isLoading				= false;

	$scope.getAllLeague = function() {
		dataSavingHttp({
			url: site_url+"contest/get_all_league",
			data: {},
		}).success(function (response) {
			$scope.leagues = response.data;
			$timeout(function() {
				$scope.contestParam.game_name = "";
				angular.element("#league_id").select2("val", "")
				angular.element("#league_duration_id").select2("val", "");
				angular.element("#salary_cap").select2("val", "");
				angular.element("#select_prize").select2("val", "");
				angular.element("#drafting_style").select2("val", "");
                                angular.element("#turbo_contest_type").select2("val", "");
			});
		});
	};

	$scope.getAllContestData = function() {
		$scope.all_duration			= {};
		$scope.all_salary_cap		= {};
		$scope.all_number_of_winner	= {};
		$scope.all_available_week	= {};
		$scope.contest_list			= [];
		$scope.all_position			= [];
		angular.element("#date").datepicker('hide');
		if(!$scope.contestParam.league_id)
		{
			return true;
		}
		resetContestData();

		$timeout(function(){
			angular.element("#league_duration_id").select2("val", "");
			angular.element("#salary_cap").select2("val", "");
			angular.element("#select_prize").select2("val", "");
			angular.element("#drafting_style").select2("val", "");
			angular.element("#turbo_contest_type").select2("val", "");
		});

		dataSavingHttp({
			url: site_url+"contest/get_all_contest_data",
			data: {league_id:$scope.contestParam.league_id},
		}).success(function (response) {
			$scope.all_duration					= response.data.all_duration;
			$scope.all_salary_cap				= response.data.all_salary_cap;
			// $scope.all_number_of_winner			= response.data.all_number_of_winner;
			$scope.all_available_week			= response.data.all_available_week;
			$scope.mindate						= response.data.mindate;
			$scope.season_scheduled_date        = response.data.seasons_dates;
			$scope.all_season_scheduled_date	= response.data.all_seasons_dates;
			// $scope.number_of_winner_validation           = response.data.number_of_winner_validation;
			$scope.contest_types				= response.data.contest_types;
			//$scope.all_position					= response.data.all_position;
			$scope.all_drafting_style 			= response.data.all_drafting_style;
			$scope.contestParam.site_rake 		= response.data.default_site_rake;
			
			for (var i = 0; i < $scope.all_available_week.length; i++) {
				var week_id = $scope.all_available_week[i].week;
					$scope.custom_weeks[week_id] =  $scope.all_available_week[i].week_detail;
			}

			$scope.createGameName();
			deselectContest();
                        $timeout(function(){
                                angular.forEach($scope.number_of_winner_validation,function(v,k){
                                        $scope.prize_type_validation[v.league_contest_type_id] = v;
                                });
                                angular.forEach(response.data.all_duration, function (value, key) {
                                        $scope.duration_ids[ value.league_duration_id ] = value.duration_id;
                                });
                        }, 100);
                        
		});
	};
        
	$scope.availableSeasonDates = function(date) {
		var Y = date.getFullYear();
		var M = (date.getMonth()+1);
		var D = date.getDate();
		var dmy = "";
		if ( M < 10 )
		{
			M ='0'+M;
		}

		if ( D < 10 )
		{
			D = '0'+D;
		}

		dmy = Y + "-" + M + "-" + D;

		if ($.inArray(dmy,$scope.season_scheduled_date) != -1)
		{
			return [ true , "" , "Available" ];
		}
		else
		{
			return [ false , "" , "No Game" ];
		}
	};

	$scope.getAvailableMatchByDay = function(date) {
		$scope.contestParam.season_scheduled_date = date;
		$scope.getAvailiableGameOfTheDayOrWeek();
	};

	$scope.getAvailiableGameOfTheDayOrWeek = function()	{
		// if((!$scope.contestParam.season_scheduled_date)&&(!$scope.contestParam.season_week))
		// {
		// 	return false;
		// }
		
		if((!($scope.contestParam.from_date)||!($scope.contestParam.to_date))&&($scope.contestParam.league_duration_id==2)){
			
			return false;
		}
		if((!$scope.contestParam.season_scheduled_date)&&($scope.contestParam.league_duration_id==1))
		{
			return false;
		}
		
		dataSavingHttp({
			url: site_url+"contest/get_available_game_of_the_day_or_week",
			data :$scope.contestParam,
		}).success(function (response) {
			$scope.contest_list = response.data.game_list;
			$scope.contestParam.contests=[];//new line added
			$scope.contests = [];
			$scope.contestObj.selectall = false;

			$scope.createGameName();
			$rootScope.updateUi();
		}).error(function (error) {
		});
	};

	$scope.getAllDraftingStyle = function(is_turbo_lineup) {

		console.log("drafting called");return false;

                if(!is_turbo_lineup){
                        is_turbo_lineup = false;
                }
		if(!$scope.contestParam.league_duration_id)
		{
			return true;
		}
                $scope.contestParam.drafting_style = '';
                $scope.contestParam.duration_id = $scope.duration_ids[$scope.contestParam.league_duration_id];
                
		angular.element("#date").datepicker('hide');
		$scope.contest_list = [];
		$scope.all_drafting_style = [];
		$scope.contestParam.season_scheduled_date = "";
		$timeout(function(){
			angular.element("#drafting_style").select2("val", "");
		});
		dataSavingHttp({
			url: site_url+"contest/get_all_drafting_style",
			data: {league_duration_id:$scope.contestParam.league_duration_id, is_turbo_lineup: is_turbo_lineup},
		}).success(function (response) {
			$scope.all_drafting_style = response.data;
			$scope.createGameName();
		});
	};

	$scope.uncappedUpdate = function() {
		if($scope.contestParam.uncapped)
		{
			$scope.contestParam.prize_selection = 'custom';
			$rootScope.updateUi();
		}
		else
		{
			$scope.contestParam.prize_selection = 'auto';
			$rootScope.updateUi();	
		}
	};

	$scope.getPrizeDetails = function() {
		var prize = $scope.contestParam.number_of_winner_id;
		var fees  = $scope.contestParam.entry_fee;
		var size  = $scope.contestParam.size;
		//$scope.contestParam.custom_prize  = "";
		// angular.element('#prize_detail').html('');
		if(!$scope.contestParam.league_id)
		{
			return true;
		}

		//check if contest type is uncapped then return
		if($scope.contestParam.contest_type == 3)
		{
			 $scope.prizePool = '';
			 $scope.uncappedPrizePool = "Prize will be calculated dynamically.";
			 $scope.contestParam.is_uncapped = true;
			 size  = $scope.contestParam.size_min;
		}
		else if($scope.contestParam.contest_type == 1 || $scope.contestParam.contest_type == 2)
		{
			$scope.contestParam.is_uncapped = false;
			$scope.uncappedPrizePool ='';
			var size  = $scope.contestParam.size_min;
			console.log(size+"fdsfs");
		}


		/*if(!prize)
		{
			$scope.prize_details = [];
			angular.element('#select_prize_error').html($rootScope.lang.REQUIRED).removeClass('hide');
		}
		if(!size)
		{
			$scope.prize_details = [];
			angular.element('#size_error').html($rootScope.lang.REQUIRED).removeClass('hide');
		}
		if(!fees)
		{
			$scope.prize_details = [];
			angular.element('#entry_fee_error').html($rootScope.lang.REQUIRED).removeClass('hide');
		}*/
		if(size&&$scope.contestParam.entry_fee&&($scope.contestParam.entry_fee==0||$scope.contestParam.entry_fee)&&$scope.contestParam.number_of_winner_id&&!isNaN($scope.contestParam.entry_fee)&&!isNaN(size))
		{
			var position_or_percentage	= $scope.prize_type_validation[$scope.contestParam.number_of_winner_id].position_or_percentage;
			var places					= $scope.prize_type_validation[$scope.contestParam.number_of_winner_id].places;
			angular.element('#size_error').html($rootScope.lang.REQUIRED).addClass('hide');
			angular.element('#entry_fee_error').html($rootScope.lang.REQUIRED).addClass('hide');

			if ('0' == position_or_percentage)
			{
				if (Number(size) < Number(places))
				{
					$timeout(function(){
						angular.element('#select_prize').select2('val','');
					});
					$timeout(function(){
						angular.element('#select_prize_error').html($rootScope.lang.INVALID_COMBINATION).removeClass('hide').show();						
					});
					return true;
				}
				angular.element('#select_prize_error').addClass('hide').hide();;
			}
			else
			{
				var tempplaces = (Number(size)*Number(places)/100);
				if(tempplaces < 1)
				{
					$timeout(function(){
						angular.element('#select_prize_error').select2('val','');
					});
					$timeout(function(){
						angular.element('#select_prize_error').html($rootScope.lang.INVALID_COMBINATION).removeClass('hide').show();						
					});
					return true;
				}
				angular.element('#select_prize_error').addClass('hide').hide();
			}			
			$scope.prize_details = [];
			$scope.prizePool = "";
			var param = {site_rake:$scope.contestParam.site_rake,size:size,entry_fee:$scope.contestParam.entry_fee,league_number_of_winner_id:$scope.contestParam.number_of_winner_id}
			dataSavingHttp({
				url: site_url+'contest/game_prize_details',
				data : param,
			}).success(function (response){		
				if(!$scope.contestParam.is_uncapped){
				 $scope.prizePool = response.data;
				}		
			}).error(function (error){

			});
		}
	};

	$scope.createGameName = function () {
		if(!$scope.contestParam.custom_name)
		{
			var league_label					= ($scope.contestParam.league_id)?angular.element("#league_id").select2("data").text:"";
			var league_duration_label			= ($scope.contestParam.league_duration_id)?angular.element("#league_duration_id").select2("data").text:"";
			var league_drafting_styles_label	= ($scope.contestParam.drafting_style)?angular.element("#drafting_style").select2("data").text:"";
			var season_week_id_label			= ($scope.contestParam.season_week)?angular.element("#week").select2("data").text:"";
			var league_salary_cap_label			= ($scope.contestParam.salary_cap)?angular.element("#salary_cap").select2("data").text:"";
			

			$scope.contestParam.game_name = league_label + ' ' + league_duration_label + ' ' + league_drafting_styles_label + ' ' + league_salary_cap_label;
		}
		else
		{
			$timeout(function () {
				document.getElementById("game_name").focus();
			}, 100);
		}
	};

	$scope.createContest = function() {
		$rootScope.current_loader = '.btn-success';
		if($scope.getPrizeDetails())
		{
			return false;
		}
		if($scope.contestParam.is_multiple_lineup && !$scope.contestParam.multiple_lineup)
		{
			angular.element('#multiple_lineup_error').html($rootScope.lang.REQUIRED).removeClass('hide');
			return false;
		}
		if(!$scope.is_valid_size)
		{
			var identifier = ($scope.contestParam.contest_type == 3) ? "#size_min_error" : "#size_error";
			angular.element(identifier).html($rootScope.lang.min_size_error).removeClass('hide').show();
			return false;
		}
		$scope.contestParam.selectall = $scope.contestObj.selectall;
		$scope.isLoading = true;
		$scope.contestParam.feature_img = $scope.feature_img;
		if($scope.contestParam.is_feature && $scope.feature_img == ''){
			angular.element("#feature_img_error").empty().append($rootScope.lang.featured_image_error);
			angular.element("#feature_img_error").show();
			angular.element("#feature_img_error").removeClass('hide');
			angular.element('html,body').animate({scrollTop:0}, 'slow');
			return false;
		}
		$scope.contestParam.drafting_style = 1;
		dataSavingHttp({
			url: site_url+"contest/create_contest",
			data: $scope.contestParam,
		}).success(function (response) {

			console.log(response);

			$scope.isLoading = false;
			$scope.contestParam.league_id = "";
			$rootScope.alert_success = response.message;
			$location.path('/contest');
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
	};
        
        $scope.createTurboContest = function() {
		$rootScope.current_loader = '.btn-success';
		if($scope.getPrizeDetails())
		{
			return false;
		}
		$scope.contestParam.selectall = $scope.contestObj.selectall;
		$scope.isLoading = true;
		$scope.contestParam.feature_img = $scope.feature_img;
                
		if($scope.contestParam.is_feature && $scope.feature_img == ''){
			angular.element("#feature_img_error").empty().append($rootScope.lang.featured_image_error);
			angular.element("#feature_img_error").show();
			angular.element("#feature_img_error").removeClass('hide');
			angular.element('html,body').animate({scrollTop:0}, 'slow');
			return false;
		}
		dataSavingHttp({
			url: site_url+"contest/create_turbo_contest",
			data: $scope.contestParam,
		}).success(function (response) {
			$scope.isLoading = false;
			$scope.contestParam.league_id = "";
			$rootScope.alert_success = response.message;
			$location.path('/contest');
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
	};

	var resetContestData = function() {
		var feature = $scope.contestParam.is_feature;
		var league_id = $scope.contestParam.league_id;
		var custom_name = $scope.contestParam.custom_name;
		deselectContest();
		$scope.contestParam							= {};
		$scope.contestParam.league_id				= league_id;
		$scope.contestParam.league_duration_id		= "";
		$scope.contestParam.prize_selection			= 'auto';
		$scope.contestParam.custom_name				= "";
		$scope.contestParam.entry_fee				= "";
		$scope.contestParam.is_feature				= feature;
		$scope.contestParam.size 					= "";
		$scope.contestParam.size_min				= "";
		$scope.contestParam.drafting_style			= "";
		$scope.contestParam.salary_cap				= "";
		$scope.contestParam.season_scheduled_date	= "";
		$scope.contestParam.site_rake				= 10;
		$scope.contestParam.game_name 				= "";
		$scope.contestParam.contest_type			= "";
		$scope.contestParam.is_period_of_recurrent		= 1;
		$scope.contestParam.no_of_game					= "";
		$scope.contestParam.is_auto_recurrent			= "";
		$scope.contestParam.period_of_recurrent			= "";
		$scope.contestParam.period_of_recurrent_value	= "";
		$scope.contestParam.auto_recurrent_stop_type	= "";
		$scope.contestParam.auto_recurrent_stop_value	= "";
		$scope.contestParam.custom_prize 				= "";	
		$timeout(function(){
			angular.element("#league_duration_id").select2("val", "");
			angular.element("#salary_cap").select2("val", "");
			angular.element("#select_prize").select2("val", "");
			angular.element("#drafting_style").select2("val", "");
			angular.element("#contest_type").select2("val", "");
			angular.element("#auto_recurrent_stop_type").select2("val", "");
		});

		$scope.contest_list = [];

		$rootScope.updateUi();
	};

	$scope.getPrizeList = function() {
		$scope.all_number_of_winner = [];
		$scope.prizePool = '';
		$scope.contestParam.custom_prize = "";
		// $scope.contestParam.size = '';
		// $scope.contestParam.entry_fee = '';


		dataSavingHttp({
			url: site_url+"contest/get_all_prize_data",
			data: {league_id:$scope.contestParam.league_id,contest_type:$scope.contestParam.contest_type},
		}).success(function (response) {
			$scope.all_number_of_winner			= response.data.all_number_of_winner;
			$scope.number_of_winner_validation	= response.data.number_of_winner_validation;
			$scope.createGameName();
			deselectContest();
			angular.forEach($scope.number_of_winner_validation,function(v,k){
				$scope.prize_type_validation[v.league_contest_type_id] = v;
			});
			$timeout(function(){
				
				if($scope.contestParam.contest_type == 2 || $scope.contestParam.contest_type == 0)
				{
					angular.element("#select_prize").select2("val", $scope.all_number_of_winner[0].league_contest_type_id);
					$scope.contestParam.number_of_winner_id = $scope.all_number_of_winner[0].league_contest_type_id;
				}
				else
				{
					angular.element("#select_prize").select2("val", "");
				}

				
				if(($scope.contestParam.contest_type).length > 0 && $scope.contestParam.contest_type == 0){
					$scope.getPrizeDetails();
					$scope.contestParam.size = 2;
				} else {
					$scope.contestParam.size = "";
				}

				if($scope.contestParam.contest_type == 3){
					$scope.contestParam.entry_fee = '';
					$scope.prizePool = '';
					$scope.uncappedPrizePool = "Prize will be calculated dynamically.";
					$scope.contestParam.is_uncapped = true;
				} else {
					$scope.contestParam.is_uncapped = false;
					$scope.uncappedPrizePool ='';
				}
			})			
		});
		
	};

	$scope.getAllLeagueGame = function() {
		dataSavingHttp({
			url: site_url+"contest/get_all_league",
			data: {},
		}).success(function (response) {			
			$scope.leagues = response.data;
			var query_data = $location.search();
			//$scope.gameParam.league_id = (query_data.league_id)?query_data.league_id:$scope.leagues[0].league_id;
			$timeout(function(){
				angular.element("#league_id").select2("val", $scope.gameParam.league_id);
				angular.element("#game_type").select2("val", $scope.gameParam.game_type);
			});
			$scope.gameParam = angular.extend($scope.gameParam, query_data);
			$location.search($scope.gameParam);
			$scope.getGameList();
		});
	};

	$scope.getGameList = function() {
		
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.gameParam);
		dataSavingHttp({
			url: site_url+"contest/contest_list/",
			data: $scope.gameParam,
		}).success(function (response) {
			$scope.gameList					= response.data.result;
			$scope.gameParam.total_items	= response.data.total;
			$scope.isLoading				= false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortGameList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.gameParam.sort_field){
			sort_order = ($scope.gameParam.sort_order=='DESC')?'ASC':'DESC';
		}
		// $scope.gameParam.sort_field		= sort_field;
		// $scope.gameParam.sort_order		= sort_order;
		// $scope.gameParam.total_items	= 0;
		// $scope.gameParam.current_page	= 1;
		paginationss.objInit($scope.gameParam,sort_order,sort_field);
		$scope.getGameList();
	};

	$scope.filterGameList = function() {
		$scope.gameParam.sort_order		= 'DESC';
		$scope.gameParam.sort_field		= 'season_scheduled_date';
		$scope.gameParam.total_items	= 0;
		$scope.gameParam.current_page	= 1;
		$scope.getGameList();
	}

	$scope.initObject = function()
	{
		$scope.gameParam				= {};
		$scope.gameParam.league_id		= "";
		$scope.gameParam.game_type		= "";
		// $scope.gameParam.items_perpage	= 10;
		// $scope.gameParam.total_items	= 0;
		// $scope.gameParam.current_page	= 1;
		// $scope.gameParam.sort_order		= 'DESC';
		// $scope.gameParam.sort_field		= 'season_scheduled_date';
		paginationss.objInit($scope.gameParam,"DESC","season_scheduled_date");
		$scope.gameList					= [];
		// var query_data = $location.search();
		// $scope.gameParam = angular.extend($scope.gameParam, query_data);
		$timeout(function(){
			angular.element("#league_id").select2("val", $scope.gameParam.league_id);
			angular.element("#game_type").select2("val", $scope.gameParam.game_type);
			angular.element("#contest_feature").select2("val", $scope.gameParam.contest_feature);
		});
	}

	$scope.clearFilter = function () {
		$scope.initObject();
		$scope.gameParam.league_id = $scope.leagues[0].league_id;
                
		$location.search($scope.gameParam);
		$scope.getGameList();
	};
	$scope.getGameDetail = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$scope.game_unique_id = $state.params.game_unique_id;
                
		dataSavingHttp({
			url: site_url+"contest/get_game_detail",
			data: {game_unique_id:$scope.game_unique_id},
		}).success(function (response) {
			$scope.gameDetail	= response.data;
			$scope.autoRecurrentDetail = response.data.auto_recc_data;
			$scope.isLoading	= false;
			if($scope.gameDetail)
			{
				$scope.gameDetailParam.game_id = response.data.contest_id;
				$scope.getGameLineupDetail(response.data.contest_id);
				$scope.getPlayerLastSalaries(response.data.contest_unique_id, response.data.league_id);
			}
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.getPlayerLastSalaries = function(contest_unique_id,league_id) {	
            	$scope.playerSalaryDetailParam.contest_unique_id = contest_unique_id;
		$scope.playerSalaryDetailParam.league_id = league_id;
		dataSavingHttp({
			url: site_url+"contest/get_all_player_last_salaries",
			data: $scope.playerSalaryDetailParam,
		}).success(function (response) {
			$scope.playerSalaries						= response.data.result;
			$scope.playerSalaryDetailParam.total_items	= response.data.total;
			$scope.isLoading				= false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortPlayerLastSalaries = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.playerSalaryDetailParam.sort_field) {
			sort_order = ($scope.playerSalaryDetailParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.playerSalaryDetailParam.sort_field	= sort_field;
		$scope.playerSalaryDetailParam.sort_order	= sort_order;
		$scope.playerSalaryDetailParam.total_items	= 0;
		$scope.playerSalaryDetailParam.current_page	= 1;

		$scope.getPlayerLastSalaries($scope.gameDetail.contest_unique_id, $scope.playerSalaryDetailParam.league_id);
	};

	$scope.getGameLineupDetail = function(game_id) {	
		$scope.gameDetailParam.game_id = game_id;
		dataSavingHttp({
			url: site_url+"contest/get_game_lineup_detail",
			data: $scope.gameDetailParam,
		}).success(function (response) {
			$scope.gameLineupDetail			= response.data.result;
			$scope.gameLineupPrize			= response.data.prize_selection;
			$scope.gameDetailParam.total_items = response.data.total;
			if(response.data.result.length>0)
			{
				$scope.getLineupDetail(response.data.result[0].lineup_master_id, $scope.gameDetail.league_id);
			}
			$scope.isLoading				= false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.getLineupDetail = function(lineup_master_id,league_id) {
		
		$scope.currentLineupMasterID = lineup_master_id;
		dataSavingHttp({
			url: site_url+"contest/get_lineup_detail",
			data: {lineup_master_id:lineup_master_id,league_id:league_id},
		}).success(function (response) {
			$scope.LineupDetail			= response.data;
		}).error(function (error) {
		});
	};

	 var deselectContest = function() {
		$scope.contests = {};
		$scope.contestParam.contests = [];
		$scope.contestObj.selectall = false;
		$rootScope.updateUi();
	}

	$scope.removeContest = function(contest_unique_id, index) {
		if(confirm("Are you sure. You want to delete this contest?"))
		{
			if($scope.contest_names[index]!="")
			{
				dataSavingHttp({
					url: site_url+"contest/remove_contest",
					data: {contest_unique_id:contest_unique_id},
				}).success(function (response) {
					$rootScope.alert_success = response.message;
					$scope.gameList.splice(index, 1);  
				}).error(function (error) {
					$rootScope.alert_error = error.message;
				});
			}
			else
			{
				$rootScope.alert_error = "Enter contest name";
			}
		}
	}
	$scope.saveContestName = function(contest_unique_id,index) {
		if($scope.contest_names[index]!="")
		{
			$scope.gameList[index].contest_name = $scope.contest_names[index];
			dataSavingHttp({
				url: site_url+"contest/change_contest_name",
				data: {contest_unique_id:contest_unique_id,contest_name:$scope.contest_names[index]},
			}).success(function (response) {
				$scope.contestObj.showSaveContest  = "";
				$rootScope.alert_success = response.message;
			}).error(function (error) {
				$scope.contestObj.showSaveContest ="";
				$rootScope.alert_error = error.message;
			});
		}
		else
		{
			$rootScope.alert_error = "Enter contest name";
		}
	}

	$scope.selectContest = function($event) {
                
		$scope.contestParam.no_of_game					= "";
		$scope.contestParam.is_period_of_recurrent		= 1;
		$scope.contestParam.is_auto_recurrent			= "";
		$scope.contestParam.period_of_recurrent			= "";
		$scope.contestParam.period_of_recurrent_value	= "";
		$scope.contestParam.auto_recurrent_stop_type	= "";
		$scope.contestParam.auto_recurrent_stop_value	= "";

		var contest_unique_id = $event.target.value;
		console.log(contest_unique_id);
		var index = $scope.contestParam.contests.indexOf(contest_unique_id);
		
		($event.target.checked)?$scope.contestParam.contests.push(contest_unique_id):$scope.contestParam.contests.splice(index, 1);
                
                /*Temparory added for client demo for IPL
                if($scope.contestParam.league_duration_id==1 && $scope.contestParam.league_id==8){
                        angular.forEach($scope.contestParam.contests, function(value, key) {
                                if(value != contest_unique_id) {
                                    //console.log(value,' != ',contest_unique_id);
                                    $scope.contestParam.contests.splice(key, 1);
                                    $scope.contests[value] = false;
                                }
                        });
                }
                Temparory condition END*/
                
		console.log($scope.contestParam.contests.length,$scope.contest_list.length);
		if($scope.contestParam.contests.length==$scope.contest_list.length)
		{
			$scope.contestObj.selectall = true;
		}
		else
		{
			$scope.contestObj.selectall = false;
		}
		$rootScope.updateUi();
	};
	$scope.toggleContest = function($event){
		
		$scope.contestParam.no_of_game					= "";
		$scope.contestParam.is_period_of_recurrent		= 1;
		$scope.contestParam.is_auto_recurrent			= "";
		$scope.contestParam.period_of_recurrent			= "";
		$scope.contestParam.period_of_recurrent_value	= "";
		$scope.contestParam.auto_recurrent_stop_type	= "";
		$scope.contestParam.auto_recurrent_stop_value	= "";
		$scope.contestParam.contests=[];
		/*$scope.contests	= $scope.contests = Array.apply(null, Array($scope.contest_list.length)).map(function() { return $event.target.checked; });
		if($event.target.checked){
			for (var i = 0; i < $scope.contest_list.length; i++) {
				$scope.contestParam.contests.push($scope.contest_list[i].season_game_uid);
			};
			angular.forEach($scope.contest_list,function(v,k){
				$scope.contestParam.contests.push(v.season_game_uid);
			});
		}*/

		if($event.target.checked)
		{
			angular.forEach($scope.contest_list,function(v,k){
				$scope.contests[v.season_game_uid] = v.season_game_uid;
				$scope.contestParam.contests.push(v.season_game_uid);
			});
		}
		else
		{
			$scope.contests = [];
			$scope.contestParam.contests = [];
		}
		$rootScope.updateUi();
		
	};

	$scope.doBlur = function($element){
		//console.log('id is '+$element);
		angular.element("#"+$element).trigger("blur");
		if($scope.contestParam.contest_type == 0)
		{
			$scope.contestParam.is_multiple_lineup = false;
			$scope.contestParam.multiple_lineup = 0;	
		}
	};

	$scope.showAutoRecurrentEdit = function(){
		
		$scope.autorecurrenteditmode = true;
		$scope.autorecurrentupdateForm = $scope.autoRecurrentDetail;
		$scope.autorecurrentupdateForm.period_of_recurrent = ($scope.autoRecurrentDetail.period_type !=0) ? $scope.autoRecurrentDetail.period_type : '';
		if($scope.autorecurrentupdateForm.period_of_recurrent!=1)
		{
			$scope.autorecurrentupdateForm.is_period_of_recurrent = 2;
		}
		else
		{
			$scope.autorecurrentupdateForm.is_period_of_recurrent = 1;
			$scope.autorecurrentupdateForm.period_of_recurrent = "";
		}
		$scope.autorecurrentupdateForm.period_of_recurrent_value = ($scope.autoRecurrentDetail.period_value !=0) ? $scope.autoRecurrentDetail.period_value : '';
		$scope.autorecurrentupdateForm.auto_recurrent_stop_type = ($scope.autoRecurrentDetail.period_stop_type !=0) ? $scope.autoRecurrentDetail.period_stop_type : '';
		$scope.autorecurrentupdateForm.auto_recurrent_stop_value = ($scope.autoRecurrentDetail.period_stop_value !=0) ? $scope.autoRecurrentDetail.period_stop_value : '';

		$rootScope.updateUi();
	}

	//submit handler for autorecurrent contest update 
	$scope.AutoReccUpdate = function(){


		$rootScope.current_loader = '.btn-success';
		$scope.autorecurrentupdateForm.contest_unique_id = $scope.gameDetail.contest_unique_id;
		
		//console.log($scope.gameDetail);return false;
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"contest/update_auto_recurrent_contest",
			data: $scope.autorecurrentupdateForm,
		}).success(function (response) {
			$scope.isLoading = false;
			$rootScope.alert_success = response.message;
			$scope.autoRecurrentDetail = response.data.auto_recc_data;
			$scope.autorecurrenteditmode = false;
			//$location.path('/contest');
			$rootScope.updateUi();
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});


	} 

	$scope.resetPrizePool = function(){
		$scope.contestParam.custom_prize = "";
	}

	$scope.getFileRosterDetail = function($info){
		
		if($info.status){
			$scope.feature_img = $info.data.image_name;
			angular.element("#feature_img_error").empty();
			angular.element("#feature_img_error").hide();
			$rootScope.updateUi();
		}
	}
	
	$scope.roster_json = "";
	$scope.getPlayerScore = function(contest_unique_id,player_uid,league_id,player_salary_master_id,sport_id){
		//$scope.roster_json = JSON.parse(info);
		dataSavingHttp({
			url: site_url+"contest/get_player_scoring",
			data: {contest_unique_id:contest_unique_id,player_uid:player_uid,league_id:league_id,player_salary_master_id:player_salary_master_id,sport_id:sport_id},
		}).success(function (response) {
			$scope.playerScoring = response.data.scorings;
			angular.element("#roster_json").modal('show');
		}).error(function(error) {});
	}

	$scope.check_valid_min_size = function()
	{
		if($scope.contestParam.is_multiple_lineup)
		{
			angular.element('#multiple_lineup_error').html('').addClass('hide');
			var identifier = ($scope.contestParam.contest_type == 3) ? "size_min" : "size";
			if( parseInt($scope.contestParam.multiple_lineup) > parseInt($scope.contestParam[identifier]))
			{
				angular.element('#' + identifier + '_error').html($rootScope.lang.min_size_error).removeClass('hide').show();
				$scope.is_valid_size = false;
			}
			else
			{
				angular.element('#' + identifier + '_error').html('').addClass('hide');
				$scope.is_valid_size = true;
			}
		}
	}

	$scope.is_multiple_lineup = function()
	{
		if(!$scope.contestParam.is_multiple_lineup)
		{
			var identifier = ($scope.contestParam.contest_type == 3) ? "#size_min_error" : "#size_error";
			$scope.contestParam.multiple_lineup = 0;
			angular.element(identifier).html('').addClass('hide');
			$scope.is_valid_size = true;	
		}
	}

	$scope.resetSeasonEndWeek = function()
	{
		$scope.contest_list = [];
		$timeout(function(){
			$scope.contestParam.season_end_week = '';
			angular.element('#end_week').select2('val','');
		},100);	
	}
	$scope.teame_list = [];
	$scope.teame_conetst_list = [];
	$scope.custom_weekly_games = function()
	{
		$scope.contest_list = [];
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"contest/get_custom_weekes",
			data: {league_id:$scope.contestParam.league_id,start_week:$scope.contestParam.season_start_week,end_week:$scope.contestParam.season_end_week},
		}).success(function (response) {
			$scope.isLoading = false;
			$scope.contest_list = response.data.game_list;
			$scope.teame_list = response.data.game_list;
			$scope.teame_conetst_list = response.data.game_list;
			var team_array = [];
			var home_array = [];
			var away_array = [];
			for (var i = 0; i < $scope.teame_list.length; i++) {
				//home_array.push($scope.contest_list[i].home);
				//away_array.push($scope.contest_list[i].away);
				home_array[$scope.teame_list[i].home_id] = $scope.teame_list[i].home;
				away_array[$scope.teame_list[i].away_id] = $scope.teame_list[i].away;
			};
			$scope.leagueTeams = angular.extend({},home_array, away_array);
			//$scope.leagueTeams = $scope.leagueTeams.unique($scope.leagueTeams);
			console.log($scope.leagueTeams);
			
		}).error(function(error) {
		});
	}

	var teamsArray = []

	$scope.selectAllTeams = function($event)
	{
		$scope.contest_list = [];
		teamsArray = [];
		$scope.contest_list = $scope.teame_conetst_list;
		$rootScope.updateUi();
	}

	$scope.selectTeams = function($event)
	{
		$scope.contest_list= [];
		var contests = [];
		var team_id = $event.target.value;
		var index = teamsArray.indexOf(team_id);
		
		($event.target.checked)?teamsArray.push(team_id):teamsArray.splice(index, 1);
		if(teamsArray.length>0)
		{
			for (var i = 0; i < $scope.teame_conetst_list.length; i++) 
			{
				for (var j = 0; j < teamsArray.length; j++) 
				{
					if(teamsArray[j]==$scope.teame_conetst_list[i].home || teamsArray[j]==$scope.teame_conetst_list[i].away)
					{
						contests[i] = $scope.teame_conetst_list[i];
					}
				}
			}
			$scope.contest_list = contests
		}
		else
		{
			$scope.contest_list = $scope.teame_conetst_list;
		}

		$rootScope.updateUi();
	}

	$rootScope.updateUi();

	$scope.availableAllSeasonDates = function(date) {
		var Y = date.getFullYear();
		var M = (date.getMonth()+1);
		var D = date.getDate();
		var dmy = "";
		if ( M < 10 )
		{
			M ='0'+M;
		}

		if ( D < 10 )
		{
			D = '0'+D;
		}

		dmy = Y + "-" + M + "-" + D;

		if ($.inArray(dmy,$scope.all_season_scheduled_date) != -1)
		{
			return [ true , "" , "Available" ];
		}
		else
		{
			return [ false , "" , "No Game" ];
		}
	};

	$scope.getAvailableMatchByFromDay = function(from_date) {
		$scope.contestParam.from_date = from_date;
		$scope.contestParam.to_date = '';
		$scope.contestParam.contests=[];
		$scope.contests = [];
		$scope.contest_list = [];
		$scope.$apply();
		$scope.getAvailiableGameOfTheDayOrWeek();
	};

	$scope.getAvailableMatchByToDay = function(to_date) {
		
		$scope.contestParam.to_date = to_date;
		$scope.getAvailiableGameOfTheDayOrWeek();
	};



}]);


Array.prototype.unique = function() {
	var a = [];
	for (var i=0, l=this.length; i<l; i++)
		if (this[i] != undefined && a.indexOf(this[i]) === -1)
			a.push(this[i]);
	return a;
}
