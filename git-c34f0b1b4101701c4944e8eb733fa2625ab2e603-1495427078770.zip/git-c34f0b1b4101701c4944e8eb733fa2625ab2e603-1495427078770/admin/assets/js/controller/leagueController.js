'use strict';

angular.module("vfantasy").controller('LeagueCtrl', ['$scope', '$timeout', '$state', '$rootScope', 'settings', 'dataSavingHttp', '$location', function($scope, $timeout, $state, $rootScope, settings, dataSavingHttp, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	$scope.leagueList					= [];
	$scope.isLoading					= false;
	$scope.leagueParam 					= {};
	$scope.leagueParam.total_items		= 0;
	$scope.leagueParam.current_page		= 1;
	$scope.leagueParam.sort_order		= "DESC";
	$scope.leagueParam.sort_field		= "league_schedule_date";
	
	
	$scope.filterResult = function() {
		$scope.leagueParam.total_items		= 0;
		$scope.leagueParam.current_page		= 1;
		$scope.leagueParam.sort_order		= "DESC";
		$scope.leagueParam.sort_field		= "league_schedule_date";
		$timeout(function(){
			angular.element("#league_id").select2("val", $scope.leagueParam.league_id);
		});
		$scope.getAllLeagues();
	};

	$scope.getAllLeagues = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;

		$location.search($scope.leagueParam);
		dataSavingHttp({
			url: site_url+"league/get_all_leagues",
			data: $scope.leagueParam,
		}).success(function (response) {
			$scope.leagueList				= response.data.result;
			$scope.leagueParam.total_items	= response.data.total;
			$scope.isLoading					= false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortleagueList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.leagueParam.sort_field) {
			sort_order = ($scope.leagueParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.leagueParam.sort_field	= sort_field;
		$scope.leagueParam.sort_order	= sort_order;
		$scope.leagueParam.total_items	= 0;
		$scope.leagueParam.current_page	= 1;
		$scope.getAllLeagues();
	};

	$scope.initObject = function() {
		$scope.leagueParam					= {};
		$scope.leagueParam.items_perpage	= 10;
		$scope.leagueParam.total_items		= 0;
		$scope.leagueParam.current_page		= 1;
		$scope.leagueParam.sort_order		= "DESC";
		$scope.leagueParam.sort_field		= "league_schedule_date";
		$scope.getAllLeagues();
	};
	$scope.clearFilter = function() {
		$scope.initObject();
		
	};
	$scope.leagueObj = {};
	$scope.changeLeagueStatus = function(league_id,league_status,index)
	{

		angular.element("#league_confirmation_modal").modal('show');
		$scope.leagueObj.league_id							= league_id;
		$scope.leagueObj.status								= league_status;
		$scope.leagueObj.index								= index;
	}

	$scope.submitLeagueStatusChange = function() {
		
		if(!($scope.leagueObj).hasOwnProperty('league_id'))
		{
			console.log("not found");
			return false;
		}	

		dataSavingHttp({
			url: site_url+"league/change_league_status",
			data: $scope.leagueObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			angular.element("#league_confirmation_modal").modal('hide');
			$scope.leagueList[$scope.leagueObj.index].active = $scope.leagueObj.status;
			$scope.leagueObj = {};
		}).error(function (error) {
			$scope.leagueObj = {};
			$rootScope.alert_error = error.message;
			angular.element("#league_confirmation_modal").modal('hide');
		});
		
	}
	
  
}]);