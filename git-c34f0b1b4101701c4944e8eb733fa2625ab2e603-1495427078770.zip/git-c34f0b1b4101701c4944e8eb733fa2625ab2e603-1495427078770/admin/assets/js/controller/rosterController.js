'use strict';

angular.module("vfantasy").controller('RosterCtrl', ['$scope', '$stateParams','$timeout', '$state', '$rootScope', 'settings', 'dataSavingHttp', '$location', function($scope,$stateParams, $timeout, $state, $rootScope, settings, dataSavingHttp, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	$scope.tempRosterList 				= {};
	$scope.rosterObj					= {};
	$scope.rosterObj.player_team_id	= [];
	$scope.rosterObj.salary				= {};
	$scope.rosterObj.action				= "";
	$scope.rosterObj.selectall			= false;
	$scope.rosterObj.league_id			= "1";
	$scope.rosterObj.roster_type		= "csv";
	$scope.rosterObj.category_id		= "";

	$scope.player_team_id		= {};
	$scope.teamList				= [];
	$scope.rosterList			= [];
	$scope.isLoading			= false;

	$scope.team_postition	= [];
	$scope.teams			= [];
	$scope.salary			= {};

	$scope.player_name;

	$scope.roster_limit = 50;

	$scope.getAllLeague = function() {
		dataSavingHttp({
			url: site_url+"roster/get_all_league"
		}).success(function (response) {
			if(response.status)
			{
				var query_data = $location.search();
				$scope.current_page = 0;
				$scope.leagues = response.data;
				$scope.rosterParam.league_id = (query_data.league_id)?query_data.league_id:response.data[0].league_id;
				$timeout(function(){
					angular.element("#league_id").select2("val", $scope.rosterParam.league_id);
				});
				$scope.rosterParam = angular.extend($scope.rosterParam, query_data);
				$location.search($scope.rosterParam);

				$scope.getAllTeam(true);
                $scope.initRosterFormData(); // Used in Custom Roster Feed 
			}
		});
	};

	$scope.getAllTeam = function(reset_param) {
		if(!$scope.rosterParam.league_id) return;

		if(!reset_param)
		{
			$scope.rosterParam.team_league_id = '';
			$scope.rosterParam.position = '';
			$scope.rosterParam.category_id = '';
			$location.search('team_league_id', null);
			$location.search('position', null);
		}

		dataSavingHttp({
			url: site_url+"roster/get_all_team",
			data: {league_id:$scope.rosterParam.league_id}
		}).success(function (response) {
			if(response.status)
			{
				var query_data = $location.search();
				$scope.teams = response.data;
				if($scope.teams.length > 0)
				{
				  $scope.rosterParam.team_league_id = (query_data.team_league_id)?query_data.team_league_id:$scope.teams[0].team_league_id;
				}
				$timeout(function(){
					angular.element("#team_league_id").select2("val", $scope.rosterParam.team_league_id);
				},1000);
				$location.search($scope.rosterParam);
				$scope.getAllPosition();
                $scope.getAllRosterCategory();
			}
		});
	};

	$scope.getAllPosition = function() {
		if(!$scope.rosterParam.league_id) return;
		dataSavingHttp({
			url: site_url+"roster/get_all_position",
			data: {league_id:$scope.rosterParam.league_id}
		}).success(function (response) {
			if(response.status)
			{
				$scope.team_postition =	response.data;

				$timeout(function(){
					angular.element("#position").select2("val", $scope.rosterParam.position);
				});
				$scope.getPlayerList();
			}
		});
	};
        
        $scope.getAllRosterCategory = function() {
		if(!$scope.rosterParam.league_id) return;
		dataSavingHttp({
			url: site_url+"roster/get_all_roster_category",
			data: {league_id:$scope.rosterParam.league_id}
		}).success(function (response) {
			if(response.status)
			{
				$scope.roster_category =	response.data;
                                $scope.rosterObj.category_id = '';
				$timeout(function(){
					angular.element("#roster_category").select2("val", "");
					angular.element("#filter_roster_category").select2("val", $scope.rosterParam.category_id);
				},100);
			}
		});
	};

	$scope.getPlayerList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;

		$location.search($scope.rosterParam);
		$scope.rosterObj.selectall = false;

		dataSavingHttp({
			url: site_url+"roster/get_all_roster",
			data: $scope.rosterParam,
		}).success(function (response) {
			$scope.rosterObj.player_team_id = [];

			$scope.player_team_id = Array.apply(null, Array(response.data.result)).map(function() { return false });

			$scope.rosterList				= response.data.result;
			$scope.rosterParam.total_items	= response.data.total;
			$scope.isLoading				= false;

		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortRosterList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.rosterParam.sort_field){
			sort_order = ($scope.rosterParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.rosterParam.sort_field	= sort_field;
		$scope.rosterParam.sort_order	= sort_order;
		$scope.rosterParam.total_items	= 0;
		$scope.rosterParam.current_page	= 1;
		$scope.getPlayerList();
	};

	$scope.filterResult = function() {
		$scope.rosterParam.items_perpage	= 10;
		$scope.rosterParam.total_items		= 0;
		$scope.rosterParam.current_page		= 1;
		$scope.rosterParam.sort_order		= "ASC";
		$scope.rosterParam.sort_field		= "full_name";
		$timeout(function(){
			angular.element("#team_league_id").select2("val", $scope.rosterParam.team_league_id);
		});
		$timeout(function(){
			angular.element("#position").select2("val", $scope.rosterParam.position);
		});
		$timeout(function(){
			angular.element("#filter_roster_category").select2("val", $scope.rosterParam.category_id);
		});
		$scope.getPlayerList();
	};

	$scope.updateRoster = function() {
		$rootScope.current_loader = '.btn-primary';
		$scope.rosterObj.league_id = $scope.rosterParam.league_id;

		dataSavingHttp({
			url: site_url+"roster/update_roster",
			data: $scope.rosterObj
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			angular.forEach($scope.player_team_id, function(value, key) {
			  	if(value && $scope.rosterObj.action != "") {
			  		$scope.rosterList[key].player_status = $scope.rosterObj.action;
			  	}
			});
                        $timeout(function(){
                                deselectPlayer();
                                $scope.getPlayerList();
                        }, 100);
			
		}).error(function(error) {
			$rootScope.alert_error = error.message;
			deselectPlayer();
		});
	};

	$scope.changePlayerStatus = function(player_team_id,status,index) {
		dataSavingHttp({
			url: site_url+"roster/change_player_status",
			data: {player_team_id:player_team_id,player_status:status},
		}).success(function (response) {
			if(response.status) {
				$rootScope.alert_success = response.message;
				$scope.rosterList[index].player_status = status;
			} 
		}).error(function(error){
			$rootScope.alert_error = error.message;	
		});
	};

	$scope.playerRelease = function() {
		$rootScope.current_loader = '.btn-success';
		if(!confirm("Are you sure you release all player."))
		{
			return false;
		}
		dataSavingHttp({
			url: site_url+"roster/release_player",
			data: {league_id:$scope.rosterParam.league_id},
		}).success(function (response) {
			if(response.status)	{
				$rootScope.alert_success = response.message;
			}
			deselectPlayer();
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
	};

	$scope.togglePlayer = function($event){
		$scope.rosterObj.player_team_id=[];
		$scope.player_team_id	= $scope.player_team_id = Array.apply(null, Array($scope.rosterList.length)).map(function() { return $event.target.checked; });
		if($event.target.checked){
			for (var i = 0; i < $scope.rosterList.length; i++) {
				$scope.rosterObj.player_team_id.push($scope.rosterList[i].player_team_id);
			};
		}
		$rootScope.updateUi();
	};

	 var deselectPlayer = function() {
		$scope.player_team_id = {};
		$scope.rosterObj.player_team_id = [];
		$scope.rosterObj.selectall = false;
		$rootScope.updateUi();
	}

	$scope.selectPlayer = function($event) {

		var player_team_id = $event.target.value;
		var index = $scope.rosterObj.player_team_id.indexOf(player_team_id);
		
		($event.target.checked)?$scope.rosterObj.player_team_id.push(player_team_id):$scope.rosterObj.player_team_id.splice(index, 1);

		if($scope.rosterObj.player_team_id.length==$scope.rosterList.length)
		{
			$scope.rosterObj.selectall = true;
		}
		else
		{
			$scope.rosterObj.selectall = false;
		}
		$rootScope.updateUi();
	};

	$scope.$on('repeatFinished', function(){
		angular.element('#league_id').select2("val", $scope.rosterParam.league_id);
		$rootScope.updateUi();
	});

	$scope.initObject = function() {
		$scope.rosterParam					= {};
		$scope.rosterParam.items_perpage	= 10;
		$scope.rosterParam.total_items		= 0;
		$scope.rosterParam.current_page		= 1;
		$scope.rosterParam.sort_order		= "ASC";
		$scope.rosterParam.sort_field		= "full_name";
		$scope.rosterParam.team_league_id			= "";
		$scope.rosterParam.role_id			= "";
		$scope.rosterParam.league_id		= "";
		$scope.rosterParam.category_id		= "";
		$scope.roster_export_type			= "csv";
		$timeout(function(){
			angular.element("#league_id").select2("val", $scope.rosterParam.league_id);
			angular.element("#team_league_id").select2("val", "");
			angular.element("#position").select2("val", "");
			angular.element("#filter_roster_category").select2("val", "");
		});
	};

	$scope.clearFilter = function () {
		$scope.initObject();
		angular.element("#league_id").select2("val", $scope.leagues[0].league_id);
		$scope.rosterParam.league_id = $scope.leagues[0].league_id;
		$scope.getPlayerList();
	};

	$scope.searchByName = function() {
		var textLen = $scope.rosterParam.player_name.length;
		if(textLen<2 && textLen!==0)
		{
			return;
		}

		if($scope.isLoading)
		{
			$scope.rosterParam.player_name = $scope.player_name;
			return;
		}
		$scope.player_name = $scope.rosterParam.player_name;
		$scope.getPlayerList();
	};

	$scope.showExportPopup = function() {
		angular.element("#export_roster_modal").modal('show');
		$rootScope.updateUi();
	};

	$scope.getFileRosterDetail = function(response) {
		var raw_name = response.data.file_name;
		$state.go('import_player', {file_name:raw_name});
	}

	$scope.intilizeRosterList = function() {
		dataSavingHttp({
			url: site_url+"upload/roster/"+$state.params.file_name+".json",
			method:"GET",
		}).success(function (response) {
			$scope.tempRosterList = response;
		}).error(function(error) {
			$scope.tempRosterList = [];
			$rootScope.alert_error = error.message;
		});
	};

	$scope.tempRoster = {};

	$scope.load_more_roster = function(){
		if($scope.tempRosterList.length<$scope.roster_limit)return;
		$scope.roster_limit += 50;
	};

	$scope.importRoster = function() {
		$rootScope.current_loader = '.btn-success';
		var import_params = {import_data:$scope.tempRosterList,import_file:$state.params.file_name};
		dataSavingHttp({
			url: site_url+"roster/import_roster",
			data:import_params,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			// $state.go("roster");
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
	};

	$scope.closeModel = function() {
		angular.element("#export_roster_modal").modal('hide');
		var url = "roster/export_roster/"+$scope.roster_export_type+'/'+$scope.rosterParam.league_id+"";
		window.open(site_url+url);
	};

	//function for cancel roster import and delete uploaded file
	$scope.cancelImportRoster = function(){

		dataSavingHttp({
			url: site_url+"roster/remove_import_file",
			data:{import_file:$state.params.file_name},
		}).success(function (response) {
		}).error(function(error) {
		});	
		$state.go("roster");

	}


        /******************************************
         ******** CUSTOM ROSTER FEED START ********
         ******************************************/
        
        $scope.initRosterFormData = function (){
                
                $scope.empty_season = {
                        team_league_id         : '',
                        first_name      : '',
                        last_name       : '',
                        nick_name       : '',
                        position        : '',
                        salary          : '',
                        injury_status   : '',
                        row             : ''
                };
                
                $scope.roster_data = {
                        league_id               : $scope.rosterParam.league_id,
                        roster                 : []
                }
                
                $scope.roster_data.roster.push($scope.empty_season);
        };
        
        $scope.AddRosterRow = function () {

                $scope.roster_data.roster.push({
                        team_league_id         : '',
                        first_name      : '',
                        last_name       : '',
                        nick_name       : '',
                        position        : '',
                        salary          : '',
                        injury_status   : '',
                        row             : ''
                });
        };
        
        $scope.RemoveRosterRow = function (index) {
            
            if ($scope.roster_data.roster.length > 1) {

                $scope.roster_data.roster[index] = [];
                
                $timeout(function () {
                    
                        $scope.roster_data.roster.splice(index, 1);
                        
                        // reste remaing row's select box values
                        angular.forEach($scope.roster_data.roster, function(value, key) {
                            
			  	if(value ) {
			  		angular.element("#team_league_id_"+key).select2("val", value.team_league_id);
                                        angular.element("#position_"+key).select2("val", value.position);
			  	}
			});
                }, 50);
            }
        };
        
        $scope.showAddRosterPopup = function() {
            
                // Reste all select box values
                angular.forEach($scope.roster_data.roster, function(value, key) {

                        if(value ) {
                                angular.element("#team_league_id_"+key).select2("val", "");
                                angular.element("#position_"+key).select2("val", "");
                        }
                });
                
                $scope.roster_data.roster = [];
                
                $scope.AddRosterRow();
                
		angular.element("#add_roster_modal").modal('show');
		$rootScope.updateUi();
                //$scope.getAddStatisticsFormData();
	};
        
        $scope.SaveRoster = function(RequestFrom) {
                
                var reqData = {
                    league_id           : $scope.rosterParam.league_id,
                    team_league_id             : [],
                    first_name          : [],
                    last_name           : [],
                    nick_name           : [],
                    position            : [],
                    salary              : [],
                    injury_status       : [],
                    row                 : []
                };
                
                angular.forEach($scope.roster_data.roster, function(value, key) {
                        
                        angular.forEach(value, function(val, k) {
                            if(k == 'team_league_id') {
                                reqData.team_league_id.push(val);
                            }
                            else if(k == 'first_name') {
                                reqData.first_name.push(val);
                            }
                            else if(k == 'last_name') {
                                reqData.last_name.push(val);
                            }
                            else if(k == 'nick_name'){
                                reqData.nick_name.push(val);
                            }
                            else if(k == 'position'){
                                reqData.position.push(val);
                            }
                            else if(k == 'salary'){
                                reqData.salary.push(val);
                            }
                            else if(k == 'injury_status'){
                                reqData.injury_status.push(val);
                            }
                            else if(k == 'row'){
                                reqData.row.push(val);
                            }
                        });
                });
                
		$rootScope.current_loader = '.btn-success';
		
		$scope.isLoading = true;
		
		dataSavingHttp({
			url: site_url+"stats_feed/create_roster_stats",
			data: reqData,
		}).success(function (response) {
			$scope.isLoading = false;
			
                        if(RequestFrom != 'AddRow') {
                            
                                $rootScope.alert_success = response.message;
                                angular.element("#add_roster_modal").modal('hide');
                               
                                $timeout(function(){
                                        $state.reload();
                                }, 500);
                        }
		}).error(function(error) {
                    
                        if(RequestFrom != 'AddRow') {
                                $rootScope.alert_error = error.message;
                        }
		});
	};
        
        $scope.edit_roster_data = {};
        $scope.showEditRosterPopup = function(stats_data) {
                $scope.edit_roster_data = {};
                
                angular.element("#edit_roster_modal").modal('show');
		$rootScope.updateUi();
                //var edit_data = stats_data;
                $scope.edit_roster_data = stats_data;
                
                $timeout(function(){
                        angular.element("#edit_team_league_id").select2("val", $scope.edit_roster_data.team_league_id);
                        angular.element("#edit_position").select2("val", $scope.edit_roster_data.position);
                }, 100);
                
                
                console.log($scope.edit_roster_data);
        };
        
        $scope.UpdateRosterStats = function() {
            
		$rootScope.current_loader = '.btn-success';
		
		$scope.isLoading = true;
                $scope.edit_roster_data.league_id = $scope.rosterParam.league_id;
		
		dataSavingHttp({
			url: site_url+"stats_feed/edit_roster_stats",
			data: $scope.edit_roster_data,
		}).success(function (response) {
			$scope.isLoading = false;
			
			$rootScope.alert_success = response.message;
                        
                        // Reste statistics modal
                        $scope.edit_roster_data= {};
                        
                        angular.element("#edit_roster_modal").modal('hide');
			//$location.path('/contest');
                        $timeout(function(){
                                $state.reload();
                        }, 500);
                        
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
	};
        
        $scope.showRosterDelConfirmPopUp = function(del_player_team_id) {
                $scope.del_player_team_id = del_player_team_id;
		angular.element("#delete_confirm_model").modal('show');
	};
        
        $scope.del_player_team_id = '';
        
        $scope.deleteRoster = function () {
                $rootScope.current_loader = '.btn-success';
		
		$scope.isLoading = true;
		
		dataSavingHttp({
			url: site_url+"stats_feed/delete_roster",
			data: {player_team_id: $scope.del_player_team_id},
		}).success(function (response) {
			$scope.isLoading = false;
			
			$rootScope.alert_success = response.message;
                        
                        angular.element("#delete_confirm_model").modal('hide');
                        
                        // Reste statistics modal
                        $scope.del_player_team_id = '';
                        
                        $timeout(function(){
                                $state.reload();
                        }, 500);
                        
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
        };
        
        $scope.downloadRosterTemplate = function() {
                var url = "stats_feed/export_roster_template/"+$scope.rosterParam.league_id+"";
		window.open(site_url+url);
        }
        
        $scope.saveUploadedRosterData = function(data){
                //console.log('data: ',data.data.file_name);
            
                $scope.isLoading = true;
                
                var reqData = {
                    league_id               : $scope.rosterParam.league_id,
                    file_name               : data.data.file_name
                };
		
		dataSavingHttp({
			url: site_url+"stats_feed/save_uploaded_roster_data",
			data: reqData,
		}).success(function (response) {
			$scope.isLoading = false;
			
			$rootScope.alert_success = response.message;
                        
			//$location.path('/contest');
                        $timeout(function(){
                                $state.reload();
                        }, 500);
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
            
        }
}]);