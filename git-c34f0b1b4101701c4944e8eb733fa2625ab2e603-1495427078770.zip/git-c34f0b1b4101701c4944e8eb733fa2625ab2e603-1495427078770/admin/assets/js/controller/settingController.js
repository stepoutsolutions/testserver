'use strict';

angular.module("vfantasy").controller('SettingCtrl', ['$scope', '$timeout', '$state', '$rootScope', 'settings', 'dataSavingHttp','$location', function($scope, $timeout, $state, $rootScope, settings, dataSavingHttp,$location){

	$rootScope.settings.layout.pageBodyFullWidth = true;
	$scope.settingObj = {};
	$scope.settingObj.payment_method = 1;
	$scope.singupBonusObj = {};

	$scope.referralList				= [];
	$scope.isLoading				= false;
	$scope.referralObj				= {};
	

	$scope.getSingupBonus = function() 
	{
		dataSavingHttp({
			url: site_url+"setting/get_signup_bonus",
			data: {},
		}).success(function (response) {
			$scope.singupBonusObj    = response.data;
		}).error(function(error){
			$rootScope.alert_error = error.message;
			$scope.settingObj = {};
		});
	}


	$scope.changePassword = function() {
		$rootScope.current_loader = '.btn-success';

		$scope.settingObj.old_password = window.md5($scope.settingObj.old_password)
		$scope.settingObj.new_password = window.md5($scope.settingObj.new_password)
		$scope.settingObj.confirm_password = window.md5($scope.settingObj.confirm_password)

		dataSavingHttp({
			url: site_url+"setting/change_password",
			data: $scope.settingObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			$scope.settingObj = {};
		}).error(function(error){
			$rootScope.alert_error = error.message;
			$scope.settingObj = {};
		});
	};

	$scope.changeDateTime = function() {
		$rootScope.current_loader = '.btn-success';

		dataSavingHttp({
			url: site_url+"setting/change_date_time",
			data: $scope.settingObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			$timeout(function(){
				window.location.href = window.location.href;
			},1000)
		}).error(function(error){
			$rootScope.alert_error = error.message;
			$scope.settingObj = {};
		});
	};


	$scope.initReferralObject = function() {
		$scope.referralParam					= {};
		$scope.referralParam.items_perpage		= 10;
		$scope.referralParam.total_items		= 0;
		$scope.referralParam.current_page		= 1;
		$scope.referralParam.sort_order			= "ASC";
		$scope.referralParam.sort_field			= "to_email";
		$scope.referralParam.team_id			= "";
		$scope.referralParam.league_id			= "";
		$scope.getReferralList();
	};

	$scope.getReferralList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;

		$location.search($scope.referralParam);
		dataSavingHttp({
			url: site_url+"setting/get_all_referrals",
			data: $scope.referralParam,
		}).success(function (response) {
			$scope.referralList					= response.data.result;
			$scope.referralParam.total_items	= response.data.total;
			$scope.isLoading					= false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.filterResult = function() {
		$scope.referralParam.total_items		= 0;
		$scope.referralParam.current_page		= 1;
		$scope.referralParam.sort_order			= "ASC";
		$scope.referralParam.sort_field			= "to_email";
		$scope.getReferralList();
	};
	$scope.sortreferralList = function(sort_field) {
			if($scope.isLoading) return;
			var sort_order = 'DESC';
			if(sort_field==$scope.referralParam.sort_field) {
				sort_order = ($scope.referralParam.sort_order=='DESC')?'ASC':'DESC';
			}
			$scope.referralParam.sort_field	= sort_field;
			$scope.referralParam.sort_order	= sort_order;
			$scope.referralParam.total_items	= 0;
			$scope.referralParam.current_page	= 1;
			$scope.getReferralList();
	};

	$scope.searchByEmail = function() {
		var textLen = $scope.referralParam.keyword.length;
		if(textLen<2 && textLen!==0)
		{
			return;
		}

		if($scope.isLoading)
		{
			$scope.referralParam.keyword = $scope.keyword;
			return;
		}
		$scope.keyword = $scope.referralParam.keyword;
		$scope.filterResult();
	};

	$scope.getReferralAmount = function() {
		$rootScope.current_loader = '.btn-success';
		dataSavingHttp({
			url: site_url+"setting/get_referral_amount",
			data: $scope.settingObj,
		}).success(function (response) {
			$scope.settingObj.referral_discount = response.data.referral_discount;
			$scope.settingObj.referral_threshold_amount = response.data.referral_threshold_amount;
		}).error(function(error){
			$rootScope.alert_error = error.message;
			$scope.settingObj = {};
		});
	};
	$scope.updateReferralAmount = function() {
		$rootScope.current_loader = '.btn-success';
		dataSavingHttp({
			url: site_url+"setting/update_referral_amount",
			data: $scope.settingObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
			$timeout(function(){
				window.location.href = window.location.href;
			},500)
		}).error(function(error){
			$rootScope.alert_error = error.message;
			var amount  = $scope.settingObj.amount;
			$scope.settingObj = {};
			$scope.settingObj.amount = amount;
		});
	};

	$scope.getPaymentSetting = function() {
		$rootScope.current_loader = '.btn-success';
		dataSavingHttp({
			url: site_url+"setting/get_payment_setting",
			data: $scope.settingObj,
		}).success(function (response) {
			//$scope.settingObj.payment_method = response.data.payment_method;
			$scope.configObj = response.data.payment_config;	
			$rootScope.updateUi();
		}).error(function(error){
			$rootScope.alert_error = error.message;
		});
	};

	$scope.updatePaymentSetting = function() {
		$rootScope.current_loader = '.btn-success';
		dataSavingHttp({
			url: site_url+"setting/update_payment_setting",
			data: $scope.settingObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
		}).error(function(error){
			$rootScope.alert_error = error.message;			
		});
	};

	$scope.updatePaymentConfig = function(){
		var paramObj = {};
		var formData = angular.element("#paymentconfig_form").serializeArray();
		angular.forEach(formData, function(kv, key){
		      paramObj[kv.name] = kv.value;
		 });
		$rootScope.current_loader = '.btn-success';
		dataSavingHttp({
			url: site_url+"setting/update_payment_setting",
			data: paramObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
		}).error(function(error){
			$rootScope.alert_error = error.message;			
		});	
	}

	$scope.updatepayment= function()
	{
		$rootScope.alert_success = 'Payment method saved successfully';
	}

	$scope.updateSignupBonus = function() {

		dataSavingHttp({
			url: site_url+"setting/update_signup_bonus",
			data: $scope.singupBonusObj,
		}).success(function (response) {
			$rootScope.alert_success = response.message;
		}).error(function(error){
			$rootScope.alert_error = error.message;			
		});

	}


}]);