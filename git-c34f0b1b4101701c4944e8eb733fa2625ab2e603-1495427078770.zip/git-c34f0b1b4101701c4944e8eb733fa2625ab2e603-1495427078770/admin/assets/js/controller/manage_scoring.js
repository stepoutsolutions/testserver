angular.module("vfantasy").controller('ScoringCtrl', ScoringCtrl);
ScoringCtrl.$inject = ['$rootScope', '$scope', '$timeout','$filter','$stateParams', '$state', 'settings', 'dataSavingHttp', 'showServerError'];

function ScoringCtrl($rootScope, $scope, $timeout, $filter, $stateParams, $state, settings, dataSavingHttp, showServerError)
{	
	// for sidebar menu parent scope
	$rootScope.settings.layout.pageBodyFullWidth = true;
	$scope.settingObj = {};
	$scope.settingObj.payment_method = 1;

	var sc			= this;
	sc.scoreParam	= {};
	sc.category		= {};
	sc.score_param 	= [];
	sc.master_scoring_rules = [];
	// function declaration part
	sc.get_scoring_filters		= get_scoring_filters;
	sc.filter_result			= filter_result;
	sc.clear_filter				= clear_filter;
	sc.update_master_scoring	= update_master_scoring;
	sc.scoreParam.format		= "";
 	function get_scoring_filters()
	{
		return dataSavingHttp({
			url: site_url + "score/get_scoring_filters"
		}).success(function (response)
		{
			sc.filters 		 = response.data.filters;
			sc.master_sports = response.data.master_sports;
			sc.master_format = response.data.master_format;

			$timeout(function(){
				angular.element("#format").select2("val", sc.scoreParam.format);
			}, 1000);

		}).error(function(error)
		{
			showServerError(error);
		});	
	}

	function filter_result(call_type)
	{
		sc.category = sc.filters[sc.scoreParam.sport_id];
		if(call_type == 'sport')
		{	
			delete sc.scoreParam.cat_id;
			sc.score_param	= {};
			sc.master_scoring_rules = [];
			$timeout(function() 
			{
				angular.element("#cat_id").select2("val", "");
			});
		}
		if(sc.scoreParam.cat_id)
		{
			console.log("call rule");
			return dataSavingHttp({
				url: site_url + "score/get_scoring_rules",
				data: sc.scoreParam
			}).success(function (response)
			{
				sc.master_scoring_rules = response.data.master_scoring_rules;

			}).error(function(error)
			{
				showServerError(error);
				sc.master_scoring_rules = [];
			});	
		}
	}

	function clear_filter()
	{
		sc.scoreParam	= {};
		sc.score_param	= {};
		sc.category		= {};
		sc.master_scoring_rules = [];
		sc.scoreParam.format = "";
		$timeout(function() 
		{
			angular.element("#cat_id").select2("val", "");
			angular.element("#sports_id").select2("val", "");
			angular.element("#format").select2("val","");
		});
	}

	function update_master_scoring()
	{
		var is_valid = true;
		angular.forEach(sc.score_param, function(value, key) 
		{
			if(value.point == "")
			{
				is_valid = false;
				angular.element('#score_point_'+ value.master_scoring_id + '_error').text($rootScope.lang.REQUIRED).removeClass('hide');
			}
			else
			{
				angular.element('#score_point_'+ value.master_scoring_id + '_error').text('').addClass('hide');	
			}  
		});
		if(is_valid)
		{
			return dataSavingHttp({
				url  : site_url + "score/update_master_scoring_points",
				data : sc.score_param
			}).success(function (response)
			{
				$rootScope.alert_success = response.message;
			}).error(function(error)
			{
				if(error.hasOwnProperty('error'))
				{
					showServerError(error);
				}
				else
				{
					$rootScope.alert_error = error.message;
				}
			});
		}
	}
}