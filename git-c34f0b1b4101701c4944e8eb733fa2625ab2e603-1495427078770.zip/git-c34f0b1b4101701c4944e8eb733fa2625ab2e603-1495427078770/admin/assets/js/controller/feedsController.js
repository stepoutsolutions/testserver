'use strict';

angular.module("vfantasy").controller('FeedsCtrl', ['$scope', '$timeout', '$state', '$rootScope', 'settings', 'dataSavingHttp', '$location', function($scope, $timeout, $state, $rootScope, settings, dataSavingHttp, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	$scope.feedsList	= [];
	$scope.isLoading	= false;

	/* Start Transaction Listing Functions */
	$scope.getAllLeague = function() {
		dataSavingHttp({
			url: site_url+"feeds/get_all_league",
			data: {},
		}).success(function (response) {
			var query_data = $location.search();
			$scope.leagues = response.data;
			$scope.feedsParam.league_id = (query_data.league_id)?query_data.league_id:$scope.leagues[0].league_id;
			$timeout(function(){
				angular.element("#league_id").select2("val", $scope.feedsParam.league_id);
			});
			$scope.feedsParam = angular.extend($scope.feedsParam, query_data);
			$location.search($scope.feedsParam);
			$scope.getFeedsList();
		});
	};

	$scope.filterResult = function() {
		$scope.feedsParam.items_perpage	= 10;
		$scope.feedsParam.total_items	= 0;
		$scope.feedsParam.current_page	= 1;
		$timeout(function() {
			angular.element("#league_id").select2("val", $scope.feedsParam.league_id);
		});
		$scope.getFeedsList();
	}

	$scope.getFeedsList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.feedsParam);
		dataSavingHttp({
			url: site_url+"feeds/get_all_raw_feed",
			data: $scope.feedsParam,
		}).success(function (response) {
			$scope.feedsList = response.data.result;
			$scope.feedsParam.total_items = response.data.total;
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortFeedsList = function(sort_field) {

		if($scope.isLoading) return;
		var sort_order = 'DESC';

		if(sort_field==$scope.feedsParam.sort_field){
			sort_order = ($scope.feedsParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.feedsParam.sort_field  = sort_field;
		$scope.feedsParam.sort_order  = sort_order;
		$scope.feedsParam.total_items  = 0;
		$scope.feedsParam.current_page = 1;
		$scope.getFeedsList();
	};

	$scope.initObject = function()
	{
		$scope.feedsParam				= {};
		$scope.feedsParam.items_perpage	= 10;
		$scope.feedsParam.total_items	= 0;
		$scope.feedsParam.current_page	= 1;
		$scope.feedsParam.league_id		= "";
		$scope.feedsParam.fromdate		= "";
		$scope.feedsParam.todate		= "";

		var query_data = $location.search();
		$scope.feedsParam = angular.extend($scope.feedsParam, query_data);
		$timeout(function(){
			angular.element("#league_id").select2("val", $scope.feedsParam.league_id);
		});
	};

	$scope.getFeedData = function(feed_id) {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		dataSavingHttp({
			url: site_url+"feeds/get_feed_detail",
			data: {'feed_id':feed_id},
		}).success(function (response) {
			$scope.feedData = JSON.parse(response.data.raw_data);
			angular.element("#raw_data_modal").modal('show');
			$scope.isLoading = false;
		}).error(function (error) {
			$rootScope.alert_success = error.message;
			$scope.isLoading = false;
		});
	};

	$scope.clearFilter = function() {
		$scope.initObject();
		angular.element("#league_id").select2("val", $scope.leagues[0].league_id);
		$scope.feedsParam.league_id = $scope.leagues[0].league_id;
		$scope.feedsParam.fromdate		= "";
		$scope.feedsParam.todate		= "";
		$scope.getFeedsList();
	};
}]);