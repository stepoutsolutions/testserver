'use strict';

angular.module("vfantasy").controller('TeamrosterCtrl', ['$scope', '$timeout', '$state', '$rootScope', 'settings', 'dataSavingHttp', '$location', function($scope, $timeout, $state, $rootScope, settings, dataSavingHttp, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	$scope.player_unique_id		= {};
	$scope.teamrosterList		= [];
	$scope.isLoading			= false;
	$scope.leagues				= [];
	$scope.teamObj				= {};
	$scope.teamObj.showSaveTeam	= "";
	$scope.team_abbrs			= [];
	$scope.getAllLeague = function() {
		dataSavingHttp({
			url: site_url+"teamroster/get_all_league"
		}).success(function (response) {
			if(response.status)
			{
				var query_data = $location.search();
				$scope.leagues = response.data;
				$scope.teamrosterParam.league_id = (query_data.league_id)?query_data.league_id:response.data[0].league_id;
				$timeout(function(){
					angular.element("#league_id").select2("val", $scope.teamrosterParam.league_id);
				});
				$scope.teamrosterParam = angular.extend($scope.teamrosterParam, query_data);
				$location.search($scope.teamrosterParam);
				$scope.getTeamList();
			}
		});
	};
	$scope.filterResult = function() {
		$scope.teamrosterParam.total_items		= 0;
		$scope.teamrosterParam.current_page		= 1;
		$scope.teamrosterParam.sort_order		= "ASC";
		$scope.teamrosterParam.sort_field		= "team_name";
		$timeout(function(){
			angular.element("#league_id").select2("val", $scope.teamrosterParam.league_id);
		});
		$scope.getTeamList();
	};

	$scope.getTeamList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;

		$location.search($scope.teamrosterParam);
		dataSavingHttp({
			url: site_url+"teamroster/get_all_teamrosters",
			data: $scope.teamrosterParam,
		}).success(function (response) {
			$scope.teamrosterList				= response.data.result;
			$scope.teamrosterParam.total_items	= response.data.total;
			$scope.isLoading					= false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortTeamrosterList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.teamrosterParam.sort_field) {
			sort_order = ($scope.teamrosterParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.teamrosterParam.sort_field	= sort_field;
		$scope.teamrosterParam.sort_order	= sort_order;
		$scope.teamrosterParam.total_items	= 0;
		$scope.teamrosterParam.current_page	= 1;
		$scope.getTeamList();
	};

	$scope.initObject = function() {
		$scope.teamrosterParam					= {};
		$scope.teamrosterParam.items_perpage	= 10;
		$scope.teamrosterParam.total_items		= 0;
		$scope.teamrosterParam.current_page		= 1;
		$scope.teamrosterParam.sort_order		= "ASC";
		$scope.teamrosterParam.sort_field		= "team_name";
		$scope.teamrosterParam.team_id			= "";
		$scope.teamrosterParam.league_id		= "";
		$timeout(function(){
			angular.element("#league_id").select2("val", $scope.teamrosterParam.league_id);
		});		
	};
	$scope.clearFilter = function() {
		$scope.initObject();
		angular.element("#league_id").select2("val", $scope.leagues[0].league_id);
		$scope.teamrosterParam.league_id = $scope.leagues[0].league_id;
		$scope.getTeamList();
	};

	$scope.saveTeamAbbr = function(team_id,index) {
		if($scope.team_abbrs[index]!="")
		{
			$scope.teamrosterList[index].team_abbr = $scope.team_abbrs[index];
			dataSavingHttp({
				url: site_url+"teamroster/change_team_abbr",
				data: {team_id:team_id,team_abbr:$scope.team_abbrs[index]},
			}).success(function (response) {
				$scope.teamObj.showSaveTeam  = "";
				$rootScope.alert_success = response.message;
			}).error(function (error) {
				$scope.teamObj.showSaveTeam ="";
				$rootScope.alert_error = error.message;
			});
		}
		else
		{
			$rootScope.alert_error = "Enter team abbr";
		}
	}
	$scope.initObject();
        
        
        /***************************
         **** CUSTOM FEED START ****
         ***************************/
        
        $scope.empty_team_stats = {
            team_name     : '',
            team_abbr     : '',
            row           : ''
        };
        
        $scope.team_stats_data = {
                league_id      : $scope.teamrosterParam.league_id,
                teams          : []
        }
        //$scope.team_stats_data.teams = [];
        $scope.team_stats_data.teams.push($scope.empty_team_stats);
        
        $scope.showAddTeamStatsPopup = function() {
                console.log('league_id:', $scope.teamrosterParam.league_id);
                $scope.team_stats_data.teams = [];
                
                $scope.AddTeamStatsRow();
                
		angular.element("#add_statistics_modal").modal('show');
		$rootScope.updateUi();
	};
        
        $scope.AddTeamStatsRow = function () {
                
                $scope.team_stats_data.teams.push({
                        team_name       : '',
                        team_abbr       : '',
                        row             : ''
                });
        };
        
        $scope.RemoveTeamStatsRow = function (index) {
            
            if ($scope.team_stats_data.teams.length > 1) {

                $scope.team_stats_data.teams[index] = [];
                
                $timeout(function () {
                    
                        $scope.team_stats_data.teams.splice(index, 1);
                });
                
            }
        };
        
        $scope.SaveTeamStats = function(RequestFrom) {
                
                var reqData = {
                    league_id           : $scope.teamrosterParam.league_id,
                    team_name           : [],
                    team_abbr           : [],
                    row                 : []
                };
                angular.forEach($scope.team_stats_data.teams, function(value, key) {
                        console.log(value);
                        angular.forEach(value, function(val, k) {
                            
                            if(k == 'team_name'){
                                reqData.team_name.push($.trim(val));
                            }
                            else if(k == 'team_abbr'){
                                reqData.team_abbr.push($.trim(val));
                            }
                            else if(k == 'row'){
                                reqData.row.push(val);
                            }
                        });
                });
                //return false;
                
		$rootScope.current_loader = '.btn-success';
		
		$scope.isLoading = true;
		
		dataSavingHttp({
			url: site_url+"stats_feed/create_team_stats",
			data: reqData,
		}).success(function (response) {
			$scope.isLoading = false;
			
                        if(RequestFrom != 'AddRow') {
                            
                                $rootScope.alert_success = response.message;
                                angular.element("#add_statistics_modal").modal('hide');
                               
                               //$location.path('/contest');
                                $timeout(function(){
                                        $state.reload();
                                }, 500);
                        }
		}).error(function(error) {
                    
                    if(RequestFrom != 'AddRow') {
                        console.log('show error');
			//$rootScope.alert_error = error.message;
                    }
		});
	};
        
        $scope.downloadTeamTemplate = function(){
                var url = "stats_feed/export_team_template/"+$scope.teamrosterParam.league_id+"";
		window.open(site_url+url);
        }
        
        $scope.saveUploadedTeamData = function(data){
                //console.log('data: ',data.data.file_name);
            
                $scope.isLoading = true;
                
                var reqData = {
                    league_id               : $scope.teamrosterParam.league_id,
                    file_name               : data.data.file_name
                };
		
		dataSavingHttp({
			url: site_url+"stats_feed/save_uploaded_team_data",
			data: reqData,
		}).success(function (response) {
			$scope.isLoading = false;
			
			$rootScope.alert_success = response.message;
                        
			//$location.path('/contest');
                        $timeout(function() {
                                $state.reload();
                        }, 500);
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
            
        }
        
        $scope.showConfirmPopUp = function(team_data) {
                $scope.delete_team_data = team_data;
		angular.element("#delete_confirm_model").modal('show');
	};
        
        $scope.delete_team_data= {};
        
        $scope.deleteTeam = function () {
                $rootScope.current_loader = '.btn-success';
		
		$scope.isLoading = true;
		
		dataSavingHttp({
			url: site_url+"stats_feed/delete_team_stats",
			data: $scope.delete_team_data,
		}).success(function (response) {
			$scope.isLoading = false;
			
			$rootScope.alert_success = response.message;
                        
                        angular.element("#delete_confirm_model").modal('hide');
                        
                        // Reste statistics modal
                        $scope.delete_team_data= {};
                        
                        $timeout(function(){
                                $state.reload();
                        }, 500);
                        
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
        };
        
        $scope.edit_team_data = {};
        $scope.showEditTeamPopup = function(team_data) {
                $scope.edit_team_data = {};
                
                angular.element("#edit_statistics_modal").modal('show');
		
                var edit_data = team_data;
                $scope.edit_team_data = edit_data;
                
                //console.log($scope.edit_team_data);
        };
        
        $scope.UpdateTeam = function() {
            
		$rootScope.current_loader = '.btn-success';
		
		$scope.isLoading = true;
		
		dataSavingHttp({
			url: site_url+"stats_feed/edit_team_stats",
			data: $scope.edit_team_data,
		}).success(function (response) {
			$scope.isLoading = false;
			
			$rootScope.alert_success = response.message;
                        
                        // Reste statistics modal
                        $scope.edit_team_data= {};
                        
                        angular.element("#edit_statistics_modal").modal('hide');
			//$location.path('/contest');
                        $timeout(function(){
                                $state.reload();
                        }, 500);
                        
		}).error(function(error) {
			$rootScope.alert_error = error.message;
		});
	};
        
        /**** CUSTOM FEED END ******/
}]);