'use strict';

angular.module("vfantasy").controller('ReportCtrl', ['$scope', '$timeout', '$state', '$rootScope', 'settings', 'dataSavingHttp', '$location', function($scope, $timeout, $state, $rootScope, settings, dataSavingHttp, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;

	/*================================== User Report Section =============================*/
	$scope.userReportList		= [];
	$scope.filterUserReport = function() {
		if($scope.userReportParam.to_date == '' || $scope.userReportParam.from_date == '')
		{
			return false;
		}	

		$scope.userReportParam.total_items		= 0;
		$scope.userReportParam.current_page		= 1;
		$scope.userReportParam.sort_order		= "ASC";
		$scope.userReportParam.sort_field		= "first_name";
		$scope.getUserReport();
	};

	$scope.getUserReport = function() {
		$scope.userReportParam.csv = false;
		$location.search($scope.userReportParam);
		dataSavingHttp({
			url: site_url+"report/get_all_user_report",
			data: $scope.userReportParam,
		}).success(function (response) {
			$scope.userReportList				= response.data.result;
			$scope.userReportParam.total_items	= response.data.total;
		}).error(function (error) {
		});
	};

	$scope.exportUserReport = function() {
		$scope.userReportParam.csv = true;
		$location.search($scope.userReportParam);
		dataSavingHttp({
			url: site_url+"report/get_all_user_report",
			data: $scope.userReportParam,
		}).success(function (response) {
			var anchor = angular.element('<a/>');
			anchor.attr({
				href: 'data:attachment/csv;charset=utf-8,' + encodeURI(response),
				target: '_blank',
				download: 'User Report.csv'
			})[0].click(); 
			$scope.userReportParam.csv = false;
		}).error(function (error) {
		});
	};

	$scope.sortUserReport = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.userReportParam.sort_field) {
			sort_order = ($scope.userReportParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.userReportParam.sort_field	= sort_field;
		$scope.userReportParam.sort_order	= sort_order;
		$scope.userReportParam.total_items	= 0;
		$scope.userReportParam.current_page	= 1;
		$scope.getUserReport();
	};

	$scope.initUserReportObject = function() {
		$scope.userReportParam					= {};
		$scope.userReportParam.items_perpage	= 50;
		$scope.userReportParam.total_items		= 0;
		$scope.userReportParam.current_page		= 1;
		$scope.userReportParam.sort_order		= "ASC";
		$scope.userReportParam.sort_field		= "first_name";
		$scope.userReportParam.from_date 		= '';
		$scope.userReportParam.to_date 			= '';
		$scope.userReportParam.csv 				= false;
		var query_data = $location.search();
		$scope.userReportParam = angular.extend($scope.userReportParam, query_data);
	};
	$scope.clearUserReportFilter = function() {
		$scope.userReportParam					= {};
		$scope.userReportParam.items_perpage	= 50;
		$scope.userReportParam.total_items		= 0;
		$scope.userReportParam.current_page		= 1;
		$scope.userReportParam.sort_order		= "ASC";
		$scope.userReportParam.sort_field		= "first_name";
		$scope.userReportParam.from_date 		= '';
		$scope.userReportParam.to_date 			= '';
		$scope.userReportParam.csv 				= false;
		$scope.getUserReport();
	};
	/*====================================================================================*/

	/*============================ Contest Report Section ================================*/
	$scope.contestReportList = [];
	$scope.filterContestReport = function() {
		$scope.contestReportParam.total_items		= 0;
		$scope.contestReportParam.current_page		= 1;
		$scope.contestReportParam.sort_order		= "ASC";
		$scope.contestReportParam.sort_field		= "first_name";
		$scope.getContestReport();
	};

	$scope.getContestReport = function() {
		$scope.contestReportParam.csv = false;
		$location.search($scope.contestReportParam);
		dataSavingHttp({
			url: site_url+"report/get_all_contest_report",
			data: $scope.contestReportParam,
		}).success(function (response) {
			$scope.contestReportList				= response.data.result;
			$scope.contestReportParam.total_items	= response.data.total;
		}).error(function (error) {
		});
	};

	$scope.exportContestReport = function() {
		$scope.contestReportParam.csv = true;
		$location.search($scope.contestReportParam);
		dataSavingHttp({
			url: site_url+"report/get_all_contest_report",
			data: $scope.contestReportParam,
		}).success(function (response) {
			var anchor = angular.element('<a/>');
			anchor.attr({
				href: 'data:attachment/csv;charset=utf-8,' + encodeURI(response),
				target: '_blank',
				download: 'Contest Report.csv'
			})[0].click();
			$scope.contestReportParam.csv = false;
		}).error(function (error) {
		});
	};

	$scope.sortContestReport = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.contestReportParam.sort_field) {
			sort_order = ($scope.contestReportParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.contestReportParam.sort_field	= sort_field;
		$scope.contestReportParam.sort_order	= sort_order;
		$scope.contestReportParam.total_items	= 0;
		$scope.contestReportParam.current_page	= 1;
		$scope.getContestReport();
	};

	$scope.initContestReportObject = function() {
		$scope.contestReportParam					= {};
		$scope.contestReportParam.items_perpage	= 50;
		$scope.contestReportParam.total_items		= 0;
		$scope.contestReportParam.current_page		= 1;
		$scope.contestReportParam.sort_order		= "ASC";
		$scope.contestReportParam.sort_field		= "first_name";
		$scope.contestReportParam.from_date 		= '';
		$scope.contestReportParam.to_date 			= '';
		$scope.contestReportParam.csv 				= false;
		var query_data = $location.search();
		$scope.contestReportParam = angular.extend($scope.contestReportParam, query_data);
	};
	$scope.clearContestReportFilter = function() {
		$scope.contestReportParam					= {};
		$scope.contestReportParam.items_perpage	= 50;
		$scope.contestReportParam.total_items		= 0;
		$scope.contestReportParam.current_page		= 1;
		$scope.contestReportParam.sort_order		= "ASC";
		$scope.contestReportParam.sort_field		= "first_name";
		$scope.contestReportParam.from_date 		= '';
		$scope.contestReportParam.to_date 			= '';
		$scope.contestReportParam.csv 				= false;
		$scope.getContestReport();
	};
	/*====================================================================================*/

	/*============================ Contest Users Report Section ==========================*/
	$scope.contestUsersReportList = [];
	$scope.filterContestUsersReport = function() {
		$scope.contestUsersReportParam.total_items		= 0;
		$scope.contestUsersReportParam.current_page		= 1;
		$scope.contestUsersReportParam.sort_order		= "ASC";
		$scope.contestUsersReportParam.sort_field		= "first_name";
		$scope.getContestUsresReport();
	};

	$scope.getContestUsersReport = function() {
		$scope.contestUsersReportParam.csv = false;
		$location.search($scope.contestUsersReportParam);
		dataSavingHttp({
			url: site_url+"report/get_all_contest_users_report",
			data: $scope.contestUsersReportParam,
		}).success(function (response) {
			$scope.contestUsersReportList				= response.data.result;
			$scope.contestUsersReportParam.total_items	= response.data.total;
		}).error(function (error) {
		});
	};

	$scope.exportContestUsersReport = function() {
		$scope.contestUsersReportParam.csv = true;
		$location.search($scope.contestUsersReportParam);
		dataSavingHttp({
			url: site_url+"report/get_all_contest_users_report",
			data: $scope.contestUsersReportParam,
		}).success(function (response) {
			var anchor = angular.element('<a/>');
			anchor.attr({
				href: 'data:attachment/csv;charset=utf-8,' + encodeURI(response),
				target: '_blank',
				download: 'Contest Users Report.csv'
			})[0].click();
			$scope.contestUsersReportParam.csv = false;
		}).error(function (error) {
		});
	};

	$scope.sortContestUsersReport = function(sort_field) {
		var sort_order = 'DESC';
		if(sort_field==$scope.contestUsersReportParam.sort_field) {
			sort_order = ($scope.contestUsersReportParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.contestUsersReportParam.sort_field	= sort_field;
		$scope.contestUsersReportParam.sort_order	= sort_order;
		$scope.contestUsersReportParam.total_items	= 0;
		$scope.contestUsersReportParam.current_page	= 1;
		$scope.getContestUsersReport();
	};

	$scope.initContestUsersReportObject = function() {
		$scope.contestUsersReportParam					= {};
		$scope.contestUsersReportParam.items_perpage	= 50;
		$scope.contestUsersReportParam.total_items		= 0;
		$scope.contestUsersReportParam.current_page		= 1;
		$scope.contestUsersReportParam.sort_order		= "ASC";
		$scope.contestUsersReportParam.sort_field		= "first_name";
		$scope.contestUsersReportParam.from_date 		= '';
		$scope.contestUsersReportParam.to_date 			= '';
		$scope.contestUsersReportParam.csv 				= false;
		var query_data = $location.search();
		$scope.contestUsersReportParam = angular.extend($scope.contestUsersReportParam, query_data);
	};
	$scope.clearContestUsersReportFilter = function() {
		$scope.contestUsersReportParam					= {};
		$scope.contestUsersReportParam.items_perpage	= 50;
		$scope.contestUsersReportParam.total_items		= 0;
		$scope.contestUsersReportParam.current_page		= 1;
		$scope.contestUsersReportParam.sort_order		= "ASC";
		$scope.contestUsersReportParam.sort_field		= "first_name";
		$scope.contestUsersReportParam.from_date 		= '';
		$scope.contestUsersReportParam.to_date 			= '';
		$scope.contestUsersReportParam.csv 				= false;
		$scope.getContestUsersReport();
	};
	/*====================================================================================*/
}]);

angular.module("vfantasy").controller('UserLocationCtrl', ['$scope', '$timeout', '$rootScope', '$stateParams','settings', 'dataSavingHttp', 'showServerError', '$location', function($scope, $timeout, $rootScope, $stateParams,settings, dataSavingHttp, showServerError, $location){

	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.userList		= [];
	$scope.isLoading	= false;
	$scope.userObj		= {};
	
	$scope.country_list = [];
	$scope.state_list = [];
	$scope.keyword;


	/* Start User History Section */
	$scope.initObject = function(filter) {
		
		$scope.userParam				= {}
		$scope.userParam.items_perpage	= 50;
		$scope.userParam.total_items	= 0;
		$scope.userParam.current_page	= 1;
		$scope.userParam.sort_order		= 'DESC';
		$scope.userParam.sort_field		= 'added_date';
		$scope.userParam.country		= "";
		$scope.userParam.state			= "";
		$scope.userParam.keyword		= "";
		if(filter=='clear')
		{
			$scope.getFilterData();
			$location.search($scope.userParam);
		}
		else
		{
			var query_data = $location.search();
			$scope.userParam = angular.extend($scope.userParam, query_data);
		}
		$timeout(function(){
			angular.element("#country").select2("val", $scope.userParam.country);
			angular.element("#state").select2("val", $scope.userParam.state);
		}, 1000);
		$scope.getUserList();
	};

	$scope.getFilterData = function() {
		dataSavingHttp({
			url: site_url+"report/get_userlocation_filter_data",
			data: {}
		}).success(function (response) {
			$scope.country_list = response.data.country;


			var is_country = $scope.userParam.country;
			if(is_country.length > 0 && is_country != ''){
				$scope.getStateList();
			} else {
				$scope.state_list 	= response.data.state;
			}
			
			
		});
	};

	$scope.getUserList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.userParam);

		
		dataSavingHttp({
			url: site_url+"report/userlocation",
			data: $scope.userParam,
		}).success(function (response) {
			$scope.userList            = response.data.result;
			$scope.userParam.total_items = response.data.total;
			
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortUesrList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.userParam.sort_field){
			sort_order = ($scope.userParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.userParam.sort_field  = sort_field;
		$scope.userParam.sort_order  = sort_order;
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
		
	};

	$scope.searchByCity = function() {
		var textLen = $scope.userParam.keyword.length;
		if(textLen<2 && textLen!==0)
		{
			return;
		}

		if($scope.isLoading)
		{
			$scope.userParam.keyword = $scope.keyword;
			return;
		}
		$scope.keyword = $scope.userParam.keyword;
		$scope.getUserList();
	};

	/*for get state list*/
	$scope.getStateList = function(){
		dataSavingHttp({
			url: site_url+"report/get_state_by_country",
			data: {master_country_id:$scope.userParam.country}
		}).success(function (response) {
			if(response.status){
				$scope.state_list = response.data.state;
				angular.element("#state").select2("val", '');
			} else {
				$scope.state_list = {};
				$timeout(function(){
					angular.element("#state").select2("val", '');
				}, 1000);
			}
		}).error(function(error){
			$scope.state_list = {};
			$timeout(function(){
					angular.element("#state").select2("val", '');
				}, 1000);
		});
	};
	/*code end*/
}]);

angular.module("vfantasy").controller('UserActivityCtrl', ['$scope', '$timeout', '$rootScope', '$stateParams','settings', 'dataSavingHttp', 'showServerError', '$location', function($scope, $timeout, $rootScope, $stateParams,settings, dataSavingHttp, showServerError, $location){

	

	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.userList		= [];
	$scope.isLoading	= false;
	$scope.userObj		= {};
	$scope.country_list = [];
	$scope.state_list   = [];
	$scope.keyword;


	/* Start User History Section */

	$scope.initObject = function(filter) {
		
		$scope.userParam				= {}
		$scope.userParam.items_perpage	= 50;
		$scope.userParam.total_items	= 0;
		$scope.userParam.current_page	= 1;
		$scope.userParam.sort_order		= 'DESC';
		$scope.userParam.sort_field		= 'last_login';
		$scope.userParam.activity_duration		= "";
		$scope.userParam.fromdate		= "";
		$scope.userParam.todate			= "";
		if(filter=='clear')
		{
			
			$location.search($scope.userParam);
		}
		else
		{
			var query_data = $location.search();
			$scope.userParam = angular.extend($scope.userParam, query_data);
		}
		$timeout(function(){
			angular.element("#activity_duration").select2("val", $scope.userParam.activity_duration);
		}, 1000);
		$scope.getUserList();
	};

	

	$scope.getUserList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.userParam);

		
		dataSavingHttp({
			url: site_url+"report/useractivity",
			data: $scope.userParam,
		}).success(function (response) {
			$scope.userList            = response.data.result;
			$scope.userParam.total_items = response.data.total;
			
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortUesrList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.userParam.sort_field){
			sort_order = ($scope.userParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.userParam.sort_field  = sort_field;
		$scope.userParam.sort_order  = sort_order;
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
		
	};

	$scope.resetDates = function(){

		if($scope.userParam.activity_duration != 4){
			$scope.userParam.fromdate		= "";
			$scope.userParam.todate			= "";
			$location.search($scope.userParam);
		}
	}

	

	
}]);
angular.module("vfantasy").controller('UserMoneyPaidCtrl', ['$scope', '$timeout', '$rootScope', '$stateParams','settings', 'dataSavingHttp', 'showServerError', '$location', function($scope, $timeout, $rootScope, $stateParams,settings, dataSavingHttp, showServerError, $location){
	
	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.userList		= [];
	$scope.isLoading	= false;
	$scope.userObj		= {};
	$scope.country_list = [];
	$scope.state_list   = [];
	$scope.keyword;


	/* Start User History Section */

	$scope.initObject = function(filter) {
		
		$scope.userParam				= {}
		$scope.userParam.items_perpage	= 50;
		$scope.userParam.total_items	= 0;
		$scope.userParam.current_page	= 1;
		$scope.userParam.sort_order		= 'DESC';
		$scope.userParam.sort_field		= 'U.added_date';
		if(filter=='clear')
		{			
			$location.search($scope.userParam);
		}
		else
		{
			var query_data = $location.search();
			$scope.userParam = angular.extend($scope.userParam, query_data);
		}
		$scope.getUserList();
	};

	

	$scope.getUserList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.userParam);

		
		dataSavingHttp({
			url: site_url+"report/get_report_money_paid_by_user",
			data: $scope.userParam,
		}).success(function (response) {
			$scope.userList            = response.data.result;
			$scope.userParam.total_items = response.data.total;
			
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortUesrList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.userParam.sort_field){
			sort_order = ($scope.userParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.userParam.sort_field  = sort_field;
		$scope.userParam.sort_order  = sort_order;
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
		
	};

}]);

angular.module("vfantasy").controller('UserDepositAmountCtrl', ['$scope', '$timeout', '$rootScope', '$stateParams','settings', 'dataSavingHttp', 'showServerError', '$location', function($scope, $timeout, $rootScope, $stateParams,settings, dataSavingHttp, showServerError, $location){
	
	$rootScope.settings.layout.pageBodyFullWidth = true;
	
	$scope.userList		= [];
	$scope.isLoading	= false;
	$scope.userObj		= {};
	$scope.country_list = [];
	$scope.state_list   = [];
	$scope.keyword;
	$scope.paymentMehod = [];
	$scope.totalDeposit = 0;
	$scope.userParam = {};
	$scope.userParam.payment_method = 'paypal';
	/* Start User History Section */

	$scope.initObject = function(filter) {
		
		$scope.userParam				= {}
		$scope.userParam.items_perpage	= 50;
		$scope.userParam.total_items	= 0;
		$scope.userParam.current_page	= 1;
		$scope.userParam.sort_order		= 'DESC';
		$scope.userParam.sort_field		= 'added_date';
		$scope.userParam.payment_method = 'paypal';
		if(filter=='clear')
		{			
			$location.search($scope.userParam);
		}
		else
		{
			var query_data = $location.search();
			$scope.userParam = angular.extend($scope.userParam, query_data);
		}
		$timeout(function(){
			angular.element("#payment_method").select2("val", "paypal");
		},500)
		$scope.getFilterData();
		$scope.getUserList();
	};

	$scope.getFilterData = function() {
		
		dataSavingHttp({
			url: site_url+"report/get_deposit_amount_filter_data",
			data: {},
		}).success(function (response) {
			$scope.paymentMehod = response.data;
		}).error(function (error) {
		});
	};

	$scope.getUserList = function() {
		if($scope.isLoading) return;
		$scope.isLoading = true;
		$location.search($scope.userParam);

		
		dataSavingHttp({
			url: site_url+"report/get_report_user_deposit_amount",
			data: $scope.userParam,
		}).success(function (response) {
			$scope.userList            = response.data.result;
			$scope.userParam.total_items = response.data.total;
			$scope.totalDeposit = response.data.total_deposit;
			$scope.isLoading = false;
		}).error(function (error) {
			$scope.isLoading = false;
		});
	};

	$scope.sortUesrList = function(sort_field) {
		if($scope.isLoading) return;
		var sort_order = 'DESC';
		if(sort_field==$scope.userParam.sort_field){
			sort_order = ($scope.userParam.sort_order=='DESC')?'ASC':'DESC';
		}
		$scope.userParam.sort_field  = sort_field;
		$scope.userParam.sort_order  = sort_order;
		$scope.userParam.total_items  = 0;
		$scope.userParam.current_page = 1;
		$scope.getUserList();
		
	};

}]);