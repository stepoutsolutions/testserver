angular.module("vfantasy").controller('SubadminCtrl', ['$scope','$timeout', '$stateParams','dataSavingHttp', '$location', '$sce','showServerError','$rootScope',function ($scope,$timeout, $stateParams,dataSavingHttp, $location, $sce,showServerError,$rootScope) {
    $scope.userObj                  = {};
    $scope.userObj.user_unique_id   = [];
    $scope.user_unique_id   = [];
    $scope.userObj.action           = "";
    $scope.userObj.reason           = "";
    $scope.PrivilegeObj = {game:0, roster:0, advertise:0, user:0, report:0, trending:0};
    
    $scope.AdminFormObj = {email:'', firstname:'', username:'', password:'', conf_password: '', privilege: $scope.PrivilegeObj};
    $scope.userParam               = {}
        $scope.userParam.items_perpage  = 10;
        $scope.userParam.total_items    = 0;
        $scope.userParam.current_page   = 1;
        $scope.userParam.sort_order     = 'DESC';
        $scope.userParam.sort_field     = 'added_date'; 

    $scope.message = 0;
    $scope.messagedetail = '';
    $scope.limit = 100;
    $scope.total = 0;
    $scope.start = 0;
    $scope.adminlist = {};
    $scope.adminlistlen =0;
    $scope.active = '';
    $scope.category_id = '';
    $scope.order_sequence = 'ASC';
    $scope.order_by = 'firstname'; 
    $scope.showSendEmailAllModel = function() {
        angular.element("#send_email_all_model").modal('show');
    };
    $scope.toggleUser = function($event){
        $scope.userObj.user_unique_id = [];
        $scope.user_unique_id   = $scope.user_unique_id = Array.apply(null, Array($scope.adminlist.length)).map(function() { return $event.target.checked; });
        if($event.target.checked){
            for (var i = 0; i < $scope.adminlist.length; i++) {
                $scope.userObj.user_unique_id.push($scope.adminlist[i].user_unique_id);
            };
        }
        $rootScope.updateUi();
    };
    $scope.userInactive = function(user_unique_id, status, index) {
          
            dataSavingHttp({
                url: site_url+"subadmin/change_user_status",
                data: {'user_unique_id':user_unique_id,'status': status},
            }).success(function (response) {
                $rootScope.alert_success    = response.message;
                $scope.adminlist[index].status = status;
                $scope.userObj.reason = "";
                angular.element("#user_inactive_modal").modal('hide');
                $scope.isLoading    = false;
            }).error(function (error) {
                $rootScope.alert_success    = error.message;
                $scope.isLoading = false;
            });
        };


    $scope.changeUserStatus = function(user_unique_id,status,index) {
        $rootScope.current_loader = '.btn-primary';
        if($scope.isLoading) return;
        $scope.isLoading = true;
        dataSavingHttp({
            url: site_url+"subadmin/change_user_status",
            data: {'user_unique_id':user_unique_id,'status': status},
        }).success(function (response) {
            $rootScope.alert_success    = response.message;
            $scope.adminlist[index].status = status;
            $scope.userObj.reason = "";
            angular.element("#user_inactive_modal").modal('hide');
            $scope.isLoading    = false;
        }).error(function (error) {
            $rootScope.alert_success    = error.message;
            $scope.isLoading = false;
        });
    };

    $scope.getAdminGroup = function() {       
        dataSavingHttp({
            url: site_url+"subadmin/get_admin_group",          
        }).success(function (response) {
            $scope.grouplist = response.data.grouplist;
        }).error(function (error) {
            $rootScope.alert_success    = error.message;
            $scope.isLoading = false;
        });
    };

    $scope.getSubGroup = function() {       
        dataSavingHttp({
            url: site_url+"subadmin/group_detail_by_id",          
            data:{category_id:$scope.category_id}
        }).success(function (response) {
            $scope.subCatlist = response.data.sub_grouplist;
        }).error(function (error) {
            $rootScope.alert_success    = error.message;
            $scope.isLoading = false;
        });
    };


    $scope.addAdminUser  = function()
    {            
		var PostData = {
				"firstname"     : $scope.AdminFormObj.firstname,
				"email"         : $scope.AdminFormObj.email, 
                "username"      : $scope.AdminFormObj.username, 
				"selected_group"      : $scope.category_id, 
				"password"      : window.md5($scope.AdminFormObj.password),
                                "confpassword"  : window.md5($scope.AdminFormObj.confpassword),
                                "privilege"     : $scope.AdminFormObj.privilege
			};
            dataSavingHttp({
                url: site_url+"subadmin/save_admin",
                data: PostData,
            }).success(function (res) {
                var response = res;
               if(response.status)
                {
                    $scope.message = 1;
                    $rootScope.alert_success = response.message;
                    setTimeout(function () {
                            window.location.href = response.next_url;
                    }, 2000);
                }
                else
                {
                    $scope.message = 2;
                    $scope.messagedetail = response.message;
                }

                $( 'html, body').animate({
                      scrollTop: $('body').offset().top
                    }, 300); 
            }).error(function (error) {
                // $scope.isLoading = false;
                showServerError(error);
            });
       
    };

    $scope.sendEmailSelectedUser = function() {
        angular.element("#send_email_selected_model").modal('hide');
        dataSavingHttp({
            url: site_url+"subadmin/send_email_selected_user/",
            data: $scope.userObj,
        }).success(function (response) {
            $rootScope.alert_success    = response.message;
            $scope.userObj={};
            $scope.userObj.user_unique_id=[];
            $scope.deselectUser();
        }).error(function (error) {
            $rootScope.alert_error  = error.message;
            angular.element("#send_email_selected_model").modal('hide');
        });
    };

    $scope.changeSelectedUserStatus = function() {
        $rootScope.current_loader = '.btn-primary';
        if($scope.isLoading) return;
        $scope.isLoading = true;
        dataSavingHttp({
            url: site_url+"subadmin/change_all_user_status",
            data: {'user_unique_id':$scope.userObj.user_unique_id,'reason':$scope.userObj.reason,'status': $scope.userObj.action},
        }).success(function (response) {
            $rootScope.alert_success        = response.message;
            angular.forEach($scope.user_unique_id, function(value, key) {
                $scope.adminlist[key].status = $scope.userObj.action;
            });
            $scope.userObj.reason           = "";
            $scope.deselectUser();
            angular.element("#all_user_inactive_modal").modal('hide');
            $scope.isLoading    = false;
        }).error(function (error) {
            $rootScope.alert_success    = error.message;
            $scope.isLoading = false;
        });
    };

    $scope.selectUser = function($event) {

        var user_unique_id = $event.target.value;
        var index = $scope.userObj.user_unique_id.indexOf(user_unique_id);
        
        ($event.target.checked)?$scope.userObj.user_unique_id.push(user_unique_id):$scope.userObj.user_unique_id.splice(index, 1);

        if($scope.userObj.user_unique_id.length==$scope.adminlist.length)
        {
            $scope.userObj.selectall = true;
        }
        else
        {
            $scope.userObj.selectall = false;
        }
        $rootScope.updateUi();
    };
    


   $scope.showSendEmailSelectedModel = function() {
        if($scope.userObj.user_unique_id.length>0)
        {
            $scope.userObj.emails = [];
            angular.forEach($scope.user_unique_id, function(value, key) {
                $scope.userObj.emails.push($scope.adminlist[key].email);
            });
            $scope.userObj.selected_emails = $scope.userObj.emails.toString();
            angular.element("#send_email_selected_model").modal('show');
        }
        else
        {
            $rootScope.alert_error  = $rootScope.lang.SELECT_USER;
        }
    };           

    $scope.serverApiCall = function(paramObj, url,name)
    {
            $location.search($scope.userParam);

            dataSavingHttp({
                url: site_url+"subadmin/"+url,
                data: paramObj,
            }).success(function (response) {
                $scope.limit = Number(angular.element('#limit').val());
                $scope.start = response.data.start;
                $scope.adminlist = response.data.adminlist;
                $scope.adminlistlen = response.data.adminlist.length;
                $scope.userParam.total_items = $scope.total = response.data.total;

                //$scope.order_sequence = response.data.order_sequence;
                $scope.order_by = response.data.field_name;
                if(response.data.order_sequence=='ASC')
                {
                    $('.ui-icon-'+name).removeClass('ui-icon-triangle-1-s');
                    $('.ui-icon-'+name).addClass('ui-icon-triangle-1-n');
                }
                else
                {
                    $('.ui-icon-'+name).removeClass('ui-icon-triangle-1-n');
                    $('.ui-icon-'+name).addClass('ui-icon-triangle-1-s');   
                }
            }).error(function (error) {
                // $scope.isLoading = false;
            });

       
    };

    $scope.deselectUser = function() {
        $scope.userObj                  = {};
        $scope.user_unique_id           = {};
        $scope.userObj.action           = "";
        $scope.userObj.reason           = "";
        $scope.userObj.user_unique_id   = [];
        $scope.userObj.selectall        = false;
        $rootScope.updateUi();
    };

    $scope.updateInactveUser = function() {
        userObj={};userObj.user_unique_id=[]; 
        $scope.deselectUser();     
    };

    $scope.getAdminList  = function(name)
    {
        
        if (typeof name != "undefined") 
        {
                $scope.order_by = name;
                $scope.order_sequence = ($scope.order_sequence == 'ASC') ? 'DESC' : 'ASC';
        }

        var paramObj = {dataparam:$scope.userParam,start: $scope.start,search_keyword: $scope.search_keyword,limit: angular.element('#limit').val(), "order": $scope.order_sequence, "field": $scope.order_by};
        $scope.serverApiCall(paramObj, 'get_admin_list',name);
    };
    
    $scope.SetPagingAct = function (text, page) 
    {
        $scope.start = (page - 1) * $scope.limit;
        $scope.getAdminList();
    };
   
    $scope.updateStatus  = function(id,status)
    {
        
        var PostData = {id:id,status:status}
            dataSavingHttp({
                url: site_url+"subadmin/update_status",
                data: PostData,
            }).success(function (response) {
                if(response.status)
                {
                    $scope.message       = 1;
                   $rootScope.alert_success = response.message;
                }
                else
                {
                    $scope.message       = 2;
                    $rootScope.alert_success = response.message;
                }

                $( 'html, body').animate({
                      scrollTop: $('body').offset().top
                    }, 300); 

                setTimeout(function () {
                    window.location.href = window.location.href;
                }, 1000);
            }).error(function (error) {
                // $scope.isLoading = false;
            });

        
    };
    
    $scope.UpdateAdminsStatus = function()
    {
        var total_checked = $( '.admin_id:checked').length;
        if ( total_checked == 0 )
        {
            hideloading();
            jAlert( 'Please select admin.' );
            return false;
        }
        else if(!$scope.status)
        {
            hideloading();
            jAlert( 'Please select status.' );
            return false;
        }
        var ser_data = {};
        var adminID = {};
        if($('.admin_id:checked').is(":checked"))
        {
            $.each( $( '.admin_id:checked' ) , function(i)
            {
                var admin_id = $(this).val();
                adminID[i] = admin_id;
            })
            ser_data['id'] = adminID;
            ser_data['status'] = $scope.status;
        }
        var PostData = ser_data;

            dataSavingHttp({
                url: site_url+"subadmin/update_status_all",
                data: PostData,
            }).success(function (response) {
                 if(response.status)
                {
                    $scope.message = 1;
                    $rootScope.alert_success = response.message;
                }
                else
                {
                    $scope.message = 2;
                    $rootScope.alert_success = response.message;
                }

                $( 'html, body').animate({
                        scrollTop: $('body').offset().top
                }, 1000); 
                
                setTimeout(function () {
                        location.reload();
                }, 1000);
            }).error(function (error) {
                // $scope.isLoading = false;
            });

       

    }
    
    $scope.UpdateAdminsPermission = function()
    {
        var total_checked = $( '.admin_id:checked').length;
        if ( total_checked == 0 )
        {
            hideloading();
            jAlert( 'Please select admin.' );
            return false;
        }
        var permission_data = {};
        var adminID = {};
        var adminid_arr = [];
        if($('.admin_id:checked').is(":checked"))
        {
            $.each( $( '.admin_id:checked' ) , function(i)
            {
                var admin_id = $(this).val();
                adminID[i] = admin_id;
                adminid_arr.push(admin_id);
            });
            
            var adminlist = $scope.adminlist;
            adminlist = jQuery.grep(adminlist, function( admin ) {
                    return (jQuery.inArray( admin.id, adminid_arr ) >= 0) ;
            });
            
            permission_data['id'] = adminID;
            permission_data['admindata'] = adminlist;
        }
        
        var PostData = permission_data;
        dataSavingHttp({
                url: site_url+"subadmin/update_permission_all",
                data: PostData,
            }).success(function (response) {
                 if(response.status)
                {
                    $scope.message = 1;
                   $rootScope.alert_success = response.message;
                }
                else
                {
                    $scope.message = 2;
                    $rootScope.alert_success = response.message;
                }

                $( 'html, body').animate({
                  scrollTop: $('body').offset().top
                }, 1000); 
                
                setTimeout(function () {
                        location.reload();
                }, 1000); 
            }).error(function (error) {
                // $scope.isLoading = false;
            });

        

    }
    
    $scope.getAdminDetail  = function(id)
    {
        var PostData = {adminid:$stateParams.editId};
       

        dataSavingHttp({
                url: site_url+"subadmin/get_admin_by_id",
                data: PostData,
            }).success(function (response) {
                 $scope.AdminFormObj = {
                    id          : response.data.admin_id,
                    email       : response.data.email, 
                    firstname   : response.data.firstname, 
                    username    : response.data.username, 
                    password    : '', 
                    confpassword: '', 
                    privilege   : $scope.PrivilegeObj
                };
                $timeout(function(){
                    var cat_id = response.data.category_ids;
                    var arr = (cat_id) ? cat_id.split(',') : [];
                    
                    angular.element('#action_grp').select2('val',arr);
                    $scope.category_id = arr;
                    console.log('group updated', arr);
                },200);
            }).error(function (error) {
                // $scope.isLoading = false;
            });

       
    };
    
    $scope.updateAdminUser = function()
    {
        var PostData = $scope.AdminFormObj;
        PostData.selected_group = $scope.category_id;
        PostData.password = ($scope.AdminFormObj.password != '') ? window.md5($scope.AdminFormObj.password) : '';
        PostData.confpassword = ($scope.AdminFormObj.confpassword != '') ? window.md5($scope.AdminFormObj.confpassword) : '';
         dataSavingHttp({
            url: site_url+"subadmin/update_admin",
            data: PostData,
        }).success(function (response) {
             if(response.status)
            {
                $scope.message = 1;
                $rootScope.alert_success = response.message;
                setTimeout(function () {
                    window.location.href = response.next_url;
                }, 2000); 
            }
            else
            {
                $scope.message = 2;
                $rootScope.alert_success = response.message;
            }

            $( 'html, body').animate({
                    scrollTop: $('body').offset().top
            }, 1000);
        }).error(function (error) {
            // $scope.isLoading = false;
        });
    };
    
    $scope.adminExportToCsv = function (name, order)
    {
            if (typeof name != "undefined")
            {
                $scope.order_by = name;
                $scope.order_sequence = $scope.order_sequence;
            }
            var from_date = angular.element('#from_date').val();
            var to_date = angular.element('#to_date').val();
            var paramObj = {start: $scope.start,from_date: from_date, to_date: to_date, limit: angular.element('#limit').val(), "order": $scope.order_sequence, "field": $scope.order_by,'is_csv':"true"};
            var file_name = 'SubAdminReport-'+random_string(7);
            //$scope.serverApiCall(paramObj, 'get_all_user_detail', name,file_name);
            window.location.href = "admin/subadmin/force_user_report_downloads/";
    };
    
    $scope.sendEmail = function()
    {
        if($("#valid").validationEngine( 'validate' ))
        {
            
            var message = angular.element("#message").val();
            var ret_email = angular.element("#ret_email").val();
            
            if(ret_email!=''){
                var PostData = {subject:$scope.subject,message:message,action:'add',ret_email:ret_email};
                 dataSavingHttp({
                        url: site_url+"subadmin/adminsetting/sendemails",
                        data: PostData,
                    }).success(function (response) {
                         if(response.status){
                        closePopDiv('sendemailpopup', 'bounceOutup');

                        $scope.message = 1;
                       $rootScope.alert_success = response.message;
                        $timeout(function(){
                            location.reload();
                        },3000); 

                    }else{
                        $scope.message = 2;
                        $scope.messagedetail = response.message;
                        $( 'html, body').animate({
                          scrollTop: $('body').offset().top
                        }, 1000); 
                    }
                    }).error(function (error) {
                        jAlert("Please select admin user.")
                        
                    });
            
            }else{
                
            }
        }
    };
    
    $scope.trustAsHtml = function (html) {
        //return $sce.trustAsHtml(html ? String(html).replace(/<[^>]+>/gm, '') : '');
        return $sce.trustAsHtml(html ? String(html) : '');
    };

    $scope.sendEmailAllUsers = function() {
        angular.element("#send_email_all_model").modal('hide');
        dataSavingHttp({
            url: site_url+"subadmin/send_email_all_user/",
            data: $scope.userObj,
        }).success(function (response) {
            $rootScope.alert_success    = response.message;
            $scope.userObj={};
            $scope.userObj.user_unique_id=[];
        }).error(function (error) {
            $rootScope.alert_error  = error.message;
            angular.element("#send_email_all_model").modal('hide');
        });
    };

    $scope.exportUser = function() {
        dataSavingHttp({
            url: site_url+"subadmin/export_users",
            data: {},
        }).success(function (response) {
            var anchor = angular.element('<a/>');
            anchor.attr({
                href: 'data:attachment/csv;charset=utf-8,' + encodeURI(response),
                target: '_blank',
                download: 'User List.csv'
            })[0].click(); 
        }).error(function (error) {
        });
    };

}]);