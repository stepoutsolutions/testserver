/* ========================================================
*
* Londinium - premium responsive admin template
*
* ========================================================
*
* File: application_blank.js;
* Description: Minimum of necessary js code for blank page.
* Version: 1.0
*
* ======================================================== */

$(function() {

/* # Bootstrap Plugins
================================================== */

	//===== Add fadeIn animation to dropdown =====//

	$('.dropdown, .btn-group').on('show.bs.dropdown', function(e){
		$(this).find('.dropdown-menu').first().stop(true, true).fadeIn(100);
	});

	//===== Add fadeOut animation to dropdown =====//

	$('.dropdown, .btn-group').on('hide.bs.dropdown', function(e){
		$(this).find('.dropdown-menu').first().stop(true, true).fadeOut(100);
	});

/* # Default Layout Options
================================================== */

	//===== Hiding sidebar =====//

	$('.sidebar-toggle').click(function () {
		$('.page-container').toggleClass('hidden-sidebar');
	});
});

function random_string(x){
	var s = "";
	while(s.length<x&&x>0){
			var r = Math.random();
			s+= (r<0.1?Math.floor(r*100):String.fromCharCode(Math.floor(r*26) + (r>0.5?97:65)));
	}
	return s;
};

function getWatchers(root) {
	root = angular.element(root || document.documentElement);
	var watcherCount = 0;

	function getElemWatchers(element) {
		var isolateWatchers = getWatchersFromScope(element.data().$isolateScope);
		var scopeWatchers = getWatchersFromScope(element.data().$scope);
		var watchers = scopeWatchers.concat(isolateWatchers);
		angular.forEach(element.children(), function (childElement) {
		watchers = watchers.concat(getElemWatchers(angular.element(childElement)));
	});
		return watchers;
	}

	function getWatchersFromScope(scope) {
		if (scope) {
			return scope.$$watchers || [];
		} else {
			return [];
		}
	}

	return getElemWatchers(root);
};