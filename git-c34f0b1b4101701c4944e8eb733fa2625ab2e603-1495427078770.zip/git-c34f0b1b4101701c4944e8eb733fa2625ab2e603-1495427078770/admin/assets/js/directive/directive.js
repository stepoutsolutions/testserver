/*Form Validations*/
vfantasy.directive('loginForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesLogin = {email:{required:true,email:true},password:{required:true}};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesLogin,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('promocodeForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesContest = {				
				promo_code			: {required: true,minlength: 7},
				sales_person		: {required: true},
				discount			: {required: true,maxlength: 3},
				benefit_cap			: {required: true,maxlength: 3},
				commission_sales	: {required: true,maxlength: 3},
				start_date			: "required",
				expiry_date			: "required",
			};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesContest,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('changepasswordForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesLogin = {
									old_password: {
										required: true
									},
									new_password: {
										required: true,
										minlength: 5
									},
									confirm_password: {
										required: true,
										minlength: 5,
										equalTo: "#new_password"
									}
								};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesLogin,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('addbalanceForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesBalance = {amount:{required:true,maxlength: 7},description:{required:true,maxlength: 255},transaction_type:{required:true}};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesBalance,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('updatesalespersonForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesBalance = {amount:{required:true,maxlength: 7},comment:{required:true,maxlength: 255}};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesBalance,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('banuserForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesBalance = {reason:{required:true,maxlength: 255}};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesBalance,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('withdrawalRequestForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesBalance = {description:{required:true,maxlength: 255}};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesBalance,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('salespersonForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesBalance = {
				first_name		:{required:true},
				last_name		:{required:true},
				email			:{required:true,email: true},
				paypal_email	:{required:true,email: true},
				dob				:{required:true},
			};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesBalance,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('contestForm', ['showFormError', 'hideFormError','$rootScope',function (showFormError, hideFormError,$rootScope) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesContest = {
				league_duration_id	: "required",
				date				: "required",
				league_id			: "required",
				time				: "required",
				week				: "required",
				game_name			: {required: true,maxlength: 50},
				drafting_style		: "required",
				contest_type		: "required",
				salary_cap			: "required",
				size_min			: {required: true,maxlength: 5,min:2,max:10000},
				size 				: {required: true,maxlength: 5,max:10000},
				entry_fee			: {required: true,max:10000},
				contest_unique_id	: {required: true,minlength: 1},
				select_prize		: "required",	
				custom_prize		: {required: true,maxlength: 7},			
				turbo_contest_type	: "required",	
				site_rake			: {required:true,min:0,max:99},		
			};
			var validationMessagesContest = {
					league_duration_id	: {"required":$rootScope.lang.LEAGUE_DURATION_ERROR},
					date				: {"required":$rootScope.lang.DATE_ERROR},
					league_id			: {"required":$rootScope.lang.LEAGUE_ID_ERROR},
					time				: {"required":$rootScope.lang.TIME_ERROR},
					week				: {"required":$rootScope.lang.WEEK_ERROR},
					drafting_style		: {"required":$rootScope.lang.DRAFTING_STYLE_ERROR},
					contest_type		: {"required":$rootScope.lang.CONTEST_TYPE_ERROR},
					salary_cap			: {"required":$rootScope.lang.SALARY_CAP_ERROR},
					size_min			: {required: $rootScope.lang.SIZE_MIN_ERROR},
					size 				: {required: $rootScope.lang.SIZE_ERROR},
					entry_fee			: {required: $rootScope.lang.ENTRY_FEE_ERROR},
					contest_unique_id	: {required: $rootScope.lang.CONTEST_ID_ERROR, minlength: $rootScope.lang.CONTEST_MIN_SIZE_ERROR},
					select_prize		: {"required":$rootScope.lang.CUSTOME_PRIZE_ERROR,maxlength:$rootScope.lang.CUSTOME_PRIZE_SIZE_ERROR},
					turbo_contest_type	: {"required":$rootScope.lang.TURBO_PLAYER_TYPE_ERROR},
					site_rake			: {required:$rootScope.lang.site_rake_error},
				};
			
			iElement.validate({
				errorElement: "span",
				rules:validationRulesContest,	
				messages:validationMessagesContest,			
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('bonuscodeForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesContest = {				
				bonus_code			: {required: true,minlength: 7},
				bonus_name			: {required: true},
				discount			: {required: true,maxlength: 3},
				cycle				: {required: true,maxlength: 3},
				start_date			: "required",
				expiry_date			: "required",
			};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesContest,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('sendemailForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {			
			var validationRulesSendEmail = {
				subject:{required:true},
				message:{required:true}
			};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesSendEmail,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('sendemailAllForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {			
			var validationRulesSendEmail = {
				all_subject:{required:true},
				all_message:{required:true}
			};
			iElement.validate({
				errorElement: "span",
				rules:validationRulesSendEmail,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('advertisementForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesAds = {
										name:{required:true,maxlength: 255},
										target_url:{required:true,url:true},
										position_type:{required:true},
										ads_image:{required:true}
									};
			iElement.validate({
				ignore: ".ignore, .select2-input",
				errorElement: "span",
				rules:validationRulesAds,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('subadminForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitFun:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesadmin = {
										name:{required:true,maxlength: 255},
										username:{required:true},
										email:{required:true,email:true},
										password:{required:true},
										confpassword:{required:true,equalTo: "#password",minlength:6}
									};
			iElement.validate({
				ignore: ".ignore, .select2-input",
				errorElement: "span",
				rules:validationRulesadmin,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitFun();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('subadminEditForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitFun:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesadmin = {
										name:{required:true,maxlength: 255},
										username:{required:true},
										email:{required:true,email:true},
										password:{},
										confpassword:{equalTo: "#password",minlength:6}
									};
			iElement.validate({
				ignore: ".ignore, .select2-input",
				errorElement: "span",
				rules:validationRulesadmin,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitFun();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('paymentconfigForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
	
			iElement.validate({
				ignore: ".ignore, .select2-input",
				errorElement: "span",
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

vfantasy.directive('signupbonusForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
	return {
		restrict: 'A',
		scope: {
			submitHandle:'&'
		},
		link: function postLink($scope, iElement, iAttrs) {
			var validationRulesadmin = {
										signup_bonus_amount:{required:true,min:0},
									};
			iElement.validate({
				ignore: ".ignore, .select2-input",
				errorElement: "span",
				rules:validationRulesadmin,
				errorPlacement: function (error, element){
					showFormError(error, element);
				},
				submitHandler: function(form) {
					$scope.submitHandle();
				},
				success: function(error, element) {
					hideFormError(error, element);
				}
			});
		}
	};
}]);

//vfantasy.directive('statisticsForm', ['showFormError', 'hideFormError', function (showFormError, hideFormError) {
//	return {
//		restrict: 'A',
//		scope: {
//			submitHandle:'&'
//		},
//		link: function postLink($scope, iElement, iAttrs) {
//                    console.log(iElement);
//			var validationRulesContest = {				
//				team_id			: {required: true},
//				player_unique_id	: {required: true},
//				master_scoring_category_id: {required: true},
//				rule_key		: {required: true},
//				score                   : {required: true},
//				minute			: "required",
//			};
//			iElement.validate({
//				errorElement: "span",
//				rules:validationRulesContest,
//				errorPlacement: function (error, element){
//					showFormError(error, element);
//				},
//				submitHandler: function(form) {
//					$scope.submitHandle();
//				},
//				success: function(error, element) {
//					hideFormError(error, element);
//				}
//			});
//		}
//	};
//}]);




/*Form Validations*/

// Route State Load Spinner(used on page or content load)
vfantasy.directive('ngSpinnerBar', ['$rootScope', '$state',	function($rootScope, $state) {
		return {
			link: function(scope, element, attrs) {
				// by defult hide the spinner bar
				element.addClass('hide'); // hide spinner bar by default

				// display the spinner bar whenever the route changes(the content part started loading)
				$rootScope.$on('$stateChangeStart', function() {
					$('.body-loader').addClass('page-on-load');
					element.removeClass('hide'); // show spinner bar
				});

				// hide the spinner bar on rounte change success(after the content loaded)
				$rootScope.$on('$stateChangeSuccess', function() {
					$rootScope.routename = $rootScope.$state.current.data.routename;
					element.addClass('hide'); // hide spinner bar
					$('.body-loader').removeClass('page-on-load'); // remove page loading indicator
					// auto scorll to page top

					// Language insert in scope from server.
					$rootScope.lang = SERVER_GLOBAL;
				});

				// handle errors
				$rootScope.$on('$stateNotFound', function() {
					element.addClass('hide'); // hide spinner bar
				});

				// handle errors
				$rootScope.$on('$stateChangeError', function() {
					element.addClass('hide'); // hide spinner bar
				});
			}
		};
	}
])

vfantasy.directive('input', [function(){
	return {
		restrict: 'E',
		priority:-1000,
		link: function (scope, iElement, iAttrs) {
		}
	};
}]);

vfantasy.directive('uixBxslider', function($timeout){
	return {
		restrict: 'A',
		link: function($scope, iElm, iAttrs) {
			$scope.$on('repeatFinished', function(){
				if(typeof iElm.destroySlider!='undefined')iElm.destroySlider();
				iElm.bxSlider($scope.$eval('{' + iAttrs.uixBxslider + '}'));
			});
			if(iAttrs.windowWidth&&angular.element(window).width()<=iAttrs.windowWidth){
				iElm.bxSlider($scope.$eval('{' + iAttrs.uixBxslider + '}'));
			}
		}
	};
});

vfantasy.directive('notifyWhenRepeatFinished', ['$timeout',
	function ($timeout) {
		return {
			restrict: 'A',
			link: function($scope, iElm, iAttrs){
				if ($scope.$last === true) {
					$timeout(function(){
						$scope.$emit('repeatFinished');
					});
				}
			}
		};
	}
]);

vfantasy.directive('datePicker', function(){
	return {
		restrict: 'A',
		scope : {
			beforeShowday : '&',
			onSelect : '&'
		},
		link: function($scope, iElm, iAttrs) {
			var options = {
				changeMonth:true,
				changeYear:true,
				yearRange: '1945:'+(new Date).getFullYear(),
				autoSize:true,
				dateFormat:"yy-mm-dd",
				showOn: "both",
     			buttonImage: site_url+"assets/images/calendar.gif",
      			buttonImageOnly: true,
      			 buttonText: "Select date",
				onSelect : function(date){
					if(typeof $scope.onSelect==='function'){
						$scope.onSelect({date:date});
					}
				}
			};

			if(typeof $scope.beforeShowday==='function'&&iAttrs.beforeShowday!==undefined)
			{
				options.beforeShowDay = function(date) {
					return $scope.beforeShowday({date:date});
				};
			}

			iAttrs.$observe('datePicker', function(){
				var newoptions = $scope.$eval('{'+iAttrs.datePicker+'}');
				var extendedoption = angular.extend(options, newoptions);
				iElm.datepicker("destroy");
				iElm.datepicker(extendedoption);
	
			});
		}
	};
});

vfantasy.directive('datePickerRange', function(){
	return {
		restrict: 'A',
		link: function($scope, iElm, iAttrs) {
			var options = {
				changeMonth:true,
				changeYear:true,
				autoSize:true,
				dateFormat:"yy-mm-dd",
				onClose :function(date) {
					if(iAttrs.datePickerRange!="")
					{
						angular.element( "."+iAttrs.datePickerRange ).datepicker( "option", "minDate", date );
					}
					if(iAttrs.minDate!="")
					{
						angular.element( "."+iAttrs.minDate ).datepicker("option", "minDate", new Date());
					}
				}				
			};
			iAttrs.$observe('minDate', function(){
				 // console.log(iAttrs.minDate);
					angular.element( "."+iAttrs.minDate ).datepicker("option", "minDate", new Date());
			});
                        setTimeout(function () {
                                iElm.datepicker(options);
                                if(iAttrs.setDate != ''){
                                    
                                    iElm.datepicker('setDate', iAttrs.setDate);
                                    iElm.trigger('change');
                                }
                        }, 10);
		}
	};
});

vfantasy.directive('dateTimePicker', function () {
        return {
                restrict: 'A',
                link: function ($scope, iElm, iAttrs) {
                       var options = {
                                changeMonth: true,
				changeYear: true,
				dateFormat:"yy-mm-dd",
				timeFormat: 'HH:mm'
                        };
                        
                        setTimeout(function () {
                                iElm.datetimepicker(options);
                        }, 10);
                }
        };
});

vfantasy.directive('selectTwo', function($timeout){
	return {
		restrict: 'A',
		link: function($scope, iElm, iAttrs) {
			iAttrs.$observe('placeholder', function(){
				$timeout(function(){
					if(iAttrs.selectTwo)
					{
						iElm.select2($scope.$eval('{'+iAttrs.selectTwo+'}'));
					}
					else
					{
						iElm.select2();
					}
				});				
			});
		}
	};
});

vfantasy.directive('ajaxSelect', ['$compile', '$timeout', function($compile, $timeout){
  return {
	restrict: 'A',
	link: function($scope, iElm, iAttrs) {
		$timeout(function(){
			$.ajaxSetup({
			    headers: {'session_key': sessionStorage.getItem(AUTH_KEY)}
			});

			iElm.select2({
				multiple: iAttrs.multipleOption,
				minimumInputLength: iAttrs.minSearch,
				placeholder : iAttrs.placeholder,
				ajax: {
					url: site_url+iAttrs.postUrl,
					dataType: 'json',
					delay: 250,
					type: "POST",
					data: function (params) {
					return {
								search_key: params,
								ids:iAttrs.userIds,
						};
				 	},
				 	results: function (response) {
					return {
					  results: response.data
					};
				 	}
				}
			});
		});			
	}
  };
}]);

vfantasy.directive('uniform', function($timeout){
	return{
		restrict: 'A',
		link: function($scope, iElm, iAttrs) {
			if(iAttrs.uniform)
			{
				iElm.uniform($scope.$eval('{'+iAttrs.uniform+'}'));
			}
			else
			{
				iElm.uniform();
			}
		}
	};
});

vfantasy.directive('resetForm', function($timeout){
	return {
		restrict: 'A',
		link: function($scope, iElm, iAttrs) {
			iElm.bind("click",function(e){
				if(typeof angular.element(iAttrs.resetForm)[0] != undefined && angular.element(iAttrs.resetForm)[0].reset != undefined ){
					angular.element(iAttrs.resetForm)[0].reset();
				}
				angular.element(iAttrs.resetForm +' .myerror').hide().html('');
				angular.forEach(angular.element(iAttrs.resetForm+' select'), function(v,k){
					angular.element(v).select2("val","");
				});
				if(iAttrs.resetForm=='#frmsignup')
				{
					angular.element('#signup_country').select2("val", user_country);
				}
				if(iAttrs.resetForm=='#frmwithdraw')
				{
					angular.element('#frmlivecheck .myerror').hide().html('');
				}
			});
		}
	};
});

vfantasy.directive("whenScrolled", function(){
	return{
		restrict: 'A',
		link: function($scope, elem, attrs){
			elem.bind("scroll", function(e){
				raw = elem[0];
				if($scope.loading===true){
					e.preventDefault();
					e.stopPropagation();
				}
				if(raw.scrollTop+raw.offsetHeight+5 >= raw.scrollHeight){
					$scope.$apply(attrs.whenScrolled);
				}
			});
		}
	};
});

vfantasy.directive("myerror", function(){
	return{
		restrict: 'C',
		link: function($scope, elem, attrs){
			elem.bind("click", function(e){
				elem.hide('fast',function(){elem.html('');});
			});
		}
	};
});

vfantasy.directive('myRepeatFinish', function($timeout) {
	return function($scope, element, attrs) {
		if ($scope.$last === true) {
			$timeout(function(){
				$scope.$emit('ngRepeatFinished');
			});
		}
	};
});

// Route State Load Spinner(used on page or content load)
vfantasy.directive('ngSpinnerBar', ['$rootScope',
	function($rootScope) {
		return {
			link: function($scope, element, attrs) {
				// by defult hide the spinner bar
				element.addClass('hide').hide(); // hide spinner bar by default

				// display the spinner bar whenever the route changes(the content part started loading)
				$rootScope.$on('$stateChangeStart', function() {
					element.removeClass('hide').show(); // show spinner bar
				});

				// hide the spinner bar on rounte change success(after the content loaded)
				$rootScope.$on('$stateChangeSuccess', function() {
					element.addClass('hide').hide(); // hide spinner bar

					// auto scorll to page top
					setTimeout(function () {
						angular.element('html,body').animate({scrollTop:0}, 'slow'); // scroll to the top on content load
					}, 1000);
				});

				// handle errors
				$rootScope.$on('$stateNotFound', function() {
					element.addClass('hide').hide(); // hide spinner bar
				});

				// handle errors
				$rootScope.$on('$stateChangeError', function() {
					element.addClass('hide').hide(); // hide spinner bar
				});
			}
		};
	}
]);

vfantasy.directive('toggleClass', function() {
	return {
		restrict: 'A',
		link: function($scope, element, attrs) {
			element.bind('click', function() {
				element.toggleClass(attrs.toggleClass);
			});
		}
	};
});

vfantasy.directive('arraySum', [ function() {

	var array_sum = function(array){
		//   example 1: array_sum([4, 9, 182.6]);
		//   example 2: total = []; index = 0.1; for (y=0; y < 12; y++){total[y] = y + index;}
		//   example 2: array_sum(total);
		//   returns 2: 67.2

		var key, sum = 0;

		if (array && typeof array === 'object' && array.change_key_case) { // Duck-type check for our own array()-created PHPJS_Array
			return array.sum.apply(array, Array.prototype.slice.call(arguments, 0));
		}

		// input sanitation
		if (typeof array !== 'object') {
			return null;
		}

		for (key in array) {
			if (!isNaN(parseFloat(array[key]))) {
				sum += parseFloat(array[key]);
			}
		}
		return numberWithCommas(sum);
	}

	var numberWithCommas = function(x){
		return x.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}

	var prizeFormat = function (item) {
		if(item || item == 0){
			if(typeof item === "string"){
				var n = item.split('.');
				if(n[1]!=undefined&&n[1]==0){
					item = n[0];
				}
			}
			formattedsalary = item.toString().replace( /(^\d{1,3}|\d{3})(?=(?:\d{3})+(?:$|\.))/g , '$1,' );
			// Universal Currency code
			return currency_code+formattedsalary;
		}
		return item;
	};

	return {
		restrict: 'A',
		link: function ($scope, iElement, iAttrs) {
			iAttrs.$observe('arraySum',function(){
				var arr = $scope.$eval(iAttrs.arraySum);
				iElement.empty().append(prizeFormat(array_sum(arr)));
			});
		}
	};
}]);

vfantasy.directive('numbersOnly', [function(){
	// Runs during compile
	return {
		restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
		link: function($scope, iElm, iAttrs, controller) {
			iElm.keypress(function(event){
				if ((event.which!=46||iElm.val().indexOf('.')!=-1) && (event.which<48||event.which>57) && event.which!=8 && event.which!=0)
				{
					event.preventDefault();
				}
			});
		}
	};
}]);

vfantasy.directive('intigerOnly', [function(){
	return {
		restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
		require: 'ngModel',
		link: function($scope, iElm, iAttrs, controller) {
			controller.$parsers.push(function (inputValue) {
				// this next if is necessary for when using ng-required on your input. 
				// In such cases, when a letter is typed first, this parser will be called
				// again, and the 2nd time, the value will be undefined
				if (inputValue == undefined) return '' 
				var transformedInput = inputValue.replace(/[^0-9]/g, ''); 
				if (transformedInput!=inputValue) {
					controller.$setViewValue(transformedInput);
					controller.$render();
				}
				return transformedInput;
			});
		}
	};
}]);

vfantasy.directive('nksOnlyNumber', function () {
    return {
        restrict: 'EA',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {   
             scope.$watch(attrs.ngModel, function(newValue, oldValue) {
                  var spiltArray = String(newValue).split("");

                  if(attrs.allowNegative == "false") {
                    if(spiltArray[0] == '-') {
                      newValue = newValue.replace("-", "");
                      ngModel.$setViewValue(newValue);
                      ngModel.$render();
                    }
                  }

                  if(attrs.allowDecimal == "false") {
                      newValue = parseInt(newValue);
                      ngModel.$setViewValue(newValue);
                      ngModel.$render();
                  }

                  if(attrs.allowDecimal != "false") {
                    if(attrs.decimalUpto) {
                       var n = String(newValue).split(".");
                       if(n[1]) {
                          var n2 = n[1].slice(0, attrs.decimalUpto);
                          newValue = [n[0], n2].join(".");
                          ngModel.$setViewValue(newValue);
                          ngModel.$render();
                       }
                    }
                  }
                  if (spiltArray.length === 0) return;
                  if (spiltArray.length === 1 && (spiltArray[0] == '-' || spiltArray[0] === '.' )) return;
                  if (spiltArray.length === 2 && newValue === '-.') return;

                /*Check it is number or not.*/
                if (isNaN(newValue)) {
                  ngModel.$setViewValue(oldValue);
                  ngModel.$render();
                }
            });
        }
    };
});


vfantasy.directive('expand', [function(){
	// Runs during compile
	return {
		restrict: 'C', // E = Element, A = Attribute, C = Class, M = Comment
		link: function($scope, iElm, iAttrs, controller) {
			/* # Interface Related Plugins
			================================================== */
			//===== Collapsible navigation =====//
			iElm.collapsible({
				defaultOpen: 'new_contest',
				cssOpen: 'level-opened',
				cssClose: 'level-closed',
				speed: 150
			});
		}
	};
}]);

vfantasy.directive('subMenu', [function(){
	// Runs during compile
	return {
		restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
		link: function($scope, iElm, iAttrs, controller) {
			iAttrs.$observe('subMenu',function(){
				if(iAttrs.subMenu==='true'){
					angular.element('.expand').next('ul').stop(true, true).slideUp('slow', function(){
						iElm.stop(true, true).slideDown('slow');
					});
				}
				else{
					angular.element('.expand').next('ul').stop(true, true).slideUp('slow');
				}
			});
		}
	};
}]);

vfantasy.directive('showMessage', ['$rootScope',function($rootScope){
	return {
		restrict: 'A',
		link: function($scope, element, attribute){
			attribute.$observe('showMessage',function(){
				$.jGrowl.defaults.pool = 1;
				if($rootScope.alert_success!="")
				{
					angular.element(".growl-success").remove();
					$.jGrowl($rootScope.alert_success, {position: 'center',theme: 'growl-success', header: '',life: 5000 });
					$rootScope.alert_success =''
				}
				else if($rootScope.alert_error!="")
				{
					angular.element(".growl-error").remove();
					$.jGrowl($rootScope.alert_error, {position: 'center',theme: 'growl-error', header: '',life: 5000 });
					$rootScope.alert_error   ='';
				}
				else if($rootScope.alert_warning !="")
				{
					angular.element(".growl-warning").remove();
					$.jGrowl($rootScope.alert_warning, {position: 'center',theme: 'growl-warning', header: '',life: 5000 });
					$rootScope.alert_warning ='';
				}
			});
		}
	};
}]);

vfantasy.directive('rangeSlider', function(){
	return {
		restrict: 'A',
		scope : {
			callback : '&'
		},
		link: function($scope, iElm, iAttrs){
			iAttrs.$observe('rangeSlider', function(){
				var option = $scope.$eval('{'+iAttrs.rangeSlider+'}');
				if(option.max_value===undefined||!option.max_value)option.max_value=parseInt(option.max);
				if(option.min_value===undefined||!option.min_value)option.min_value=parseInt(option.min);
				iElm.slider({
					range: true,
					min: parseInt(option.min),
					max: parseInt(option.max),
					values: [option.min_value, option.max_value],
					stop: function(event, ui) {
						$scope.callback({event:event, ui:ui});
					}
				});
			});
		}
	};
});

vfantasy.directive('toolTip', ['$compile',function($compile){
	return {
		restrict: 'A',
		link: function(scope, iElm, iAttrs){
			iAttrs.$observe('title', function(){
				iElm.tooltip("destroy")
				iElm.tooltip();
			});
		}
	};
}]);

vfantasy.directive('uploadFile', function($rootScope){
	return {
		restrict: 'A',
		scope : {
			callback : '&'
		},
		link: function($scope, iElm, iAttrs){
			iAttrs.$observe('uploadFile', function(){
				var option = $scope.$eval('{'+iAttrs.uploadFile+'}');
				var uploader = new plupload.Uploader({
					runtimes : 'gears,html5,flash,browserplus,silverlight,html4',
					browse_button: iAttrs.id, // this can be an id of a DOM element or the DOM element itself
					url: site_url+option.post_url
				});
				uploader.init();

				uploader.bind('FilesAdded', function(up, files) {
					uploader.start();
				});

				uploader.bind('FileUploaded', function (up, file, res) {
					var res1 = res.response.replace('"{', '{').replace('}"', '}');
					var objResponse = JSON.parse(res1);
					$scope.callback({data:objResponse});
				});
				uploader.bind('Error', function (up, err) {
					var response = JSON.parse(err.response);
					$.jGrowl(response.message, {position: 'center',theme: 'growl-error', header: 'Error!',life: 5000});
				});
				
			});
		}
	};
});

vfantasy.directive('validationEngine', function(){
	return {
		link: function(scope, element, attrs, ctrl) {
			if(typeof scope.onValidationComplete == 'undefined' ) scope.onValidationComplete = function(){};
			element.validationEngine('attach', {onValidationComplete:function(form,status){scope.onValidationComplete(form,status);}});
		}
	}
});