<?php
	$system_path = '../system';
	require_once('../index.php');