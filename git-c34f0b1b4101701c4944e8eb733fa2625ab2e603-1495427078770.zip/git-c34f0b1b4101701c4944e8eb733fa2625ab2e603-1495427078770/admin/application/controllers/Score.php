<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Score extends MYREST_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Score_model');
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_scoring_filters_post()
	{
		$this->data = array();
		$sports = $this->Score_model->get_all_table_data('*', MASTER_SPORTS, array('active' => ACTIVE));
		$this->data["filters"] = array();
		if(!empty($sports))
		{
			$this->data["master_sports"] = array();
			foreach ($sports as $sport) 
			{
				$this->data["master_sports"][$sport["sports_id"]] = $sport;
				if(!array_key_exists($sport["sports_id"], $this->data["filters"]))
			    {
			    	$this->data["filters"][$sport["sports_id"]] = array();
			    }
			    $score_cats = $this->Score_model->get_all_table_data('*', MASTER_SCORING_CATEGORY, array('sports_id' => $sport["sports_id"]));
			    if(!empty($score_cats))
			    {
			    	$this->data["filters"][$sport["sports_id"]]["scoring_cat"] = $score_cats;	
			    }
			}
			
			$this->data['master_format'] = array(
				CRICKET_T20 		=> "T20",
				CRICKET_ONE_DAY 	=> "One-Day",
				CRICKET_TEST		=> "Test"
				
			);

		}
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=> $this->data) , rest_controller::HTTP_OK);
	}

	public function get_scoring_rules_post()
	{
		$post = $this->input->post();
		if(!empty($post))
		{
			$where = array(
			 'master_scoring_category_id' => $post['cat_id']	
			);

			if(!empty($post['format']))
			{
				$where['format'] = $post['format'];
			}	


			$scoring_rules = $this->Score_model->get_all_table_data('format,master_scoring_id, score_position, score_points', MASTER_SCORING_RULES, $where);
			$this->data["master_scoring_rules"] = $scoring_rules;
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=> $this->data) , rest_controller::HTTP_OK);
		}
	}

	public function update_master_scoring_points_post()
	{
		$post = $this->input->post();
		if(!empty($post))
		{
			if($this->Score_model->update_batch(MASTER_SCORING_RULES, $post, 'master_scoring_id'))
			{
				$this->response(array(config_item('rest_status_field_name')=> TRUE, 'message'=>$this->lang->line('score_updated_success')) , rest_controller::HTTP_OK);
			}
			else
			{
				$this->response(array(config_item('rest_status_field_name')=> FALSE, 'message'=>$this->lang->line('score_updated_error')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);	
			}
		}
	}
}	
