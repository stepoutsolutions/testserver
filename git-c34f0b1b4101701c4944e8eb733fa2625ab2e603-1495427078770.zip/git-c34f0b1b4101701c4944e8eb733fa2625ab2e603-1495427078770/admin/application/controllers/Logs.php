<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logs extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->lang->load('fire_log', 'english');
		$this->load->helper(array('spark_url', 'fire_log'));
		$this->load->config('fire_log');
		$this->load->library('fire_log');
	}

	public function index()
	{
	}

	public function view()
	{
	}
}

/* End of file Logs.php */
/* Location: ./application/controllers/Logs.php */