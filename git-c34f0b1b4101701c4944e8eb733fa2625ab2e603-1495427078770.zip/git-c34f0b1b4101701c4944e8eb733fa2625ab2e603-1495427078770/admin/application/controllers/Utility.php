<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Utility extends MY_Controller {

	public $data = array();

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->data['admin_privilege'] = $this->admin_privilege;
	}
	
	public function index()
	{
		redirect();
	}

	public function template($folder="", $view="")
	{
		$this->load->view("template/$folder/$view", $this->data);
	}

	public function javascript_var($lang='')
	{
		$lang = str_ireplace(".js", "", $lang);

		$language = ($this->session->userdata('language'))?$this->session->userdata('language'):$this->config->item('language');
		$this->lang->load('javascript_lang', $language);

		$lang = (isset($this->lang->language[$lang]))?$this->lang->line($lang):array();
		$common = (isset($this->lang->language['common']))?$this->lang->line('common'):array();
		$data['lang'] = array_merge($lang,$common);

		$this->load->view('utility/javascript_var', $data);
	}

	public function layout()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function _404()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}
}

/* End of file Utility.php */
/* Location: ./application/controllers/Utility.php */
