<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Common extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function index()
	{
		redirect('','refresh');
	}

	public function index_get()
	{
		$this->index();
	}

	public function get_language_list_post()
	{
		$this->load->config('vconfig');
		$language = $this->config->item('language_list');
		$is_logged_in = ($this->session->userdata('admin_id'))?TRUE:FALSE;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>array('language_list'=>$language, 'site_language'=>$this->session->userdata('language'), 'is_logged_in'=>$is_logged_in)) , rest_controller::HTTP_OK);
	}

	public function update_site_language_post()
	{
		$response_code = rest_controller::HTTP_OK;
		$this->init_post_data();
		$this->load->config('vconfig');
		$language_list = $this->config->item('language_list');
		$language = $this->input->post('language');
		if(array_key_exists($language, $language_list))
		{
			$this->session->set_userdata('language', $language);
			$data = array('language'=>$language);
		
		}
		else
		{
			$response_code = rest_controller::HTTP_INTERNAL_SERVER_ERROR;
			$data = array();
		}
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$data), $response_code);
	}


	public function rollback_prize_get()
	{
		exit(1);
		$contest_unique_ids = array('qEBjRrwnT','NpGx2lno0','jREwPOklM','sKbZV4MAf','axcgMXrTO','9K36m7fsz','sa60nw7oW','1tWiDMZpq');
		$this->db->select('*');
		$this->db->where_in('contest_unique_id', $contest_unique_ids);
		$this->db->from(CONTEST);
		$query = $this->db->get();
		$res1 = $query->result_array();


		$this->load->model('User_model');
		$a=0;
		foreach ($res1 as $key => $val)
		{
			$contest_unique_id = $val['contest_unique_id'];
			$contest_id = $val['contest_id'];

			$condition = array('contest_unique_id'=>$contest_unique_id, 'payment_type'=>CREDIT);
			$this->db->select('PHT.*,english_description');
			$this->db->from(PAYMENT_HISTORY_TRANSACTION.' AS PHT');
			$this->db->join(MASTERDESCRIPTION.' AS MD', 'MD.master_description_id = PHT.master_description_id');
			$this->db->where($condition);
			$query = $this->db->get();
			$result = $query->result_array();

			$a += count($result);
			if($result)
			{
				foreach ($result as $key => $value)
				{
					$this->db->select('*');
					$this->db->from(PAYMENT_HISTORY_TRANSACTION);
					$this->db->where(array('user_id'=> $value['user_id'],'contest_unique_id'=>$contest_unique_id,'master_description_id'=> '14'));
					$query = $this->db->get();
					$res = $query->row_array();

					if($res) continue;

					$this->db->select('balance');
					$this->db->from(USER);
					$this->db->where('user_id', $value['user_id']);
					$query = $this->db->get();
					$user_result = $query->row_array();
					if($user_result)
					{
						$balance = $user_result['balance'];
						$transaction_amount = $value['transaction_amount'];

						$new_balance = $balance - $transaction_amount;

						$condition = array('user_id'=>$value['user_id']);
						$data = array('balance'=>$new_balance);

						$this->db->where($condition);
						$this->db->update(USER, $data);
		
						$payment_data = array(
									'user_id'						=> $value['user_id'],
									'master_description_id'			=> '14',
									'contest_unique_id'				=> $contest_unique_id,
									'payment_type'					=> '1',
									'transaction_amount'			=> $transaction_amount,
									'user_balance_at_transaction'	=> $balance,
									'created_date'					=> format_date()
								);

						$this->db->insert(PAYMENT_HISTORY_TRANSACTION, $payment_data);

						$condition = array('user_id'=>$value['user_id'],'contest_unique_id'=>$contest_unique_id);
						$data = array('is_winner'=>'0');
						$this->db->where($condition);
						$this->db->update(LINEUP_MASTER, $data);

						$this->db->where(array('contest_id'=>$contest_id, 'user_id'=>$value['user_id']) );
						$this->db->delete(LEADERBOARD);
					}
				}

				$condition = array('contest_unique_id'=>$contest_unique_id);
				$data = array('prize_distributed'=>'0');
				$this->db->where($condition);
				$this->db->update(CONTEST, $data);
			}
		}
		debug($a);
	}

	public function dummy_email_get($emailer='', $to_email='')
	{

			$name = "Vinfo User";
			if(empty($to_email)){
				$email = "rahulp.vinfotech@gmail.com";
			}
			else{
				$email = $to_email;
			}
			$send_email = FALSE;

		if($emailer=="approve_request"){	

				$type = '';
				$data['full_name']	= "Vinfo User";
				$data['email']		= $email;
				$data['status']		= 1;
				$data['amount']     = 150;
				$message			= $this->load->view('emailer/withdrawal_request',$data,true);
				$to					= $data['email'];
				$subject			= 'Subject';
				$message			= $message;
		}

		if($emailer=="reject_request"){	
				$data['full_name']	= "Vinfo User";
				$data['email']		= $email;
				$data['status']		= 0;
				$data['amount']     = 150;
				$message			= $this->load->view('emailer/withdrawal_request',$data,true);
				$to					= $data['email'];
				$subject			= 'subject';
				$message			= $message;
		}	

		 
			if($send_email){
				//send_email($email, $subject, $message, FROM_ADMIN_EMAIL, $name);
			}
				
			echo $message;die;

		  //send_email($to,$subject,$message);
	}
}

/* End of file common.php */
/* Location: ./application/controllers/common.php */