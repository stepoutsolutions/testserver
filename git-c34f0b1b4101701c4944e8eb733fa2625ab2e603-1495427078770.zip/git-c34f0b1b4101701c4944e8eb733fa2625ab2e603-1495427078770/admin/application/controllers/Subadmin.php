<?php if (!defined('BASEPATH'))	exit('No direct script access allowed');

class Subadmin extends MYREST_Controller {
	public $admin_id = "";
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Subadmin_model');
		$data = json_decode(file_get_contents('php://input'), true);
		$_POST = $data;	
		$this->admin_id =$this->session->userdata('admin_id');	

		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function save_admin_post()
	{
		if ($this->input->post())
		{
			$this->form_validation->set_rules('firstname', 'Name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique['.ADMIN.'.email]');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|is_unique['.ADMIN.'.username]');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]');
			$this->form_validation->set_rules('confpassword', 'Confirm password', 'trim|required|matches[password]');

			if ($this->form_validation->run())
			{ 
				
                                $post_values = array();
                                $post_values['firstname']       = $this->input->post('firstname');
								$post_values['email']           = strtolower($this->input->post('email'));
								$post_values['username']        = $this->input->post('username');
								$post_values['password']        = md5($this->input->post('password'));
                                $post_values['updated_by']      = $this->admin_id;
                                $post_values['updated_date']    = format_date();
                                $post_values['role']            = SUBADMIN_ROLE;
                                $post_values['status']            = '1';
                                $cat_id = $this->input->post('selected_group');                                
                                $grouplist = $this->Subadmin_model->group_detail_by_id(implode(',', $cat_id));
                                $post_values['privilege']       = json_encode($grouplist, JSON_NUMERIC_CHECK);
                                                              
							    $this->db->insert(ADMIN, $post_values);
                                $this->db->last_query();
                                
                                /*
                                 * Send email with login detail
                                 */ 
                                $data['name']       = $this->input->post('firstname');
                                $data['email']      = $this->input->post('email');
                                $data['password']   = $this->input->post('password');
                                $data['link']       = site_url('admin');
                              
                                $this->return[$this->rest_status_field_name] = TRUE;
                                $this->return['message'] = 'Admin has been added successfully.';
                                $this->return['next_url'] = site_url('manageadmin');
                                $this->response($this->return, 200);
			}
			else
			{
				$this->send_validation_errors();
			}
		}
	}
  
  public function get_admin_group_post()
  {
		$grouplist = $this->Subadmin_model->get_subadmin_group_list();		
		$result['grouplist'] = $grouplist;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
  }

  public function group_detail_by_id_post()
  {
  		$post_data = $this->input->post();

		$sub_grouplist = $this->Subadmin_model->group_detail_by_id(implode(',', $post_data['category_id']));		
		$result['sub_grouplist'] = $sub_grouplist;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
  }

  public function change_user_status_post()
  {
    $this->form_validation->set_rules('user_unique_id', 'User Unique Id', 'trim|required');
    $this->form_validation->set_rules('status', 'Status', 'trim|required');
    $status = $this->input->post("status");
    
    if (!$this->form_validation->run()) 
    {
      $this->send_validation_errors();
    }
    
    $user_unique_id = $this->input->post('user_unique_id');   
    $data_arr = array(
            "status"    => $status
          );
    $this->db->where('admin_id', $user_unique_id)
                  ->update(ADMIN, $data_arr); 
    
    if($user_unique_id && $status != '')
    {
      $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
    }
    else
    {
      $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
    } 
  }  

  public function change_all_user_status_post()
	{
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		$status = $this->input->post("status");
		
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$user_unique_ids = $this->input->post('user_unique_id');
		if(empty($user_unique_ids))
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		$reason = $this->input->post("reason")?$this->input->post("reason"):"";
		foreach ($user_unique_ids as $user_unique_id) 
		{
			$data_arr = array(
							"status"			=> $status							
						);
			$this->db->where('admin_id', $user_unique_id)
                  ->update(ADMIN, $data_arr); 
			$result = true;
		}
		
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function send_email_selected_user_post()
	{
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required|max_length[500]');
		$this->form_validation->set_rules('selected_emails','Selected emails' ,'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$this->load->helper('mail_helper');
		$post_data = $this->input->post();
		
		// $this->send_email($post_data['selected_emails'], $post_data['subject'], $post_data['message']);
		send_email($post_data['selected_emails'], $post_data['subject'], $post_data['message']);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('email_send')), rest_controller::HTTP_OK);
	}

     public function get_admin_list_post()
	{
		$limit = 10;
		$data_post = $this->input->post();
		$start = $data_post['start'];
		$filter_name = (isset($data_post['search_keyword'])) ? $data_post['search_keyword'] : '';
		$fieldname = $data_post['field'];
		$order = $data_post['order'];
		if (@$data_post['limit'])
		{
			$limit = $data_post['limit'];
		}
		$offset = $start;

		$config['limit'] = $limit;
		$dataparam = $data_post['dataparam'];
		$config['dataparam'] = $dataparam;
		$config['start'] = $start;
		$config['filter_name'] = $filter_name;
		$config['fieldname'] = $fieldname;
		$config['order'] = $order;
                $config['is_csv'] = false;

		$adminlist = $this->Subadmin_model->get_admin_list($config, false);
                
                if(!empty($adminlist)){
                    
                    foreach($adminlist as $key=>$admin) {
                        
                        $privilege_obj = json_decode($admin['privilege']);                  
                        $adminlist[$key]['privilege_obj'] = $privilege_obj;
                    }
                }
                
		$config['count_only'] = TRUE;

		$total = $this->Subadmin_model->get_admin_list($config, TRUE);
		$order_sequence = $order == 'ASC' ? 'DESC' : 'ASC';
                
		$result = array(
                                'adminlist' => $adminlist,
                                'start' => $offset,
                                'total' => $total,
                                'field_name' => $fieldname,
                                'order_sequence' => $order_sequence
		);
                
        $this->return[$this->rest_status_field_name] = TRUE;
		$this->return['data'] = $result;
		$this->response($this->return, 200);
                
	}
        
        public function update_status_post()
	{
		if ($this->input->post())
		{
			$this->form_validation->set_rules('status', 'status', 'required');
			$this->form_validation->set_rules('id', 'Admin key', 'trim|required');

			if ($this->form_validation->run()) 
			{
				$dataArr = array("status" => $this->input->post('status'));
				$id = $this->input->post('id');
				$result = $this->Subadmin_model->update_admin_by_id($id, $dataArr);

				if ($result) 
				{
					$msg = array('status' => true, 'message' => "Admin status has been updated successfully.");
				} 
				else 
				{
					$msg = array('status' => false, 'message' => "Try Again.");
				}
			} 
			else
			{
				$msg = array('status' => false, 'message' => validation_errors());
			}

			$this->echo_Jason($msg);
		}
	}
        
        public function update_status_all_post()
	{
		$list = $this->input->post('id');
		$status = $this->input->post('status');

		if ($this->input->post())
		{
                        $data['status'] = $status;
                        foreach ($list as $key => $value) {
                                $this->db->where('id', $value);
                                $this->db->update(ADMIN, $data); 
                        }
                        
                        if($this->input->post('status')<2)
			{
				$msg = array('status' => true, 'message' => "Admin status have been updated successfully.");
			}
			elseif($this->input->post('status')==2)
			{
				$msg = array('status' => true, 'message' => "Admin have been deleted successfully.");
			}
			$this->echo_Jason($msg);
		}
	}
        
        public function update_permission_all_post()
	{
		if ($this->input->post())
		{
			$this->form_validation->set_rules('admindata', 'Permission row', 'required');

			if ($this->form_validation->run()) 
			{
				$admindata = $this->input->post('admindata');
                                
                                if(!empty($admindata)){
                                    
                                    foreach ($admindata as $admin){
                                    
                                        $data = array(
                                                'privilege'     => json_encode($admin['privilege_obj'], JSON_NUMERIC_CHECK),
                                                'updated_by'    => $this->admin_id,
                                                'updated_date'  => format_date()
                                        );
                                        $this->db->where('id', $admin['id']);
                                        $this->db->update(ADMIN, $data); 
                                    }
                                    
                                    $msg = array('status' => true, 'message' => "Admin permission have been updated successfully.");
                                }
				else 
				{
					$msg = array('status' => false, 'message' => "Please select admin.");
				}
			} 
			else
			{
				$msg = array('status' => false, 'message' => validation_errors());
			}

			$this->echo_Jason($msg);
		}
	}
        
        public function get_admin_by_id_post()
	{
		if ($this->input->post())
		{
			$id = $this->input->post('adminid');
			$this->form_validation->set_rules('adminid', 'Admin key', 'trim|required');
			if ($this->form_validation->run())
			{
				$result = $this->Subadmin_model->get_admin_by_id($id);	
				$prev_arr = json_decode($result['privilege']);				
				
				$selected_abbr = implode( ',' , array_map( function( $n ){ return '\''.$n.'\''; } ,  $prev_arr) );
				$result['category_ids'] = $this->Subadmin_model->group_detail_by_abbr($selected_abbr);
				
				if ($result)
				{					
					$this->return[$this->rest_status_field_name] = validation_errors();				
					$this->return['data'] = $result;
					$this->response($this->return, 200);
				}
			}
			else
			{
				$this->return[$this->rest_status_field_name] = validation_errors();				
				$this->response($this->return, 200);
			}

			
		}
	}
        
        /**
         * This method update admin info
         */
        public function update_admin_post()
	{
		if ($this->input->post())
		{   
            $this->form_validation->set_rules('id', 'Admin key', 'trim|required');
			$this->form_validation->set_rules('firstname', 'Name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|callback__unique_email');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|callback__unique_username');
            $this->form_validation->set_rules('password', 'Password', 'trim|min_length[5]');
			$this->form_validation->set_rules('confpassword', 'Confirm password', 'trim|matches[password]');

			if ($this->form_validation->run())
			{
				$post_values = array();
                $post_values['firstname']       = $this->input->post('firstname');
				$post_values['email']           = strtolower($this->input->post('email'));
				$post_values['username']        = $this->input->post('username');
				
                $post_values['updated_by']      = $this->admin_id;
                $cat_id = $this->input->post('selected_group');                                
                $grouplist = $this->Subadmin_model->group_detail_by_id(implode(',', $cat_id));
                $post_values['privilege']       = json_encode($grouplist, JSON_NUMERIC_CHECK);
                $post_values['updated_date']    = format_date();
                
                if(!empty($this->input->post('password'))){
                        $post_values['password']= md5($this->input->post('password'));
                }
                                
				$id = $this->input->post('id');				
				$result = $this->Subadmin_model->update_admin_by_id($id, $post_values);
                                
                // if(!empty($this->input->post('password'))){
                        /*
                        * Send email with login detail if password gets change
                        */ 
                       // $data['name']       = $this->input->post('firstname');
                       // $data['email']      = $this->input->post('email');
                       // $data['password']   = $this->input->post('password');
                       // $data['link']       = site_url('fantasyadmin');

                       // $message = $this->load->view('emailer/subadmin_changepassword_emailer',$data,true);	
                       // $subject = 'Your Vfantasy admin account password has been changed';
                       // send_email( $data['email'] , $subject , $message, FROM_ADMIN_EMAIL, FROM_EMAIL_NAME);
                // }
                                
                $this->return[$this->rest_status_field_name] = TRUE;
                $this->return['message'] = 'Admin has been updated successfully.';
                $this->return['next_url'] = site_url('manageadmin');
                $this->response($this->return, 200);
                                
			} 
			else
			{
			    $this->send_validation_errors();
			}
		}
	}
        
        /**
         * This method checks for unique email in case of edit info
         * @param string $email
         * @return boolean
         */
        function _unique_email($email){
                $id = $this->input->post('id');
                $this->db->select('admin_id',FALSE)
                        ->from(ADMIN.' as A')
                        ->where('A.email',$email);
                
                if(!empty($id)){
                        $this->db->where("A.admin_id != $id");
                }
                
                $sql = $this->db->get();
                $result = $sql->num_rows();
                
                if(empty($result)){
                    return true;
                } 
                else {
                    $this->form_validation->set_message('_unique_email', 'The Email field must contain a unique value.');

                    return false;
                }
        }
        
        /**
         * This method checks for unique username in case of edit info
         * @param string $username
         * @return boolean
         */
        function _unique_username($username){
                $id = $this->input->post('id');
                //echo '$username: '.$username.' :: '.$id;
                $this->db->select('admin_id',FALSE)
                        ->from(ADMIN.' as A')
                        ->where('A.username',$username);
                
                if(!empty($id)){
                        $this->db->where("A.admin_id != $id");
                }
                
                $sql = $this->db->get();
                $result = $sql->num_rows();
                
                if(empty($result)){
                    return TRUE;
                } 
                else {

                    $this->form_validation->set_message('_unique_username', 'The Username field must contain a unique value.');

                    return false;
                }
        }
        
        /**
	 * @Summary		: Export List all admin list
	 * @access 		: public
	 * @param            : Null
	 */
	// report for download function
	/*public function force_user_report_downloads_get()
	{
                $data_post = $this->input->post();
		$config['filter_name'] = (isset($data_post['search_keyword'])) ? $data_post['search_keyword'] : '';
		$config['is_csv'] = TRUE;
		$adminlist = $this->Subadmin_model->get_admin_list($config, true);
	}*/
	public function export_users_post()
	{
		$sql = $this->db->select('email as emails')
						->from(ADMIN)
						->where('status', '1')
						->where('role', '2')
						->get();
		
		$this->load->dbutil();
		$this->load->helper('download');
		$data = $this->dbutil->csv_from_result($sql);
		$data = "Created on " . format_date('today', 'Y-m-d') . "\n\n" .html_entity_decode($data);
		$name = 'AdminList.csv';
		force_download($name, $data);
		exit();
	}

	public function send_email_all_user_post()
	{
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required|max_length[500]');
		$this->load->helper('mail_helper');
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$post_data = $this->input->post();
		$sql = $this->db->select('GROUP_CONCAT(email) as emails')
						->from(ADMIN)
						->where('status', '1')
						->get();
		$result = $sql->row_array();
		
		$user_list  = $result['emails'];
		if($user_list)
			send_email($user_list, $post_data['subject'], $post_data['message']);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('email_send')), rest_controller::HTTP_OK);
	}

}
/* End of file adminusers.php */
/* Location: ./application/controllers/fantasyadmin/adminusers.php */