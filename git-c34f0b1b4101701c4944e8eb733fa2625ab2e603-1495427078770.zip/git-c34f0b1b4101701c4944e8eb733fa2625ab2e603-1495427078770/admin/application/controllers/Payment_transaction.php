<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Payment_transaction extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Transaction_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}


	public function get_all_transaction_post()
	{
		$result = $this->Transaction_model->get_all_transaction();
		$temp_array = array();
		// foreach($result['result'] as $data)
		// {
		// 	if($data['master_description_id']==1 || $data['master_description_id']==2 || $data['master_description_id']==3)
		// 	{
		// 		$data['english_description'] = str_replace('{{contest_name}}', $data['contest_name'],$data['english_description']);
		// 	}
		// 	$temp_array[] = $data;
		// }
		$order_message_array = $this->lang->line('order_message_array');
		foreach($result['result'] as $data)
		{	
			//default description
			$default_msg = $order_message_array[$data['source']];
			$description = $default_msg;


			//description for game join / won game / cancel game
			if(in_array($data['source'],array(ORDER_SOURCE_JOIN_GAME,ORDER_SOURCE_GAME_CANCEL,ORDER_SOURCE_GAME_WON)))
			{
				$contest_name = (!empty($data['contest_name'])) ? $data['contest_name'] : 'Contest';
				$description  = str_replace("{{contest_name}}",$contest_name,$default_msg);
			}	

			//description for Admin Deposit/Withdraw
			if($data['source'] == ORDER_SOURCE_ADMIN)
			{
				$admin_action = ($data['source'] == 0) ? 'deposited' : 'withdrawal';//0 = credit 1 = debit
				$description = str_replace("{{admin_action}}",$admin_action,$default_msg);
			}
			$data['description'] = $description;
			$temp_array[] = $data;
		}
		$result['result'] = $temp_array;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_descriptions_post(){

		$result = $this->Transaction_model->get_all_descriptions();
	  	$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);

	}

}

/* End of file Payment_transaction.php */
/* Location: ./application/controllers/Payment_transaction.php */