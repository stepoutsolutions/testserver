<?php defined('BASEPATH') OR exit('No direct script access allowed');

class League extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('League_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_leagues_post()
	{
		$result = $this->League_model->get_all_leagues();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function change_league_status_post()
	{
		$post_data =  $this->input->post();
		if(empty($post_data['league_id']))
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}

		$data 	= array('active'=>$post_data['status']);
		$where  = array('league_id'=>$post_data['league_id']);

		$result = $this->League_model->update_league_status($data,$where);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('successfully_update_league')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}
}

/* End of file Teamroster.php */
/* Location: /admin/application/controllers/Teamroster.php */