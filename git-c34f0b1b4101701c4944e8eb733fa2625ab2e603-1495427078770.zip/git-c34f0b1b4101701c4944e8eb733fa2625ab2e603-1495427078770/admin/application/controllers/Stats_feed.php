<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Stats_feed extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Statsfeed_model');
		//Do your magic here
	}
        
        #############################
        # SEASON FEED START
        #############################
        
        public function get_add_season_form_data_post()
	{
                $this->load->model('Roster_model');
                
                $stats_data  = $this->input->post();
                
                // Get All Team
		$team_result = $this->Statsfeed_model->get_all_team($stats_data['league_id']);
                
                $data = array('team'=> $team_result);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data' => $data) , rest_controller::HTTP_OK);
	}
        
        public function create_season_stats_post() {
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',          'League ID',    'trim|required');
			
                        $this->form_validation->set_rules('home_id[]',          'Home team',         'trim|required');
			$this->form_validation->set_rules('away_id[]',          'Away team',       'trim|required');
			$this->form_validation->set_rules('type[]',             'Season type', 'trim|required');
			//$this->form_validation->set_rules('scheduled_date[]',   'Schedule date',        'trim|required');

			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $stats_data        = $this->input->post();
    			
			$league_detail     = $this->Statsfeed_model->get_league_detail($stats_data['league_id']);

                        if(empty($league_detail))
                        {
                                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }
                        
                        $this->load->model('api_credential_model');
                        
                        $api = $this->api_credential_model->active_feed_provide_season_year($stats_data['league_id']);
                        $season_year = $api['year'];
                        
                        // Save Season Data

                        $season_stats = array();

                        if(count($stats_data['row']) > 0){

                                for($r=0; $r < count($stats_data['row']); $r++){
                                        $season_stats[] = array(
                                                'league_id'             => $stats_data['league_id'],
                                                'year'                  => $season_year,
                                                'home_id'               => $stats_data['home_id'][$r],
                                                'away_id'               => $stats_data['away_id'][$r],
                                                'type'                  => $stats_data['type'][$r],
                                                'season_scheduled_date' => $stats_data['scheduled_date'][$r],
                                                'scheduled_date'        => date('Y-m-d', strtotime($stats_data['scheduled_date'][$r]))
                                        );  
                                }
                        }
                        
                        $result = $this->Statsfeed_model->replace_into_batch(SEASON, $season_stats);
                        
                        ## update season_game_unique_id filed value from season_id field
                        
                        foreach($season_stats as $season){
                            
                                $upd_data = array('season_game_unique_id' => "concat('$season_year',season_id)");
                        
                                $where = "league_id = ".$season['league_id'];
                                $where .= " AND home_id = '".$season['home_id']."'";
                                $where .= " AND away_id = '".$season['away_id']."'";
                                $where .= " AND season_scheduled_date = '".$season['season_scheduled_date']."'";
                                
                                $this->Statsfeed_model->update_feed(SEASON, $where, $upd_data, TRUE);
                        }
                        
                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Season data has been saved successfully.'), rest_controller::HTTP_OK);
                        
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function delete_season_stats_post(){
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('season_id',       'Season key',           'trim|required');
			
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $stats_data = $this->input->post();
    			
			if($stats_data['season_id']) {
                            
                                $where = array(
                                        'season_id'     => $stats_data['season_id']
                                );  
                                
                                $result = $this->Statsfeed_model->delete_stats(SEASON, $where);
                                
                                if($result){
                                    $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Season record has been deleted successfully.'), rest_controller::HTTP_OK);
                                } 
                                else {
                                    $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'There is some proble in delete operation.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                        }
                        else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function export_season_template_get($league_id) {
            
                $this->load->model('api_credential_model');
                                
                $api = $this->api_credential_model->active_feed_provide_season_year($league_id);
                $season_year = $api['year'];
            
                $this->Statsfeed_model->export_season_template($league_id, $season_year);
	}
        
        public function do_upload_season_post()
	{
		$dir				= APP_ROOT_PATH.UPLOAD_DIR;
		$subdir				= APP_ROOT_PATH.SEASONFEED_DIR;
		$ext				= pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		
		$this->check_folder_exist($dir);
		$this->check_folder_exist($subdir);

		$config['allowed_types']	= 'xlsx';
		$config['max_size']		= '5000';
		$config['max_width']		= '1024';
		$config['max_height']		= '1000';
		$config['upload_path']		= $subdir;
		$config['file_name']		= time();

		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('file'))
		{
			$error = $this->upload->display_errors();
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		else
		{
			$upload_data = $this->upload->data();

			if($ext==='xlsx')
			{
				$this->xlsx_to_json_season($upload_data['full_path'], $upload_data['raw_name']);    
			}

			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>array('file_name'=> $upload_data['raw_name'])), rest_controller::HTTP_OK);
		}
	}

	private function xlsx_to_json_season($file, $raw_name)
	{
		//load the excel library
		$this->load->library('PHPExcel');

                //read file from path
		$objPHPExcel = PHPExcel_IOFactory::load($file);

		$feed_data = array();
		$coloum_meta = array('A'=>'home_id','B'=>'away_id','C'=>'type','D'=>'season_scheduled_date');

                $row_cnt = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();

                for($r = 4; $r <= $row_cnt; $r++){

                        if($r > 200){
                            break;
                        }
                        
                        foreach($coloum_meta as $c_key => $c_field){
                                $feed_data[$r][$c_field] = $objPHPExcel->getActiveSheet()->getCell($c_key.$r)->getValue();
                        }
                }
                //print_r($feed_data); die;

		$dir = APP_ROOT_PATH.SEASONFEED_DIR;
		$this->load->helper('file');
		$data = json_encode($feed_data);
		$json_file = $dir.$raw_name.'.json';
		$response = write_file($json_file, $data);
		unlink($file);
		return $response;
	}
        
        public function save_uploaded_season_data_post() {

                $stats_data         = $this->input->post();

                $dir                = APP_ROOT_PATH.SEASONFEED_DIR;
                $json_file          = $dir.$stats_data['file_name'].'.json';

                $str                = file_get_contents($json_file);
                $stats_file_data    = json_decode($str, true);

                //print_r($stats_file_data);

                $league_detail     = $this->Statsfeed_model->get_league_detail($stats_data['league_id']);

                if(empty($league_detail))
                {
                        unlink($json_file);
                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                }

                $this->load->model('api_credential_model');

                $api = $this->api_credential_model->active_feed_provide_season_year($stats_data['league_id']);
                $season_year = $api['year'];


                // Save Feed Player Statistics Data

                if(!empty($stats_file_data)){

                        $season_stats = array();

                        foreach($stats_file_data as $key => $stats){
                                
                                if(empty($stats['home_id']) && empty($stats['away_id']) && empty($stats['type']) && empty($stats['season_scheduled_date'])){
                                        continue;
                                }
                            
                                if(empty($stats['home_id'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Home team is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['away_id'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Away team is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if($stats['home_id'] == $stats['away_id']){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Home team and Away team must be different."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['type'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Type field is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['season_scheduled_date'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Schedule date is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }

                                $home_id = explode(')_', $stats['home_id']);
                                $away_id = explode(')_', $stats['away_id']);
                                
                                $season_stats[] = array(
                                        'league_id'             => $stats_data['league_id'],
                                        'year'                  => $season_year,
                                        'home_id'               => trim(end($home_id)),
                                        'away_id'               => trim(end($away_id)),
                                        'type'                  => $stats['type'],
                                        'season_scheduled_date' => date('Y-m-d H:i', strtotime(trim($stats['season_scheduled_date']))),
                                        'scheduled_date'        => date('Y-m-d', strtotime(trim($stats['season_scheduled_date']))),
                                        'file_name'             => $stats_data['file_name']
                                );  
                        }

                        $result = $this->Statsfeed_model->replace_into_batch(SEASON, $season_stats);
                        
                        ## update season_game_unique_id filed value from season_id field
                        if(!empty($season_stats)){
                                foreach($season_stats as $season){

                                        $upd_data = array('season_game_unique_id' => "concat('$season_year',season_id)");

                                        $where = "league_id = ".$season['league_id'];
                                        $where .= " AND home_id = '".$season['home_id']."'";
                                        $where .= " AND away_id = '".$season['away_id']."'";
                                        $where .= " AND season_scheduled_date = '".$season['season_scheduled_date']."'";

                                        $this->Statsfeed_model->update_feed(SEASON, $where, $upd_data, TRUE);
                                }
                        }

                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Season data has been uploaded successfully.'), rest_controller::HTTP_OK);
                }
                else {
                        unlink($json_file);

                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'Uploaded sheet can not be empty.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                }
                        
        }
        ##############################
        # SEASON FEED END
        #############################
        
        
        #############################
        # SCORE STATISTICS START
        #############################
        
        public function get_season_statisctics_feed_post()
	{
		$this->form_validation->set_rules('league_id', 'League ID', 'trim|required');
		$this->form_validation->set_rules('season_game_unique_id', 'Season match ID', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		
		$result = $this->Statsfeed_model->get_season_statisctics_feed();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_add_score_stats_form_data_post()
	{                
                $league_id  = $this->input->post('league_id');
                $season_game_unique_id  = $this->input->post('season_game_unique_id');
                
		$team_result = $this->Statsfeed_model->get_season_game_team($this->input->post());
                
                // Get players of selected teams
                $team_ids = array_column($team_result, 'team_id');
                $player_result = $this->Statsfeed_model->get_team_player($team_ids, $league_id);
                
                // Get All positions
                $position_result = $this->Statsfeed_model->get_all_position($league_id);
                
                // Get Scoring Category
                $scoring_cat_result = $this->Statsfeed_model->get_scoring_category($league_id);
                
                // Get Scoring Rule
                $category_ids = array_column($scoring_cat_result, 'master_scoring_category_id');
                $scoring_rule_result = $this->Statsfeed_model->get_scoring_rule($category_ids);
		
                $data = array('team'=> $team_result, 'player' => $player_result, 'position' => $position_result, 'scoring_category' => $scoring_cat_result, 'scoring_rule' => $scoring_rule_result);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data' => $data) , rest_controller::HTTP_OK);
	}

	public function create_score_stats_post() {
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',              'League ID','trim|required');
			$this->form_validation->set_rules('season_game_unique_id',  'Season match ID',     'trim|required');
			
                        $this->form_validation->set_rules('team_id[]',              'Team',     'trim|required');
			$this->form_validation->set_rules('player_unique_id[]',     'Player',   'trim|required');
			$this->form_validation->set_rules('master_scoring_category_id[]', 'Scoring type', 'trim|required');
			$this->form_validation->set_rules('stats_key[]',            'Event',    'trim|required');
			$this->form_validation->set_rules('stats_value[]',          'Score',    'trim|required');
			//$this->form_validation->set_rules('minute[]',              'Minute',   'trim|required');

			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $this->load->model('Contest_model');
                        
                        $stats_data         = $this->input->post();
    			
			$season_game_detail = $this->Contest_model->get_season_game_detail($stats_data['season_game_unique_id'], $stats_data['league_id']);
                        
                        if(empty($season_game_detail))
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'Season game not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
                        
                        $feed_match_stats = $this->Statsfeed_model->get_feed_match_statistics($stats_data['season_game_unique_id'], $stats_data['league_id']);
                        
                        if(empty($feed_match_stats)){
                            
                                // Insert Feed Match Statistics Data
                                $feed_match_statistics_id = $stats_data['league_id'].'_'. $season_game_detail['season_game_unique_id'] .'_'.strtotime($season_game_detail['season_scheduled_date']);
                                $match_stats = array(
                                        'feed_match_statistics_id' => $feed_match_statistics_id,
                                        'league_id' => $stats_data['league_id'],
                                        'season_game_unique_id' => $season_game_detail['season_game_unique_id'],
                                        'season_scheduled_date' => $season_game_detail['season_scheduled_date'],
                                        'home' => $season_game_detail['home_id'],
                                        'away' => $season_game_detail['away_id']
                                );
                                $this->Statsfeed_model->save_feed_match_statistics($match_stats);
                                
                                $feed_match_stats_id = $feed_match_statistics_id;
                                
                        } else {
                                $feed_match_stats_id = $feed_match_stats['feed_match_statistics_id'];
                        }
                        
                        if($feed_match_stats_id){
                            
                                // Save Feed Player Statistics Data
                                unset($stats_data['league_id']);
                                unset($stats_data['season_game_unique_id']);
                                
                                $player_stats = array();
                                
                                if(count($stats_data['row']) > 0){

                                        for($r=0; $r < count($stats_data['row']); $r++){
                                                $player_stats[] = array(
                                                        'feed_match_statistics_id'  => $feed_match_stats_id,
                                                        'team_id'                   => $stats_data['team_id'][$r],
                                                        'player_unique_id'          => $stats_data['player_unique_id'][$r],
                                                        //'position'                  => $stats_data['player_unique_id'][$r],
                                                        'scoring_type'              => $stats_data['master_scoring_category_id'][$r],
                                                        'stats_key'                 => $stats_data['stats_key'][$r],
                                                        'stats_value'               => $stats_data['stats_value'][$r],
                                                        'minute'                    => $stats_data['minute'][$r],
                                                );  
                                        }
                                }
                                //print_r($player_stats);
                               $result = $this->Statsfeed_model->replace_into_batch(FEED_PLAYER_STATISTICS, $player_stats);
                               
                               $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Player Statistics has been saved successfully.'), rest_controller::HTTP_OK);
                        }
                        else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function edit_score_stats_post(){
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',              'League ID','trim|required');
			$this->form_validation->set_rules('season_game_unique_id',  'Season match ID',     'trim|required');
			
                        $this->form_validation->set_rules('team_id',              'Team',     'trim|required');
			$this->form_validation->set_rules('player_unique_id',     'Player',   'trim|required');
			$this->form_validation->set_rules('master_scoring_category_id', 'Scoring type', 'trim|required');
			$this->form_validation->set_rules('stats_key',            'Event',    'trim|required');
			$this->form_validation->set_rules('stats_value',          'Score',    'trim|required');
			//$this->form_validation->set_rules('minute[]',              'Minute',   'trim|required');

			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $this->load->model('Contest_model');
                        
                        $stats_data             = $this->input->post();
    			
			$season_game_detail = $this->Contest_model->get_season_game_detail($stats_data['season_game_unique_id'], $stats_data['league_id']);
                        
                        if(empty($season_game_detail))
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'Season game not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
                        
                        $feed_match_stats = $this->Statsfeed_model->get_feed_match_statistics($stats_data['season_game_unique_id'], $stats_data['league_id']);
                        
                        if(empty($feed_match_stats)){
                            
                            $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> $this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        } 
                        else {
                                $feed_match_stats_id = $feed_match_stats['feed_match_statistics_id'];
                        }
                        
                        if($feed_match_stats_id){
                            
                                // Save Feed Player Statistics Data
                                unset($stats_data['league_id']);
                                unset($stats_data['season_game_unique_id']);
                                
                                $player_stats = array();
                                $player_stats[] = array(
                                        'feed_match_statistics_id'  => $feed_match_stats_id,
                                        'team_id'                   => $stats_data['team_id'],
                                        'player_unique_id'          => $stats_data['player_unique_id'],
                                        //'position'                  => $stats_data['position'][$r],
                                        'scoring_type'              => $stats_data['master_scoring_category_id'],
                                        'stats_key'                 => $stats_data['stats_key'],
                                        'stats_value'               => $stats_data['stats_value'],
                                        'minute'                    => $stats_data['minute'],
                                );  
                                
                                //print_r($player_stats);
                               $result = $this->Statsfeed_model->replace_into_batch(FEED_PLAYER_STATISTICS, $player_stats);
                               
                               $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Player Statistics has been updated successfully.'), rest_controller::HTTP_OK);
                        }
                        else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function delete_score_stats_post(){
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',              'League ID','trim|required');
			$this->form_validation->set_rules('season_game_unique_id',  'Season match ID',     'trim|required');
			
                        $this->form_validation->set_rules('team_id',              'Team',     'trim|required');
			$this->form_validation->set_rules('player_unique_id',     'Player',   'trim|required');
			$this->form_validation->set_rules('master_scoring_category_id', 'Scoring type', 'trim|required');
			$this->form_validation->set_rules('stats_key',            'Event',    'trim|required');
			$this->form_validation->set_rules('stats_value',          'Score',    'trim|required');
			//$this->form_validation->set_rules('minute[]',              'Minute',   'trim|required');

			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $this->load->model('Contest_model');
                        
                        $stats_data             = $this->input->post();
    			
			if($stats_data['feed_match_statistics_id']){
                            
                                
                                
                                $where = array(
                                        'feed_match_statistics_id'  => $stats_data['feed_match_statistics_id'],
                                        'team_id'                   => $stats_data['team_id'],
                                        'player_unique_id'          => $stats_data['player_unique_id'],
                                        //'position'                  => $stats_data['position'][$r],
                                        'scoring_type'              => $stats_data['master_scoring_category_id'],
                                        'stats_key'                 => $stats_data['stats_key']
                                );  
                                
                                //print_r($player_stats);
                                //$this->db->table_name = FEED_PLAYER_STATISTICS;
                                //$result = $this->Statsfeed_model->delete($where);
                                
                                $result = $this->Statsfeed_model->delete_stats(FEED_PLAYER_STATISTICS, $where);
                                
                                if($result){
                                    $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Player Statistics has been deleted successfully.'), rest_controller::HTTP_OK);
                                } 
                                else {
                                    $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'There is some proble in delete operation.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                        }
                        else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function export_score_stats_template_get($season_game_id, $league_id) {
            
                $this->Statsfeed_model->export_score_stats_template($season_game_id, $league_id);
	}
        
        public function do_upload_score_post()
	{
		$dir				= APP_ROOT_PATH.UPLOAD_DIR;
		$subdir				= APP_ROOT_PATH.STATSFEED_DIR;
		$ext				= pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		
		$this->check_folder_exist($dir);
		$this->check_folder_exist($subdir);

		$config['allowed_types']	= 'xlsx';
		$config['max_size']			= '5000';
		$config['max_width']		= '1024';
		$config['max_height']		= '1000';
		$config['upload_path']		= $subdir;
		$config['file_name']		= time();

		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('file'))
		{
			$error = $this->upload->display_errors();
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		else
		{
			$upload_data = $this->upload->data();

			if($ext==='xlsx')
			{
				$this->xlsx_to_json_score($upload_data['full_path'], $upload_data['raw_name']);    
			}

			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>array('file_name'=> $upload_data['raw_name'])), rest_controller::HTTP_OK);
		}
	}

	private function xlsx_to_json_score($file, $raw_name)
	{
		//load the excel library
		$this->load->library('PHPExcel');

                //read file from path
		$objPHPExcel = PHPExcel_IOFactory::load($file);

		$feed_data = array();
		$coloum_meta = array('A'=>'player_unique_id','B'=>'scoring_type','C'=>'stats_key','D'=>'stats_value','E'=>'minute');

                $row_cnt = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();

                for($r = 3; $r <= $row_cnt; $r++){
                        
                        if($r > 200){
                            break;
                        }
                        
                        foreach($coloum_meta as $c_key => $c_field){
                                $feed_data[$r][$c_field] = $objPHPExcel->getActiveSheet()->getCell($c_key.$r)->getValue();
                        }
                }
                //print_r($feed_data); die;

		$dir = APP_ROOT_PATH.STATSFEED_DIR;
		$this->load->helper('file');
		$data = json_encode($feed_data);
		$json_file = $dir.$raw_name.'.json';
		$response = write_file($json_file, $data);
		unlink($file);
		return $response;
	}
        
        public function save_uploaded_score_stats_data_post() {
                        $this->load->model('Contest_model');
                        
                        $stats_data             = $this->input->post();
                        
                        $dir = APP_ROOT_PATH.STATSFEED_DIR;
                        $json_file = $dir.$stats_data['file_name'].'.json';
                        
                        $str = file_get_contents($json_file);
                        $stats_file_data = json_decode($str, true);
                        
                        //print_r($stats_file_data);
                        
			$season_game_detail = $this->Contest_model->get_season_game_detail($stats_data['season_game_unique_id'], $stats_data['league_id']);
                        
                        if(empty($season_game_detail))
			{
                                unlink($json_file);
                                
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'Season game not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
                        
                        $feed_match_stats = $this->Statsfeed_model->get_feed_match_statistics($stats_data['season_game_unique_id'], $stats_data['league_id']);
                        
                        if(empty($feed_match_stats)){
                            
                                // Insert Feed Match Statistics Data
                                $feed_match_statistics_id = $stats_data['league_id'].'_'. $season_game_detail['season_game_unique_id'] .'_'.strtotime($season_game_detail['season_scheduled_date']);
                                $match_stats = array(
                                        'feed_match_statistics_id' => $feed_match_statistics_id,
                                        'league_id' => $stats_data['league_id'],
                                        'season_game_unique_id' => $season_game_detail['season_game_unique_id'],
                                        'season_scheduled_date' => $season_game_detail['season_scheduled_date'],
                                        'home' => $season_game_detail['home_id'],
                                        'away' => $season_game_detail['away_id']
                                );
                                $this->Statsfeed_model->save_feed_match_statistics($match_stats);
                                
                                $feed_match_stats_id = $feed_match_statistics_id;
                                
                        } else {
                                $feed_match_stats_id = $feed_match_stats['feed_match_statistics_id'];
                        }
                        
                        if($feed_match_stats_id){
                            
                                // Save Feed Player Statistics Data
                            
                                if(!empty($stats_file_data)){
                                        
                                        $player_stats = array();
                                        
                                        foreach($stats_file_data as $key => $stats){

                                                if(empty($stats['player_unique_id'])){
                                                        unlink($json_file);
                                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, player field is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                                }
                                                if(empty($stats['scoring_type'])){
                                                        unlink($json_file);
                                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, scoring type field is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                                }
                                                if(empty($stats['stats_key'])){
                                                        unlink($json_file);
                                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, event field is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                                }
                                                if(empty($stats['stats_value'])){
                                                        unlink($json_file);
                                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, score field is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                                }
                                                
                                                $player = explode(')_', $stats['player_unique_id']);
                                                $scoring_type = explode('_', $stats['scoring_type']);
                                                
                                                $player_data = $offer_taken = $this->Statsfeed_model->get_single_row('team_id', PLAYER, array('player_unique_id' => trim(end($player)), 'league_id' => $stats_data['league_id']));
                                                
                                                $player_stats[] = array(
                                                        'feed_match_statistics_id'  => $feed_match_stats_id,
                                                        'player_unique_id'          => trim(end($player)),
                                                        'team_id'                   => $player_data['team_id'],
                                                        //'position'                  => $stats_data['player_unique_id'][$r],
                                                        'scoring_type'              => trim(end($scoring_type)),
                                                        'stats_key'                 => trim($stats['stats_key']),
                                                        'stats_value'               => $stats['stats_value'],
                                                        'minute'                    => $stats['minute'],
                                                        'file_name'                 => $stats_data['file_name']
                                                );  
                                        }
                                        
                                        $result = $this->Statsfeed_model->replace_into_batch(FEED_PLAYER_STATISTICS, $player_stats);    
                                        
                                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Player Statistics has been uploaded successfully.'), rest_controller::HTTP_OK);
                                }
                                else {
                                        unlink($json_file);

                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'Uploaded sheet can not be empty.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                        }
                        else
			{
                                unlink($json_file);
                                
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
        }
        #############################
        # SCORE STATISTICS END
        #############################
        
        
        #############################
        # TEAM STATISTICS START
        #############################
        
        public function create_team_stats_post() {
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',       'League ID',           'trim|required');
			
                        $this->form_validation->set_rules('team_name[]',     'Team name',           'trim|required');
			$this->form_validation->set_rules('team_abbr[]',     'Team abbreviation',   'trim|required');

			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $stats_data = $this->input->post();
                        
                        $this->load->model(array('api_credential_model', 'Teamroster_model'));

                        $api = $this->api_credential_model->active_feed_provide_season_year($stats_data['league_id']);
                        $season_year = $api['year'];
                        
                        ## Check for Valid League ID
                        $league_detail     = $this->Statsfeed_model->get_league_detail($stats_data['league_id']);
                        
                        if(empty($league_detail))
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
                        
                        
                        if(count(array_unique($stats_data['team_abbr'])) != count($stats_data['row'])) {
                                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'The Team abbreviation field must contain a unique value.') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }
                        
                        ## Check for Team Abbr Already Exist
                        $team_abbr_exist = $this->Teamroster_model->is_team_abbr_exist($stats_data['team_abbr'], $stats_data['league_id'], $season_year);

                        if(!empty($team_abbr_exist)){
                                
                                $team_abbrs = array_column($team_abbr_exist, 'team_abbr');
                            
                                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'Team abbreviation '.implode(', ', $team_abbrs).' already exist.') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }
    			
                        $team_stats = array();

                        if(count($stats_data['row']) > 0) {
                                
                                for($r=0; $r < count($stats_data['row']); $r++){
                                        $team_stats[] = array(
                                                //'team_id'           => rand(100,9999),
                                                'team_abbr'         => $stats_data['team_abbr'][$r],
                                                'team_name'         => $stats_data['team_name'][$r],
                                                'team_market'       => $stats_data['team_name'][$r],
                                                'league_id'         => $stats_data['league_id'],
                                                'year'              => $season_year
                                        );  
                                }
                        }
                        //print_r($team_stats); die;
                        $result = $this->Statsfeed_model->replace_into_batch(TEAM, $team_stats);
                       
                        ## update team_id filed value from t_id field
                        
                        $upd_data = array('team_id' => 't_id');
                        
                        $where = "team_abbr IN (".implode( ',' , array_map( function( $n ){ return '\''.$n.'\''; } , $stats_data['team_abbr'] ) ).")";
                        $where .= " AND league_id = ".$stats_data['league_id'];
                        $where .= " AND year = ".$season_year;
                        $this->Statsfeed_model->update_feed(TEAM, $where, $upd_data, TRUE);
                        

                       $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Team(s) have been saved successfully.'), rest_controller::HTTP_OK); 
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function edit_team_stats_post(){
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('team_id', 'Team ID','trim|required');
            $this->form_validation->set_rules('team_name', 'Team name', 'trim|required');
            $this->form_validation->set_rules('team_abbr', 'Team abbreviation', 'trim|required');
			//$this->form_validation->set_rules('minute[]',              'Minute',   'trim|required');

			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
            $this->load->model('Contest_model');
            $stats_data = $this->input->post();
    			
			$this->load->model(array('Teamroster_model'));

                        ## Check for Team Abbr Already Exist
                        $team_abbr_exist = $this->Teamroster_model->is_team_abbr_exist($stats_data);

                        if(!empty($team_abbr_exist))
                        {
                            $team_abbrs         = array_column($team_abbr_exist, 'team_abbr');
                            $temp_str           = implode(', ', $team_abbrs);
                            $team_abr_exist_msg = str_replace('%s', $temp_str , $this->admin_lang["team_abbr_exist"]);
                            $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> $team_abr_exist_msg) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }
    			
                        $team_data = array(
                                'team_abbr'         => $stats_data['team_abbr'],
                                'team_name'         => $stats_data['team_name'],
                                'team_market'       => $stats_data['team_name']
                        );  
                        //print_r($team_stats); die;
                        
                        ## update team_id filed value from t_id field
                        
                        $where = "t_id = ".$stats_data['t_id'];
                        $this->Statsfeed_model->update_feed(TEAM, $where, $team_data);
                        
                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Team has been updated successfully.'), rest_controller::HTTP_OK); 
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function export_team_template_get($league_id) {
            
                $this->load->model('api_credential_model');
                                
                $api = $this->api_credential_model->active_feed_provide_season_year($league_id);
                $season_year = $api['year'];
            
                $this->Statsfeed_model->export_team_template($league_id, $season_year);
	}
        
        public function do_upload_team_post()
	{
		$dir				= APP_ROOT_PATH.UPLOAD_DIR;
		$subdir				= APP_ROOT_PATH.TEAMFEED_DIR;
		$ext				= pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		
		$this->check_folder_exist($dir);
		$this->check_folder_exist($subdir);

		$config['allowed_types']	= 'xlsx';
		$config['max_size']		= '5000';
		$config['max_width']		= '1024';
		$config['max_height']		= '1000';
		$config['upload_path']		= $subdir;
		$config['file_name']		= time();

		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('file'))
		{
			$error = $this->upload->display_errors();
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		else
		{
			$upload_data = $this->upload->data();

			if($ext==='xlsx')
			{
				$this->xlsx_to_json_team($upload_data['full_path'], $upload_data['raw_name']);    
			}

			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>array('file_name'=> $upload_data['raw_name'])), rest_controller::HTTP_OK);
		}
	}

	private function xlsx_to_json_team($file, $raw_name)
	{
		//load the excel library
		$this->load->library('PHPExcel');

                //read file from path
		$objPHPExcel = PHPExcel_IOFactory::load($file);

		$feed_data = array();
		$coloum_meta = array('A'=>'team_name','B'=>'team_abbr');

                $row_cnt = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();

                for($r = 3; $r <= $row_cnt; $r++){
                    
                        if($r > 200){
                            break;
                        }

                        foreach($coloum_meta as $c_key => $c_field){
                                $feed_data[$r][$c_field] = $objPHPExcel->getActiveSheet()->getCell($c_key.$r)->getValue();
                        }
                }
                //print_r($feed_data); die;

		$dir = APP_ROOT_PATH.TEAMFEED_DIR;
		$this->load->helper('file');
		$data = json_encode($feed_data);
		$json_file = $dir.$raw_name.'.json';
		$response = write_file($json_file, $data);
		unlink($file);
		return $response;
	}
        
        public function save_uploaded_team_data_post() {
                        
                $stats_data             = $this->input->post();

                $dir = APP_ROOT_PATH.TEAMFEED_DIR;
                $json_file = $dir.$stats_data['file_name'].'.json';

                $str = file_get_contents($json_file);
                $stats_file_data = json_decode($str, true);

                //print_r($stats_file_data);

                $league_detail     = $this->Statsfeed_model->get_league_detail($stats_data['league_id']);

                if(empty($league_detail))
                {
                        unlink($json_file);

                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                }

                // Save Team Data

                if(!empty($stats_file_data)) {
                        
                        $this->load->model(array('api_credential_model', 'Teamroster_model'));
                        
                        $api = $this->api_credential_model->active_feed_provide_season_year($stats_data['league_id']);
                        $season_year = $api['year'];
                    
                        $team_abbr_list = array_column($stats_file_data, 'team_abbr');
                        
                        $team_abbr_exist = $this->Teamroster_model->is_team_abbr_exist($team_abbr_list, $stats_data['league_id'], $season_year);

                        if(!empty($team_abbr_exist)){
                                
                                $team_abbrs = array_column($team_abbr_exist, 'team_abbr');
                            
                                unlink($json_file);
                                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'Team abbreviation '.implode(', ', $team_abbrs).' already exist.') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }

                        $team_stats = array();

                        foreach($stats_file_data as $key => $stats){
                                
                                // If complete row is blank then skip this row
                                if(empty($stats['team_name']) && empty($stats['team_abbr'])){
                                        continue;
                                }
                            
                                if(empty($stats['team_name'])){
                                    
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Team name is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['team_abbr'])){
                                    
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Team abbreviation is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }

                                $team_stats[] = array(
                                        //'team_id'           => rand(100,9999),
                                        'team_abbr'         => $stats['team_abbr'],
                                        'team_name'         => $stats['team_name'],
                                        'team_market'       => $stats['team_name'],
                                        'league_id'         => $stats_data['league_id'],
                                        'year'              => $season_year,
                                        'file_name'         => $stats_data['file_name']
                                );  
                        }

                        $result = $this->Statsfeed_model->replace_into_batch(TEAM, $team_stats);  
                        
                        ## update team_id filed value from t_id field
                        
                        $upd_data = array('team_id' => 't_id');
                        
                        $where = "team_abbr IN (".implode( ',' , array_map( function( $n ){ return '\''.$n.'\''; } , $team_abbr_list ) ).")";
                        $where .= " AND league_id = ".$stats_data['league_id'];
                        $where .= " AND year = ".$season_year;
                        $this->Statsfeed_model->update_feed(TEAM, $where, $upd_data, TRUE);
                        
                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Team data has been uploaded successfully.'), rest_controller::HTTP_OK);
                }
                else {
                        unlink($json_file);

                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'Uploaded sheet can not be empty.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                }
                        
        }
        
        public function delete_team_stats_post(){
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('team_id', 'Team ID', 'trim|required');
           // $this->form_validation->set_rules('league_id', 'League ID', 'trim|required');
			
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        
            $stats_data             = $this->input->post();
    		$result = $this->Statsfeed_model->delete_team_from_league($stats_data);
            if($result){
                $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Team data has been deleted successfully.'), rest_controller::HTTP_OK);
            } 
            else {
                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'There is some proble in delete operation.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
            }
            
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        #############################
        # TEAM STATISTICS END
        #############################
        
        
        #############################
        # ROSTER FEED START
        #############################
        
        public function create_roster_stats_post() {
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',          'League ID',        'trim|required');
			
                        $this->form_validation->set_rules('team_id[]',          'Team',             'trim|required');
			$this->form_validation->set_rules('position[]',         'Position',         'trim|required');
			$this->form_validation->set_rules('first_name[]',       'First name',       'trim|required|alpha_numeric_spaces');
                        $this->form_validation->set_rules('last_name[]',        'Last name',        'trim|required|alpha_numeric_spaces');
                        $this->form_validation->set_rules('nick_name[]',        'Nick name',        'trim|alpha_numeric_spaces');
			
                        $this->form_validation->set_rules('salary[]',           'Salary',           'trim|numeric');
                        
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $post_data        = $this->input->post();
    			
			$league_detail     = $this->Statsfeed_model->get_league_detail($post_data['league_id']);

                        if(empty($league_detail))
                        {
                                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }
                        
                        // Save Roster Data
                        $roster = array();

                        if(count($post_data['row']) > 0) {
                            
                                $p_id = array();
                                
                                for($r=0; $r < count($post_data['row']); $r++) {
                                    
                                        $roster = array(
                                                'league_id'             => $post_data['league_id'],
                                                'player_unique_id'      => rand().time(),
                                                'team_id'               => $post_data['team_id'][$r],
                                                'position'              => $post_data['position'][$r],
                                                'first_name'            => $post_data['first_name'][$r],
                                                'last_name'             => $post_data['last_name'][$r],
                                                'full_name'             => $post_data['first_name'][$r] . ' ' . $post_data['last_name'][$r],
                                                'nick_name'             => (!empty($post_data['nick_name'][$r])) ? $post_data['nick_name'][$r] : NULL,
                                                'salary'                => (!empty($post_data['salary'][$r])) ? $post_data['salary'][$r] : 0,
                                                'injury_status'         => (!empty($post_data['injury_status'][$r])) ? $post_data['injury_status'][$r] : NULL,
                                                'player_status'         => '1'
                                        );  
                                        
                                        $p_id[] = $this->Statsfeed_model->insert(PLAYER, $roster);
                                }
                                
                                ## update player_unique_id filed value from p_id field
                                
                                $upd_data = array('player_unique_id' => 'p_id');
                                
                                $where = "p_id IN (".implode( ',', $p_id ).")";
                                
                                $this->Statsfeed_model->update_feed(PLAYER, $where, $upd_data, TRUE);
                        }
                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Roster data has been saved successfully.'), rest_controller::HTTP_OK);
                }
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function edit_roster_stats_post() {
            
                if($this->input->post())
		{
			$this->form_validation->set_rules('league_id',          'League ID',        'trim|required');
			
                        $this->form_validation->set_rules('team_id',          'Team',             'trim|required');
			$this->form_validation->set_rules('position',         'Position',         'trim|required');
			$this->form_validation->set_rules('first_name',       'First name',       'trim|required|alpha_numeric_spaces');
                        $this->form_validation->set_rules('last_name',        'Last name',        'trim|required|alpha_numeric_spaces');
                        $this->form_validation->set_rules('nick_name',        'Nick name',        'trim|alpha_numeric_spaces');
			
                        $this->form_validation->set_rules('salary',           'Salary',           'trim|numeric');
                        
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
                        
                        $post_data        = $this->input->post();
    			
			$league_detail     = $this->Statsfeed_model->get_league_detail($post_data['league_id']);

                        if(empty($league_detail))
                        {
                                $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                        }
                        
                        ## update Roster data

                        $upd_data = array(
                                        'team_id'               => $post_data['team_id'],
                                        'position'              => $post_data['position'],
                                        'first_name'            => $post_data['first_name'],
                                        'last_name'             => $post_data['last_name'],
                                        'full_name'             => $post_data['first_name'] . ' ' . $post_data['last_name'],
                                        'nick_name'             => (!empty($post_data['nick_name'])) ? $post_data['nick_name'] : NULL,
                                        'salary'                => (!empty($post_data['salary'])) ? $post_data['salary'] : 0,
                                        'injury_status'         => (!empty($post_data['injury_status'])) ? $post_data['injury_status'] : NULL
                                );

                        $where = "player_unique_id = ".$post_data['player_unique_id'];

                        $this->Statsfeed_model->update_feed(PLAYER, $where, $upd_data, FALSE);

                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Roster data has been updated successfully.'), rest_controller::HTTP_OK);
                }
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
        }
        
        public function delete_roster_post(){
            
        
			$this->form_validation->set_rules('player_team_id', 'Player Unique Id', 'trim|required');
            if (!$this->form_validation->run()) 
            {
                $this->send_validation_errors();
            }
                        
            $stats_data = $this->input->post();
    		$upd_data = array(
                    'is_deleted'     => 1
            );  
            $where = "player_team_id = ".$stats_data['player_team_id'];

            $result = $this->Statsfeed_model->update_feed(PLAYER_TEAM, $where, $upd_data, FALSE);
            
            if($result){
                    $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Roster record has been deleted successfully.'), rest_controller::HTTP_OK);
            } 
            else {
                    $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'There is some proble in delete operation.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
            }
                        
            
		
		
        }
        
        public function export_roster_template_get($league_id) {
            
                $this->Statsfeed_model->export_roster_template($league_id);
	}
        
        public function do_upload_roster_post()
	{
		$dir				= APP_ROOT_PATH.UPLOAD_DIR;
		$subdir				= APP_ROOT_PATH.ROSTER_DIR;
		$ext				= pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		
		$this->check_folder_exist($dir);
		$this->check_folder_exist($subdir);

		$config['allowed_types']	= 'xlsx';
		$config['max_size']		= '5000';
		$config['max_width']		= '1024';
		$config['max_height']		= '1000';
		$config['upload_path']		= $subdir;
		$config['file_name']		= time();

		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('file'))
		{
			$error = $this->upload->display_errors();
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		else
		{
			$upload_data = $this->upload->data();

			if($ext==='xlsx')
			{
				$this->xlsx_to_json_roster($upload_data['full_path'], $upload_data['raw_name']);    
			}

			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>array('file_name'=> $upload_data['raw_name'])), rest_controller::HTTP_OK);
		}
	}

	private function xlsx_to_json_roster($file, $raw_name)
	{
		//load the excel library
		$this->load->library('PHPExcel');

                //read file from path
		$objPHPExcel = PHPExcel_IOFactory::load($file);

		$feed_data = array();
		$coloum_meta = array('A'=>'team_id','B'=>'position','C'=>'first_name','D'=>'last_name','E'=>'nick_name','F'=>'salary','G'=>'injury_status');

                $row_cnt = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();

                for($r = 3; $r <= $row_cnt; $r++){
                    
                        if($r > 200){
                            break;
                        }

                        foreach($coloum_meta as $c_key => $c_field){
                                $feed_data[$r][$c_field] = $objPHPExcel->getActiveSheet()->getCell($c_key.$r)->getValue();
                        }
                }
                
		$dir = APP_ROOT_PATH.ROSTER_DIR;
		$this->load->helper('file');
		$data = json_encode($feed_data);
		$json_file = $dir.$raw_name.'.json';
		$response = write_file($json_file, $data);
		unlink($file);
		return $response;
	}
        
        public function save_uploaded_roster_data_post() {

                $stats_data         = $this->input->post();

                $dir                = APP_ROOT_PATH.ROSTER_DIR;
                $json_file          = $dir.$stats_data['file_name'].'.json';

                $str                = file_get_contents($json_file);
                $stats_file_data    = json_decode($str, true);

                //print_r($stats_file_data);

                $league_detail     = $this->Statsfeed_model->get_league_detail($stats_data['league_id']);

                if(empty($league_detail))
                {
                        unlink($json_file);
                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> 'League not found') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                }

                // Save Roster Data

                if(!empty($stats_file_data)){

                        $p_id = array();
                        $roster_arr = array();
                        
                        foreach($stats_file_data as $key => $stats){
                                
                                if( empty($stats['team_id']) && empty($stats['position']) && empty($stats['first_name']) && empty($stats['last_name']) 
                                        && empty($stats['nick_name']) && empty($stats['salary']) && empty($stats['injury_status']) ){
                                        continue;
                                }
                            
                                if(empty($stats['team_id'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Team is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['position'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Position is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['first_name'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, First name is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }
                                if(empty($stats['last_name'])){
                                        unlink($json_file);
                                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=> "At row $key, Last name is required."), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                                }

                                $team_id = explode(')_', $stats['team_id']);
                                
                                $roster_arr[] = array(
                                                'league_id'             => $stats_data['league_id'],
                                                'player_unique_id'      => rand().time(),
                                                'team_id'               => trim(end($team_id)),
                                                'position'              => $stats['position'],
                                                'first_name'            => $stats['first_name'],
                                                'last_name'             => $stats['last_name'],
                                                'full_name'             => $stats['first_name'] . ' ' . $stats['last_name'],
                                                'nick_name'             => (!empty($stats['nick_name'])) ? $stats['nick_name'] : NULL,
                                                'salary'                => (!empty($stats['salary'])) ? trim($stats['salary']) : 0,
                                                'injury_status'         => (!empty($stats['injury_status'])) ? trim($stats['injury_status']) : NULL,
                                                'player_status'         => '1',
                                                'file_name'             => $stats_data['file_name']
                                        );
                        }
                        
                        ## Insert Roster Data
                        if(!empty($roster_arr)){
                                foreach($roster_arr as $roster){
                                        $p_id[] = $this->Statsfeed_model->insert(PLAYER, $roster);
                                }
                        }
                                
                        ## update player_unique_id filed value from p_id field
                        
                        if (!empty($p_id)) {
                                $upd_data = array('player_unique_id' => 'p_id');

                                $where = "p_id IN (".implode( ',', $p_id ).")";

                                $this->Statsfeed_model->update_feed(PLAYER, $where, $upd_data, TRUE);
                        }
                       
                        $this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'Roster data has been uploaded successfully.'), rest_controller::HTTP_OK);
                }
                else {
                        unlink($json_file);

                        $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'Uploaded sheet can not be empty.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
                }               
        }
        
        #############################
        # ROSTER FEED END
        #############################
        
        /**
	* @Summary: check if folder exists otherwise create new
	*/
	private function check_folder_exist($dir)
	{
		if(!is_dir($dir))
         		return mkdir($dir, 0777);
		return TRUE;
	}
}
/* End of file Stats_feed.php */
/* Location: ./application/controllers/Stats_feed.php */
