<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Contest extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Contest_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_league_post()
	{
		$result = $this->Contest_model->get_all_league();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}
        
        public function get_all_position_post()
	{
		$league_id  = $this->input->post('league_id');

		$result = $this->Contest_model->get_all_position($league_id);
                
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_prize_data_post()
	{
		$league_id = $this->input->post('league_id');
		$contest_type = $this->input->post('contest_type');
		$number_of_winner	= $this->Contest_model->get_all_number_of_winner($league_id, $contest_type);
		$result = array(					
					'all_number_of_winner'			=> $number_of_winner['all_number_of_winner'],
					'number_of_winner_validation'	=> $number_of_winner['number_of_winner_validation']
				);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}
	public function get_all_contest_data_post()
	{
		
		$league_id 			= $this->input->post('league_id');
       // $all_position       = $this->Contest_model->get_all_position($league_id);
		$seasons_dates		= $this->Contest_model->get_season_date($league_id);
		$all_seasons_dates	= $this->Contest_model->get_all_season_date($league_id);
		$all_duration		= $this->Contest_model->get_all_duration($league_id);
		$all_salary_cap		= $this->Contest_model->get_all_salary_cap($league_id);
		$all_drafting_style = $this->Contest_model->get_all_drafting_style();
		$all_available_week	= array();

		// $number_of_winner	= $this->Contest_model->get_all_number_of_winner($league_id);

		$contest_types = array("0"=>"H2H", "1"=>"Multiuser League", "2"=>"50/50", "3"=>"Uncapped");

		// $size_list = $this->Common_model->get_all_fee_size(array('action_from' => 'admin', 'action_for' => 'size'));
		// $fee_list = $this->Common_model->get_all_fee_size(array('action_from' => 'admin', 'action_for' => 'fee'));
		
		$result = array(
					'mindate'					=> format_date('today', 'Y-m-d'),
					'seasons_dates'				=> $seasons_dates,
					'all_seasons_dates'			=> $all_seasons_dates,
					'all_duration'				=> $all_duration,
					'all_salary_cap'			=> $all_salary_cap,
					'all_available_week'		=> $all_available_week,
					'contest_types'				=> $contest_types,
                  //  'all_position'              => $all_position,
                    'all_drafting_style'		=> $all_drafting_style,
                    'default_site_rake'			=> DEFAULT_SITE_RAKE
				);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_drafting_style_post()
	{
                $league_duration_id = $this->input->post('league_duration_id');
		$is_turbo_lineup = $this->input->post('is_turbo_lineup');
		$result = $this->Contest_model->get_all_drafting_style();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_available_game_of_the_day_or_week_post($return_only = FALSE)
	{
		$data_arr = array(
							"league_id" => $this->input->post('league_id'),
							"league_duration_id" => $this->input->post('league_duration_id')
						);
		if($this->input->post('league_duration_id')==1)
		{
			$data_arr['season_scheduled_date'] = $this->input->post('season_scheduled_date');
		}
		else
		{
			$data_arr['from_date'] = $this->input->post('from_date');
			$data_arr['to_date'] = $this->input->post('to_date');
		}

		$game_list = $this->Contest_model->get_available_game_of_the_day_or_week($data_arr);
		$result = TRUE;

		@$home = array_column($game_list, 'home');
		@$away = array_column($game_list, 'away');

		if (!is_array($home))
			$home = array();

		if (!is_array($away))
			$away = array();

		$home_away = array_merge($home, $away);
		$home_away = array_unique($home_away);

		if (!$game_list)
			$game_list = array();

                /*Temparory added for client demo for IPL*/
//		if ($this->input->post('entry_fee') != 0)
//		{
//			if (count($home_away) < 3)
//				$result = FALSE;
//		}
                /*Temparory added for client demo for IPL END*/

		$response['game_list'] = $game_list;
		$response['result'] = $result;

		if ($return_only)
			return $result;
		else
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$response) , rest_controller::HTTP_OK);
	}

	public function game_prize_details_post()
	{
		$game_data = $this->input->post();
		$site_rake = (isset($game_data['site_rake'])) ? (int)$game_data['site_rake'] : DEFAULT_SITE_RAKE;
		

		$result = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size'], $game_data['entry_fee'], $game_data['league_number_of_winner_id'], $site_rake);
		$prize_pool = array_sum(array_map("format_num_callback", $result));
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$prize_pool), rest_controller::HTTP_OK);
	}

	public function create_contest_post()
	{

		


		if($this->input->post())
		{
			$this->form_validation->set_rules('league_id', $this->lang->line('league'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('game_name', $this->lang->line('game_name'), 'trim|required|max_length[50]');
			$this->form_validation->set_rules('league_duration_id', $this->lang->line('duration'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('entry_fee', $this->lang->line('entry_fee'), 'trim|required');
			$this->form_validation->set_rules('drafting_style', $this->lang->line('drafting_style'), 'trim|required');
			$this->form_validation->set_rules('number_of_winner_id', $this->lang->line('number_of_winner_id'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('salary_cap', $this->lang->line('salary_cap'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('contest_type', $this->lang->line('contest_type'), 'trim|required');
			$this->form_validation->set_rules('site_rake', $this->lang->line('site_rake'), 'trim|required');

			$duration_id		= $this->input->post('duration_id');
			$is_uncapped		= $this->input->post('contest_type')==3?'1':'0';
			$is_feature			= $this->input->post('is_feature')?$this->input->post('is_feature'):'0';
			$prize_selection	= $this->input->post('prize_selection');
			$is_multiple_lineup	= $this->input->post('is_multiple_lineup');

			$disable_auto_cancel	= '0';
			$prize_pool				= '';
			$guaranteed_prize		= '0';
			$minimum_size			= 0;

			$multiple_lineup = 0;
			if($is_multiple_lineup)
			{
				$this->form_validation->set_rules('multiple_lineup', $this->lang->line('multiple_lineup'), 'trim|required|max_length[2]|integer|greater_than_equal_to[2]');
				$multiple_lineup = $this->input->post('multiple_lineup');
			}

			if ($duration_id == 1) //Daily
			{
				$this->form_validation->set_rules('season_scheduled_date', $this->lang->line('date'), 'trim|required');
			}
			elseif ($duration_id == 2) //Custom
			{
				$this->form_validation->set_rules('from_date','From Date', 'trim|required');
				$this->form_validation->set_rules('to_date', 'To Date', 'trim|required');
			}
			if($is_uncapped)
			{
				$this->form_validation->set_rules('size_min', $this->lang->line('size_min'), 'trim|required|is_natural_no_zero');
			}			
			else
			{
				$this->form_validation->set_rules('size', $this->lang->line('size'), 'trim|required|is_natural_no_zero|greater_than_equal_to[2]');
			}
			if($prize_selection == 'custom')
			{
				$this->form_validation->set_rules('custom_prize', $this->lang->line('custom_prize'), 'trim|required|is_natural_no_zero');
				$guaranteed_prize = '1';
			}
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}

			$auto_recurrent_id = 0;
			$game_data = $this->input->post();


			if ( $this->input->post('league_duration_id')!=3 && ! $this->get_available_game_of_the_day_or_week_post( TRUE ) )
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_game_size')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}

			// if($this->input->post('league_duration_id')==3 && count($game_data['contests'])==0)
			// {
			// 	$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_game_size')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			// }

			$list_game_date_wise = $this->Contest_model->get_list_game_date_wise($game_data['contests'],$game_data['league_id']);
			$home_away = array_column($list_game_date_wise, 'home', 'away');
			$away_home = array_column($list_game_date_wise, 'away', 'home');

			foreach ($list_game_date_wise as $key => $value)
			{
				$list_of_games[] = $value['season_game_uid'];
			}
			
			$game_data['selected_matches'] = implode(',', $list_of_games);

			// if (!isset($game_data['season_week']) || !$game_data['season_week'])
			// {
			// 	$game_data['season_week'] = '0';
			// }

			$game_data['game_unique_id'] = random_string('alnum', 9);
			$game_data['season_scheduled_date'] = $this->Contest_model->get_season_scheduled_date($list_of_games[0], $game_data['league_id']);

			if ($duration_id == 1) //Daily
			{
				//$game_data['season_week'] = $this->Contest_model->get_current_week($game_data['league_id'], $game_data['season_scheduled_date']);
			}
			$game_data['season_week'] = '0';
			
			$player_salary_master_data = $this->Contest_model->get_player_salary_master($game_data['league_id']);

			if(isset($player_salary_master_data['player_salary_master_id']))
			{
				$player_salary_master_id = $player_salary_master_data['player_salary_master_id'];
			}
			else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('player_relase_error')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			if ($is_feature == 1)
			{
				$disable_auto_cancel	= '1';
				$minimum_size			= 2;
			}

			$site_rake = (isset($game_data['site_rake'])) ? (int)$game_data['site_rake'] : DEFAULT_SITE_RAKE;
			//echo $game_data['site_rake'].'  '.$site_rake;die;
		

			if ($is_uncapped)
			{
				$game_data['size']		= UNCAPPED_GAME_SIZE;
				// $minimum_size			= $game_data['size_min'];
				$minimum_size			= $game_data['size_min'];
				$disable_auto_cancel	= '1';
				$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size_min'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
				$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
			}
			elseif($this->input->post('contest_type')==0)
			{
				$game_data['size'] = 2;
				$minimum_size	   = 2;
				$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
				$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
			}
			else
			{
				$minimum_size			= $game_data['size_min'];
				$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size_min'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
				$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
			}

			if($prize_selection=='custom')
			{
				$prize_pool = $game_data['custom_prize'];
			}
			
			$data_array = array(
								"contest_unique_id"				=> $game_data['game_unique_id'],
								"player_salary_master_id"		=> $player_salary_master_data['player_salary_master_id'],
								"contest_name"					=> $game_data['game_name'],
								"league_id"						=> $game_data['league_id'],
								"league_duration_id"			=> $game_data['league_duration_id'],
								"season_scheduled_date"			=> $game_data['season_scheduled_date'],
								"league_drafting_styles_id"		=> $game_data['drafting_style'],
								"season_week"					=> $game_data['season_week'],
								"league_salary_cap_id"			=> $game_data['salary_cap'],
								"size"							=> $game_data['size'],
								"minimum_size"					=> $minimum_size,
								"is_feature"					=> "$is_feature",
								"is_uncapped"					=> "$is_uncapped",
								"multiple_lineup"				=> $multiple_lineup,
								"entry_fee"						=> $game_data['entry_fee'],
								"prize_pool"					=> $prize_pool,
								"league_contest_type_id"		=> $game_data['number_of_winner_id'],
								"selected_matches"				=> $game_data['selected_matches'],
								"disable_auto_cancel"			=> $disable_auto_cancel,
								"site_rake"						=> $site_rake,
								"guaranteed_prize"				=> $guaranteed_prize,
								"contest_access_type"			=> "0",
								"auto_recurrent_id"				=> $auto_recurrent_id,
								"contest_type"					=> $game_data['contest_type'],
								"added_date"					=> format_date()
							);

				//print_r($data_array);die;

				if ($is_feature == 1 && !empty($game_data['feature_img']))
				{
					$data_array['feature_image'] = $game_data['feature_img']; 
				}

				if($this->input->post('is_auto_recurrent'))
				{
					$data_array['is_auto_recurrent']  = 1;
				}


			$game_id = $this->Contest_model->save_contest($data_array);
			
			if($game_id)
			{
				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('contest_create_successfully')), rest_controller::HTTP_OK);
			}
			else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}
        public function create_turbo_contest_post()
	{
		if($this->input->post())
		{                    
			$this->form_validation->set_rules('league_id', $this->lang->line('league'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('turbo_contest_type', $this->lang->line('Player Type'), 'trim|required');
			$this->form_validation->set_rules('game_name', $this->lang->line('game_name'), 'trim|required|max_length[50]');
			$this->form_validation->set_rules('league_duration_id', $this->lang->line('duration'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('entry_fee', $this->lang->line('entry_fee'), 'trim|required');
			$this->form_validation->set_rules('drafting_style', $this->lang->line('drafting_style'), 'trim|required');
			$this->form_validation->set_rules('number_of_winner_id', $this->lang->line('number_of_winner_id'), 'trim|required|is_natural_no_zero');
			//$this->form_validation->set_rules('salary_cap', $this->lang->line('salary_cap'), 'trim|required|is_natural_no_zero');
			$this->form_validation->set_rules('contest_type', $this->lang->line('contest_type'), 'trim|required');

			$duration_id		= $this->input->post('duration_id');
			$is_uncapped		= $this->input->post('contest_type')==3?'1':'0';
			$is_feature		= $this->input->post('is_feature')?$this->input->post('is_feature'):'0';
			$prize_selection	= $this->input->post('prize_selection');

			$disable_auto_cancel	= '0';
			$prize_pool		= '';
			$guaranteed_prize	= '0';
			$minimum_size		= 0;
			if ($duration_id == 1) //Daily
			{
				$this->form_validation->set_rules('season_scheduled_date', $this->lang->line('date'), 'trim|required');
			}
			elseif ($duration_id == 2) //Weekly
			{
				$this->form_validation->set_rules('season_week', $this->lang->line('week'), 'trim|required|is_natural_no_zero');
			}
			elseif ($duration_id == 3) //Custom
			{
				$this->form_validation->set_rules('from_date', $this->lang->line('from_date'), 'trim|required');
				$this->form_validation->set_rules('to_date', $this->lang->line('to_date'), 'trim|required');
			}
			if($is_uncapped)
			{
				$this->form_validation->set_rules('size_min', $this->lang->line('size_min'), 'trim|required|is_natural_no_zero');
			}
			else
			{
				$this->form_validation->set_rules('size', $this->lang->line('size'), 'trim|required|is_natural_no_zero|greater_than_equal_to[2]');
			}
			if($prize_selection == 'custom')
			{
				$this->form_validation->set_rules('custom_prize', $this->lang->line('custom_prize'), 'trim|required|is_natural_no_zero');
				$guaranteed_prize = '1';
			}
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}

			$is_auto_recurrent = 0;
			$game_data = $this->input->post();

			if($this->input->post('is_auto_recurrent')&& !$is_uncapped)
				$is_auto_recurrent = 1;

			if( ! $this->get_available_game_of_the_day_or_week_post( TRUE ) )
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_game_size')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}

			$list_game_date_wise = $this->Contest_model->get_list_game_date_wise($game_data['contests'],$game_data['league_id']);

			$home_away = array_column($list_game_date_wise, 'home', 'away');
			$away_home = array_column($list_game_date_wise, 'away', 'home');

			foreach ($list_game_date_wise as $key => $value)
			{
				$list_of_games[] = $value['season_game_unique_id'];
			}
			if (count($away_home) < 1 || count($home_away) < 1) // Used to check atleast 2 teams should be picked
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_game_select')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);				
			}

			$game_data['selected_matches'] = implode(',', $list_of_games);

			if (!isset($game_data['season_week']) || !$game_data['season_week'])
			{
				$game_data['season_week'] = '0';
			}

			$game_data['game_unique_id'] = random_string('alnum', 9);
			$game_data['season_scheduled_date'] = $this->Contest_model->get_season_scheduled_date($list_of_games[0], $game_data['league_id']);

			if ($duration_id == 1) //Daily
			{
				$game_data['season_week'] = $this->Contest_model->get_current_week($game_data['league_id'], $game_data['season_scheduled_date']);
			}
			
			$player_salary_master_data = $this->Contest_model->get_player_salary_master($game_data['league_id']);

			if(isset($player_salary_master_data['player_salary_master_id']))
			{
				$player_salary_master_id = $player_salary_master_data['player_salary_master_id'];
			}
			else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('player_relase_error')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			if ($is_feature == 1)
			{
				$disable_auto_cancel	= '1';
				$minimum_size			= 2;
			}
			$site_rake = (isset($game_data['site_rake'])) ? (int)$game_data['site_rake'] : DEFAULT_SITE_RAKE;

			if ($is_uncapped)
			{
				$game_data['size']		= UNCAPPED_GAME_SIZE;
				// $minimum_size			= $game_data['size_min'];
				$minimum_size			= $game_data['size_min'];
				$disable_auto_cancel	= '1';
				$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size_min'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
				$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
			}
			elseif($this->input->post('contest_type')==0)
			{
				$game_data['size'] = 2;
				$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
				$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
			}
			else
			{
				$minimum_size			= $game_data['size_min'];
				$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size_min'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
				$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
			}

			if($prize_selection=='custom')
			{
				$prize_pool = $game_data['custom_prize'];
			}

			$data_array = array(
								"contest_unique_id"			=> $game_data['game_unique_id'],
								"player_salary_master_id"	=> $player_salary_master_data['player_salary_master_id'],
								"contest_name"				=> $game_data['game_name'],
								"league_id"					=> $game_data['league_id'],
								"league_duration_id"		=> $game_data['league_duration_id'],
								"season_scheduled_date"		=> $game_data['season_scheduled_date'],
								"league_drafting_styles_id"	=> $game_data['drafting_style'],
								"season_week"				=> $game_data['season_week'],								
								//"league_salary_cap_id"		=> $game_data['salary_cap'],
								"size"						=> $game_data['size'],
								"minimum_size"				=> $minimum_size,
								"is_feature"                => "$is_feature",
								"is_uncapped"				=> "$is_uncapped",
								"entry_fee"					=> round($game_data['entry_fee']),
								"prize_pool"				=> round($prize_pool),
								"league_contest_type_id"	=> $game_data['number_of_winner_id'],
								"selected_matches"			=> $game_data['selected_matches'],
								"disable_auto_cancel"		=> $disable_auto_cancel,
								"site_rake"					=> $site_rake,
								"guaranteed_prize"			=> $guaranteed_prize,
								"contest_access_type"		=> "0",
								"auto_recurrent_id"			=> $is_auto_recurrent,
								"contest_type"				=> $game_data['contest_type'],
								"added_date"				=> format_date(),
								"is_turbo_lineup"			=> 1,
								"turbo_contest_type"		=> $game_data['turbo_contest_type']
							);

				if ($is_feature == 1 && !empty($game_data['feature_img']))
				{
					$data_array['feature_image'] = $game_data['feature_img']; 
				}
			$game_id = $this->Contest_model->save_contest($data_array);
			
			if($game_id)
			{
				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('contest_create_successfully')), rest_controller::HTTP_OK);
			}
			else
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * [create_auto_recurrent_contest description]
	 * @MethodName create_auto_recurrent_contest
	 * @Summary This function used to create auto recurrent contest
	 * @param      array  game data
	 * @return     array
	 */
	public function create_auto_recurrent_contest($game_data)
	{
		$_POST['period_of_recurrent_value'] =  (int) $this->input->post('period_of_recurrent_value');
		$_POST['no_of_game'] =  (int) $this->input->post('no_of_game');
		$_POST['auto_recurrent_stop_value'] =  (int) $this->input->post('auto_recurrent_stop_value');
		/*if($this->input->post('is_period_of_recurrent')==1)
		{
			$_POST['period_of_recurrent'] =  $this->input->post('is_period_of_recurrent');
			$game_data['period_of_recurrent'] = $this->input->post('is_period_of_recurrent');
		}*/
		// echo $game_data['period_of_recurrent'];die("ok");	
		if($game_data['selectall'])
		{
			$this->form_validation->set_rules('period_of_recurrent', $this->lang->line('period_of_recurrent'), 'trim|required|greater_than[0]');
		}
		if($game_data['period_of_recurrent']!=1 && $game_data['period_of_recurrent']!="")
		{
			$this->form_validation->set_rules('period_of_recurrent_value', $this->lang->line('period_of_recurrent_value'), 'trim|required|greater_than[0]');
		}

		$this->form_validation->set_rules('no_of_game', $this->lang->line('no_of_game'), 'less_than[31]');

		if($game_data['period_of_recurrent']=="" && $this->input->post('is_period_of_recurrent'))
		{
			if(isset($game_data['no_of_game'])&&$game_data['no_of_game']==0)
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>"Please Enter No of Game"), rest_controller::HTTP_INTERNAL_SERVER_ERROR);				
			}
		}
		if(isset($game_data['no_of_game']) && $game_data['no_of_game']!="" && $game_data['no_of_game']!=0)
		{
			$this->form_validation->set_rules('auto_recurrent_stop_type', $this->lang->line('auto_recurrent_stop_type'), 'trim|required');
			$this->form_validation->set_rules('auto_recurrent_stop_value', $this->lang->line('auto_recurrent_stop_value'), 'trim|required|greater_than[0]');			
		}
		$duration_id		= $game_data['league_duration_id'];
		$is_uncapped		= $game_data['contest_type']==3?'1':'0';
		$is_feature			= isset($game_data['is_feature']) && $game_data['is_feature'] ?$game_data['is_feature']:'0';
		$prize_selection	= $game_data['prize_selection'];

		$disable_auto_cancel	= '0';
		$prize_pool				= '';
		$guaranteed_prize		= '0';
		$minimum_size			= 0;

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$list_game_date_wise = $this->Contest_model->get_list_game_date_wise($game_data['contests'],$game_data['league_id']);

		$home_away = array_column($list_game_date_wise, 'home', 'away');
		$away_home = array_column($list_game_date_wise, 'away', 'home');

		foreach ($list_game_date_wise as $key => $value)
		{
			$list_of_games[] = $value['season_game_unique_id'];
		}

		$game_data['selected_matches'] = implode(',', $list_of_games);

		if (!isset($game_data['season_week']) || !$game_data['season_week'])
		{
			$game_data['season_week'] = '0';
		}

		$game_data['season_scheduled_date'] = $this->Contest_model->get_season_scheduled_date($list_of_games[0], $game_data['league_id']);

		if ($duration_id == 1) //Daily
		{
			$game_data['season_week'] = $this->Contest_model->get_current_week($game_data['league_id'], $game_data['season_scheduled_date']);
		}
		
		$week_month = $this->Contest_model->get_all_season_month_and_week($game_data['league_id']);

		if($game_data['period_of_recurrent']==2)
		{
			$week = $week_month['end_week'] - $game_data['season_week'];
			if($week <= $game_data['period_of_recurrent_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		elseif($game_data['period_of_recurrent']==3)
		{
			$month = $week_month['end_month'] - date("m", strtotime(format_date()));
			if($month <= $game_data['period_of_recurrent_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}

		if($game_data['auto_recurrent_stop_type']!=4 && $game_data['auto_recurrent_stop_type']!='' && $game_data["period_of_recurrent"] == '')
		{			
			$start_date = new DateTime(format_date());

			$time = explode(" ", $game_data['season_scheduled_date']);
			if($time[1]=='00:00:00')
			{
				$contest_time = $time[0]." 23:59:00"; /*This for when time is 00:00:00 then create issue*/
			}
			else
			{
				$contest_time = $game_data['season_scheduled_date'];
			}
			
			$since_start = $start_date->diff(new DateTime($contest_time));

			if($game_data['auto_recurrent_stop_type'] == 1 && $since_start->days == 0  && $since_start->h == 0 && $since_start->i < $game_data['auto_recurrent_stop_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			elseif($game_data['auto_recurrent_stop_type'] == 2 && $since_start->days == 0 && $since_start->h < $game_data['auto_recurrent_stop_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			elseif($game_data['auto_recurrent_stop_type'] == 3 && $since_start->days < $game_data['auto_recurrent_stop_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}

		if ($is_feature == 1)
		{
			$disable_auto_cancel	= '1';
			$minimum_size			= 2;
		}
		$site_rake = (isset($game_data['site_rake'])) ? (int)$game_data['site_rake'] : DEFAULT_SITE_RAKE;

		if ($is_uncapped)
		{
			$game_data['size']		= UNCAPPED_GAME_SIZE;
			$minimum_size			= $game_data['size_min'];
			$disable_auto_cancel	= '1';
			$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size_min'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
			$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
		}
		elseif($this->input->post('contest_type')==0)
		{
			$game_data['size'] = 2;
			$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
			$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
		}
		else
		{
			$prize_pool_data = $this->Contest_model->prize_details_by_size_fee_prizing($game_data['size'], $game_data['entry_fee'], $game_data['number_of_winner_id'],$site_rake);
			$prize_pool = array_sum(array_map("format_num_callback", $prize_pool_data));
		}
		$period_of_recurrent_value = $game_data["period_of_recurrent_value"]?$game_data["period_of_recurrent_value"]:0;
		$period_of_recurrent = $game_data["period_of_recurrent"]?$game_data["period_of_recurrent"]:0;
		$auto_recurrent_stop_type = $game_data["auto_recurrent_stop_type"]?$game_data["auto_recurrent_stop_type"]:0;
		$auto_recurrent_stop_value = $game_data["auto_recurrent_stop_value"]?$game_data["auto_recurrent_stop_value"]:0;
		$no_of_game = $game_data['no_of_game']?$game_data['no_of_game']:0;
		
		$data_array = array(
							"league_id"					=> $game_data["league_id"],
							"contest_name"				=> $game_data['game_name'],
							"contest_access_type"		=> "0",
							"contest_type"				=> $game_data["contest_type"],
							"league_duration_id"		=> $game_data["league_duration_id"],
							"league_drafting_styles_id"	=> $game_data["drafting_style"],
							"league_salary_cap_id"		=> $game_data["salary_cap"],
							"size"						=> $game_data["size"],
							"minimum_size"				=> $minimum_size,
							"is_feature"				=> "$is_feature",
							"entry_fee"					=> $game_data["entry_fee"],							
							"prize_pool"				=> $prize_pool,
							"league_contest_type_id"	=> $game_data['number_of_winner_id'],
							"disable_auto_cancel"		=> $disable_auto_cancel,
							"site_rake"					=> $site_rake,
							"is_uncapped"				=> "$is_uncapped",
							"period_type"				=> "$period_of_recurrent",
							"period_value"				=> $period_of_recurrent_value,
							"period_stop_type"			=> "$auto_recurrent_stop_type",
							"period_stop_value"			=> $auto_recurrent_stop_value,
							"no_of_game"				=> $no_of_game,
							"added_date"				=> format_date(),
							"modified_date"				=> format_date()
						);
		if($period_of_recurrent==0)
		{
			$data_array["season_scheduled_date"] = $game_data['season_scheduled_date'];
			$data_array["season_week"] = $game_data['season_week'];
			$data_array["selected_matches"] = $game_data['selected_matches'];
		}
		if ($is_feature == 1 && !empty($game_data['feature_img']))
		{
			$data_array['feature_image'] = $game_data['feature_img']; 
		}

		$auto_recurrent_id = $this->Contest_model->save_auto_recurrent_contest($data_array);
		return $auto_recurrent_id;
	}


	public function update_auto_recurrent_contest_post()
	{
		$_POST['period_of_recurrent_value'] =  (int) $this->input->post('period_of_recurrent_value');
		$_POST['no_of_game'] =  (int) $this->input->post('no_of_game');
		$_POST['auto_recurrent_stop_value'] =  (int) $this->input->post('auto_recurrent_stop_value');
		if($this->input->post('is_period_of_recurrent')==1)
		{
			$_POST['period_of_recurrent'] =  $this->input->post('is_period_of_recurrent');
			$game_data['period_of_recurrent'] = $this->input->post('is_period_of_recurrent');
			$_POST['period_of_recurrent_value'] =  0;
		}
		$game_data = $this->input->post();
		if(!isset($game_data) || empty($game_data))
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		
		$this->form_validation->set_rules('no_of_game', $this->lang->line('no_of_game'), 'less_than[31]');

		if($game_data['period_of_recurrent']!=1 && $game_data['period_of_recurrent']!='')
		{
			$this->form_validation->set_rules('period_of_recurrent_value', $this->lang->line('period_of_recurrent_value'), 'trim|required|greater_than[0]');
		}
		if(isset($game_data['no_of_game']) && $game_data['no_of_game']!="" && $game_data['no_of_game']!=0)
		{
			$this->form_validation->set_rules('auto_recurrent_stop_type', $this->lang->line('auto_recurrent_stop_type'), 'trim|required');
			$this->form_validation->set_rules('auto_recurrent_stop_value', $this->lang->line('auto_recurrent_stop_value'), 'trim|required|greater_than[0]');			
		}
		
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$main_game_data = $this->Contest_model->get_game_detail($game_data['contest_unique_id']);
		
		$week_month = $this->Contest_model->get_all_season_month_and_week($game_data['league_id']);

		if($game_data['period_of_recurrent']==2)
		{
			$week = $week_month['end_week'] -  $main_game_data['season_week'];
			if($week <= $game_data['period_of_recurrent_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		elseif($game_data['period_of_recurrent']==3)
		{
			$month = $week_month['end_month'] - date("m", strtotime(format_date()));
			if($month <= $game_data['period_of_recurrent_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}

		if($game_data['auto_recurrent_stop_type']!=4 && $game_data['auto_recurrent_stop_type']!='' && $game_data["period_of_recurrent"] == '')
		{			
			$start_date = new DateTime(format_date());

			$time = explode(" ", $main_game_data['season_scheduled_date']);
			if($time[1]=='00:00:00')
			{
				$contest_time = $time[0]." 23:59:00"; /*This for when time is 00:00:00 then create issue*/
			}
			else
			{
				$contest_time = $main_game_data['season_scheduled_date'];
			}
			
			$since_start = $start_date->diff(new DateTime($contest_time));

			if($game_data['auto_recurrent_stop_type'] == 1 && $since_start->days == 0  && $since_start->h == 0 && $since_start->i < $game_data['auto_recurrent_stop_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			elseif($game_data['auto_recurrent_stop_type'] == 2 && $since_start->days == 0 && $since_start->h < $game_data['auto_recurrent_stop_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			elseif($game_data['auto_recurrent_stop_type'] == 3 && $since_start->days < $game_data['auto_recurrent_stop_value'])
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_auto_reucrrent_duration')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}

		$period_value = (!empty($game_data['period_of_recurrent_value'])) ? $game_data['period_of_recurrent_value'] : 0; 
		$period_type = $game_data['period_of_recurrent']!="" ? $game_data['period_of_recurrent'] : 0;
		$update_data_array = array(
			"period_type"				=> "$period_type",
			"period_value"				=> $period_value,
			"period_stop_type"			=> $game_data['auto_recurrent_stop_type'],
			"period_stop_value"			=> $game_data['auto_recurrent_stop_value'],
			"no_of_game"				=> $game_data["no_of_game"],
			"modified_date"				=> format_date(),
		);

		$is_updated = $this->Contest_model->update_auto_recurrent_contest($update_data_array,array('auto_recurrent_id'=>$game_data['auto_recurrent_id']));
		if($is_updated){
			$result['auto_recc_data'] = $this->Contest_model->get_auto_recurring_contest_detail($game_data['auto_recurrent_id']);
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('contest_updated_successfully'),'data'=>$result), rest_controller::HTTP_OK);
		} else {
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}


	}
	/*public function _invite_users($invite_array)
	{
		$invite_users_emails = array();
		$invite_emails = array();
		if(!empty($invite_array['invite_users'])&&isset($invite_array['invite_users']))
		{
			$result = $this->Contest_model->get_all_email_by_user_id($invite_array['invite_users']);
			foreach ($result as $rs) 
			{
				$invite_users_emails[] =  array("email" => $rs['email'],"user_id"=>$rs['user_id']);
			}
		}
		if(!empty($invite_array['invite_emails'])&&isset($invite_array['invite_emails']))
		{
			$invite_email_temp = explode(',', $invite_array['invite_emails']);
			$result = $this->Contest_model->get_all_user_id_by_email($invite_array['invite_emails']);
			foreach ($result as $rs) 
			{
				$invite_emails[] = array("email"=>$rs['email'],"user_id"=>$rs['user_id']);
			}
			$email = array_column($invite_emails,'email');
			$invite_email_temp = array_diff($invite_email_temp, $email);
			foreach($invite_email_temp as $rs)
			{
				$invite_emails[] = array("email"=>$rs,"user_id"=>0);
			}
		}
		$invite_users_temp = unique_multidim_array(array_merge($invite_users_emails, $invite_emails),'email');
		$invite_users_array = array();
		foreach($invite_users_temp as $rs)
		{
			$rs['game_unique_id'] = $invite_array['game_unique_id'];
			$rs['message'] = "Game Invite";
			$rs['invite_from'] = 0;
			$rs['status'] = 1;
			$rs['created_date'] = format_date();
			$invite_users_array[] = $rs;
		}
		if(count($invite_users_array)>0)
		{
			$this->Contest_model->replace_into_batch(INVITE,$invite_users_array);
		}
	}*/
	public function contest_list_post()
	{
		$data_arr = $this->input->post();
		$result = $this->Contest_model->contest_list($data_arr);
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_game_detail_post()
	{
		$game_unique_id = $this->input->post('game_unique_id');
		$result = $this->Contest_model->get_game_detail($game_unique_id);

		if(!empty($result['auto_recurrent_id'])){
			//$result['auto_recc_data'] = $this->Contest_model->get_auto_recurring_contest_detail($result['auto_recurrent_id']);
		} else {
			$result['auto_recc_data'] = '';	
		}
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_game_lineup_detail_post()
	{
		$result = $this->Contest_model->get_lineup_users_by_game();
		$scoring = $this->Contest_model->show_winning_amount_weekly();
		
		$result['prize_selection'] = $scoring;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_lineup_detail_post()
	{
		$lineup_master_id = $this->input->post('lineup_master_id');
		$league_id = $this->input->post('league_id');
		$result = $this->Contest_model->get_lineup_detail($lineup_master_id,$league_id);
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_player_last_salaries_post()
	{
		$player_salary_master_id = $this->input->post('player_salary_master_id');
		$league_id = $this->input->post('league_id');
		$result = $this->Contest_model->get_all_player_last_salaries($player_salary_master_id, $league_id);
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_player_scoring_post()
	{
		$league_id = $this->input->post('league_id');
		$contest_unique_id = $this->input->post('contest_unique_id');
		$player_salary_master_id = $this->input->post('player_salary_master_id');
		$player_uid = $this->input->post('player_uid');
		$sports_id = $this->input->post('sport_id');

		$result = $this->Contest_model->get_roster_score($contest_unique_id,$player_uid,$league_id,$player_salary_master_id,$sports_id);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_user_by_key_post() 
	{
		$search_key = $this->input->post('search_key');
		$user_ids = $this->input->post('ids');
		$result['data'] = $this->Contest_model->get_all_user_by_key($search_key,$user_ids);
		
		$this->response($result);
	}

	public function change_contest_name_post()
	{
		$post_data =  $this->input->post();
		$result = $this->Contest_model->change_contest_name($post_data);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('successfully_update_name')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function remove_contest_post()
	{
		$contest_unique_id =  $this->input->post("contest_unique_id");
		$result = $this->Contest_model->remove_contest($contest_unique_id);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('successfully_remove_contest')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('contest_not_deleted')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	// get custom weekly game list
	public function get_custom_weekes_post()
	{
		$result = TRUE;
		$game_list = $this->Contest_model->get_all_custome_weeks_game();
		
		@$home = array_column($game_list, 'home');
		@$away = array_column($game_list, 'away');

		if (!is_array($home))
			$home = array();

		if (!is_array($away))
			$away = array();

		$home_away = array_merge($home, $away);
		$home_away = array_unique($home_away);

		if (!$game_list)
			$game_list = array();

		$response['game_list'] = $game_list;
		$response['result'] = $result;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$response) , rest_controller::HTTP_OK);
		

	}	

	public function do_upload_post(){
		
		
		$file_field_name	= $this->post('name');
		$dir				= ROOT_PATH.UPLOAD_DIR;
		$subdir				= ROOT_PATH.FEATURE_CONTEST_DIR;
		$temp_file			= $_FILES['file']['tmp_name'];
		$ext				= pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		$vals = 			@getimagesize($temp_file);
		$width = $vals[0];
		$height = $vals[1];
		if ($height != '140' || $width != '325') {
			$invalid_size = str_replace("{max_height}",'140',$this->lang->line('ad_image_invalid_size'));
			$invalid_size = str_replace("{max_width}",'325',$invalid_size);
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$invalid_size) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}

		if( strtolower( IMAGE_SERVER ) == 'local')
		{
			$this->check_folder_exist($dir);
			$this->check_folder_exist($subdir);
		}

		$file_name = time().".".$ext ;

		/*--Start amazon server upload code--*/
		if( strtolower( IMAGE_SERVER ) == 'remote' )
		{
			$this->load->library( 'S3' );

			//if upload on s3 is enabled
			//instantiate the class

			$s3           = new S3( AWS_ACCESS_KEY , AWS_SECRET_KEY );
			$filePath     = FEATURE_CONTEST_DIR.$file_name;
			$is_s3_upload = $s3->putObjectFile($temp_file, BUCKET, $filePath, S3::ACL_PUBLIC_READ);

			if ( $is_s3_upload )
			{ 
				$data = array( 'image_name' => IMAGE_PATH.$filePath ,'image_url'=> IMAGE_PATH.$filePath);
				$this->response(array(config_item('rest_status_field_name')=>TRUE,'data'=>$data) , rest_controller::HTTP_OK);

			} else {
				$error = $this->lang->line('image_upload_error');
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			/*--End amazon server upload code--*/
		} else {

			$config['allowed_types']	= 'jpg|png|jpeg|gif';
			$config['max_size']			= '5000';
			$config['max_width']		= '325';
			$config['max_height']		= '140';
			$config['upload_path']		= $subdir;
			$config['file_name']		= time();

			$this->load->library('upload', $config);
			if ( ! $this->upload->do_upload('file'))
			{
				$error = $this->upload->display_errors();
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			else
			{

				$upload_data = $this->upload->data();
				$this->response(
						array(
								config_item('rest_status_field_name')=>TRUE,
								'data'=>array('image_name' =>IMAGE_PATH.FEATURE_CONTEST_DIR.$file_name ,'image_url'=> $subdir),
								rest_controller::HTTP_OK
							)
						);
			}
		}	
	
	}

	/**
	* @Summary: check if folder exists otherwise create new
	* @create_date: 24 july, 2015
	*/
	private function check_folder_exist($dir)
	{
		
		if(!is_dir($dir))
			return mkdir($dir, 0777);
		return TRUE;
	}
}

/* End of file Contest.php */
/* Location: ./application/controllers/Contest.php */