<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Bonus_code extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Bonuscode_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function new_bonus_code_post()
	{
		$this->form_validation->set_rules('discount', 'Discount', 'trim|required|max_length[2]');
		$this->form_validation->set_rules('expiry_date', 'Expiry Date', 'trim|required');
		$this->form_validation->set_rules('bonus_code', 'Promo Code', 'trim|required');
		$this->form_validation->set_rules('start_date', 'Start Date', 'trim|required');
		$this->form_validation->set_rules('bonus_name', 'Name of bonus code', 'trim|required');
		$this->form_validation->set_rules('cycle', 'Cycle', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$post_data = $this->input->post();
		$bonus_code_detail = $this->Bonuscode_model->get_bonus_code_by_id($post_data['bonus_code']);
		if(!empty($bonus_code_detail))
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('already_exists')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		$data_array = array(
				"bonus_code"	=> $post_data['bonus_code'],
				"start_date"	=> $post_data['start_date'],
				"expiry_date"	=> $post_data['expiry_date'],
				"discount"		=> $post_data['discount'],
				"cycle"			=> $post_data['cycle'],
				"bonus_name"	=> $post_data['bonus_name'],
				"status"		=> '1',
				"added_date"	=> date('Y-m-d H:i:s')
			);

		if($this->input->post('benefit_cap'))
		{
			$data_array['benefit_cap'] = $this->input->post('benefit_cap');
		}

		$result = $this->Bonuscode_model->new_promo_code($data_array);

		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('create_bonus_code')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}


	public function get_bonus_codes_post()
	{
		$result = $this->Bonuscode_model->get_bonus_codes();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_bonus_code_detail_post()
	{
		$result = $this->Bonuscode_model->get_bonus_code_detail();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_user_by_key_post() 
	{
		$search_key = $this->input->post('search_key');
		$result['data'] = $this->Bonuscode_model->get_all_user_by_key($search_key);
		
		$this->response($result);
	}	
}

/* End of file Promo_code.php */
/* Location: ./application/controllers/Promo_code.php */