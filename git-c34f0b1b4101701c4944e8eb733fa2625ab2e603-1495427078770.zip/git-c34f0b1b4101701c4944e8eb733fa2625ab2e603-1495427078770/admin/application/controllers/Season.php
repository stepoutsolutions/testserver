<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Season extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Season_model');
		//Do your magic here
	}

	public function get_all_season_schedule_post()
	{
		$result = $this->Season_model->get_all_season_schedule();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_league_post()
	{
		$result = $this->Season_model->get_all_league();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_team_post()
	{
		$league_id  = $this->input->post('league_id');

		$result = $this->Season_model->get_all_team($league_id);
		$records[0]['team_abbreviation'] = "all";
		$records[0]['team_name'] = "All Team";
		$records = array_merge($records, $result);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$records) , rest_controller::HTTP_OK);
	}

	public function get_all_week_post()
	{
		$league_id  = $this->input->post('league_id');

		$result = $this->Season_model->get_all_week($league_id);
		$records[0]['week'] = "all";
		$records[0]['season_week'] = "All Week";
		$records = array_merge($records, $result);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$records) , rest_controller::HTTP_OK);
	}

	public function get_season_stats_post()
	{
		$this->form_validation->set_rules('league_id', 'League Id', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		
		$result = $this->Season_model->get_all_season_stats();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}
}
/* End of file Season.php */
/* Location: ./application/controllers/Season.php */