<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Withdrawal extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Withdrawal_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_withdrawal_request_post()
	{
		$result = $this->Withdrawal_model->get_all_withdrawal_request();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}



	public function change_withdrawal_status_post()
	{
		$this->form_validation->set_rules('order_id', 'Payment Withdraw Id', 'trim|required');
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		if(!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$result = $this->Withdrawal_model->change_withdrawal_status($this->input->post());
		if($result)
		{
			$order_id = $this->input->post('order_id');
			$withraw_info = $this->Withdrawal_model->get_single_withdraw_request($order_id);

			if($withraw_info){
				$user_id 		= $withraw_info['user_id'];
				$user_language  = (!empty($withraw_info['language'])) ? $withraw_info['language'] : $this->config->item('language');
				//if status is reject then credit requested amount back to user balance 
				$status = $this->input->post('status');
				if($status == 2){
					$update_balance_arr = array(
						'balance' 			=> $withraw_info['real_amount'] + $withraw_info['balance'],
						'winning_balance'   => $withraw_info['winning_amount'] + $withraw_info['winning_balance']
					);
					$this->Withdrawal_model->update_user_balance($update_balance_arr,array('user_id'=>$user_id));
				}

				//add an entry into user notification table
				$notification_type = ($status == 1) ? NOTIFY_WITHDRAW_APPROVE : NOTIFY_WITHDRAW_REJECT;//6 for request reject and 7 for approve.
				$this->Withdrawal_model->add_notification($notification_type,'0',$user_id,'');
				$email_action = ($status == 1) ? 'Approved' : 'Rejected'; 
				//send email regarding withdrawal request to user's email
				$data['status'] 		= $status;
				$data['full_name']		= $withraw_info['full_name'];
				$data['email']			= $withraw_info['email'];
				$data['user_language']  = $user_language;
				$data['amount'] 		= $withraw_info['amount'];
				$data['message'] 		= str_replace("{action}", $email_action, $this->lang->line('withdrawal_request_message_'.$user_language));
				$data['message']    = str_replace("{withdrawal_amount}", $withraw_info['amount'],$data['message']);
				$message			= $this->load->view('emailer/withdrawal_request',$data,true);
				$to					= $withraw_info['email'];
				$subject			= str_replace("{action}", $email_action,$this->lang->line('withdrawal_request_subject_'.$user_language));;
				$message			= $message;
				$this->send_email($to,$subject,$message);
			}
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function get_filter_data_post()
	{
		$withdrawal_type = array(
							//	"Paypal"		=> "1",
							//	"Live Cheque"	=> "2"
							);
		$withdrawal_status = array(
									"Pending"	=> "0",
									"Approved"	=> "1",
									"Rejected"	=> "2"
								);
		$result = array('withdrawal_type'=>$withdrawal_type,'withdrawal_status'=>$withdrawal_status);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

}
/* End of file Withdrawal.php */
/* Location: ./application/controllers/Withdrawal.php */