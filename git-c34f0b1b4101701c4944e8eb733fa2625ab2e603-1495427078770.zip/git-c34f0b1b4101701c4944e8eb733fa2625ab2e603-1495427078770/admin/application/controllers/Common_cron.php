<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Common_cron extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model("Contest_model");
	}

	public function auto_recurrent_contest()
	{
		$auto_recurrent_contest = $this->Contest_model->get_all_auto_recurrent_contest();
		// echo "<pre>";print_r($auto_recurrent_contest);die;
		foreach ($auto_recurrent_contest as $contest)
		{
			// echo "<pre>";print_r($contest);die;
			$contest_detail = $this->Contest_model->get_auto_recurrent_last_contest($contest['auto_recurrent_id']);
			
				// echo "<pre>";print_r($contest_detail);die;
			// echo $contest['period_type'];
			if($contest['period_type']==0 && $contest_detail['size'] == $contest_detail['total_user_joined'])
			{
				$no_of_game = $this->Contest_model->get_all_contest_by_auto_re_id($contest['auto_recurrent_id'], format_date());
				if($no_of_game < $contest['no_of_game'])
				{
					$start_date = new DateTime(format_date());
					$time = explode(" ", $contest['season_scheduled_date']);
					if($time[1]=='00:00:00')
					{
						$contest_time = $time[0]." 23:59:00"; /*This for when time is 00:00:00 then create issue*/
					}
					else
					{
						$contest_time = $contest['season_scheduled_date'];
					}
					$since_start = $start_date->diff(new DateTime($contest_time));
					$period_stop_value = $contest['period_stop_value'];

					if( $contest['period_stop_type'] == 1)
					{
						
						if($since_start->days >= 1 || $since_start->h >= 1)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						elseif ($since_start->i >= $period_stop_value)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						else
						{
							$this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
						}
					}
					elseif($contest['period_stop_type']==2)// 2 = Hours
					{
						if($since_start->days >= 1)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						elseif ($since_start->h >= $period_stop_value)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						else
						{	
							$this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
						}
					}
					elseif($contest['period_stop_type']==3)// 3 =  Days
					{
						if ($since_start->days >= $period_stop_value)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						else
						{
							echo "else contdition";die;
							// $this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
						}
							
					}
					elseif($contest['period_stop_type']==4) // 4 = Never
					{
						$this->create_auto_recurrent_contest($contest);
					}
				}
				elseif($contest['no_of_game']==0)
				{
					if(format_date() < $contest['season_scheduled_date'])
						$this->create_auto_recurrent_contest($contest);
					else
						$this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
				}
				else
				{
					$this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
				}
			}/*End period_type = 0 */
			elseif($contest['period_type']==1 && ($contest_detail['size'] == $contest_detail['total_user_joined'] OR $contest['is_uncapped']))
			{
				if($contest_detail['season_scheduled_date'] > format_date() && $contest_detail['is_uncapped']=='0')
				{
					$contest['selected_matches']	= $contest_detail['selected_matches'];
					$contest['season_week']				= $contest_detail['season_week'];
					$contest['season_scheduled_date']	= $contest_detail['season_scheduled_date'];
				}
				else if($contest_detail['season_scheduled_date'] < format_date())
				{
					if($contest['league_duration_id']==1)//Daily
					{
						$days = date("D",strtotime($contest_detail['season_scheduled_date']));
						$season_match_date = date("Y-m-d H:i:s",strtotime(format_date().'next '.$days));
						$game_detail = $this->get_all_weekly_daily_matches($contest['league_id'], $contest['league_duration_id'], $season_match_date, "");
						
						if(empty($game_detail))
						{
							continue;
						}
					}
					else // Weekly
					{
						$season_week = $contest_detail['season_week'] + 1; 
						$game_detail = $this->get_all_weekly_daily_matches($contest['league_id'], $contest['league_duration_id'], "", $season_week);
					}
					$contest['selected_matches']		= $game_detail['selected_matches'];
					$contest['season_week']				= $game_detail['season_week'];
					$contest['season_scheduled_date']	= $game_detail['season_scheduled_date'];

					$contest_count = count(explode(',', $contest['selected_matches']));
					if($contest_count<2)
					{
						continue;
					}
				}
				else
				{
					continue;
				}
				$no_of_game = $this->Contest_model->get_all_contest_by_auto_re_id($contest['auto_recurrent_id'], format_date());
				
				if($no_of_game < $contest['no_of_game'])
				{
					$start_date = new DateTime(format_date());
					$time = explode(" ", $contest['season_scheduled_date']);
					if($time[1]=='00:00:00')
					{
						$contest_time = $time[0]." 23:59:00"; /*This for when time is 00:00:00 then create issue*/
					}
					else
					{
						$contest_time = $contest['season_scheduled_date'];
					}
					$since_start = $start_date->diff(new DateTime($contest_time));
					
					$period_stop_value = $contest['period_stop_value'];

					if($contest['period_stop_type'] == 1)
					{
						if($since_start->days >= 1 || $since_start->h >= 1)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						elseif ($since_start->i >= $period_stop_value)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						else
						{
							continue;
						}
					}
					elseif($contest['period_stop_type']==2)// 2 = Hours
					{
						if($since_start->days >= 1)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						elseif ($since_start->h >= $period_stop_value)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						else
						{	
							continue;
						}
					}
					elseif($contest['period_stop_type']==3)// 3 =  Days
					{
						if ($since_start->days >= $period_stop_value)
						{
							$this->create_auto_recurrent_contest($contest);
						}
						else
						{
							continue;
						}
							
					}
					elseif($contest['period_stop_type']==4) // 4 = Never
					{
						$this->create_auto_recurrent_contest($contest);
					}
				}
				elseif($contest['no_of_game']==0)
				{
					if(format_date() < $contest['season_scheduled_date'])
						$this->create_auto_recurrent_contest($contest);
					else
						continue;
				}
				else
				{
					continue;
				}
			}/*End period_type = 1  Whole League */
			elseif($contest['period_type']==2 &&  ($contest_detail['size'] == $contest_detail['total_user_joined'] OR $contest['is_uncapped']))
			{
				if($contest_detail['season_scheduled_date'] >= format_date() && $contest_detail['is_uncapped']=='0')
				{	
					$contest['selected_matches']	= $contest_detail['selected_matches'];
					$contest['season_week']				= $contest_detail['season_week'];
					$contest['season_scheduled_date']	= $contest_detail['season_scheduled_date'];
				}
				else if($contest_detail['season_scheduled_date'] < format_date())
				{ 
					if($contest['league_duration_id']==1)//Daily
					{
						$days = date("D",strtotime($contest_detail['season_scheduled_date']));
						$season_match_date = date("Y-m-d H:i:s",strtotime(format_date().'next '.$days));
						$game_detail = $this->get_all_weekly_daily_matches($contest['league_id'], $contest['league_duration_id'], $season_match_date, "");
						
						if(empty($game_detail))
						{
							continue;
						}
					}
					else // Weekly
					{
						$season_week = $contest_detail['season_week'] + 1;
						$game_detail = $this->get_all_weekly_daily_matches($contest['league_id'], $contest['league_duration_id'], "", $season_week);
					}
					
					$contest['selected_matches']		= $game_detail['selected_matches'];
					$contest['season_week']				= $game_detail['season_week'];
					$contest['season_scheduled_date']	= $game_detail['season_scheduled_date'];

					$contest_count = count(explode(',', $contest['selected_matches']));
					if($contest_count<2)
					{
						continue;
					}
				}
				else
				{
					continue;
				}
				
				
				$week_month = $this->Contest_model->get_all_season_month_and_week($contest['league_id']);
				$week = $week_month['end_week'] - $contest['season_week'];
				if($week >= $contest['period_value'])
				{
					$no_of_game = $this->Contest_model->get_all_contest_by_auto_re_id($contest['auto_recurrent_id'], format_date());
					if($no_of_game < $contest['no_of_game'])
					{
						$start_date = new DateTime(format_date());
						$time = explode(" ", $contest['season_scheduled_date']);
						if($time[1]=='00:00:00')
						{
							$contest_time = $time[0]." 23:59:00"; /*This for when time is 00:00:00 then create issue*/
						}
						else
						{
							$contest_time = $contest['season_scheduled_date'];
						}
						$since_start = $start_date->diff(new DateTime($contest_time));
						
						$period_stop_value = $contest['period_stop_value'];

						if($contest['period_stop_type'] == 1)
						{
							if($since_start->days >= 1 || $since_start->h >= 1)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							elseif ($since_start->i >= $period_stop_value)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							else
							{
								continue;
							}
						}
						elseif($contest['period_stop_type']==2)// 2 = Hours
						{
							if($since_start->days >= 1)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							elseif ($since_start->h >= $period_stop_value)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							else
							{	
								continue;
							}
						}
						elseif($contest['period_stop_type']==3)// 3 =  Days
						{
							if ($since_start->days >= $period_stop_value)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							else
							{
								continue;
							}
								
						}
						elseif($contest['period_stop_type']==4) // 4 = Never
						{
							$this->create_auto_recurrent_contest($contest);
						}
					}
					elseif($contest['no_of_game']==0)
					{
						if(format_date() < $contest['season_scheduled_date'])
							$this->create_auto_recurrent_contest($contest);
						else
							continue;
					}
					else
					{
						continue;
					}
				}
				else
				{
					$this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
				}
			}/*End period_type = 2  Week */
			elseif($contest['period_type']==3 &&  ($contest_detail['size'] == $contest_detail['total_user_joined'] OR $contest['is_uncapped']))
			{
				if($contest_detail['season_scheduled_date'] > format_date() && $contest_detail['is_uncapped']=='0')
				{ 
					$contest['selected_matches']		= $contest_detail['selected_matches'];
					$contest['season_week']				= $contest_detail['season_week'];
					$contest['season_scheduled_date']	= $contest_detail['season_scheduled_date'];
				}
				else if($contest_detail['season_scheduled_date'] < format_date())
				{ 
					if($contest['league_duration_id']==1)//Daily
					{
						$days = date("D",strtotime($contest_detail['season_scheduled_date']));
						$season_match_date = date("Y-m-d H:i:s",strtotime(format_date().'next '.$days));
						$game_detail = $this->get_all_weekly_daily_matches($contest['league_id'], $contest['league_duration_id'], $season_match_date, "");
						
						if(empty($game_detail))
						{
							continue;
						}
					}
					else // Weekly
					{
						$season_week = $contest_detail['season_week'] + 1;
						$game_detail = $this->get_all_weekly_daily_matches($contest['league_id'], $contest['league_duration_id'], "", $season_week);
					}
					$contest['selected_matches']		= $game_detail['selected_matches'];
					$contest['season_week']				= $game_detail['season_week'];
					$contest['season_scheduled_date']	= $game_detail['season_scheduled_date'];
					
					$contest_count = count(explode(',', $contest['selected_matches']));
					if($contest_count<2)
					{
						continue;
					}
				}
				else
				{
					continue;
				}
				
				$week_month = $this->Contest_model->get_all_season_month_and_week($contest['league_id']);
				$week = $week_month['end_week'] - $contest['season_week'];
				$month = $week_month['end_month'] - date("m", strtotime(format_date()));			
				if($month >= $contest['period_value'])
				{
					$no_of_game = $this->Contest_model->get_all_contest_by_auto_re_id($contest['auto_recurrent_id']);
					if($no_of_game < $contest['no_of_game'])
					{
						$start_date = new DateTime(format_date());
						$time = explode(" ", $contest['season_scheduled_date']);
						if($time[1]=='00:00:00')
						{
							$contest_time = $time[0]." 23:59:00"; /*This for when time is 00:00:00 then create issue*/
						}
						else
						{
							$contest_time = $contest['season_scheduled_date'];
						}
						$since_start = $start_date->diff(new DateTime($contest_time));
						
						$period_stop_value = $contest['period_stop_value'];

						if($contest['period_stop_type'] == 1)
						{
							if($since_start->days >= 1 || $since_start->h >= 1)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							elseif ($since_start->i >= $period_stop_value)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							else
							{
								continue;
							}
						}
						elseif($contest['period_stop_type']==2)// 2 = Hours
						{
							if($since_start->days >= 1)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							elseif ($since_start->h >= $period_stop_value)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							else
							{	
								continue;
							}
						}
						elseif($contest['period_stop_type']==3)// 3 =  Days
						{
							if ($since_start->days >= $period_stop_value)
							{
								$this->create_auto_recurrent_contest($contest);
							}
							else
							{
								continue;
							}
								
						}
						elseif($contest['period_stop_type']==4) // 4 = Never
						{
							$this->create_auto_recurrent_contest($contest);
						}
					}
					elseif($contest['no_of_game']==0)
					{
						if(format_date() < $contest['season_scheduled_date'])
							$this->create_auto_recurrent_contest($contest);
						else
							continue;
					}
					else
					{
						continue;
					}
				}
				else
				{
					$this->Contest_model->change_auto_recurrent_status($contest['auto_recurrent_id']);
				}
			}/*End period_type = 2  Month */
		}
	}

	public function create_auto_recurrent_contest($game_data)
	{		
		$is_feature			= $game_data['is_feature'];
		$is_uncapped		= $game_data['is_uncapped'];
		$guaranteed_prize	= '0';
		$player_salary_master_data = $this->Contest_model->get_player_salary_master($game_data['league_id']);
		$game_data['game_unique_id'] = random_string('alnum', 9);
		$data_array = array(
						"contest_unique_id"				=> $game_data['game_unique_id'],
						"player_salary_master_id"		=> $player_salary_master_data['player_salary_master_id'],
						"contest_name"					=> $game_data['contest_name'],
						"league_id"						=> $game_data['league_id'],
						"league_duration_id"			=> $game_data['league_duration_id'],
						"season_scheduled_date"			=> $game_data['season_scheduled_date'],
						"league_drafting_styles_id"		=> $game_data['league_drafting_styles_id'],
						"season_week"					=> $game_data['season_week'],
						"league_salary_cap_id"			=> $game_data['league_salary_cap_id'],
						"size"							=> $game_data['size'],
						"minimum_size"					=> $game_data['minimum_size'],
						"is_feature"					=> "$is_feature",
						"is_uncapped"					=> "$is_uncapped",
						"feature_image"					=> $game_data['feature_image'],
						"entry_fee"						=> $game_data['entry_fee'],
						"prize_pool"					=> $game_data['prize_pool'],
						"league_contest_type_id"		=> $game_data['league_contest_type_id'],
						"selected_matches"				=> $game_data['selected_matches'],
						"disable_auto_cancel"			=> $game_data['disable_auto_cancel'],
						"site_rake"						=> $game_data['site_rake'],
						"guaranteed_prize"				=> "$guaranteed_prize",
						"contest_access_type"			=> "0",
						"auto_recurrent_id"				=> $game_data['auto_recurrent_id'],
						"contest_type"					=> $game_data['contest_type'],
						"added_date"					=> format_date()
					);
		$game_id = $this->Contest_model->save_contest($data_array);	
	}

	public function get_all_contest_data_post($league_id )
	{
		$seasons_dates		= $this->Contest_model->get_season_date($league_id);
		$all_available_week	= $this->Contest_model->get_all_available_week($league_id);
		$data_array = array(
				"seasons_dates"=>$seasons_dates,
				"all_available_week"=>$all_available_week,
			);
		return $data_array;
	}

	public function get_all_weekly_daily_matches($league_id,$league_duration_id,$season_scheduled_date="",$season_week="")
	{
		$data_arr = array(
							"league_id" => $league_id,
							"league_duration_id" => $league_duration_id
						);
		if($league_duration_id==1)
		{
			$data_arr['season_scheduled_date'] = $season_scheduled_date;
		}
		else
		{
			$data_arr['season_week'] = $season_week;
		}

		$game_list = $this->Contest_model->get_available_game_of_the_day_or_week($data_arr);		
		$game_list = array_column($game_list, 'season_game_unique_id');
		$data_array = array();
		if(!empty($game_list))
		{
			$list_game_date_wise = $this->Contest_model->get_list_game_date_wise($game_list, $league_id);

			foreach ($list_game_date_wise as $key => $value)
			{
				$list_of_games[] = $value['season_game_unique_id'];
			}
			
			$data_array['selected_matches'] = implode(',', $list_of_games);
			$data_array['season_scheduled_date'] = $this->Contest_model->get_season_scheduled_date($list_of_games[0], $league_id);
			$data_array['season_week'] = $this->Contest_model->get_current_week($league_id, $data_array['season_scheduled_date']);
		}
		return $data_array;
	}
}