<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Setting_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function change_password_post()
	{
		$this->form_validation->set_rules('old_password', 'Old Password', 'trim|required');
		$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|matches[confirm_password]|min_length[5]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|min_length[5]');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$data_arr = $this->input->post();

		$result = $this->Setting_model->chnage_password($data_arr);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('change_password_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('change_password_error')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);	
		}
	}

	public function change_date_time_post()
	{
		$date = '';
		$this->load->helper( 'file' );
		if ($this->input->post("date"))
		{
			$date = date("Y-m-d H:i:s", strtotime($this->input->post("date")));
		}
		$date_time = '';

		if ( $date )
			$date_time = $date;

		$path = ROOT_PATH.'date_time.php';
		$data = '<?php $date_time = "'.$date_time.'";';

		write_file($path, $data);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>"Update date time successfully") , rest_controller::HTTP_OK);
	}

	public function update_referral_amount_post()
	{	
		$this->form_validation->set_rules('referral_discount', 'Referral Discount', 'trim|required');
		$this->form_validation->set_rules('referral_threshold_amount', 'Referral Threshold Amount', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$data_arr =  $this->input->post();
		$result = $this->load->Setting_model->update_referral_amount($data_arr);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>"referral setting updated successfully.") , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function get_referral_amount_post()
	{
		$result = $this->load->Setting_model->get_referral_current_amount();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_referrals_post()
	{
		$result = $this->Setting_model->get_all_referrals();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_payment_setting_post()
	{
		$result = $this->load->Setting_model->get_payment_setting();
		$result['payment_config'] = $this->load->Setting_model->get_payment_config();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function update_payment_setting_post()
	{	
		$post_data = $this->input->post();
		if(empty($post_data)){
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		$config_array = array();
		$count = 0;
		$payment_config_array = $this->lang->line('payment_config_array');
		foreach ($post_data as $key => $value) {
		    $this->form_validation->set_rules($key, $payment_config_array[$key], 'trim|required');
			$config_array[$count]['update_array'] = array('meta_value'=>$value,'modified_date'=>format_date());
			$config_array[$count]['where_array']  = array('meta_key'=>$key);
			$count++;
		}
		if(!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$result = $this->load->Setting_model->update_payment_config($config_array);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>"Payment setting updated successfully.") , rest_controller::HTTP_OK);
	}//function end.

	public function get_signup_bonus_post()
	{
		$result = $this->load->Setting_model->get_singup_bonus_data();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
		
	}

	public function update_signup_bonus_post()
	{
		$post_data = $this->input->post();
		if(empty($post_data)){
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}

		$update_arr = array(
			'signup_bonus_amount' => (isset($post_data['signup_bonus_amount'])) ? $post_data['signup_bonus_amount'] : 10,
		);
		$update_cond = array(
			'signup_bonus_id' => $post_data['signup_bonus_id']
		);
		$result = $this->load->Setting_model->update_signup_bonus_data($update_arr,$update_cond);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>"Signup bonus amount updated successfully.") , rest_controller::HTTP_OK);


	}


}

/* End of file Setting.php */
/* Location: ./application/controllers/Setting.php */