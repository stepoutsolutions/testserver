<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Report_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_user_report_post()
	{
		$result = $this->Report_model->get_all_user_report();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_contest_report_post()
	{
		$result = $this->Report_model->get_all_contest_report();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_contest_users_report_post()
	{
		$result = $this->Report_model->get_all_contest_users_report();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}


	//functions for user location section under reporting 
	public function userlocation_post()
	{
		$result = $this->Report_model->get_all_userlocation();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_userlocation_filter_data_post()
	{
		$country = $this->Report_model->get_all_country();
		$state 	 = $this->Report_model->get_all_state();
		
		
		$result['country']		= $country;
		$result['state']		= $state;
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result), rest_controller::HTTP_OK);
	}

	public function get_state_by_country_post()
	{
		//$this->load->model('User_model');
		$master_country_id = $this->input->post('master_country_id') ?: '';
		if($master_country_id!='')
		{
			$data['state'] = $this->Report_model->get_all_state_by_country($master_country_id);

			if($data)
			{
				$response 		= array(
								config_item('rest_status_field_name')=>TRUE,
								'data'	=> $data 
								);
				$this->response($response, rest_controller::HTTP_OK);
			}
			else
			{
				$response 		= array(
								config_item('rest_status_field_name')=>FALSE,
								'error'	=> 'State not found' 
								);
				$this->response($response, rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$response 		= array(
								config_item('rest_status_field_name')=>FALSE,
								'error'	=> 'Please select country' 
								);
				$this->response($response, rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	//Functions for user activity report under reporing section
	public function useractivity_post()
	{
	  $result = $this->Report_model->get_all_useractivity();
	  $this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_report_money_paid_by_user_post()
	{
		$result = $this->Report_model->get_report_money_paid_by_user();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_deposit_amount_filter_data_post()
	{		
		$result = array("paypal"=>"Paypal","astropay"=>"Astropay");
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result), rest_controller::HTTP_OK);
	}

	public function get_report_user_deposit_amount_post()
	{
		$result = $this->Report_model->get_report_user_deposit_amount();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}


}

/* End of file Report.php */
/* Location: ./application/controllers/Report.php */