<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Roster extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Roster_model');
		//Do your magic here
	}

	public function get_all_league_post()
	{
		$result = $this->Roster_model->get_all_league();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_position_post()
	{
		$league_id  = $this->input->post('league_id');

		$result = $this->Roster_model->get_all_position($league_id);
		$records[0]['position_name'] = "All Position";
		$records[0]['position'] = "all";
		$records = array_merge($records,$result);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$records) , rest_controller::HTTP_OK);
	}

	public function get_all_team_post()
	{
		$league_id  = $this->input->post('league_id');

		$result = $this->Roster_model->get_all_team($league_id);
		//$records = array_merge($records,$result);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}
        
        public function get_all_roster_category_post() {
            $league_id = $this->input->post('league_id');
            
            $result = $this->Roster_model->get_all_roster_category($league_id);
//            $records = array();
//            if (!empty($league_id)) {
//                $records[0]['lineup_category_value'] = "all";
//                $records[0]['lineup_category_id'] = 0;
//                $records[0]['lineup_category'] = "All Category";
//            }
//            $records = array_merge($records, $result);
            $this->response(array(config_item('rest_status_field_name') => TRUE, 'data' => $result), rest_controller::HTTP_OK);
        }

	public function get_all_roster_post()
	{
		$result = $this->Roster_model->get_all_rosters();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function update_roster_post()
	{
		$this->form_validation->set_rules('league_id', 'League Id', 'trim|required');
		$action = $this->input->post('action');
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		
		$re_salary = 0;
		$re_injury = 0;
		$re_status = 0;
		
		$salary			= $this->input->post('salary');
		$injury			= $this->input->post('injury');
		$status			= $this->input->post('action');
		$players		= $this->input->post('player_team_id');
		$league_id		= $this->input->post('league_id');
		$category_id	= $this->input->post('category_id');
		$player_salary	= array();

		if(!empty($salary))
		{
			foreach($players as $key=>$value)
			{
				if(strlen($salary[$value]) > 6)
				{
					$this->api_response_arry['response_code'] = 500;
					$this->api_response_arry['message']       = '';
					$this->api_response();
				}
				if(isset($salary[$value]))
				{
					if($status != "")
					{
						$player_salary[] = array(
											"player_team_id"	=> $value,
											"salary"			=> $salary[$value],
											"player_status"		=> $status
										);
					}
					else
					{
						$player_salary[] = array(
											"player_team_id"	=> $value,
											"salary"			=> $salary[$value]
										);
					}
				}
			}

			$re_salary = $this->Roster_model->update_roster_batch($player_salary);
		}
		
	
		if(!empty($injury))
		{

			$player_ids = $this->Roster_model->get_player_ids($players);
			if($player_ids)
			{
				foreach($player_ids as $key=>$value)
				{

					$player_injury[] = array(
												"player_id"			=> $value['player_id'],
												"injury_status"		=> $injury[$value['player_team_id']]
											);
				}	
			}	
				
			if(!empty($player_injury))
			{
				$re_injury = $this->Roster_model->update_roster_injury($player_injury);
			}	
			
		}

		if(!empty($status) && $status != 2)
		{
			foreach($players as $key=>$value)
			{
				$player_status[] = array(
										"player_team_id" => $value,
										"player_status" => $status
									);
				
			}
			$re_status = $this->Roster_model->update_roster_batch($player_status);
		}
		/*if(!empty($category_id))
		{
			foreach($players as $key=>$value)
			{
				$player_status[] = array(
										"player_team_id" => $value,
										"category_id" => $category_id
									);
				
			}
			$re_status = $this->Roster_model->update_roster($league_id,$player_status);
		}*/

		if($re_salary)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		if($re_injury)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		if($re_status)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function change_player_status_post()
	{
		$this->form_validation->set_rules('player_team_id', 'Player Unique Id', 'trim|required');
		$this->form_validation->set_rules('player_status', 'Player Status', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		
		$player_team_id = $this->input->post('player_team_id');
		$player_status = $this->input->post("player_status");

		$result = $this->Roster_model->change_player_status($player_team_id,$player_status);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function release_player_post()
	{
		$this->form_validation->set_rules('league_id', 'League Id', 'trim|required');
		if(!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$league_id = $this->input->post('league_id');

		$result = $this->Roster_model->release_player($league_id);

		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('player_release_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function export_roster_get($roster_type, $league_id)
	{
		if($roster_type == 'csv')
		{
			$this->Roster_model->export_roster_csv($league_id);
		}
		else
		{
			$this->Roster_model->export_roster_xlsx($league_id);
		}
	}

	public function import_roster_post()
	{
		$post_data   = $this->input->post('import_data');
		$import_file = $this->input->post('import_file');

		if($post_data)
		{	
			$roster_array = array();
			foreach($post_data as $data)
			{
				$roster_array[] = array(
									"player_team_id"	=> (string)$data['player_unique_id'],
									"salary"			=> $data['salary']
								);
			}
			$result = $this->Roster_model->import_roster($roster_array);
			if($result)
			{

				//import file name not empty and file exists in location then delete this file
				if(!empty($import_file) && file_exists(APP_ROOT_PATH.ROSTER_DIR.$import_file.'.json')){
					unlink(APP_ROOT_PATH.ROSTER_DIR.$import_file.'.json');
				}

				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('roster_successfull_import')), rest_controller::HTTP_OK);
			}
		}
		else
		{
			
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('invalid_parameter')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function do_upload_post()
	{
		
		$file_field_name	= $this->post('name');
		$dir				= APP_ROOT_PATH.UPLOAD_DIR;
		$subdir				= APP_ROOT_PATH.ROSTER_DIR;
		$temp_file			= $_FILES['file']['tmp_name'];
		$ext				= pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		
		$this->check_folder_exist($dir);
		$this->check_folder_exist($subdir);

		$config['allowed_types']	= 'csv|xlsx';
		$config['max_size']			= '5000';
		$config['max_width']		= '1024';
		$config['max_height']		= '1000';
		$config['upload_path']		= $subdir;
		$config['file_name']		= time();

		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('file'))
		{
			$error = $this->upload->display_errors();
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($error)) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		else
		{
			$upload_data = $this->upload->data();

			if($ext==='xlsx')
			{
				$this->xlsx_to_json($upload_data['full_path'], $upload_data['raw_name']);
			}
			elseif($ext==='csv')
			{
				$this->csv_to_json($upload_data['full_path'], $upload_data['raw_name']);
			}

			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>array('file_name'=>$upload_data['raw_name'])), rest_controller::HTTP_OK);
		}
	}

	private function xlsx_to_json($file, $raw_name)
	{
		//load the excel library
		$this->load->library('PHPExcel');
		//read file from path
		$objPHPExcel = PHPExcel_IOFactory::load($file);
		//get only the Cell Collection

		$all_sheets = $objPHPExcel->getSheetNames();
		$player_roster = array();
		$coloum_meta = array('A'=>'player_unique_id','B'=>'position','C'=>'full_name','D'=>'nick_name','E'=>'team_name','F'=>'salary','G'=>'league_abbr','H'=>'league_id');

		foreach($all_sheets as $sheet_name)
		{
			$sheet =  $objPHPExcel->setActiveSheetIndexByName($sheet_name);
			$final_response[$sheet_name] = array();
			$data						= array();

			$cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();

			$i=0;
			$a=0;
			//extract to a PHP readable array format
			foreach ($cell_collection as $cell) 
			{
				$column		= $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
				$row		= $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
				$data_value	= $objPHPExcel->getActiveSheet()->getCell($cell)->getCalculatedValue();
				//header will/should be in row 1 only. of course this can be modified to suit your need.
				if ($row!==1)
				{
					$a++;
					$player_roster[$i][$coloum_meta[$column]] = utf8_encode($data_value);
					if(count($coloum_meta)===$a)
					{
						$i++;
						$a=0;
					}
				}
			}
		}

		$dir = APP_ROOT_PATH.ROSTER_DIR;
		$this->load->helper('file');
		$data = json_encode($player_roster);
		$json_file = $dir.$raw_name.'.json';
		$response = write_file($json_file, $data);
		unlink($file);
		return $response;
	}

	private function csv_to_json($file, $raw_name)
	{
		$this->load->library('CSVReader');
		$result =   $this->csvreader->parse_file($file);		
		$player_roster = array();
		$rs = $result[0];
		if(!isset($rs['PlayerUniqueID']) OR !isset($rs['PlayerName']) OR !isset($rs['Position']) OR !isset($rs['PlayerTeam']) OR !isset($rs['Salary']) OR !isset($rs['LeagueID']) OR !isset($rs['LeagueName'])OR !isset($rs['NickName']))
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'Invalid File') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		foreach ($result as $rs) 
		{
			
			$player_roster[] = array(
									"player_unique_id"	=> utf8_encode($rs['PlayerUniqueID']),
									"position"			=> utf8_encode($rs['Position']),
									"full_name"			=> utf8_encode($rs['PlayerName']),
									"nick_name"			=> utf8_encode($rs['NickName']),
									"team_name"			=> utf8_encode($rs['PlayerTeam']),
									"salary"			=> utf8_encode($rs['Salary']),
									"league_abbr"		=> utf8_encode($rs['LeagueName']),
									"league_id"			=> utf8_encode($rs['LeagueID'])
								);
		}
		
		$dir = APP_ROOT_PATH.ROSTER_DIR;
		$this->load->helper('file');
		$data = json_encode($player_roster);
		$json_file = $dir.$raw_name.'.json';
		$response = write_file($json_file, $data);
		unlink($file);
		return $response;
	}

	/**
	* @Summary: check if folder exists otherwise create new
	* @create_date: 24 july, 2015
	*/
	private function check_folder_exist($dir)
	{
		if(!is_dir($dir))
			return mkdir(getcwd().$dir, 0777);
		return TRUE;
	}

	//function for remove uploded file if import cancel by admin
	public function remove_import_file_post(){
		$file_name = $this->input->post('import_file');
		if(!empty($file_name)){
			$this->load->helper('file');
			$dir = APP_ROOT_PATH.ROSTER_DIR;
			delete_files($dir);
		}
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>''), rest_controller::HTTP_OK);
	}
}

/* End of file Roster.php */
/* Location: /admin/application/controllers/Roster.php */