<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Feeds extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Feeds_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_league_post()
	{
		$result = $this->Feeds_model->get_all_league();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_raw_feed_post()
	{
		$result = $this->Feeds_model->get_all_raw_feed();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_feed_detail_post()
	{
		$feed_id = $this->input->post('feed_id');
		$result = $this->Feeds_model->get_feed_detail($feed_id);
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}
}

/* End of file Feeds.php */
/* Location: /admin/application/controllers/Feeds.php */