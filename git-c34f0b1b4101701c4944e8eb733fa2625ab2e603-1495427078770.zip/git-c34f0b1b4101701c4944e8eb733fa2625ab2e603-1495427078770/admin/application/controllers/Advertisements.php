<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Advertisements extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$_POST = $this->post();
		$this->load->model('Advertisement_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function create_advertisement_post()
	{
		  
			$data = $this->input->post();
			 
			$this->form_validation->set_rules('name', 'name', 'trim|required');
			$this->form_validation->set_rules('target_url', 'target_url', 'trim|required');
			$this->form_validation->set_rules('position_type', 'type', 'trim|required');
			$this->form_validation->set_rules('ads_image', 'image_adsense', 'trim|required');
			if (!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}
			
			$result = $this->Advertisement_model->create_ads($data);
			if ($result)
			{
				
				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('ad_created_success')) , rest_controller::HTTP_OK);
			}
			else
			{
				
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('ad_try_again')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
	}



	function do_upload_post() 
	{
		$pos_type = $this->post('post_type');
		$type_detail  = $this->Advertisement_model->get_position_type($pos_type);
		$file_field_name = 'userfile';
		
		$temp_file = $_FILES['userfile']['tmp_name'];
		$ext = pathinfo($_FILES['userfile']['name'], PATHINFO_EXTENSION);
		$vals = @getimagesize($temp_file);
		$width = $vals[0];
		$height = $vals[1];
		
		if ($height != $type_detail['height'] || $width != $type_detail['width'])
		{
			$invalid_size = str_replace("{max_height}",$type_detail['height'],$this->lang->line('ad_image_invalid_size'));
			$invalid_size = str_replace("{max_width}",$type_detail['width'],$invalid_size);

			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$invalid_size) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			
		}

		if( strtolower( IMAGE_SERVER ) == 'local')
		{
			$dir = ROOT_PATH.ADVERTISEMENT_IMAGE;
			$this->check_folder_exist($dir);
		}

		$file_name = time() . "." . $ext;

		//Start amazon server upload code
		if (strtolower(IMAGE_SERVER) == 'remote')
		{
			$dir = ADVERTISEMENT_IMAGE;
			$this->load->library('S3');

			//if upload on s3 is enabled instantiate the class
			$s3 = new S3(AWS_ACCESS_KEY, AWS_SECRET_KEY);
			$filePath = $dir . $file_name;
			//echo $filePath;die;
			$is_s3_upload = $s3->putObjectFile($temp_file, BUCKET, $filePath, S3::ACL_PUBLIC_READ);

			if ($is_s3_upload)
			{
				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data' => IMAGE_PATH . AD_IMAGE_DIR . $file_name, 'file_name' => $file_name) , rest_controller::HTTP_OK);
			}
			else
			{
				
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('ad_try_again')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			$config['allowed_types'] = 'jpg|png|jpeg|gif';
			$config['max_size'] = '4048'; //204800
			$config['max_width'] = '1024';
			$config['max_height'] = '1000';
			$config['upload_path'] = $dir;
			$config['file_name'] = $file_name;

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload($file_field_name))
			{
				
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>strip_tags($this->upload->display_errors())) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
			else
			{
				$uploaded_data = $this->upload->data();
				$image_path = IMAGE_PATH . AD_IMAGE_DIR . $uploaded_data['file_name'];
				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data' => $image_path, 'file_name' =>$uploaded_data['file_name']) , rest_controller::HTTP_OK);
			}
		}
		
	}

	/**
	 * @Summary: check if folder exists otherwise create new
	 * @create_date: 18 may, 2015
	 * @last_update_date: 18 may, 2015
	 * @access: public
	 */
	public function check_folder_exist($dir)
	{
		if (!is_dir($dir))
			mkdir($dir, 0777);
	}

	public function get_positions_post()
	{
		$positions = $this->Advertisement_model->get_positions();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$positions) , rest_controller::HTTP_OK);
	}

	public function remove_image_post()
	{
		$image_name = $this->input->post('image_name');

		if( strtolower( IMAGE_SERVER ) == 'local')
		{
			$image_full_path = ROOT_PATH.ADVERTISEMENT_IMAGE.$image_name;
			unlink($image_full_path);
		}


		if(strtolower( IMAGE_SERVER ) == 'remote')
		{
		   $image_full_path = ADVERTISEMENT_IMAGE.$image_name;
		   $this->load->library( 'S3' );
		   $s3  = new S3( AWS_ACCESS_KEY , AWS_SECRET_KEY );
		   @$s3->deleteObject(BUCKET,$image_full_path);
		}	

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('ad_image_removed')) , rest_controller::HTTP_OK);
	}

	public function get_advertisement_post()
	{
		$limit = 10;
		$data_post = $this->input->post();
		$start = 0;
		$filter_name = (isset($data_post['search_keyword'])) ? $data_post['search_keyword'] : '';
		$fieldname = $data_post['sort_field'];
		$order = $data_post['sort_order'];
		if ($data_post['items_perpage'])
		{
			$limit = $data_post['items_perpage'];
		}

		if(isset($data_post['current_page']))
		{

			$start = $data_post['current_page']-1;
			$start = $start*$limit;
		}

		$offset = $start;

		$config['limit'] = $limit;
		$config['start'] = $start;
		$config['filter_name'] = $filter_name;
		$config['fieldname'] = $fieldname;
		$config['order'] = $order;

		$advertisement = $this->Advertisement_model->get_advertisement($config, FALSE);
		//echo $this->db->last_query();die;
		$config['count_only'] = TRUE;

		$total = $this->Advertisement_model->get_advertisement($config, TRUE);
		$order_sequence = $order == 'ASC' ? 'DESC' : 'ASC';
		$data = array(
							'result' => $advertisement,
							'current_page' => $offset,
							'total' => $total,
							'sort_field' => $fieldname,
							'sort_order' => $order_sequence
				  );

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$data),rest_controller::HTTP_OK);
	}

	public function update_status_post()
	{
		
			$this->form_validation->set_rules('status', 'status', 'required');
			$this->form_validation->set_rules('ad_management_id', 'ad_management_id', 'trim|required');
			if(!$this->form_validation->run()) 
			{
				$this->send_validation_errors();
			}

			$dataArr = array("status" => $this->input->post('status'));
			$id = $this->input->post('ad_management_id');
			$result = $this->Advertisement_model->update_advertisement_by_id($id, $dataArr);
			if ($result) 
			{
				$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('ad_status_updated')) , rest_controller::HTTP_OK);
			} 
			else 
			{
				$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('ad_try_again')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
			}
	}
	
}

/* End of file Auth.php */
/* Location: ./application/controllers/Auth.php */