<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$_POST = $this->post();
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function index_get()
	{		
		$this->index();
	}

	public function login_get()
	{		
		$this->index();
	}

	/**
	 * [dologin description]
	 * @MethodName dologin
	 * @Summary This function used to login user into the system
	 * @return   boolean
	 */
	public function dologin_post()
	{
		$this->form_validation->set_rules('email', 'Login', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$this->load->model('Adminauth_model');

		$data = $this->Adminauth_model->admin_login($this->input->post('email'), $this->input->post('password'));
		if ($data != NULL)
		{
			if ($data['status'] == 0) {
				$this->response(array(config_item('rest_status_field_name') => FALSE, config_item('rest_message_field_name') => array('email'=>'Your account is inactive!')) , rest_controller::HTTP_BAD_REQUEST);
			}
			

			$key = $this->generate_active_login_key($data['admin_id']); //Generate Active Login Key
			$data[AUTH_KEY] = $key;

			$data['admin_privilege'] = json_decode($data['privilege']);
			
			if ($data['admin_privilege']) {
				$data['admin_privilege'] = array_combine(array_keys(array_flip($data['admin_privilege'])), $data['admin_privilege']);	
			}
			
			$this->seesion_initialization($data); // Initialize User Session
			if (($this->session->userdata('role') == 2)) {
				$this->admin_privilege = $this->session->userdata('admin_privilege');
				$this->check_subadmin_acess_privilege();		
			}
			
			$this->response(array(config_item('rest_status_field_name') => TRUE,'Data'=>array(
				AUTH_KEY=>$key, 
				'redirect_after_login'=>$this->redirect_after_login 
				)) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name') => FALSE, config_item('rest_message_field_name') => array('email'=>'Incorrect credentials!')) , rest_controller::HTTP_BAD_REQUEST);
		}
	}

	/**
	 * [logout description]
	 * @MethodName logout
	 * @Summary This function used to logout user from the system
	 * @return   boolean
	 */
	public function logout_post() 
	{
		$key = $this->input->get_request_header(AUTH_KEY); 
		$this->delete_active_login_key($key);

		$this->admin_id			= "";
		$this->admin_fullname	= "";
		$this->admin_email		= "";
		$this->role_type		= "";
		$this->session->sess_destroy();
		$this->session->sess_regenerate();
		return TRUE;
	}
	
	public function logout_get()
	{
		$this->logout_post();
		redirect('auth', 'refresh');
	}
}

/* End of file Auth.php */
/* Location: ./application/controllers/Auth.php */