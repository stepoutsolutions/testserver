<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Admin_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('Dashboard_model');
		if($this->admin_role == SUBADMIN_ROLE){                    
            if(empty($this->admin_privilege['dashboard'])){                
               $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'You do not have permission to access game management.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
            }
        }
	}

	public function dashboard_post()
	{		
		$dashboard_detail = $this->Dashboard_model->dashbaord_detail();
		$dashboard_graph_detail = $this->Dashboard_model->dashboard_graph_detail();
		$result = array("dashboard_detail"=>$dashboard_detail, "dashboard_graph_detail"=>$dashboard_graph_detail);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result), rest_controller::HTTP_OK);
	}
}

/* End of file Dashboard.php */
/* Location: /admin/application/controllers/Dashboard.php */