<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User extends Admin_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		//Do your magic here
		/*if($this->admin_role == SUBADMIN_ROLE){                    
            if(empty($this->admin_privilege['manage_users'])){                
               $this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>'You do not have permission to access game management.'), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
            }
        }*/
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function users_post()
	{
		$result = $this->User_model->get_all_user();
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_user_detail_post()
	{
		$user_id = $this->post('user_unique_id');
		$result = $this->User_model->get_user_detail_by_id($user_id);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function user_transaction_history_post()
	{
		$this->form_validation->set_rules('user_id', 'User ID', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$result = $this->User_model->user_transaction_history();
		
		$temp_array = array();
		foreach($result['result'] as $data)
		{
			if($data['master_description_id']==1 || $data['master_description_id']==2 || $data['master_description_id']==3)
			{
				$data['description'] = str_replace('{{contest_name}}', $data['contest_name'],$data['english_description']);
			}
			$temp_array[] = $data;
		}
		$result['result'] = $temp_array;
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function user_game_history_post()
	{
		$this->form_validation->set_rules('user_id', 'User ID', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$result = $this->User_model->game_history_by_user();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function change_user_status_post()
	{
		$this->form_validation->set_rules('user_unique_id', 'User Unique Id', 'trim|required');
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		$status = $this->input->post("status");
		if($status == 0)
		{
			$this->form_validation->set_rules('reason', 'Reason', 'trim|required');
		}
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		
		$user_unique_id = $this->input->post('user_unique_id');
		$reason = $this->input->post("reason")?$this->input->post("reason"):"";
		$data_arr = array(
						"status"		=> $status,
						"status_reason"	=> $reason
					);
		$result = $this->User_model->update_user_detail($user_unique_id,$data_arr);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}	
	}

	public function change_all_user_status_post()
	{
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		$status = $this->input->post("status");
		if($status == 0)
		{
			$this->form_validation->set_rules('reason', 'Reason', 'trim|required');
		}
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$user_unique_ids = $this->input->post('user_unique_id');
		if(empty($user_unique_ids))
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		$reason = $this->input->post("reason")?$this->input->post("reason"):"";
		foreach ($user_unique_ids as $user_unique_id) 
		{
			$data_arr[] = array(
							"status"			=> $status,
							"status_reason"		=> $reason,
							"user_unique_id"	=> $user_unique_id
						);
		}
		$result = $this->User_model->update_all_user_status($data_arr);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('update_status_success')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function add_user_balance_post()
	{
		if(empty($this->input->post()))
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('enter_required_field')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		$this->form_validation->set_rules('user_unique_id', 'User Unique Id', 'trim|required');
		$this->form_validation->set_rules('amount', 'Amount', 'trim|required|max_length[7]|numeric');
		$this->form_validation->set_rules('transaction_type','Transaction Type' ,'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		
		$user_unique_id		= $this->input->post('user_unique_id');
		$amount				= $this->input->post("amount");
		$transaction_type	= $this->input->post("transaction_type");		

		$user_detail = $this->User_model->get_user_detail_by_id($user_unique_id);
		
		if($user_detail['balance']<$amount && $transaction_type == 'DEBIT')
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('insufficient_balance')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}

		$order_data = array();
		$order_data['real_amount'] = $amount;
		$order_data['source'] 	   = ORDER_SOURCE_ADMIN;//admin
		$order_data['source_id']   = 0;
		$order_data['user_id']     = $user_detail['user_id'];
		$order_data['date_added']  = format_date();
		$order_data['status']  	   = 1;
		$order_data['plateform']   = 1;



		if($transaction_type == 'DEBIT')
		{
			$balance = $user_detail['balance'] - $amount;
			$order_data['type']  	   = 1;//debit
		}
		else
		{
			$balance = $user_detail['balance'] + $amount;
			$order_data['type']  	   = 0;//credit
		}

		$this->User_model->make_payment_transaction($order_data);

		$data_arr = array(
					"balance"		=> $balance
				);

		$result = $this->User_model->update_user_detail($user_unique_id, $data_arr);

		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$data_arr, 'message'=>$this->lang->line('balance_update_success')), rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('no_change')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function get_filter_data_post()
	{
		$country = $this->User_model->get_all_country();
		$value	= $this->User_model->get_max_min_user_balance();
		
		$result['country']		= $country;
		$result['min_value']	= round($value['min_value']);
		$result['max_value']	= round($value['max_value']);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result), rest_controller::HTTP_OK);
	}

	public function send_email_selected_user_post()
	{
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required|max_length[500]');
		$this->form_validation->set_rules('selected_emails','Selected emails' ,'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$this->load->helper('mail_helper');
		$post_data = $this->input->post();
		
		// $this->send_email($post_data['selected_emails'], $post_data['subject'], $post_data['message']);
		send_email($post_data['selected_emails'], $post_data['subject'], $post_data['message']);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('email_send')), rest_controller::HTTP_OK);
	}

	public function send_email_all_user_post()
	{
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required|max_length[500]');
		$this->load->helper('mail_helper');
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$post_data = $this->input->post();
		$result = $this->User_model->get_all_user_list();
		$user_list  = $result['emails'];
		if($user_list)
			send_email($user_list, $post_data['subject'], $post_data['message']);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('email_send')), rest_controller::HTTP_OK);
	}

	public function export_users_post()
	{
		$this->User_model->export_users();
	}

	public function export_users_get()
	{
		$this->User_model->export_users();
	}
	
	public function remove_cpf_post()
	{
		$this->form_validation->set_rules('user_unique_id', 'User Detail', 'trim|required');
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$this->load->model('User_model');
		$this->User_model->remove_cpf($this->input->post('user_unique_id'));
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'CPF No removed successfully.'), rest_controller::HTTP_OK);
	}

	public function verify_user_pancard_post()
	{
		$this->form_validation->set_rules('user_unique_id', 'User Detail', 'trim|required');
		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$this->load->model('User_model');
		$user_unique_id = $this->input->post('user_unique_id');
		$update_arr = array(
			'verify' => 1
		);	
		$result = $this->User_model->update_user_detail($user_unique_id, $update_arr);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>'PAN card verified successfully.','data'=>$update_arr), rest_controller::HTTP_OK);
	}
}
/* End of file User.php */
/* Location: ./application/controllers/User.php */