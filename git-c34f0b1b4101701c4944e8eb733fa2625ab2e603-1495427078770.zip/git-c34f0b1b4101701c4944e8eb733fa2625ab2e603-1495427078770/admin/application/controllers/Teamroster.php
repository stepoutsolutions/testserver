<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Teamroster extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Teamroster_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_league_post()
	{
		$result = $this->Teamroster_model->get_all_league();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_teamrosters_post()
	{
		$result = $this->Teamroster_model->get_all_teamrosters();
		
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function change_team_abbr_post()
	{
		$post_data =  $this->input->post();
		$result = $this->Teamroster_model->change_team_abbr($post_data);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('successfully_update_team_abbr')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('no_change')), rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}
}

/* End of file Teamroster.php */
/* Location: /admin/application/controllers/Teamroster.php */