<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Promo_code extends MYREST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Promocode_model');
		//Do your magic here
	}

	public function index()
	{
		$this->load->view('layout/layout', $this->data, FALSE);
	}

	public function get_all_country_post()
	{
		$result = $this->Promocode_model->get_all_country();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_state_post()
	{
		$country = $this->input->post('master_country_id');
		$result = $this->Promocode_model->get_all_state_by_country($country);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function new_sales_person_post()
	{
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
		$this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('paypal_email', 'Paypal Email', 'trim|required|valid_email');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}

		$post_data = $this->input->post();

		$check_email = $this->Promocode_model->check_sales_person_email($post_data['email']);

		if($check_email)
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('alredy_exists')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}


		$sales_person_unique_id = random_string('alnum', 8);
		$data_array = array(
				"sales_person_unique_id"	=> $sales_person_unique_id,
				"first_name"				=> $post_data['first_name'],
				"last_name"					=> $post_data['last_name'],
				"email"						=> $post_data['email'],
				"dob"						=> $post_data['dob'],
				"paypal_id"					=> $post_data['paypal_email'],
				"address"					=> $post_data['address'],
				"master_country_id"			=> intval($post_data['master_country_id']),
				"master_state_id"			=> intval($post_data['master_state_id']),
				"city"						=> $post_data['city'],
				"zip_code"					=> intval($post_data['zip_code']),
				"status"					=> '1',
				"added_date"				=> date('Y-m-d H:i:s')
			);
		$result = $this->Promocode_model->new_sales_person($data_array);
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('create_promo_code')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function get_sales_person_post()
	{
		$result = $this->Promocode_model->get_sales_person();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function new_promo_code_post()
	{
		$this->form_validation->set_rules('benefit_cap', 'Benefit Cap', 'trim|required');
		$this->form_validation->set_rules('commission_sales', 'Commission For Sales Person', 'trim|required');
		$this->form_validation->set_rules('discount', 'Discount', 'trim|required');
		$this->form_validation->set_rules('expiry_date', 'Expiry Date', 'trim|required');
		$this->form_validation->set_rules('promo_code', 'Promo Code', 'trim|required');
		$this->form_validation->set_rules('sales_person', 'Sales Person', 'trim|required');
		$this->form_validation->set_rules('start_date', 'Start Date', 'trim|required');
		$this->form_validation->set_rules('user_type', 'Select Type', 'trim|required');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$post_data = $this->input->post();

		$sales_person_unique_id = random_string('alnum', 8);
		$data_array = array(
				"sales_person_id"			=> $post_data['sales_person'],
				"promo_code"				=> $post_data['promo_code'],
				"start_date"				=> $post_data['start_date'],
				"expiry_date"				=> $post_data['expiry_date'],
				"discount"					=> $post_data['discount'],
				"benefit_cap"				=> $post_data['benefit_cap'],
				"sales_person_commission"	=> $post_data['commission_sales'],
				"status"					=> '1',
				"added_date"				=> date('Y-m-d H:i:s')
			);
		$result = $this->Promocode_model->new_promo_code($data_array);
		
		if($result)
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('create_sales_person')) , rest_controller::HTTP_OK);
		}
		else
		{
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
	}

	public function get_sales_person_payout_post()
	{
		$result = $this->Promocode_model->get_sales_person_payout();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_promo_codes_post()
	{
		$result = $this->Promocode_model->get_promo_codes();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_commission_payout_post()
	{
		$result = $this->Promocode_model->get_commission_payout();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_promo_code_detail_post()
	{
		$result = $this->Promocode_model->get_promo_code_detail();

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_all_user_by_key_post() 
	{
		$search_key = $this->input->post('search_key');
		$result['data'] = $this->Promocode_model->get_all_user_by_key($search_key);
		
		$this->response($result);
	}

	public function get_all_sales_person_post() 
	{
		$search_key = $this->input->post('search_key');
		$result['data'] = $this->Promocode_model->get_all_sales_person($search_key);
		
		$this->response($result);
	}

	public function get_sales_person_detail_post()
	{
		$sales_person_id = $this->input->post('sales_person_id');
		$result = $this->Promocode_model->get_sales_person_detail($sales_person_id);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function update_sales_person_detail_post()
	{
		$post_data = $this->input->post();
		$post_data['zip_code'] = intval($post_data['zip_code']);
		$check_email = $this->Promocode_model->check_sales_person_email($post_data['email'],$post_data['sales_person_unique_id']);

		if($check_email)
		{
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('alredy_exists')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}
		$result = $this->Promocode_model->update_sales_person_detail($post_data);

		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('sales_person_updated')) , rest_controller::HTTP_OK);
	}

	public function get_sales_person_earning_post()
	{
		$sales_person_id = $this->input->post('sales_person_id');
		$result = $this->Promocode_model->get_sales_person_earning($sales_person_id);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function update_sales_person_earning_post()
	{
		$this->form_validation->set_rules('sales_person_id', 'Sales Person ID', 'trim|required');
		$this->form_validation->set_rules('amount', 'Amount', 'trim|required|integer|max_length[7]');
		$this->form_validation->set_rules('comment', 'Commment', 'trim|required|max_length[255]');

		if (!$this->form_validation->run()) 
		{
			$this->send_validation_errors();
		}
		$post_data = $this->input->post();
		$data_array = array(
				"sales_person_id"	=> $post_data['sales_person_id'],
				"amount_paid"		=> $post_data['amount'],
				"comment"			=> $post_data['comment'],
				"added_date"		=> date("Y-m-d H:i:s")
			);
		$result = $this->Promocode_model->update_sales_person_earning($data_array);
		if($result)
			$this->response(array(config_item('rest_status_field_name')=>TRUE, 'message'=>$this->lang->line('sales_person_earning_update')) , rest_controller::HTTP_OK);
		else
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 'message'=>$this->lang->line('invalid_parameter')) , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
	}

	public function get_sales_person_earning_history_post()
	{
		$sales_person_id = $this->input->post('sales_person_id');
		$result = $this->Promocode_model->get_sales_person_earning_history($sales_person_id);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}

	public function get_promo_code_dates_post()
	{
		$start_date = format_date('today','Y-m-d');
		$end_date = date("Y-m-d", strtotime(date("Y-m-d", strtotime($start_date)) . " + 1 year"));
		$result = array('start_date' => $start_date, "expiry_date" => $end_date);
		$this->response(array(config_item('rest_status_field_name')=>TRUE, 'data'=>$result) , rest_controller::HTTP_OK);
	}	
}

/* End of file Promo_code.php */
/* Location: ./application/controllers/Promo_code.php */