<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pre_launch extends CI_Controller {

	public $data = array();

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}
	
	/**
	 * [index description]
	 * @MethodName index
	 * @Summary This function used to pre lanuch update bonus to all site users
	 * @return   boolean
	 */
	public function index()
	{
		$payment_history_query = "SELECT user_id FROM vi_payment_history_transaction WHERE master_description_id = 13 GROUP BY user_id";
		$sql = $this->db->select("U.user_id, U.balance")
						->from(USER." U")
						->where_not_in("U.user_id",$payment_history_query,FALSE)
						// ->limit(10)
						->get();
		$result = $sql->result_array();
		$payment_history = array();
		$update_balance = array();

		$bonus_amount = 5;

		foreach($result as $rs)
		{
			$payment_history[] = array(
					"user_id"						=> $rs['user_id'],
					"payment_type"					=> CREDIT,
					"master_description_id"			=> TRANSACTION_HISTORY_PRE_LAUNCH_BONUS,
					"transaction_amount"			=> $bonus_amount,
					"user_balance_at_transaction"	=> $rs['balance'],
					"amount_type"					=> AMOUNT_TYPE_REAL,
					"created_date"					=> format_date()
				);
			$update_balance[] = array(
					"user_id" => $rs['user_id'],
					"balance" => $rs['balance'] + $bonus_amount
				);
		}

		$this->db->insert_batch(PAYMENT_HISTORY_TRANSACTION, $payment_history);

		$this->db->update_batch(USER, $update_balance, 'user_id');
	}
}

/* End of file Utility.php */
/* Location: ./application/controllers/Utility.php */
