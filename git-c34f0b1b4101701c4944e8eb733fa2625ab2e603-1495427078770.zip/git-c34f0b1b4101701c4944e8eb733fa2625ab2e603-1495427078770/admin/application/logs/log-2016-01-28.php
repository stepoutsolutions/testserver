<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-28 06:08:09 --> Could not find the language line "transaction"
ERROR - 2016-01-28 06:11:12 --> Could not find the language line "transaction"
ERROR - 2016-01-28 08:19:24 --> Could not find the language line "user"
ERROR - 2016-01-28 08:22:09 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session E:\xampp\htdocs\vfantasysports\system\libraries\Session\Session.php 609
