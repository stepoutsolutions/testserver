<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

function format_date( $date = 'today' , $format = 'Y-m-d H:i:s' )
{
	if( $date=="today" )
	{
		if ( IS_LOCAL_TIME === TRUE )
		{
			$back_time = strtotime( BACK_YEAR );
			$dt = date( $format , $back_time );
		}
		else
		{
			$dt = date( $format );
		}
	}
	else
	{
		if( is_numeric ( $date ) )
		{
			$dt = date( $format , $date );
		}
		else
		{
			if( $date != null )
			{
				$dt = date( $format , strtotime ( $date ) );
			}
			else
			{
				$dt="--";
			}
		}
	}

	$path = ROOT_PATH.'date_time.php';

	if(file_exists($path))
	{
		include($path);
	}
 
	if ( isset( $date_time ) && $date_time &&  ($_SERVER['SERVER_NAME'] != 'www.playzo.in' ) )
	{
		$dt = date( $format , strtotime( $date_time ) );
	}
	return $dt;
	//return "2015-05-24 14:00:00";
}

function prize_json()
{
    $json = '{  "Top 1":{"1":100},
    			"Top 3":{"1":50,"2":30,"3":20},
    			"Top 10":{"1":15.5,"2":14,"3":12.5,"4":11,"5":9.5,"6":8.5,"7":8,"8":7.5,"9":7,"10":6.5},
    			"Top 20":{"1":27.50,"2":17.50,"3":11.50,"4":8.50,"5":7.25,"6":5.75,"7":4.50,"8":3.00,"9":2.00,"10":1.50,"11":1.20,"12":1.20,"13":1.20,"14":1.20,"15":1.20,"16":1.00,"17":1.00,"18":1.00,"19":1.00,"20":1.00},
    			"Top 30%":{"30":100},
    			"Top 50%":{"50":100}
    		 }';
    return $json;
}

function format_num_callback($n)
{
    return floatval( str_replace(',', '', $n) );
}

function truncate_number( $number = 0 , $decimals = 2 )
{
	$point_index = strrpos( $number , '.' );
	if($point_index===FALSE) return $number;
	return substr( $number , 0 , $point_index + $decimals + 1 );
}

function debug( $msg , $die=FALSE )
{
	echo ( "<style> pre{background-color:chocolate;font-weight:bolder;} .debug{color: black;text-align:center;background-color:yellow;font-weight:bolder;padding:10px;font-size:14px;}</style>" );

	echo ("\n<p class='debug'>\n");

	echo ("MSG".time().": ");

	if ( is_array ( $msg ) )
	{
		echo ( "\n<pre>\n" );
		print_r ( $msg );
		echo ( "\n</pre>\n" );
	}
	elseif ( is_object ( $msg ) )
	{
		echo ( "\n<pre>\n" );
		var_dump ( $msg );
		echo ( "\n</pre>\n" );
	}
	else
	{
		echo ( $msg );
	}

	echo ( "\n</p>\n" );

	if ( $die )
	{
		die;
	}
}
if (!function_exists('array_column')) {
	function array_column($input, $column_key, $index_key = null)
	{
		if ( empty( $input ) )
		{
			return array();
		}

		if ($index_key !== null) {
			// Collect the keys
			$keys = array();
			$i = 0; // Counter for numerical keys when key does not exist

			foreach ($input as $row) {
				if (array_key_exists($index_key, $row)) {
					// Update counter for numerical keys
					if (is_numeric($row[$index_key]) || is_bool($row[$index_key])) {
						$i = max($i, (int)$row[$index_key] + 1);
					}

					// Get the key from a single column of the array
					$keys[] = $row[$index_key];
				} else {
					// The key does not exist, use numerical indexing
					$keys[] = $i++;
				}
			}
		}

		if ($column_key !== null) {
			// Collect the values
			$values = array();
			$i = 0; // Counter for removing keys

			foreach ($input as $row) {
				if (array_key_exists($column_key, $row)) {
					// Get the values from a single column of the input array
					$values[] = $row[$column_key];
					$i++;
				} elseif (isset($keys)) {
					// Values does not exist, also drop the key for it
					array_splice($keys, $i, 1);
				}
			}
		} else {
			// Get the full arrays
			$values = array_values($input);
		}

		if ($index_key !== null) {
			return array_combine($keys, $values);
		}

		return $values;
	}

}
function array_pluck($key, $array)
{
    if (is_array($key) || !is_array($array)) return array();
    $funct = create_function('$e', 'return is_array($e) && array_key_exists("'.$key.'",$e) ? $e["'. $key .'"] : null;');
    return array_map($funct, $array);
}

function replace_quotes($string)
{
	return preg_replace(array("/`/", "/'/", "/&acute;/"), "",$string);
}
function unique_multidim_array($array, $key) { 
    $temp_array = array(); 
    $i = 0; 
    $key_array = array(); 
    
    foreach($array as $val) { 
        if (!in_array($val[$key], $key_array)) { 
            $key_array[$i] = $val[$key]; 
            $temp_array[$i] = $val; 
        } 
        $i++; 
    } 
    return $temp_array; 
}