<!DOCTYPE html>
<html lang="en" ng-app="vfantasy">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title ng-bind="$state.current.data.pageTitle+' | Vfantasy'"></title>
<base href="<?php echo base_url();?>">

<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/brain-theme.css">
<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Cuprum">
<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
<link rel="shortcut icon" href="<?php echo base_url();?>favicon.ico" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>favicon.ico" type="image/x-icon">

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/vendor/md5.min.js"></script>

<?php $this->load->view('include/global_script_var');?>
<script type="text/javascript">
$.ajaxSetup({
    headers: {'<?php  $auth_key = $this->config->item('rest_key_name'); echo $auth_key; ?>': sessionStorage.getItem(AUTH_KEY)}
});
</script>
<link id="ng_load_plugins_before">
<style type="text/css">
/*li.active > ul {
    display: block !important;
}*/
</style>
</head>
<body ng-class="{'full-width':!settings.layout.pageBodyFullWidth}" ng-controller="CommonCtrl" ng-cloak>
	<div class="body-loader page-on-load"></div>
	<!-- BEGIN PAGE SPINNER -->
	<div ng-spinner-bar="" class="page-spinner-bar">
		<div class="bounce1"></div>
		<div class="bounce2"></div>
		<div class="bounce3"></div>
	</div>
	<!-- END PAGE SPINNER -->

	<!-- Navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<div class="hidden-lg pull-right">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar">
						<span class="sr-only">Toggle sidebar</span>
						<i class="fa fa-bars"></i>
					</button>
				</div>
				<ul class="nav navbar-nav navbar-left-custom" ng-controller="LogoutCtrl" ng-class="{hide:!settings.layout.pageBodyFullWidth}">
					<li class="user dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown">
							<img src="http://placehold.it/500" alt="">
							<span>Vfantasy</span>
							<i class="caret"></i>
						</a>
						<ul class="dropdown-menu">
							<li><a href="change_password"><i class="fa fa-cog"></i> {{lang.setting}}</a></li>
							<li><a ng-click="logout()"><i class="fa fa-mail-forward"></i> {{lang.logout}}</a></li>
						</ul>
					</li>
					<li><a class="nav-icon sidebar-toggle"><i class="fa fa-bars"></i></a></li>
				</ul>				
			</div>
			<ul ng-if="is_logged_in" class="nav navbar-nav navbar-right">
				<li class="user dropdown" ng-init="getLanguage()">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<span ng-bind="language_list[site_language]"></span>
						<i class="caret"></i>
					</a>
					<ul class="dropdown-menu">
						<li ng-repeat="(key, value) in language_list">
							<a href="" ng-click="(site_language!==key)&&changeLanguage(key);" ng-class="{active:site_language===key}"><i class="fa fa-language"></i> {{value}}</a>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /navbar -->

	<!-- Page header -->
	<div class="container-fluid">
		<div class="page-header">
			<div class="logo">
				<a href="dashboard"><img src="assets/images/logo.png" alt=""></a>
			</div>
		</div>
	</div>
	<!-- /page header -->
<!-- if($this->admin_role == SUBADMIN_ROLE){  -->

	<!-- Page container -->
	<div class="page-container container-fluid">
		<!-- Sidebar -->
		<div class="sidebar collapse" ng-if="settings.layout.pageBodyFullWidth" ng-init="initializeTab()">
			<ul class="navigation">
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['dashboard'])){ ?>
					<li class="dashboard" ng-class="{active:routename=='dashboard'}" ng-click="tab=''">
						<a href="dashboard"><i class="fa fa-bars"></i> {{lang.dashboard}}</a>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="dashboard" ng-class="{active:routename=='dashboard'}" ng-click="tab=''">
						<a href="dashboard"><i class="fa fa-bars"></i> {{lang.dashboard}}</a>
					</li>
				<?php } ?>
				
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_users'])){ ?>
					<li ng-class="{active:routename=='user'}" ng-click="tab=''">
						<a href="user"><i class="fa fa-bars"></i> {{lang.manage_user}}</a>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li ng-class="{active:routename=='user'}" ng-click="tab=''">
						<a href="user"><i class="fa fa-bars"></i> {{lang.manage_user}}</a>
					</li>
				<?php } ?>
				
			
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_contest'])){ ?>
					<li class="contest" ng-class="{active:(['contest','new_contest','contest_detail', 'new_turbo_contest'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='contest'">
							<i class="fa fa-bars"></i> {{lang.manage_contest}}
						</a>
						<ul ng-show="(routename=='contest'||routename=='new_contest'||routename=='new_turbo_contest'||routename=='contest_detail'||tab=='contest') && (tab!='finance' && tab!='bonus' && tab!='report' && tab!='advertisement' && tab!='referral')">
							<li ng-class="{active:routename=='contest'}"><a href="contest">{{lang.view_contest}}</a></li>
							<li ng-class="{active:routename=='new_contest'}"><a href="new_contest">{{lang.new_contest}}</a></li>
                            <?php /* ?> <li ng-class="{active:routename=='new_turbo_contest'}"><a href="new_turbo_contest">{{lang.new_turbo_contest}}</a></li> <?php */ ?>
						</ul>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="contest" ng-class="{active:(['contest','new_contest','contest_detail', 'new_turbo_contest'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='contest'">
							<i class="fa fa-bars"></i> {{lang.manage_contest}}
						</a>
						<ul ng-show="(routename=='contest'||routename=='new_contest'||routename=='new_turbo_contest'||routename=='contest_detail'||tab=='contest') && (tab!='finance' && tab!='bonus' && tab!='report' && tab!='advertisement' && tab!='referral')">
							<li ng-class="{active:routename=='contest'}"><a href="contest">{{lang.view_contest}}</a></li>
							<li ng-class="{active:routename=='new_contest'}"><a href="new_contest">{{lang.new_contest}}</a></li>
                            <?php /* ?>  <li ng-class="{active:routename=='new_turbo_contest'}"><a href="new_turbo_contest">{{lang.new_turbo_contest}}</a></li> <?php */ ?>
						</ul>
					</li>
				<?php } ?>


				
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['roster_management'])){ ?>
					<li class="roster" ng-class="{active:routename=='roster'}" ng-click="tab=''">
						<a href="roster"><i class="fa fa-bars"></i> {{lang.roster_management}}</a>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="roster" ng-class="{active:routename=='roster'}" ng-click="tab=''">
						<a href="roster"><i class="fa fa-bars"></i> {{lang.roster_management}}</a>
					</li>
				<?php } ?>
				
				
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_finance'])){ ?>
					<li class="finance" ng-class="{active:(['withdrawal_list','transaction_list'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='finance'">
							<i class="fa fa-bars"></i> {{lang.manage_finance}}
						</a>
						<ul ng-show="(routename=='withdrawal_list'||routename=='transaction_list' ||tab=='finance') && (tab!='contest' && tab!='bonus' && tab!='report' && tab!='advertisement' && tab!='referral')">
							<li ng-class="{active:routename=='withdrawal_list'}"><a href="withdrawal_list"> {{lang.withdrawal_list}}</a></li>
							<li ng-class="{active:routename=='transaction_list'}"><a href="transaction_list"> {{lang.transaction_list}}</a></li>
						</ul>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="finance" ng-class="{active:(['withdrawal_list','transaction_list'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='finance'">
							<i class="fa fa-bars"></i> {{lang.manage_finance}}
						</a>
						<ul ng-show="(routename=='withdrawal_list'||routename=='transaction_list' ||tab=='finance') && (tab!='contest' && tab!='bonus' && tab!='report' && tab!='advertisement' && tab!='referral')">
							<li ng-class="{active:routename=='withdrawal_list'}"><a href="withdrawal_list"> {{lang.withdrawal_list}}</a></li>
							<li ng-class="{active:routename=='transaction_list'}"><a href="transaction_list"> {{lang.transaction_list}}</a></li>
						</ul>
					</li>
				<?php } ?>
				
				
	
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['team_list'])){ ?>
					<li class="teamroster" ng-class="{active:routename=='team_roster'}" ng-click="tab=''">
						<a href="teamroster"><i class="fa fa-bars"></i> {{lang.team_list}}</a>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="teamroster" ng-class="{active:routename=='team_roster'}" ng-click="tab=''">
						<a href="teamroster"><i class="fa fa-bars"></i> {{lang.team_list}}</a>
					</li>
				<?php } ?>
				
				
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['season_schedule'])){ ?>
					<li ng-class="{active:(['season','season_stats'].indexOf(routename)!==-1)}" ng-click="tab=''">
						<a href="season"><i class="fa fa-bars"></i> {{lang.season_schedule}}</a>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li ng-class="{active:(['season','season_stats'].indexOf(routename)!==-1)}" ng-click="tab=''">
						<a href="season"><i class="fa fa-bars"></i> {{lang.season_schedule}}</a>
					</li>
				<?php } ?>

				<?php /* if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_scoring'])){ */ ?>
					<li class="manage_league" ng-class="{active:routename=='league'}" ng-click="tab='league'">
						<a href="league"><i class="fa fa-bars"></i> {{lang.manage_leagues}}</a>
					</li>
				


				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_referrals'])){ ?>
					<li class="referral" ng-class="{active:(['manage_referrals','update_referral_amount'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='referral'">
							<i class="fa fa-bars"></i> Manage Referrals
						</a>
						<ul ng-show="(routename=='manage_referrals'||routename=='update_referral_amount'||tab=='referral') && (tab!='finance' && tab!='bonus' && tab!='report' && tab!='advertisement')">
							<li ng-class="{active:routename=='manage_referrals'}"><a href="manage_referrals">Referral List</a></li>
							<li ng-class="{active:routename=='update_referral_amount'}"><a href="update_referral_amount">Update Referral Settings</a></li>
						</ul>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					 <li class="referral" ng-class="{active:(['manage_referrals','update_referral_amount'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='referral'">
							<i class="fa fa-bars"></i> Manage Referrals
						</a>
						<ul ng-show="(routename=='manage_referrals'||routename=='update_referral_amount'||tab=='referral') && (tab!='finance' && tab!='bonus' && tab!='report' && tab!='advertisement')">
							<li ng-class="{active:routename=='manage_referrals'}"><a href="manage_referrals">Referral List</a></li>
							<li ng-class="{active:routename=='update_referral_amount'}"><a href="update_referral_amount">Update Referral Settings</a></li>
						</ul>
					</li>
				<?php } ?>

				
				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_advertisement'])){ ?>
					<li class="contest" ng-class="{active:(['advertisement','new_advertisement'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='advertisement'">
							<i class="fa fa-bars"></i> {{lang.advertisement}}
						</a>
						<ul ng-show="(routename=='advertisement'||routename=='new_advertisement'||tab=='advertisement') && (tab!='finance' && tab!='bonus' && tab!='report' && tab!='contest' && tab!='referral')">
							<li ng-class="{active:routename=='advertisement'}"><a href="advertisement">{{lang.view_advertisement}}</a></li>
							<li ng-class="{active:routename=='new_advertisement'}"><a href="new_advertisement">{{lang.new_advertisement}}</a></li>
						</ul>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="contest" ng-class="{active:(['advertisement','new_advertisement'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='advertisement'">
							<i class="fa fa-bars"></i> {{lang.advertisement}}
						</a>
						<ul ng-show="(routename=='advertisement'||routename=='new_advertisement'||tab=='advertisement') && (tab!='finance' && tab!='bonus' && tab!='report' && tab!='contest' && tab!='referral')">
							<li ng-class="{active:routename=='advertisement'}"><a href="advertisement">{{lang.view_advertisement}}</a></li>
							<li ng-class="{active:routename=='new_advertisement'}"><a href="new_advertisement">{{lang.new_advertisement}}</a></li>
						</ul>
					</li>
				<?php } ?>
				
				<?php /* if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_scoring'])){ ?>
					<li class="manage_scoring" ng-class="{active:routename=='manage_scoring'}" ng-click="tab=''">
						<a href="manage_scoring"><i class="fa fa-bars"></i> {{lang.manage_scoring}}</a>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="manage_scoring" ng-class="{active:routename=='manage_scoring'}" ng-click="tab=''">
						<a href="manage_scoring"><i class="fa fa-bars"></i> {{lang.manage_scoring}}</a>
					</li>
				<?php } */?>
				
				    <?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['manage_signup_bonus'])){ ?>
						<li class="manage_signup_bonus" ng-class="{active:routename=='manage_signup_bonus'}" ng-click="tab=''">
							<a href="manage_signup_bonus"><i class="fa fa-bars"></i> {{lang.team_list}}</a>
						</li>
					<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
						<li class="manage_signup_bonus" ng-class="{active:routename=='manage_signup_bonus'}" ng-click="tab=''">
							<a href="manage_signup_bonus"><i class="fa fa-bars"></i> {{lang.manage_signup_bonus}}</a>
						</li>
					<?php } ?>

				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['reports'])){ ?>
					<li class="report" ng-class="{active:(['user_report', 'user_location', 'user_activity','user_money_paid','user_deposit_amount'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='report'">
							<i class="fa fa-bars"></i> {{lang.report}}
						</a>

						<ul ng-show="(routename=='user_report'||routename=='user_location'||routename=='user_activity'||routename=='user_money_paid'||tab=='report') && (tab!='finance' && tab!='bonus' && tab!='contest' && tab!='advertisement')">

							<li ng-class="{active:routename=='user_report'}"><a href="user_report">{{lang.user_report}}</a></li>
							<li ng-class="{active:routename=='user_location'}"><a href="user_location">{{lang.user_location}}</a></li>
							<li ng-class="{active:routename=='user_activity'}"><a href="user_activity">{{lang.user_activity}}</a></li>
							<li ng-class="{active:routename=='user_money_paid'}"><a href="user_money_paid">{{lang.user_money_paid}}</a></li>
							<li ng-class="{active:routename=='user_deposit_amount'}"><a href="user_deposit_amount">{{lang.user_deposit_amount}}</a></li>
						</ul>
					</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="report" ng-class="{active:(['user_report', 'user_location', 'user_activity','user_money_paid','user_deposit_amount'].indexOf(routename)!==-1)}">
						<a href="javascript:void(0);" class="expand1" ng-click="tab='report'">
							<i class="fa fa-bars"></i> {{lang.report}}
						</a>

						<ul ng-show="(routename=='user_report'||routename=='user_location'||routename=='user_activity'||routename=='user_money_paid'||tab=='report') && (tab!='finance' && tab!='bonus' && tab!='contest' && tab!='advertisement')">

							<li ng-class="{active:routename=='user_report'}"><a href="user_report">{{lang.user_report}}</a></li>
							<li ng-class="{active:routename=='user_location'}"><a href="user_location">{{lang.user_location}}</a></li>
							<li ng-class="{active:routename=='user_activity'}"><a href="user_activity">{{lang.user_activity}}</a></li>
							<li ng-class="{active:routename=='user_money_paid'}"><a href="user_money_paid">{{lang.user_money_paid}}</a></li>
							<li ng-class="{active:routename=='user_deposit_amount'}"><a href="user_deposit_amount">{{lang.user_deposit_amount}}</a></li>
						</ul>
					</li>
					
				<?php } ?>

				<?php if($this->admin_role ==SUBADMIN_ROLE&&!empty($this->admin_privilege['bonus_code'])){ ?>
				<li class="promo-code" ng-class="{active:(['bonus_code_detail', 'bonus_code', 'new_bonus_code'].indexOf(routename)!==-1)}">
					<a href="javascript:void(0);" class="expand1" ng-click="tab='bonus'">
						<i class="fa fa-bars"></i> {{lang.manage_bonus_code}}
					</a>

					<ul ng-show="(routename=='bonus_code_detail' || routename=='bonus_code'||routename=='new_bonus_code' || tab=='bonus') && (tab!='finance' && tab!='contest' && tab!='report' && tab!='advertisement' && tab != 'blog')">
						<li ng-class="{active:routename=='new_bonus_code'}"><a href="new_bonus_code">{{lang.new_bonus_code}}</a></li>
						<li ng-class="{active:routename=='bonus_code' || routename=='bonus_code_detail'}"><a href="bonus_code">{{lang.bonus_code}}</a></li>
					</ul>
				</li>
				<?php }elseif($this->admin_role ==SUPERADMIN_ROLE){ ?>
					<li class="promo-code" ng-class="{active:(['bonus_code_detail', 'bonus_code', 'new_bonus_code'].indexOf(routename)!==-1)}">
					<a href="javascript:void(0);" class="expand1" ng-click="tab='bonus'">
						<i class="fa fa-bars"></i> {{lang.manage_bonus_code}}
					</a>

					<ul ng-show="(routename=='bonus_code_detail' || routename=='bonus_code'||routename=='new_bonus_code' || tab=='bonus') && (tab!='finance' && tab!='contest' && tab!='report' && tab!='advertisement' && tab != 'blog')">
						<li ng-class="{active:routename=='new_bonus_code'}"><a href="new_bonus_code">{{lang.new_bonus_code}}</a></li>
						<li ng-class="{active:routename=='bonus_code' || routename=='bonus_code_detail'}"><a href="bonus_code">{{lang.bonus_code}}</a></li>
					</ul>
				</li>
				<?php } ?>
			</ul>
		</div>
		<!-- /sidebar -->

		<!-- Main contain load here -->
		<div class="page-content">
			<div class="loading-img"></div>
			<ui-view></ui-view>
		</div>
		<!-- /Main contain load here -->
	</div>		
	<!-- /Page container -->	
	<!-- Error Message Observer Section -->
	<span show-message="{{alert_success}}"></span>
	<span show-message="{{alert_error}}"></span>
	<span show-message="{{alert_warning}}"></span>
	<!-- End-->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
	<script type="text/javascript" src="https://www.google.com/jsapi"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/interface/collapsible.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/interface/jgrowl.min.js"></script>
	
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/vendor/angular.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/ng-google-chart.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/vendor/angular-ui-router.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/vendor/ocLazyLoad.min.js"></script>
	
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/jquery.validationEngine.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/jquery.validationEngine-en.js"></script>

	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/angular/ui-bootstrap-tpls.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/interface/jquery-ui-timepicker-addon.js"></script>
	<script src="<?php echo base_url();?>assets/js/angular-filter.js"></script>

	<script type="text/javascript" src="<?php echo base_url();?>assets/js/application_blank.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/static/app.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/service/services.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/directive/directive.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/controller/commonController.js"></script>
</body>
</html>