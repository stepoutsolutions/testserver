<!-- Page title -->
<div class="page-title">
	<h5><i class="fa fa-warning"></i> 404 error</h5>
</div>
<!-- /page title -->
<!-- Error wrapper -->
<div class="error-wrapper text-center">
	<h1>404</h1>
	<h5>- Oops, an error has occurred. Page not found! -</h5>
	<!-- Error content -->
	<div class="error-content">
		<div class="row">
			<div class="col-md-12">
				<a ng-if="is_logged_in" ng-click="$state.go('dashboard');" class="btn btn-danger btn-block">Back to dashboard</a>
				<a ng-if="!is_logged_in" ng-click="$state.go('root');" class="btn btn-danger btn-block">Back to login</a>
			</div>
		</div>
	</div>
	<!-- /error content -->
</div>  
<!-- /error wrapper -->