<!--Page content -->
<div class="content" data-ng-init="initObject()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.manage_league}}</h5>
	</div>
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title">League List</h6>
			<h6 class="panel-title pull-right">Total Record Count : <span ng-bind="leagueParam.total_items"></span></h6>
                        
                      
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="leagueList.length>0">
						<th width="2%">
							#
						</th>
						<th width="7%" data-ng-bind="lang.league_id">
						</th>
						<th class="pointer" ng-click="sortleagueList('league_name');">
							{{lang.league_name}}
							<i ng-class="(leagueParam.sort_field=='league_name'&&leagueParam.sort_order=='DESC')?'fa-sort-desc':((leagueParam.sort_field=='league_name'&&leagueParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortleagueList('league_abbr');">
							{{lang.league_abbr}}
							<i ng-class="(leagueParam.sort_field=='league_abbr'&&leagueParam.sort_order=='DESC')?'fa-sort-desc':((leagueParam.sort_field=='league_abbr'&&leagueParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortleagueList('league_uid');">
							{{lang.league_uid}}
							<i ng-class="(leagueParam.sort_field=='league_uid'&&leagueParam.sort_order=='DESC')?'fa-sort-desc':((leagueParam.sort_field=='league_uid'&&leagueParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortleagueList('league_schedule_date');">
							{{lang.league_schedule_date}}
							<i ng-class="(leagueParam.sort_field=='league_schedule_date'&&leagueParam.sort_order=='DESC')?'fa-sort-desc':((leagueParam.sort_field=='league_schedule_date'&&leagueParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortleagueList('active');">
							{{lang.status}}
							<i ng-class="(leagueParam.sort_field=='active'&&leagueParam.sort_order=='DESC')?'fa-sort-desc':((leagueParam.sort_field=='active'&&leagueParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th>
							{{lang.action}}
						</th>
					</tr>
					<tr ng-if="leagueList.length==0">
						<td align="center" colspan="8" data-ng-bind="lang.no_leagues"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="leagueList.length>0" ng-repeat="league in leagueList">
						<td ng-bind="((leagueParam.current_page*10)+$index)-9"></td>
						<td ng-bind="league.league_id"></td>
						<td ng-bind="league.league_name"></td>
						<td ng-bind="league.league_abbr"></td>
						<td ng-bind="league.league_uid"></td>
						<td ng-bind="league.league_date"></td>
						<td>

							<i class="fa fa-warning danger" ng-show="league.active==0" title="Inactive"></i>
							<i class="fa fa-unlock success" ng-show="league.active==1" title="Active"></i>
						</td>
						<td>
							<div class="btn-group">
								<button class="btn btn-link btn-icon btn-xs tip" data-toggle="dropdown" data-hover="dropdown">
									<i class="fa fa-cogs"></i>
								</button>
								<button class="btn btn-link btn-icon btn-xs tip" data-toggle="dropdown" data-hover="dropdown">
									<span class="caret caret-split"></span>
								</button>
								<ul class="dropdown-menu dropdown-menu-right">
										
									<li><a ng-click="changeLeagueStatus(league.league_id,'0',$index)" ng-if="league.active==1" >Inactive</a></li>										
									<li><a ng-click="changeLeagueStatus(league.league_id,'1',$index)" ng-if="league.active==0">Active</a></li>										
								</ul>
							</div>
						</td>
						
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="leagueList.length>0">
			<pagination ng-if="leagueParam.total_items>10" boundary-links="true" total-items="leagueParam.total_items" ng-model="leagueParam.current_page" ng-change="getAllLeagues()" items-per-page="leagueParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->


<!-- Inactive User modal -->
	<div id="league_confirmation_modal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title">League Status Confirmation</h5>
				</div>
					<div class="modal-body has-padding">
						
						<div class="form-group">
							<h4 ng-if="leagueObj.status == 0">Do you really want to inactivate this league ?</h4>	
							<h4 ng-if="leagueObj.status == 1">Do you really want to activate this league ?</h4>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="leagueObj={}">No</button>
						<button type="button" class="btn btn-primary" ng-click="submitLeagueStatusChange();"><i class=""></i>Yes</button>
					</div>
			</div>
		</div>
	</div>
	<!-- /Inactive User modal -->


