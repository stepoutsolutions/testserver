<!-- Page content -->
<div class="content" data-ng-init="initObject('');getFilterData();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.manage_site_users}}</h5>
	</div>
	<!-- /page title -->
	<!-- Filter Section -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.country"></th>
						<th data-ng-bind="lang.balance"></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center">
							<select name="country" id="country" data-placeholder="{{lang.all_country}}" class="select-full" ng-model="userParam.country" data-ng-change="filterCountry()" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value="" data-ng-bind="lang.all_country"></option>
								<option ng-repeat="country in country_list" value="{{::country.master_country_id}}">{{::country.country_name}}</option>
							</select>
						</td>
						<td class="text-center" width="30%">
							<label><?php echo CURRENCY_CODE;?>{{userParam.frombalance}} - <?php echo CURRENCY_CODE;?>{{userParam.tobalance}}</label>
							<div id="range-slider" callback="filterBalance(event, ui);" range-slider="max_value:'{{userParam.tobalance}}',min_value:'{{userParam.frombalance}}',min:'{{min_balance_value}}',max:'{{max_balance_value}}'"></div>
						</td>
						<td class="text-center">
							<input type="text" placeholder="{{lang.email_name_username}}" id="keyword" name="keyword" ng-model="userParam.keyword" class="form-control" data-ng-change="searchByEmailOrName()">
						</td>
					</tr>
					<tr>
						<td colspan="3">
							<a href="javascript:void(0);" ng-click="initObject('clear')"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /Filter Section -->
	<!-- User Listing -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.users"></h6>
			<div class="dropdown pull-right">
				<a href="#" class="btn btn-link btn-lg btn-icon dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cogs"></i><span class="caret"></span></a>
				<ul class="dropdown-menu dropdown-menu-right">
					<li><a href="javascript:void(0);" ng-click="exportUser()" data-ng-bind="lang.export_users"></a></li>
					<li><a href="javascript:void(0);" ng-click="showSendEmailAllModel()" data-ng-bind="lang.send_email_to_all_user"></a></li>
					<li><a href="javascript:void(0);" ng-click="showSendEmailSelectedModel()" data-ng-bind="lang.send_email_to_selected_user"></a></li>
				</ul>
			</div>
			<h6 class="panel-title pull-right">Total Record Count : <span ng-bind="userParam.total_items"></span></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered">
				<thead>
					<tr ng-if="userList.length > 0">
						<th>
							<input type="checkbox" ng-model="userObj.selectall" value="{{userObj.selectall}}" ng-checked="userObj.selectall" uniform="radioClass:'choice', selectAutoWidth:false" ng-click="toggleUser($event);">
						</th>
						<th class="pointer" ng-click="sortUesrList('user_name');">
							{{lang.username}}
							<i ng-class="(userParam.sort_field=='user_name'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='user_name'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('first_name');">
							{{lang.name}}
							<i ng-class="(userParam.sort_field=='first_name'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='first_name'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('email');">
							{{lang.email}}
							<i ng-class="(userParam.sort_field=='email'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='email'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('phone_no');">
							Phone
							<i ng-class="(userParam.sort_field=='phone_no'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='phone_no'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" class="numeric" ng-click="sortUesrList('balance');">
							{{lang.balance}}
							<i ng-class="(userParam.sort_field=='balance'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='balance'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						
						

						<th class="pointer" class="numeric" ng-click="sortUesrList('bonus_balance');">
							{{lang.bonus_balance}}
							<i ng-class="(userParam.sort_field=='bonus_balance'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='bonus_balance'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('added_date');">
							{{lang.member_since}}
							<i ng-class="(userParam.sort_field=='added_date'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='added_date'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('last_login');">
							{{lang.last_login}}
							<i ng-class="(userParam.sort_field=='last_login'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='last_login'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('status');">
							{{lang.status}}
							<i ng-class="(userParam.sort_field=='status'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='status'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer">
							PAN Card
						</th>
						<th>
							{{lang.action}}
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="userList.length > 0" ng-repeat="user in userList">
						<td><input type="checkbox" name="user_unique_id[]" value="{{user.user_unique_id}}" ng-checked="user_unique_id[$index]" ng-model="user_unique_id[$index]" ng-click="selectUser($event)" uniform="radioClass:'choice', selectAutoWidth:false"/></td>
						<td><img ng-src="{{user.image}}" class="user-avatar">{{user.user_name}}</td>
						<td data-ng-bind="::user.name"></td>
						<td><a href="mailto:{{::user.email}}">{{::user.email}}</a></td>
						<td data-ng-bind="::user.phone_no"></td>
						<td data-ng-bind-html="user.balance | salaryFormat"></td>
						<td data-ng-bind="user.bonus_balance"></td>
						<td data-ng-bind="::user.member_since"></td>
						<td data-ng-bind="::user.last_login"></td>
						<td>
							<i class="fa fa-trash-o danger" ng-show="user.status==4" title="{{lang.user_deleted_title}}"></i>
							<i class="fa fa-ban danger" ng-show="user.status==3" title="{{lang.user_banned_title}}"></i>
							<i class="fa fa-warning danger" ng-show="user.status==2" title="{{lang.user_email_not_verified_title}}"></i>
							<i class="fa fa-unlock success" ng-show="user.status==1" title="{{lang.user_active_title}}"></i>
							<i class="fa fa-lock danger" ng-show="user.status==0" title="{{lang.user_activation_pending_title}}"></i>
						</td>
						<td ng-if="user.pan_card">

							<div class="btn-group">
								<button class="btn btn-link btn-icon btn-xs tip" data-toggle="dropdown" data-hover="dropdown">
									<i class="fa fa-cogs"></i>
								</button>
								<button class="btn btn-link btn-icon btn-xs tip" data-toggle="dropdown" data-hover="dropdown">
									<span class="caret caret-split"></span>
								</button>
								<ul class="dropdown-menu dropdown-menu-right">
									<li>
										<a href="{{user.pan_card}}" target="_blank">View PAN Card</a>
									</li>	
									<li ng-if="user.verify == 0">
										<a href="javascript:void(0);" ng-click="VerifyPANCard(user.user_unique_id,$index)">Verify PAN Card</a>
									</li>
									<li ng-if="user.verify == 1">
										<a href="javascript:void(0)">PAN Card Verified</a>
									</li>								
								</ul>
							</div>
						</td>
						<td ng-if="!user.pan_card">--</td>
						<td>
							<div class="btn-group">
								<button class="btn btn-link btn-icon btn-xs tip" data-toggle="dropdown" data-hover="dropdown">
									<i class="fa fa-cogs"></i>
								</button>
								<button class="btn btn-link btn-icon btn-xs tip" data-toggle="dropdown" data-hover="dropdown">
									<span class="caret caret-split"></span>
								</button>
								<ul class="dropdown-menu dropdown-menu-right">
									<li ng-show="user.cpf_no"><a ng-click="removeCPF(user.user_unique_id, $index)" href="javascript:void(0);" data-ng-bind="lang.remove_cpf"></a></li>	
									<li><a tabindex="-1" href="user_detail/{{user.user_unique_id}}" data-ng-bind="lang.user_detail"></a></li>
									<li><a ng-click="getUserDetail(user.user_unique_id,$index)" href="javascript:void(0);" data-ng-bind="lang.manage_balance"></a></li>								
									<li><a ng-click="userInactive(user.user_unique_id,'0',$index)" ng-if="user.status==1 || user.status ==2" data-ng-bind="lang.inactive"></a></li>										
									<li><a ng-click="changeUserStatus(user.user_unique_id,'1',$index)" ng-if="user.status==0" data-ng-bind="lang.active"></a></li>										
								</ul>
							</div>
						</td>
					</tr>
					<tr ng-if="userList.length == 0">
						<td colspan="9" align="center" data-ng-bind="lang.no_record_found"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="userList.length>0">
			<div class="table-actions">
				<label data-ng-bind="lang.apply_action"></label>
				<select id="action" class="select-liquid" data-placeholder="{{lang.select_action}}" select-two="minimumResultsForSearch:'-1'" ng-model="userObj.action">
					<option value="" data-ng-bind="lang.select_action"></option>
					<option value="1" data-ng-bind="lang.active"></option>
					<option value="0" data-ng-bind="lang.inactive"></option>
				</select>
				<button ng-if="userObj.action !='' && userObj.action=='0'" type="button" ng-click="updateInactveUser()" class="btn btn-primary" ng-class="{disabled:userObj.user_unique_id.length==0}"><i class=""></i> {{lang.update}}</button>
				<button ng-if="userObj.action !='' && userObj.action=='1'" type="button" ng-click="changeSelectedUserStatus()" class="btn btn-primary" ng-class="{disabled:userObj.user_unique_id.length==0}"><i class=""></i> {{lang.update}}</button>
			</div>
			<pagination boundary-links="true" ng-if="userParam.total_items>10" total-items="userParam.total_items" ng-model="userParam.current_page" ng-change="getUserList()" items-per-page="userParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /User Listing -->
	<!-- Add User Balance modal -->
	<div id="add_balance_modal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" data-ng-bind="lang.manage_user_balance"></h5>
				</div>
				<!-- Add User Balance modal -->
				<form role="form" addbalance-form submit-handle="addUserBalance()" name="manage_balance_form" id="manage_balance_form">
					<div class="modal-body has-padding">
						<div class="form-group">
							<label data-ng-bind="lang.user_name"></label>
							<span disabled="disabled" class="form-control"  data-ng-bind="userDetail.user_name"></span>
						</div>
						<div class="form-group">
							<label data-ng-bind="lang.current_balance"></label>
							<span disabled="disabled" class="form-control"  data-ng-bind-html="userDetail.balance | salaryFormat"></span>
						</div>
						<div class="form-group">
							<label data-ng-bind="lang.transaction_type"> </label>
							<div>
								<label class="radio-inline" for="credit">
									<input type="radio" name="transaction_type" id="credit" value="CREDIT" uniform="radioClass:'choice', selectAutoWidth:false" ng-model="userBalance.transaction_type" checked="checked" ng-change="changeBalanceButtonText()">
									{{lang.credit}}
								</label>
								<label class="radio-inline" for="debit">
									<input type="radio" name="transaction_type" id="debit" value="DEBIT" uniform="radioClass:'choice', selectAutoWidth:false"  ng-model="userBalance.transaction_type" ng-change="changeBalanceButtonText()">
									{{lang.debit}}
								</label>
							</div>
						</div>
						<div class="form-group">
							<label data-ng-bind="lang.amount"></label>
							<input type="text" name="amount" id="amount" class="form-control" ng-model="userBalance.amount" maxlength="7" intiger-only>
							<label for="amount" class="error hide" id="amount_error"></label>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="userbalance={}" data-ng-bind="lang.close"></button>
						<button type="submit" class="btn btn-primary" id="manage_balance_btn">{{lang.add_balance}}</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /Add User Balance modal -->
	<!-- Inactive User modal -->
	<div id="user_inactive_modal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" data-ng-bind="lang.manage_inactive"></h5>
				</div>
				<!-- Inactive User modal -->
				<form  role="form" banuser-form submit-handle="changeUserStatus(userObj.user_unique_id,userObj.status,userObj.index)">
					<div class="modal-body has-padding">
						
						<div class="form-group">
							<label data-ng-bind="lang.reason"></label>
							<textarea class="form-control" id="reason" name="reason" ng-model="userObj.reason"></textarea>
							<label for="reason" class="error hide" id="reason_error"></label>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="userObj={}" data-ng-bind="lang.close"></button>
						<button type="submit" class="btn btn-primary"><i class=""></i>{{lang.inactive}}</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /Inactive User modal -->

	<!-- All Inactive User modal -->
	<div id="all_user_inactive_modal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" data-ng-bind="lang.manage_inactive"></h5>
				</div>
				<!-- Inactive User modal -->
				<form  role="form" banuser-form submit-handle="changeSelectedUserStatus()">
					<div class="modal-body has-padding">
						<div class="form-group">
							<label data-ng-bind="lang.reason"></label>
							<textarea class="form-control" id="reason" name="reason" ng-model="userObj.reason"></textarea>
							<label for="reason" class="error hide" id="reason_error"></label>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="userObj={};userObj.user_unique_id=[];deselectUser();" data-ng-bind="lang.close"></button>
						<button type="submit" class="btn btn-primary"><i class=""></i>{{lang.inactive}}</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /Inactive User modal -->

	<!-- Send Email To All Users -->
	<div id="send_email_all_model" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" data-ng-bind="lang.manage_send_email"></h5>
				</div>
				<!-- Inactive User modal -->
				<form  role="form" sendemail-all-form submit-handle="sendEmailAllUsers()">
					<div class="modal-body has-padding">
						<div class="form-group">
							<label data-ng-bind="lang.selected_email"></label>
							<div class="form-control" id="all_selected_email" disabled="" name="all_selected_email">All Users Selected</div>
						</div>
						<div class="form-group">
							<label data-ng-bind="lang.subject"></label>
							<input type="text" class="form-control" id="all_subject" name="all_subject" ng-model="userObj.subject">
							<label for="all_subject" class="error hide" id="all_subject_error"></label>
						</div>
						<div class="form-group">
							<label data-ng-bind="lang.message"></label>
							<textarea class="form-control" id="all_message" name="all_message" ng-model="userObj.message"></textarea>
							<label for="all_message" class="error hide" id="all_message_error"></label>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="userObj={};userObj.user_unique_id=[];deselectUser();" data-ng-bind="lang.close"></button>
						<button type="submit" class="btn btn-primary"><i class=""></i>{{lang.send_email}}</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /Send Email To All Users Model -->

	<!-- Send Email To All Users -->
	<div id="send_email_selected_model" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" data-ng-bind="lang.manage_send_email"></h5>
				</div>
				<!-- Inactive User modal -->
				<form role="form" sendemail-form submit-handle="sendEmailSelectedUser()">
					<div class="modal-body has-padding">
						<div class="form-group">
							<label data-ng-bind="lang.selected_email"></label>
							<textarea class="form-control" id="selected_email" disabled="" name="selected_email" ng-bind="userObj.selected_emails">
							</div>
							<label for="selected_email" class="error hide" id="selected_email_error"></label>
						</textarea>
						<div class="form-group">
							<label data-ng-bind="lang.subject"></label>
							<input type="text" class="form-control" id="subject" name="subject" ng-model="userObj.subject">
							<label for="subject" class="error hide" id="subject_error"></label>
						</div>
						<div class="form-group">
							<label data-ng-bind="lang.message"></label>
							<textarea class="form-control" id="message" name="message" ng-model="userObj.message"></textarea>
							<label for="message" class="error hide" id="message_error"></label>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="userObj={};userObj.user_unique_id=[];deselectUser();" data-ng-bind="lang.close"></button>
						<button type="submit" class="btn btn-primary"><i class=""></i>{{lang.send_email}}</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /Send Email To All Users Model -->
</div>
<!-- /Page content -->