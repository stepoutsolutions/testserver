<!-- Page content -->
<div class="content" data-ng-init="getUserDetailByID();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.user_informations}}</h5>
	</div>
	<!-- /page title -->
	<!-- User Detail Section Start -->
	<form class="form-horizontal" action="#" role="form" ng-if="userDetailLength > 0" >
		<div class="panel panel-default">
			<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.user_detail"></h6></div>
			<div class="panel-body">
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.first_name+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.first_name"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.last_name+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.last_name"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.user_name+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.user_name"></label>
							</div>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.email+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.email"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.balance+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="userDetail.balance | salaryFormat"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.date_of_birth+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.dob"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">					
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.city+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.city"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.street +' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.address"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.zip_code+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.zip_code"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.state+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.state_name"></label>
							</div>
						</div>
					</div>
				</div>

				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.country+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.country_name"></label>
							</div>
						</div>
					</div>
					<?php /* ?>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.cpf_no+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.cpf_no"></label>
							</div>
						</div>
					</div>
					<?php */ ?>
				</div>


				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.gender+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.gender"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.phone+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.phone_no"></label>
							</div>
						</div>
					</div>
				</div>

				<div class="form-group">
					
					<?php /*?><div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.favorite_club+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.team_name"></label>
							</div>
						</div>
					</div>
					<?php */ ?>
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.language+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.language"></label>
							</div>
						</div>
					</div>
				</div>

				<div class="form-group" ng-if="userDetail.facebook_id">
					<div class="col-md-6">
						<div class="row">
							<label class="col-sm-4 control-label text-right" data-ng-bind="lang.facebook+' : '"></label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="::userDetail.facebook_id"></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
	<div class="page-title" ng-if="userDetailLength == 0">
		<h5><i class="fa fa-user"></i>{{lang.invalid_user}}</h5>
	</div>
	<!-- User Detail Section End -->
	<!-- User Transaction History Section Start -->	
	<div class="panel panel-default" ng-if="userTransactions.length > 0">{{}}
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.users_transaction"></h6></div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortUserTransaction('description');">
							{{lang.description}}
							<i ng-class="(transParam.sort_field=='description'&&transParam.sort_order=='DESC')?'fa-sort-desc':((transParam.sort_field=='description'&&transParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserTransaction('status');">
							{{lang.withdrawal_status}}
							<i ng-class="(transParam.sort_field=='status'&&transParam.sort_order=='DESC')?'fa-sort-desc':((transParam.sort_field=='status'&&transParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserTransaction('transaction_amount');">
							{{lang.credit}}
							<i ng-class="(transParam.sort_field=='transaction_amount'&&transParam.sort_order=='DESC')?'fa-sort-desc':((transParam.sort_field=='transaction_amount'&&transParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" class="numeric" ng-click="sortUserTransaction('transaction_amount');">
							{{lang.debit}}
							<i ng-class="(transParam.sort_field=='transaction_amount'&&transParam.sort_order=='DESC')?'fa-sort-desc':((transParam.sort_field=='transaction_amount'&&transParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserTransaction('created_date');">
							{{lang.transaction_date}}
							<i ng-class="(transParam.sort_field=='created_date'&&transParam.sort_order=='DESC')?'fa-sort-desc':((transParam.sort_field=='created_date'&&transParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="transaction in userTransactions">
						<td data-ng-bind="::transaction.description"></td>
						<td>
							<span ng-if="transaction.status==0">Pending</span>
							<span ng-if="transaction.status==1">Approved</span>
							<span ng-if="transaction.status==2">Rejected</span>
						</td>
						<td>
							<span ng-if="transaction.payment_type==2" data-ng-bind-html="transaction.transaction_amount | salaryFormat"></span>
						</td>
						<td>
							<span ng-if="transaction.payment_type==1" data-ng-bind-html="transaction.transaction_amount | salaryFormat"></span>
						</td>
						<td data-ng-bind="::transaction.created_date"></td>
					</tr>
				</tbody>
			</table>
		</div>

		<div class="table-footer" ng-if="transParam.total_items>10">
			<pagination boundary-links="true" total-items="transParam.total_items" ng-model="transParam.current_page" ng-change="userTransactionHistory()" items-per-page="transParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- User Transaction History End -->

	<!-- User Game Section Start -->
	<div class="panel panel-default" ng-if="gameList.length>0">
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.user_games"></h6></div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortGameList('game_name');">
							{{lang.game}}
							<i ng-class="(gameParam.sort_field=='game_name'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='game_name'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('size');">
							{{lang.entrants}}
							<i ng-class="(gameParam.sort_field=='size'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='size'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('entry_fee');">
							{{lang.fees}}
							<i ng-class="(gameParam.sort_field=='entry_fee'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='entry_fee'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('prize_pool');">
							{{lang.prize_pool}}
							<i ng-class="(gameParam.sort_field=='prize_pool'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='prize_pool'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('season_scheduled_date');">
							{{lang.start_time}}
							<i ng-class="(gameParam.sort_field=='season_scheduled_date'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='season_scheduled_date'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="game in gameList">
						<td data-ng-bind="::game.contest_name"></td>
						<td>{{game.total_user_joined}}/
							<label ng-if="game.size!=-1">{{game.size}}</label>
							<label ng-if="game.size==-1">&#8734</label>
						</td>
						<td data-ng-bind-html="game.entry_fee | salaryFormat"></td>
						<td data-ng-bind-html="game.prize_pool | salaryFormat"></td>
						<td data-ng-bind="::game.season_scheduled_date"></td>
					</tr>
				</tbody>
			</table>
		</div>

		<div class="table-footer" ng-if="gameParam.total_items>10">
			<pagination boundary-links="true" total-items="gameParam.total_items" ng-model="gameParam.current_page" ng-change="getGameList()" items-per-page="gameParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- User Game End -->
</div>
<!-- /Page content -->