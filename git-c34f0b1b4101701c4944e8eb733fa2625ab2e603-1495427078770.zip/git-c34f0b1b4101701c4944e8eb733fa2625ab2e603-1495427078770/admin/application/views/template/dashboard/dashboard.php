<!-- Page content -->
<div class="content" ng-init="getDashboard()">
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>{{lang.dashboard_label}}</h5>
		<!-- <span class="pull-right"></span> -->
		<select class="pull-right" name="withdrawal_type" id="withdrawal_type" ng-change="getDashboard()" ng-model="filter" data-placeholder="Select Filter" class="select-full" select-two="minimumResultsForSearch:'-2',width:'150px'">
			<option value="">All</option>
			<option value="today">Today</option>
			<option value="yesterday">Yesterday</option>
			<option value="week">This week</option>
			<option value="month">This month</option>
			<option value="threemonth">Last 3 month</option>
			<option value="year">This year</option>
			<option value="custom">Custom</option>
		</select>
	</div>
	<ul class="row stats">
		<li class="col-xs-2"><a href="#" class="btn btn-default" ng-bind="dashboardDetail.total_users"></a> <span>Total Users</span></li>
		<li class="col-xs-2"><a href="#" class="btn btn-default" ng-bind="dashboardDetail.earning | salaryFormat"></a> <span>Entry Fees</span></li>
		<li class="col-xs-3"><a href="#" class="btn btn-default" ng-bind="dashboardDetail.in_progress_game_commission | salaryFormat"></a> <span>Site Commission of In Progress Games</span></li>
		<li class="col-xs-3"><a href="#" class="btn btn-default" ng-bind="dashboardDetail.total_earning | salaryFormat"></a> <span>Total entry fees as of today</span></li>
		<li class="col-xs-2"><a href="#" class="btn btn-default" ng-bind="dashboardDetail.in_progress_total_game"></a> <span>Total games in progress</span></li>
	</ul>
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title">CONTEST</h6>
		</div>
		<div class="panel-body">
			<div class="graph-fullwidth">
				<div google-chart chart="generalGraphData" id="general_graph" class="chart-div"></div>
			</div>
		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title">TOTAL GAMES CREATED</h6><a href="javascript:void(0);" class="pull-right btn btn-default" data-ng-bind="contestDetail.total_contest">25</a></div>
		<div class="panel-body">
			<div class="col-md-6">
				<div class="graph-medium">
					<div google-chart chart="contestPPGraphData" id="contest_pp" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="contestGraph.contest_chart_public_private.private"></a> <span>Private</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="contestGraph.contest_chart_public_private.public"></a> <span>Public</span></li>
				</ul>
			</div>
			<div class="col-md-6">
				<div class="graph-medium">	
					<div google-chart chart="contestAUGraphData" id="contest_au" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="contestGraph.contest_chart_user_admin.user"></a> <span>User</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="contestGraph.contest_chart_user_admin.admin"></a> <span>Admin</span></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title">ENTRY FEE PAID</h6><a href="javascript:void(0);" class="pull-right btn btn-default" data-ng-bind="earningDetail.total_entry_fees | salaryFormat"></a></div>
		<div class="panel-body">
			<div class="col-md-6">
				<div class="graph-medium">
					<div google-chart chart="earningPPGraphData" id="earning_pp" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="earningGraphData.entry_fee_chart_public_private.private | salaryFormat"></a> <span>Private</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="earningGraphData.entry_fee_chart_public_private.public | salaryFormat"></a> <span>Public</span></li>
				</ul>
			</div>
			<div class="col-md-6">
				<div class="graph-medium">	
					<div google-chart chart="earningAUGraphData" id="earning_au" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="earningGraphData.entry_fee_chart_user_admin.user | salaryFormat"></a> <span>User</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="earningGraphData.entry_fee_chart_user_admin.admin | salaryFormat"></a> <span>Admin</span></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title">PRIZE MONEY</h6><a href="javascript:void(0);" class="pull-right btn btn-default" data-ng-bind="prizeDetail.total_prize | salaryFormat"></a></div>
		<div class="panel-body">
			<div class="col-md-6">
				<div class="graph-medium">
					<div google-chart chart="prizePPGraphData" id="earning_pp" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="prizeGraphData.prize_chart_public_private.private | salaryFormat"></a> <span>Private</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="prizeGraphData.prize_chart_public_private.public | salaryFormat"></a> <span>Public</span></li>
				</ul>
			</div>
			<div class="col-md-6">
				<div class="graph-medium">	
					<div google-chart chart="prizeAUGraphData" id="earning_au" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="prizeGraphData.prize_chart_user_admin.user | salaryFormat"></a> <span>User</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="prizeGraphData.prize_chart_user_admin.admin | salaryFormat"></a> <span>Admin</span></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title">REVENUE EARNED </h6><a href="javascript:void(0);" class="pull-right btn btn-default" data-ng-bind="siteCommissionDetail.total_commission | salaryFormat"></a></div>
		<div class="panel-body">
			<div class="col-md-6">
				<div class="graph-medium">
					<div google-chart chart="siteCommissionPPGraphData" id="earning_pp" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="siteCommissionGraphData.site_commission_chart_public_private.private | salaryFormat"></a> <span>Private</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="siteCommissionGraphData.site_commission_chart_public_private.public | salaryFormat"></a> <span>Public</span></li>
				</ul>
			</div>
			<div class="col-md-6">
				<div class="graph-medium">
					<div google-chart chart="siteCommissionAUGraphData" id="earning_pp" class="chart-div"></div>
				</div>
				<ul class="row stats margin-zero">
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="siteCommissionGraphData.site_commission_chart_user_admin.user | salaryFormat"></a> <span>User</span></li>
					<li class="col-xs-6"><a href="#" class="btn btn-default" data-ng-bind="siteCommissionGraphData.site_commission_chart_user_admin.admin | salaryFormat"></a> <span>Admin</span></li>
				</ul>
			</div>
		</div>
	</div>
	
</div>
<!-- Page content -->

<div>
	
</div>