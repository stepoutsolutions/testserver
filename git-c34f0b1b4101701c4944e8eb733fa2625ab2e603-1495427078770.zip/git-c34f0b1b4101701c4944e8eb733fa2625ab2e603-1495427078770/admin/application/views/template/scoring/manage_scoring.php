<!--Page content -->
<div class="content" data-ng-init="sc.get_scoring_filters()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.manage_scoring_label}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters">
			</h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.sports"></th>
						<th data-ng-bind="lang.scoring_cat"></th>
						<th data-ng-bind="lang.formats"></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center" ng-if="sc.master_sports">
							<select data-placeholder="{{lang.select_sports}}" id="sports_id" ng-model="sc.scoreParam.sport_id" data-ng-change="sc.filter_result('sport')" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value=""></option>
								<option ng-repeat="sport in sc.master_sports" value="{{sport.sports_id}}" ng-bind="sport.sports_name"></option>
							</select>
						</td>
						<td class="text-center">
							<select data-placeholder="{{lang.select_cat}}" id="cat_id" ng-model="sc.scoreParam.cat_id" data-ng-change="sc.filter_result()" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value=""></option>
								<option ng-repeat="category in sc.category['scoring_cat']" value="{{category.master_scoring_category_id}}" ng-bind="category.scoring_category_name  | removeUnderScore | titleCase" ng-if="sc.category"></option>
							</select>
						</td>

						<td class="text-center">
							<select data-placeholder="{{lang.select_format}}" id="format" ng-model="sc.scoreParam.format" data-ng-change="sc.filter_result()" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value="" data-ng-bind="lang.all_format"></option>
								<option ng-repeat="(key,value) in sc.master_format" value="{{key}}" ng-bind="value" ng-if="sc.master_format"></option>
							</select>
						</td>

					</tr>
					<tr>
						<td>
							<a href="javascript:void(0);" ng-click="sc.clear_filter()">
								<span class="label label-info" data-ng-bind="lang.clear_filters"></span>
							</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.scoring_management"></h6>
			</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered">
						<tbody>
							<tr ng-show="sc.master_scoring_rules.length == 0">
								<td data-ng-bind="lang.no_scoring_found">No Scoring Found</td>
							</tr>
							<tr ng-hide="sc.master_scoring_rules.length == 0">
								<td data-ng-bind="lang.formats"></td>
								<td data-ng-bind="lang.rule_info"></td>
								<td data-ng-bind="lang.points"></td>
							</tr>
							<tr ng-repeat="scoring in sc.master_scoring_rules">
								<td class="">
									<span ng-if="scoring.format == '1'" ng-bind="lang.format_one_day"></span>
									<span ng-if="scoring.format == '2'" ng-bind="lang.format_test"></span>
									<span ng-if="scoring.format == '3'" ng-bind="lang.format_t20"></span>
								</td>
								<td class="" ng-bind="scoring.score_position"></td>
								<td class="text-center">
									<input type="text" class="form-control"  ng-init="sc.score_param[$index].score_points = scoring.score_points;sc.score_param[$index].master_scoring_id = scoring.master_scoring_id" ng-model="sc.score_param[$index].score_points" nks-only-number allow-decimal="true" decimal-upto="2" allow-negative="true">
									<label for="" class="error hide" id="score_point_{{scoring.master_scoring_id}}_error"></label>
								</td>
							</tr>
							<!-- <tr ng-hide="sc.master_scoring_rules.length == 0">
								<td colspan="2">
									<button type="button" class="btn btn-success" ng-click="sc.update_master_scoring();"><i class=""></i>{{lang.update}}</button>
								</td>
							</tr> -->
						</tbody>
					</table>
				</div>
				<div class="form-actions text-left" ng-hide="sc.master_scoring_rules.length == 0">
					<div class="form-group">
							<button type="button" class="btn btn-success" ng-click="sc.update_master_scoring();"><i class=""></i>{{lang.update}}</button>
					</div>
				</div>
			</div>
		</div>
</div>
<!-- /Page content-->
