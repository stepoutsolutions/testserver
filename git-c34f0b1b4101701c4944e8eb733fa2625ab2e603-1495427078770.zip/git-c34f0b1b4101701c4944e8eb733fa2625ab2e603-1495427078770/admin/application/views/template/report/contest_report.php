<!--Page content -->
<div class="content" data-ng-init="initContestReportObject();getContestReport()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.contest_report}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th  width="50%" data-ng-bind="lang.select_date"></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td  width="50%">
							<div class="col-sm-6">
								<input type="text" class="from-date form-control" name="from" date-picker-range="to-date" placeholder="{{lang.from}}" ng-model="contestReportParam.from_date" readonly="">
							</div>
							<div class="col-sm-6">
								<input type="text" class="to-date form-control" name="to" date-picker-range placeholder="{{lang.to}}" ng-model="contestReportParam.to_date" data-ng-change="filterContestReport()" readonly="">
							</div>
						</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="clearContestReportFilter()"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.contest_report_list"></h6>
			<div class="dropdown pull-right" ng-if="contestReportList.length > 0">
				<a href="#" class="btn btn-link btn-lg btn-icon dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cogs"></i><span class="caret"></span></a>
				<ul class="dropdown-menu dropdown-menu-right">
					<li><a href="javascript:void(0);" ng-click="exportContestReport()" data-ng-bind="lang.export_contest_report"></a></li>
				</ul>
			</div>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="contestReportList.length>0">
						<th class="pointer" ng-click="sortContestReport('first_name');">
							{{lang.name}}
							<i ng-class="(contestReportParam.sort_field=='first_name'&&contestReportParam.sort_order=='DESC')?'fa-sort-desc':((contestReportParam.sort_field=='first_name'&&contestReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortContestReport('user_name');">
							
							{{lang.username}}
							<i ng-class="(contestReportParam.sort_field=='user_name'&&contestReportParam.sort_order=='DESC')?'fa-sort-desc':((contestReportParam.sort_field=='user_name'&&contestReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortContestReport('country_name');">
							
							{{lang.country}}
							<i ng-class="(contestReportParam.sort_field=='country_name'&&contestReportParam.sort_order=='DESC')?'fa-sort-desc':((contestReportParam.sort_field=='country_name'&&contestReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.contest_unique_id">	
						</th>
						<th class="pointer" ng-click="sortContestReport('size');">
							{{lang.entrants}}
							<i ng-class="(contestReportParam.sort_field=='size'&&contestReportParam.sort_order=='DESC')?'fa-sort-desc':((contestReportParam.sort_field=='size'&&contestReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortContestReport('entry_fee');">
							
							{{lang.entery_fees}}
							<i ng-class="(contestReportParam.sort_field=='entry_fee'&&contestReportParam.sort_order=='DESC')?'fa-sort-desc':((contestReportParam.sort_field=='entry_fee'&&contestReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortContestReport('league_abbr');">
							{{lang.league_description}}
							<i ng-class="(contestReportParam.sort_field=='league_abbr'&&contestReportParam.sort_order=='DESC')?'fa-sort-desc':((contestReportParam.sort_field=='league_abbr'&&contestReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.salary_cap">
						</th>
						<th data-ng-bind="lang.prize_type"></th>
						<th data-ng-bind="lang.game_status"></th>
						<th data-ng-bind="lang.won"></th>
						<th data-ng-bind="lang.promo_code"></th>
						<th data-ng-bind="lang.amount_received"></th>
						<th data-ng-bind="lang.promo_code_benefit"></th>
					</tr>
					<tr ng-if="contestReportList.length==0">
						<td align="center" colspan="4" data-ng-bind="lang.no_contest_report"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="contestReportList.length>0" ng-repeat="contestreport in contestReportList">
						<td data-ng-bind ="::contestreport.name"></td>
						<td data-ng-bind ="::contestreport.user_name"></td>
						<td data-ng-bind ="::contestreport.country_name"></td>
						<td data-ng-bind ="::contestreport.contest_unique_id"></td>
						<td align="center" data-ng-bind ="::contestreport.size"></td>
						<td align="center" data-ng-bind ="contestreport.entry_fee | salaryFormat"></td>
						<td data-ng-bind ="::contestreport.league_abbr"></td>
						<td align="left"data-ng-bind ="::contestreport.salary_cap"></td>
						<td data-ng-bind ="::contestreport.prize_type"></td>
						<td data-ng-bind ="::contestreport.game_status"></td>
						<td data-ng-bind ="::contestreport.won"></td>
						<td data-ng-bind ="::contestreport.promo_code"></td>
						<td align="center" data-ng-bind ="contestreport.amount_received | salaryFormat"></td>
						<td align="center" data-ng-bind ="contestreport.promo_code_benefit | salaryFormat"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="contestReportParam.total_items>50">
			<pagination ng-if="contestReportParam.total_items>50" boundary-links="true" total-items="contestReportParam.total_items" ng-model="contestReportParam.current_page" ng-change="getTeamList()" items-per-page="contestReportParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->