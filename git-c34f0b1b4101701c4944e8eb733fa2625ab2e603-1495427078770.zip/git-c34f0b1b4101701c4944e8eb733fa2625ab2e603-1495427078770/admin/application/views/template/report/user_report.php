<!--Page content -->
<div class="content" data-ng-init="initUserReportObject();getUserReport();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.user_report}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th  width="50%" data-ng-bind="lang.select_date"></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td  width="50%">
							<div class="col-sm-6">
								<input type="text" class="from-date form-control" name="from" date-picker-range="to-date" set-date="-2year" placeholder="{{lang.from}}" ng-model="userReportParam.from_date" readonly="">
							</div>
							<div class="col-sm-6">
								<input type="text" class="to-date form-control" name="to" date-picker-range set-date="today" placeholder="{{lang.to}}" ng-model="userReportParam.to_date" data-ng-change="filterUserReport()" readonly="">
							</div>
						</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="filterUserReport()" class="btn btn-primary" ng-disabled="userReportParam.from_date == '' && userReportParam.to_date == ''">Search</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.user_report_list"></h6>
			<div class="dropdown pull-right" ng-if="userReportList.length > 0">
				<a href="#" class="btn btn-link btn-lg btn-icon dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cogs"></i><span class="caret"></span></a>
				<ul class="dropdown-menu dropdown-menu-right">
					<li><a href="javascript:void(0);" ng-click="exportUserReport()" data-ng-bind="lang.export_user_report"></a></li>
				</ul>
			</div>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="userReportList.length>0">
						<th class="pointer" ng-click="sortUserReport('user_name');">	
							{{lang.username}}
							<i ng-class="(userReportParam.sort_field=='user_name'&&userReportParam.sort_order=='DESC')?'fa-sort-desc':((userReportParam.sort_field=='user_name'&&userReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserReport('first_name');">	
							{{lang.name}}
							<i ng-class="(userReportParam.sort_field=='first_name'&&userReportParam.sort_order=='DESC')?'fa-sort-desc':((userReportParam.sort_field=='first_name'&&userReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserReport('country_name');">
							{{lang.country}}
							<i ng-class="(userReportParam.sort_field=='country_name'&&userReportParam.sort_order=='DESC')?'fa-sort-desc':((userReportParam.sort_field=='country_name'&&userReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserReport('email');">
							{{lang.email}}
							<i ng-class="(userReportParam.sort_field=='email'&&userReportParam.sort_order=='DESC')?'fa-sort-desc':((userReportParam.sort_field=='email'&&userReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUserReport('dob');">
							{{lang.dob}}
							<i ng-class="(userReportParam.sort_field=='dob'&&userReportParam.sort_order=='DESC')?'fa-sort-desc':((userReportParam.sort_field=='dob'&&userReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.deposited">
						</th>
						<th data-ng-bind="lang.withdrawal">
							
						</th>
						<th class="pointer" ng-click="sortUserReport('balance');">
							{{lang.current_balance}}
							<i ng-class="(userReportParam.sort_field=='balance'&&userReportParam.sort_order=='DESC')?'fa-sort-desc':((userReportParam.sort_field=='balance'&&userReportParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.matches_played">
							
						</th>
						<th data-ng-bind="lang.matches_won">
							
						</th>
						<th data-ng-bind="lang.matches_lost">
							
						</th>
						<th data-ng-bind="lang.prize_amount_won">
							
						</th>
						<th data-ng-bind="lang.prize_amount_lost">
						</th>
					</tr>
					<tr ng-if="userReportList.length==0">
						<td align="center" colspan="4" data-ng-bind="lang.no_user_report"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="userReportList.length>0" ng-repeat="userreport in userReportList">
						<td ng-bind="::userreport.user_name"></td>
						<td ng-bind="::userreport.name"></td>
						<td ng-bind="::userreport.country_name"></td>
						<td ng-bind="::userreport.email"></td>
						<td ng-bind="::userreport.dob"></td>
						<td ng-bind="::userreport.deposit_by_user"></td>
						<td ng-bind="::userreport.withdraw_by_user"></td>
						<td ng-bind="::userreport.balance"></td>
						<td ng-bind="::userreport.matches_played"></td>
						<td ng-bind="::userreport.matches_won"></td>
						<td ng-bind="::userreport.matches_lost"></td>
						<td ng-bind="::userreport.prize_amount_won"></td>
						<td ng-bind="::userreport.prize_amount_lost"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="userReportList.length>0">
			<pagination ng-if="userReportParam.total_items>50" boundary-links="true" total-items="userReportParam.total_items" ng-model="userReportParam.current_page" ng-change="getUserReport()" items-per-page="userReportParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->