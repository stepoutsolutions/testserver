<!--Page content -->
<div class="content" data-ng-init="initContestUsersReportObject();getContestUsersReport()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.contest_users_report}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th  width="50%" data-ng-bind="lang.select_date"></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td  width="50%">
							<div class="col-sm-6">
								<input type="text" class="from-date form-control" name="from" date-picker-range="to-date" placeholder="{{lang.from}}" ng-model="contestUsersReportParam.from_date" readonly="">
							</div>
							<div class="col-sm-6">
								<input type="text" class="to-date form-control" name="to" date-picker-range placeholder="{{lang.to}}" ng-model="contestUsersReportParam.to_date" data-ng-change="filterContestUsersReport()" readonly="">
							</div>
						</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="clearContestUsersReportFilter()"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.contest_users_report_list"></h6>
			<div class="dropdown pull-right" ng-if="contestUsersReportList.length > 0">
				<a href="#" class="btn btn-link btn-lg btn-icon dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cogs"></i><span class="caret"></span></a>
				<ul class="dropdown-menu dropdown-menu-right">
					<li><a href="javascript:void(0);" ng-click="exportContestUsersReport()" data-ng-bind="lang.export_contest_users_report"></a></li>
				</ul>
			</div>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="contestUsersReportList.length>0">
						<th data-ng-bind="lang.contest_created_by" width="10%"></th>
	                    <th data-ng-bind="lang.total_contest_created"></th>
	                    <th data-ng-bind="lang.total_contest_completed"></th>
	                    <th data-ng-bind="lang.total_contest_cancelled"></th>
	                    <th data-ng-bind="lang.total_contest_in_progress"></th>
					</tr>
					<tr ng-if="contestUsersReportList.length==0">
						<td align="center" colspan="4" data-ng-bind="lang.no_contest_users_report"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="contestUsersReportList.length>0" ng-repeat="contestusersreport in contestUsersReportList">
						<td data-ng-bind = "contestusersreport.contest_created_by"></td>
	                    <td data-ng-bind = "contestusersreport.total_contest_created"></td>
	                    <td data-ng-bind = "contestusersreport.total_contest_completed"></td>
	                    <td data-ng-bind = "contestusersreport.total_contest_cancelled"></td>
	                    <td data-ng-bind = "contestusersreport.total_contest_in_progress"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="contestUsersReportParam.total_items>50">
			<pagination ng-if="contestUsersReportParam.total_items>50" boundary-links="true" total-items="contestUsersReportParam.total_items" ng-model="contestUsersReportParam.current_page" ng-change="getContestUsresReport()" items-per-page="contestUsersReportParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->