<!-- Page content -->
<div class="content" data-ng-init="initObject('');getFilterData();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.user_activity}}</h5>
	</div>
	<!-- /page title -->
	<!-- Filter Section -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.duration"></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center" width="50%">
							<select name="activity_duration" id="activity_duration" data-placeholder="{{lang.all}}" class="select-full" ng-model="userParam.activity_duration" data-ng-change="getUserList();resetDates();" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value=""  data-ng-bind="lang.all"></option>
								<option value="1" data-ng-bind="lang.today"></option>
								<option value="2" data-ng-bind="lang.this_month"></option>
								<option value="3" data-ng-bind="lang.this_year"></option>
								<option value="4" data-ng-bind="lang.custom"></option>
							</select>
						</td>
						
						<td class="text-center" width="50%">
							<div class="col-sm-6" ng-show="userParam.activity_duration == '4'">
								<input type="text" class="from-date form-control" name="from" date-picker-range="to-date" placeholder="{{lang.from}}" ng-model="userParam.fromdate" readonly="">
							</div>
							<div class="col-sm-6" ng-show="userParam.activity_duration == '4'">
								<input type="text" class="to-date form-control" name="to" date-picker-range placeholder="{{lang.to}}" ng-model="userParam.todate" data-ng-change="getUserList()" readonly="">
							</div>
						</td>
					</tr>
					<tr>
						<td colspan="3">
							<a href="javascript:void(0);" ng-click="initObject('clear')"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /Filter Section -->
	<!-- User Listing -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.users"></h6>
			
			<h6 class="panel-title pull-right">{{lang.total_record_count}} : <span ng-bind="userParam.total_items"></span></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered">
				<thead>
					<tr ng-if="userList.length > 0">
						<th>
							{{lang.username}}
						</th>
						<th class="pointer" ng-click="sortUesrList('first_name');">
							{{lang.name}}
							<i ng-class="(userParam.sort_field=='first_name'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='first_name'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('email');">
							{{lang.email}}
							<i ng-class="(userParam.sort_field=='email'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='email'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('MC.country_name');">
							{{lang.country}}
							<i ng-class="(userParam.sort_field=='MC.country_name'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='MC.country_name'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('added_date');">
							{{lang.member_since}}
							<i ng-class="(userParam.sort_field=='added_date'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='added_date'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('last_login');">
							{{lang.last_login}}
							<i ng-class="(userParam.sort_field=='last_login'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='last_login'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortUesrList('login_count');">
							{{lang.login_count}}
							<i ng-class="(userParam.sort_field=='login_count'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='login_count'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" class="numeric" ng-click="sortUesrList('balance');">
							{{lang.balance}}
							<i ng-class="(userParam.sort_field=='balance'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='balance'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						
						<th class="pointer" ng-click="sortUesrList('status');">
							{{lang.status}}
							<i ng-class="(userParam.sort_field=='status'&&userParam.sort_order=='DESC')?'fa-sort-desc':((userParam.sort_field=='status'&&userParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						
					</tr>
				</thead>
				<tbody>
					<tr ng-if="userList.length > 0" ng-repeat="user in userList">
						<td><img ng-src="{{user.image}}" class="user-avatar">{{user.user_name}}</td>
						<td data-ng-bind="::user.name"></td>
						<td data-ng-bind="::user.email"></td>
						<td data-ng-bind="::user.country_name"></td>
						<td data-ng-bind="::user.member_since"></td>
						<td data-ng-bind="::user.last_login"></td>
						<td data-ng-bind="::user.login_count"></td>
						<td data-ng-bind-html="user.balance | salaryFormat"></td>
						<td>
							<i class="fa fa-trash-o danger" ng-show="user.status==4" title="{{lang.user_deleted_title}}"></i>
							<i class="fa fa-ban danger" ng-show="user.status==3" title="{{lang.user_banned_title}}"></i>
							<i class="fa fa-warning danger" ng-show="user.status==2" title="{{lang.user_email_not_verified_title}}"></i>
							<i class="fa fa-unlock success" ng-show="user.status==1" title="{{lang.user_active_title}}"></i>
							<i class="fa fa-lock danger" ng-show="user.status==0" title="{{lang.user_activation_pending_title}}"></i>
						</td>
					</tr>
					<tr ng-if="userList.length == 0">
						<td colspan="9" align="center" data-ng-bind="lang.no_record_found"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="userList.length>0">
			<pagination boundary-links="true"  ng-if="userParam.total_items>50" total-items="userParam.total_items" ng-model="userParam.current_page" ng-change="getUserList()" items-per-page="userParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /User Listing -->
	
</div>
<!-- /Page content -->