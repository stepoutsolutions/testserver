<?php echo $this->load->view('emailer/header');?>
<tr>
	<td class="" height="190" valign="top" style="background: #FFF;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%" style="padding:20px 20px;">
					<?php echo $message; ?>
				</td>
			</tr>
		</table>
	</td>
</tr>

<?php echo $this->load->view('emailer/footer'); ?>