<style type="text/css">
	/*br{display: none!important;}*/
</style>
<div class="content" id="container">
	<div class="title"><h5>Send Emails</h5></div>
	<!-- Form begins -->
        <div class="nNote nSuccess hideit success_message " ng-show="message==1" ng-click="hidemsg()" hide-message="{{messagedetail}}">
                <p><strong>SUCCESS: </strong><span ng-bind="messagedetail"></span></p>
        </div>
        <div class="nNote nFailure hideit error_message " ng-show="message==2" ng-click="hidemsg()" hide-message="{{messagedetail}}">
                <p><strong>ERROR: </strong><span ng-bind="messagedetail"></span></p>
        </div>
        
        <form class="mainForm" id="valid">
		
                <div class="widget first">
                        <div class="head">
                                <h5 class="iList">Send Email to All Sub-Admin</h5>
                        </div>

                        <div class="rowElem">
                                <label for="size">Subject</label>
                                <div class="formRight">
                     <input type="text" name="subject" id="subject" ng-model="subject" maxlength="150" class="validate[required,maxSize[150]]" style="width:50%;"/>
                                </div>
                                <div class="fix"></div>
                        </div>

                          <div class="rowElem">
                                <label>Message</label>
                                <div class="formRight">
                                        <textarea rows="8" cols="" name="message" id="message" maxlength="2000" class="wysiwyg validate[required,maxSize[2000]]" style="width:50%;"></textarea>
                                </div>
                                <div class="fix"></div>
                          </div>

                        <div class="rowElem">
                                <label for="">&nbsp;</label>
                                <div class="formRight">
                     <input type="button" value="Submit" class="greyishBtn" id="send_emails" ng-click="sendEmailToAdmins();"/>
                                </div>
                                <div class="fix"></div>
                        </div>
                        <div class="fix"></div>
                </div>
		
	</form>
</div>
<!--<style type="text/css">
	.paste,.cut,.copy,.h1,.h2,.h3,.h4,.h5,.h6,.insertImage,.insertTable,.code,.separator,.removeFormat,.html,.createLink,.insertUnorderedList,.insertOrderedList,.redo,.undo,.outdent,.indent{display:none!important;} 
</style>-->

<script>
//CKEDITOR.replace( 'message' );
$("#valid").validationEngine();
</script>

