<!--Page content -->
<div class="content" ng-init="initAdvertisement();getAdminGroup();">
    <!-- Page title -->
    <div class="page-title">
        <h5><i class="fa fa-align-justify"></i>Admin Management</h5>
    </div>
    <!-- page title -->

    <!-- New Promocode Section Start -->
    <form class="" role="form" subadmin-form submit-fun="addAdminUser()" role="form">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6 class="panel-title">Create </h6>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="row">
                        <label class="col-md-3 control-label" for="promo_code">Name
                            <span class="mandatory">*</span>
                        </label>
                        <div class="col-md-9">
                            <input id="name" name="name" type="text" ng-model="AdminFormObj.firstname" class="form-control" maxlength="25">
                            <label for="name" class="error hide" id="name_error"></label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-md-3 control-label" for="discount">Username
                            <span class="mandatory">*</span>
                        </label>
                        <div class="col-md-9">
                            <input id="username" name="username" type="text" ng-model="AdminFormObj.username" class="form-control">
                            <label for="discount" class="error hide" id="username_error"></label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-md-3 control-label" for="discount">Email
                            <span class="mandatory">*</span>
                        </label>
                        <div class="col-md-9">
                            <input id="email" name="email" type="text" ng-model="AdminFormObj.email" class="form-control">
                            <label for="discount" class="error hide" id="email_error"></label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-md-3 control-label" for="discount">Password
                            <span class="mandatory">*</span>
                        </label>
                        <div class="col-md-9">
                            <input id="password" name="password" type="password" ng-model="AdminFormObj.password" class="form-control">
                            <label for="discount" class="error hide" id="password_error"></label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-md-3 control-label" for="discount">Confirm Password
                            <span class="mandatory">*</span>
                        </label>
                        <div class="col-md-9">
                            <input id="confpassword" name="confpassword" type="password" ng-model="AdminFormObj.confpassword" class="form-control">
                            <label for="discount" class="error hide" id="confpassword_error"></label>
                        </div>
                    </div>
                </div>
                    
                <div class="form-group">
                    <div class="row">
                        <label class="col-md-3 control-label" for="discount">Select Group
                            <span class="mandatory">*</span>
                        </label>
                        <div class="col-md-9">
                            <select ng-change="getSubGroup()" id="action" class="select-liquid" data-placeholder="Select Group" select-two="minimumResultsForSearch:'-1'" multiple ng-model="category_id">
                                <option value=""></option>                  
                                <option value="{{grp.category_id}}" ng-repeat="grp in grouplist" ng-bind="grp.category_name"></option>                 
                            </select>
                        </div>
                    </div>
                </div>            
            
                <div class="form-actions text-left">
                    <button type="submit" class="btn btn-success">
                        <i class=""></i>Submit
                    </button>
                    <a ng-href="manageadmin">
                        <button type="button" class="btn btn-warning">
                        Cancel
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </form>
    <!-- New Promocode Section End -->

</div>
<!-- Page content -->