<?php echo $this->load->view('emailer/header');?>
<tr>
	<td width="100%" style="padding:20px 20px 10px 20px;background-color:#FFFFFF;">
		<div class="sub-title" style="font-family:'Roboto' ,Arial, Helvetica, sans-serif; font-size:26px; color:#333; padding:0 0 8px;font-weight:bold">Hi <?php echo $name;?>,
		</div>
	 </td>
 </tr>
 <tr>				 
	<td style="padding:0 20px 20px 20px; vertical-align:top; background-color:#FFFFFF;">
	<p class="text" style="font-family:'Roboto' ,Arial, Helvetica, sans-serif; font-size:16px; line-height:20px; color:#333;">
            Your account has been created for Arabian Gulf League Admin. We are very excited to have you as admin.
        </p>
        
        <p class="text" style="font-family:'Roboto' ,Arial, Helvetica, sans-serif; font-size:16px; line-height:20px; color:#333;">
            Your login details are:
            <br>
            Email: <?php echo $email;?>
            <br>
            Password: <?php echo $password;?>
            <br>
            URL: <a href="<?php echo $link;?>" style="text-decoration:none">
                    <span style="color:#007EFB"><?php echo $link;?></span>
		</a>
	</p>

	</td>
</tr>
<?php echo $this->load->view('emailer/footer'); ?>