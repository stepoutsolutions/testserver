<!-- Page content -->
<div class="content" data- ng-init="getPromoCodes();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.promo_code_list}}</h5>
	</div>
	<!-- /page title -->

	<!-- Promocode Section -->
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.promo_code"></h6></div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="promoCodeList.length==0">
				<thead>
					<tr>
						<td align="center" data-ng-bind="lang.no_promo_code"></td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="promoCodeList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortPromoCodesList('promo_code');">
							{{lang.promo_code}}
							<i ng-class="(promoCodeParam.sort_field=='promo_code'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='promo_code'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('first_name');">
							{{lang.sales_person}}
							<i ng-class="(promoCodeParam.sort_field=='first_name'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='first_name'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('discount');">
							{{lang.discount}}
							<i ng-class="(promoCodeParam.sort_field=='discount'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='discount'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('benefit_cap');">
							{{lang.benifit_cap}}
							<i ng-class="(promoCodeParam.sort_field=='benefit_cap'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='benefit_cap'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.amount_received">
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('sales_person_commission');">
							{{lang.commission}}
							<i ng-class="(promoCodeParam.sort_field=='sales_person_commission'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='sales_person_commission'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('start_date');">
							{{lang.start_date}}
							<i ng-class="(promoCodeParam.sort_field=='start_date'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='start_date'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('expiry_date');">
							{{lang.end_date}}
							<i ng-class="(promoCodeParam.sort_field=='expiry_date'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='expiry_date'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodesList('status');">
							Status{{lang.status}}
							<i ng-class="(promoCodeParam.sort_field=='status'&&promoCodeParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeParam.sort_field=='status'&&promoCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.action">
							Action
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="promo in promoCodeList">
						<td data-ng-bind="::promo.promo_code"></td>
						<td data-ng-bind="::promo.sales_person_name"></td>
						<td data-ng-bind="::promo.discount"></td>
						<td data-ng-bind="promo.benefit_cap  | salaryFormat"></td>
						<td data-ng-bind="promo.amount_received  | salaryFormat"></td>
						<td data-ng-bind="::promo.sales_person_commission"></td>
						<td data-ng-bind="::promo.start_date"></td>
						<td data-ng-bind="::promo.expiry_date"></td>
						<td>
							<i class="fa fa-lock danger" ng-show="promo.status==0" title="Sales Person Activation Pending"></i>
							<i class="fa fa-unlock success" ng-show="promo.status==1" title="Sales Person Active"></i>
						</td>
						<td>
							<a href="promo_code_detail/{{promo.promo_code}}">
								<span class="label label-primary" data-ng-bind="lang.detail_view">Detail View</span>
							</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="promoCodeParam.total_items>10">
			<pagination boundary-links="true" total-items="promoCodeParam.total_items" ng-model="promoCodeParam.current_page" ng-change="getPromoCodes()" items-per-page="promoCodeParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!--Promocode End -->
</div>
<!-- /Page content -->