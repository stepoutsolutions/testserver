<!-- Page content -->
<div class="content" data-ng-init="getPromoCodeDetail()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.promo_code_detail_list}}</h5>
	</div>
	<!-- /page title -->

	<!-- Promo code detail End Section -->
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.promo_code_detail">Promo Code Detail <span ng-if="is_panel>0">{{salesPersonDetail.sales_person_name}} - {{salesPersonDetail.email}}</span></h6></div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="promoCodeDetailList.length==0">
				<thead>
					<tr>
						<td align="center" data-ng-bind="lang.no_promo_code_detail"></td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="promoCodeDetailList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortPromoCodeDetailList('promo_code');">
							{{lang.promo_code}}
							<i ng-class="(promoCodeDetailParam.sort_field=='promo_code'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='promo_code'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th  class="pointer" ng-click="sortPromoCodeDetailList('first_name');">
							{{lang.name}}
							<i ng-class="(promoCodeDetailParam.sort_field=='first_name'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='first_name'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodeDetailList('game_name');">
							{{lang.game_name}}
							<i ng-class="(promoCodeDetailParam.sort_field=='game_name'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='game_name'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.promo_code_detail">
							{{lang.game_status}}
						</th>
						<th class="pointer" ng-click="sortPromoCodeDetailList('size');">
							{{lang.entrants_participants}}
							<i ng-class="(promoCodeDetailParam.sort_field=='size'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='size'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodeDetailList('entry_fee');">
							{{lang.entry_fee}}
							<i ng-class="(promoCodeDetailParam.sort_field=='entry_fee'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='entry_fee'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodeDetailList('amount_received');">
							{{lang.amount_received}}
							<i ng-class="(promoCodeDetailParam.sort_field=='amount_received'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='amount_received'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodeDetailList('season_scheduled_date');">
							{{lang.contest_scheduled_date}}
							<i ng-class="(promoCodeDetailParam.sort_field=='season_scheduled_date'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='season_scheduled_date'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortPromoCodeDetailList('added_date');">
							{{lang.promocode_used_date}}
							<i ng-class="(promoCodeDetailParam.sort_field=='added_date'&&promoCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((promoCodeDetailParam.sort_field=='added_date'&&promoCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="promocode in promoCodeDetailList">
						<td data-ng-bind="::promocode.promo_code"></td>
						<td data-ng-bind="::promocode.full_name"></td>
						<td data-ng-bind="::promocode.game_name">
						<td data-ng-bind="promocode.status | uppercase"></td>
						<td>
							{{promocode.total_user_joined}}/
							<label ng-if="promocode.size!=-1">{{promocode.size}}</label>
							<label ng-if="promocode.size==-1">&#8734</label>
						</td>
						<td data-ng-bind="promocode.entry_fee | salaryFormat"></td>
						<td data-ng-bind="promocode.amount_received | salaryFormat"></td>
						<td data-ng-bind="::promocode.season_scheduled_date"></td>
						<td data-ng-bind="::promocode.added_date"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="promoCodeDetailParam.total_items>10">
			<pagination boundary-links="true" total-items="promoCodeDetailParam.total_items" ng-model="promoCodeDetailParam.current_page" ng-change="getPromoCodeDetail()" items-per-page="promoCodeDetailParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- Promo code detail End -->
</div>
<!-- /Page content -->