<!--Page content -->
<div class="content" data-ng-init="getAllCountry()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>{{lang.new_sales_person}}</h5>
	</div>
	<!-- page title -->

	<!-- New Sales Person Section Start -->
	<form class="form-horizontal" role="form" salesperson-form submit-handle="newSalesPerson()">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.sales_person">Sales Person</h6>
			</div>
			<div class="panel-body">
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="first_name">{{lang.first_name}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="first_name" name="first_name" type="text" ng-model="salesPersonParam.first_name" class="form-control">
								<label for="first_name" class="error hide" id="first_name_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="last_name">{{lang.last_name}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="last_name" name="last_name" type="text" ng-model="salesPersonParam.last_name" class="form-control">
								<label for="last_name" class="error hide" id="last_name_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="email">{{lang.email}}<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<input id="email" name="email" type="text" ng-model="salesPersonParam.email" class="form-control">
								<label for="email" class="error hide" id="email_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
							<div class="row">
								<label class="col-md-3 control-label" for="email">{{lang.paypal_email}}<span class="mandatory">*</span></label>
								<div class="col-md-9">
									<input id="paypal_email" name="paypal_email" type="text" ng-model="salesPersonParam.paypal_email" class="form-control">
									<label for="paypal_email" class="error hide" id="paypal_email_error"></label>
								</div>
							</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="date">{{lang.date_of_birth}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="dob" name="dob" type="text" class="form-control" ng-model="salesPersonParam.dob" date-picker on-select="setDob(date)" readonly>
								<label for="dob" class="error hide" id="dob_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="address" data-ng-bind="lang.address"></label>
							<div class="col-md-9">
								<input id="address" name="address" type="text" class="form-control" ng-model="salesPersonParam.address">
								<label for="address" class="error hide" id="address_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="zipcode" data-ng-bind="lang.zipcode"></label>
							<div class="col-md-9">
								<input id="zip_code" name="zip_code" type="text" intiger-only ng-model="salesPersonParam.zip_code" class="form-control">
								<label for="zip_code" class="error hide" id="zip_code_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="email" data-ng-bind="lang.city"></label>
							<div class="col-md-9">
								<input id="city" name="city" type="text" ng-model="salesPersonParam.city" class="form-control">
								<label for="city" class="error hide" id="city_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="country" data-ng-bind="lang.country"></label>
							<div class="col-md-9">
								<select id="master_country_id" name="master_country_id" data-placeholder="{{lang.select_country}}" ng-model="salesPersonParam.master_country_id" data-ng-change="getAllState()" class="select-full" select-two="minimumResultsForSearch:'2',width:'100%'">
									<option value=""></option>
									<option value="{{::country.master_country_id}}" ng-repeat="country in countryList track by country.abbr">{{::country.country_name}}</option>
								</select>
								<label for="master_country_id" class="error hide" id="master_country_id_error"></label>
							</div>
						</div>
					</div>				
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="master_state_id" data-ng-bind="lang.state">State : </label>
							<div class="col-md-9">
								<select id="master_state_id" name="master_state_id" data-placeholder="{{lang.select_state}}" ng-model="salesPersonParam.master_state_id" class="select-full" select-two="minimumResultsForSearch:'2',width:'100%'">
									<option value="" data-ng-bind="lang.select_state">Select State</option>
									<option value="{{::state.master_state_id}}" ng-repeat="state in stateList track by state.master_state_id">{{::state.name}}</option>
								</select>
								<label for="master_state_id" class="error hide" id="master_state_id_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success"><i class=""></i>{{lang.submit}}</button>
					<a ng-href="sales_person"><button type="button" class="btn btn-warning"></i>{{lang.cancel}}</button></a>
				</div>
			</div>
		</div>
	</form>
	<!-- New Sales Person Section End -->
</div>
<!-- Page content -->
