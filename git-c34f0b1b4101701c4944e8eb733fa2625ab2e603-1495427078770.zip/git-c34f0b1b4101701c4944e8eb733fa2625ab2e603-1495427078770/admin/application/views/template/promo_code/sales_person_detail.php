<!--Page content -->
<div class="content"  data-ng-init="getSalesPersonPayout()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>Sales Person Payout List</h5>
	</div>
	<!-- /page title -->

	<!-- Sales Person Detail Section -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title">Payout Detail <span ng-if="is_panel>0">({{salesPersonDetail.sales_person_name}} - {{salesPersonDetail.email}})</span></h6>
			<a ng-if="is_panel>0" href="javascript:void(0);" ng-click="getEarningDetail(salesPersonDetail.sales_person_id)" class="pull-right btn btn-xs btn-success">Manage Earning</a>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="salesPersonDetailList.length==0">
				<thead>
					<tr>
						<td align="center">No Sales Person Payout</td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="salesPersonDetailList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortSalesPersonPayoutList('promo_code');">
							Promo Code
							<i ng-class="(salesPersonDetailParam.sort_field=='promo_code'&&salesPersonDetailParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonDetailParam.sort_field=='promo_code'&&salesPersonDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonPayoutList('discount');">
							Discount(%)
							<i ng-class="(salesPersonDetailParam.sort_field=='discount'&&salesPersonDetailParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonDetailParam.sort_field=='discount'&&salesPersonDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonPayoutList('benefit_cap');">
							Benifit Cap
							<i ng-class="(salesPersonDetailParam.sort_field=='benefit_cap'&&salesPersonDetailParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonDetailParam.sort_field=='benefit_cap'&&salesPersonDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonPayoutList('sales_person_commission');">
							Commission(%)
							<i ng-class="(salesPersonDetailParam.sort_field=='sales_person_commission'&&salesPersonDetailParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonDetailParam.sort_field=='sales_person_commission'&&salesPersonDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonPayoutList('start_date');">
							Start Date
							<i ng-class="(salesPersonDetailParam.sort_field=='start_date'&&salesPersonDetailParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonDetailParam.sort_field=='start_date'&&salesPersonDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonPayoutList('expiry_date');">
							End Date
							<i ng-class="(salesPersonDetailParam.sort_field=='expiry_date'&&salesPersonDetailParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonDetailParam.sort_field=='expiry_date'&&salesPersonDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="">
							Business Recieved
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="commission in salesPersonDetailList">
						<td data-ng-bind="::commission.promo_code"></td>
						<td data-ng-bind="::commission.discount"></td>
						<td data-ng-bind="commission.benefit_cap | salaryFormat"></td>
						<td data-ng-bind="::commission.sales_person_commission"></td>
						<td data-ng-bind="::commission.start_date"></td>
						<td data-ng-bind="::commission.expiry_date"></td>
						<td data-ng-bind="commission.amount_received | salaryFormat"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="salesPersonDetailParam.total_items>10">
			<pagination boundary-links="true" total-items="salesPersonDetailParam.total_items" ng-model="salesPersonDetailParam.current_page" ng-change="getSalesPersonPayout()" items-per-page="salesPersonDetailParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>

	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title">Sales Person Paid Earnings</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="salesPersonEarningList.length==0">
				<thead>
					<tr>
						<td align="center">No Sales Person Paid Earning</td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="salesPersonEarningList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortSalesPersonEarningList('amount_paid');">
							Amount Paid
							<i ng-class="(salesPersonEarningParam.sort_field=='amount_paid'&&salesPersonEarningParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonEarningParam.sort_field=='amount_paid'&&salesPersonEarningParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonEarningList('comment');">
							Comment
							<i ng-class="(salesPersonEarningParam.sort_field=='comment'&&salesPersonEarningParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonEarningParam.sort_field=='comment'&&salesPersonEarningParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonEarningList('added_date');">
							Paid Date
							<i ng-class="(salesPersonEarningParam.sort_field=='added_date'&&salesPersonEarningParam.sort_order=='DESC')?'fa-sort-desc':((salesPersonEarningParam.sort_field=='added_date'&&salesPersonEarningParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="earning in salesPersonEarningList">
						<td data-ng-bind="earning.amount_paid | salaryFormat"></td>
						<td data-ng-bind="::earning.comment"></td>
						<td data-ng-bind="::earning.added_date"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="salesPersonEarningParam.total_items>10">
			<pagination boundary-links="true" total-items="salesPersonEarningParam.total_items" ng-model="salesPersonEarningParam.current_page" ng-change="getSalesPersonEarningHistory(salesPersonEarningParam.sales_person_id)" items-per-page="salesPersonEarningParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- Sales Person Detail End -->
	<!-- Earning detial modal -->
	<div id="earning_detail_modal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title">Manage Earning</h5>
				</div>

				<form role="form" updatesalesperson-form submit-handle="updateSalesPersonEarning(salesPersonDetail.sales_person_id)">
					<div class="modal-body has-padding">
						<div class="form-group">
							<label>Unpaid Amount</label>
							<span disabled="disabled" class="form-control">{{salerPersonEarning.unpaid_amount-salerPersonEarning.amount | salaryFormat}}</span>
						</div>
						<div class="form-group">
							<label>Total Earning</label>
							<span disabled="disabled" class="form-control"  data-ng-bind="salerPersonEarning.total_earning | salaryFormat"></span>
						</div>
						<div class="form-group">
							<label>Amount</label>
							<input type="text" name="amount" id="amount" class="form-control" ng-model="salerPersonEarning.amount" maxlength="7" intiger-only>
							<label for="amount" class="error hide" id="amount_error"></label>
						</div>
						<div class="form-group">
							<label>Comment</label>
							<textarea class="form-control" name="comment" id="comment" ng-model="salerPersonEarning.comment"></textarea>
							<label for="comment" class="error hide" id="comment_error"></label>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-warning" data-dismiss="modal" ng-click="userbalance={}">Close</button>
						<button type="submit" class="btn btn-primary"><i class=""></i>Update</button>
					</div>

				</form>
			</div>
		</div>
	</div>
	<!-- /Earning detial modal -->
</div>
<!-- /Page content