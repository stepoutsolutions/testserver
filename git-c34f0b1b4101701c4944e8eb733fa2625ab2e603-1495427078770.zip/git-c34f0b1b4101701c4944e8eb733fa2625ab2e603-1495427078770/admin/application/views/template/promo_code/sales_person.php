<!-- Page content -->
<div class="content" data-ng-init="getSalesPerson();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.sales_person_list}}</h5>
	</div>
	<!-- /page title -->
	<!-- Sales Person Section -->

	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.sales_person"></h6></div>

		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="salesPersonList.length==0">
				<thead>
					<tr>
						<td align="center" data-ng-bind="lang.no_sales_person"></td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="salesPersonList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortSalesPersonList('first_name');">
							{{lang.first_name}}
							<i ng-class="(personsParam.sort_field=='first_name'&&personsParam.sort_order=='DESC')?'fa-sort-desc':((personsParam.sort_field=='first_name'&&personsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonList('last_name');">
							{{lang.last_name}}
							<i ng-class="(personsParam.sort_field=='last_name'&&personsParam.sort_order=='DESC')?'fa-sort-desc':((personsParam.sort_field=='last_name'&&personsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonList('email');">
							{{lang.email}}
							<i ng-class="(personsParam.sort_field=='email'&&personsParam.sort_order=='DESC')?'fa-sort-desc':((personsParam.sort_field=='email'&&personsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.amount_received">
						</th>
						<th class="pointer" ng-click="sortSalesPersonList('dob');">
							{{lang.dob}}
							<i ng-class="(personsParam.sort_field=='dob'&&personsParam.sort_order=='DESC')?'fa-sort-desc':((personsParam.sort_field=='dob'&&personsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonList('added_date');">
							{{lang.added_date}}
							<i ng-class="(personsParam.sort_field=='added_date'&&personsParam.sort_order=='DESC')?'fa-sort-desc':((personsParam.sort_field=='added_date'&&personsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSalesPersonList('status');">
							{{lang.status}}
							<i ng-class="(personsParam.sort_field=='status'&&personsParam.sort_order=='DESC')?'fa-sort-desc':((personsParam.sort_field=='status'&&personsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.action">
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="person in salesPersonList">
						<td data-ng-bind="::person.first_name"></td>
						<td data-ng-bind="::person.last_name"></td>
						<td data-ng-bind="::person.email"></td>
						<td data-ng-bind="person.amount_received | salaryFormat"></td>
						<td data-ng-bind="::person.dob"></td>
						<td data-ng-bind="::person.added_date"></td>
						<td>
							<i class="fa fa-lock danger" ng-show="person.status==0" title="Sales Person Activation Pending"></i>
							<i class="fa fa-unlock success" ng-show="person.status==1" title="Sales Person Active"></i>
							<i class="fa fa-warning danger" ng-show="person.status==2" title="Sales Person Deleted"></i>
						</td>
						<td>
							<a href="edit_sales_person/{{person.sales_person_unique_id}}">
								<i class="fa fa-edit" title="{{lang.edit_sales_person}}"></i>
							</a>
							<a href="sales_person_detail/{{person.sales_person_unique_id}}">
								<i class="fa fa-eye" title="{{lang.sales_person_detail}}"></i>
							</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="personsParam.total_items>10">
			<pagination boundary-links="true" total-items="personsParam.total_items" ng-model="personsParam.current_page" ng-change="getSalesPerson()" items-per-page="personsParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- Sales Person End -->
</div>
<!-- /Page content -->