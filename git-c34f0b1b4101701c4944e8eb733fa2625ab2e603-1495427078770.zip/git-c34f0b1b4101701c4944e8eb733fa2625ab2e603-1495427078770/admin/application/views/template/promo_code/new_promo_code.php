<style type="text/css">
	.select2-container.select-full{width: 100%;}
</style>
<!--Page content -->
<div class="content">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>{{lang.create_promo_code}}</h5>
	</div>
	<!-- page title -->

	<!-- New Promocode Section Start -->
	<form class="form-horizontal" role="form" promocode-form submit-handle="newPromoCode()">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.promo_code"></h6></div>
			<div class="panel-body">
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="promo_code">{{lang.promo_code}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.promo_code_help}}" tool-tip><i class="fa fa-info-circle help"></i></a> 
							</label>
							<div class="col-md-9">
								<input id="promo_code" name="promo_code" type="text" ng-model="newPromoCodeParam.promo_code" class="form-control" maxlength="7">
								<label for="promo_code" class="error hide" id="promo_code_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="sales_person">{{lang.sales_person}}
								<span class="mandatory">*</span> 
							</label>
							<div class="col-md-9">
								<input type="hidden" id="sales_person" name="sales_person" min-search="3" post-url="promo_code/get_all_sales_person" user-ids="{{newPromoCodeParam.sales_person}}" ng-model="newPromoCodeParam.sales_person" ajax-select class="select-full" placeholder="{{lang.select_sales_person}}">
								<label for="sales_person" class="error hide" id="sales_person_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="discount">{{lang.discount}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.discount_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input id="discount" name="discount" intiger-only maxlength="3" type="text" ng-model="newPromoCodeParam.discount" class="form-control">
								<label for="discount" class="error hide" id="discount_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="benefit_cap">{{lang.benifit_cap}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.benefit_cap_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input id="benefit_cap" name="benefit_cap" intiger-only type="text" ng-model="newPromoCodeParam.benefit_cap" class="form-control">
								<label for="benefit_cap" class="error hide" id="benefit_cap_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="commission_sales">{{lang.commission}}
								<span class="mandatory">*</span> 
							</label>
							<div class="col-md-9">
								<input id="commission_sales" name="commission_sales" intiger-only maxlength="3" type="text" ng-model="newPromoCodeParam.commission_sales" class="form-control">
								<label for="commission_sales" class="error hide" id="commission_sales_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="start_date">{{lang.promo_code_date}} 
								<span class="mandatory">*</span> 
								<a href="#" data-placement="top" title="{{lang.promo_code_date_help}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-4">
								<input type="text" class="from-date form-control" name="start_date" id="start_date" date-picker="minDate:'{{promo_code_dates.start_date}}', maxDate: '{{promo_code_dates.expiry_date}}'" placeholder="{{lang.start_date}}" ng-model="newPromoCodeParam.start_date" readonly="" on-select="selectDate(date, 'start_date')">
								<label for="start_date" class="error hide" id="start_date_error"></label>
							</div>
							<div class="col-md-4" ng-if="newPromoCodeParam.start_date">
								<input type="text" class="to-date form-control" name="expiry_date" id="expiry_date" date-picker="minDate:'{{newPromoCodeParam.start_date}}', maxDate: '{{promo_code_dates.expiry_date}}'" placeholder="{{lang.end_date}}" ng-model="newPromoCodeParam.expiry_date" readonly="" on-select="selectDate(date,'expiry_date')">
								<label for="expiry_date" class="error hide" id="expiry_date_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success"><i class=""></i>{{lang.submit}}</button>
					<a ng-href="promo_code"><button type="button" class="btn btn-warning"></i>{{lang.cancel}}</button></a>
				</div>
			</div>
		</div>
	</form>
	<!-- New Promocode Section End -->
</div>
<!-- Page content -->