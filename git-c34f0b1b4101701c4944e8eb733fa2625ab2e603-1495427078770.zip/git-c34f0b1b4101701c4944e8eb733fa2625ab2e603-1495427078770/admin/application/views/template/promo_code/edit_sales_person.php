<!--Page content -->
<div class="content" data-ng-init="getSalesPersonDetail();getAllCountry();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>Edit Sales Person</h5>
	</div>
	<!-- page title -->

	<!-- Edit sales person Section Start -->
	<form class="form-horizontal" role="form" salesperson-form submit-handle="updateSalesPersonDetail()">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title">Sales Person</h6>
			</div>
			<div class="panel-body">
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="first_name">First Name : <span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="first_name" name="first_name" type="text" ng-model="salesPersonParam.first_name" class="form-control">
								<label for="first_name" class="error hide" id="first_name_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="last_name">Last Name : <span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="last_name" name="last_name" type="text" ng-model="salesPersonParam.last_name" class="form-control">
								<label for="last_name" class="error hide" id="last_name_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="email">Email : <span class="mandatory">*</span></label>
							<div class="col-md-9">
								<input id="email" name="email" type="text" ng-model="salesPersonParam.email" class="form-control">
								<label for="email" class="error hide" id="email_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="email">Paypal Email : <span class="mandatory">*</span></label>
							<div class="col-md-9">
								<input id="paypal_email" name="paypal_email" type="text" ng-model="salesPersonParam.paypal_id" class="form-control">
								<label for="paypal_email" class="error hide" id="paypal_email_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="date">Date of birth : <span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="dob" name="dob" type="text" class="form-control" ng-model="salesPersonParam.dob" date-picker on-select="setDob(date)" readonly>
								<label for="dob" class="error hide" id="dob_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="address">Address : </label>
							<div class="col-md-9">
								<input id="address" name="address" type="text" class="form-control" ng-model="salesPersonParam.address">
								<label for="address" class="error hide" id="address_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="zipcode">ZipCode : </label>
							<div class="col-md-9">
								<input id="zip_code" name="zip_code" type="text" intiger-only ng-model="salesPersonParam.zip_code" class="form-control">
								<label for="zip_code" class="error hide" id="zip_code_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="email">City : </label>
							<div class="col-md-9">
								<input id="city" name="city" type="text" ng-model="salesPersonParam.city" class="form-control">
								<label for="city" class="error hide" id="city_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="country">Country : </label>
							<div class="col-md-9">
								<select id="master_country_id" name="master_country_id" ng-model="salesPersonParam.master_country_id" data-ng-change="getAllState()" class="select-full" select-two="minimumResultsForSearch:'2',width:'100%'">
									<option value="">Select Country</option>
									<option value="{{country.master_country_id}}"  ng-repeat="country in countryList track by country.master_country_id" ng-selected="country.master_country_id == salesPersonParam.master_country_id">{{country.country_name}}</option>
								</select>
								<label for="master_country_id" class="error hide" id="master_country_id_error"></label>
							</div>
						</div>
					</div>				
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="email">State : </label>
							<div class="col-md-9">
								<select id="master_state_id" name="master_state_id" ng-model="salesPersonParam.master_state_id" class="select-full" select-two="minimumResultsForSearch:'2',width:'100%'">
									<option value="">Select State</option>
									<option value="{{state.master_state_id}}" ng-repeat="state in stateList track by state.master_state_id">{{state.name}}</option>
								</select>
								<label for="master_state_id" class="error hide" id="master_state_id_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="user_type">Status : 
								<span class="mandatory">*</span>
							</label>
							<div class="col-md-9">
								<div class="widget-inner">
									<div class="radio-inline">
										<label for="sales_person">
											<input type="radio" name="status" id="active" value="1" class="styled" ng-checked="salesPersonParam.status==1" ng-model="salesPersonParam.status" uniform="radioClass:'choice', selectAutoWidth:false">
											Active
										</label>
									</div>
									<div class="radio-inline">
										<label for="user">
											<input type="radio" name="status" id="inactive" value="0" class="styled" ng-checked="salesPersonParam.status==0" ng-model="salesPersonParam.status" uniform="radioClass:'choice', selectAutoWidth:false">
											In-Active
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success"><i class=""></i>Submit</button>
					<a ng-href="sales_person"><button type="button" class="btn btn-warning"></i>Cancel</button></a>
				</div>
			</div>
		</div>
	</form>
	<!-- Edit sales person Section End -->
</div>
<!-- Page content -->
