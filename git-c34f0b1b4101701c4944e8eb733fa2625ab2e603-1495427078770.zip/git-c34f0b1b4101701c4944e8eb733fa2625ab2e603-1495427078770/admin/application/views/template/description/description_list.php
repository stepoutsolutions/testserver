<!-- Page content -->
<div class="content" data-ng-init="initObject('');">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.description_list}}</h5>
	</div>
	<!-- /page title -->
	
	<!-- User Listing -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.descriptions"></h6>
			
			<h6 class="panel-title pull-right">Total Record Count : <span ng-bind="DesParam.total_items"></span></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered">
				<thead>
					<tr ng-if="DescriptionList.length > 0">
						<th class="pointer" ng-click="sortDescriptionList('description_key');">
							{{lang.description_key}}
							<i ng-class="(DesParam.sort_field=='description_key'&&DesParam.sort_order=='DESC')?'fa-sort-desc':((DesParam.sort_field=='description_key'&&DesParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortDescriptionList('english_description');">
							{{lang.english_description}}
							<i ng-class="(DesParam.sort_field=='english_description'&&DesParam.sort_order=='DESC')?'fa-sort-desc':((DesParam.sort_field=='english_description'&&DesParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortDescriptionList('portuguese_description');">
							{{lang.portuguese_description}}
							<i ng-class="(DesParam.sort_field=='portuguese_description'&&DesParam.sort_order=='DESC')?'fa-sort-desc':((DesParam.sort_field=='portuguese_description'&&DesParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortDescriptionList('added_date');">
							{{lang.added_date}}
							<i ng-class="(DesParam.sort_field=='added_date'&&DesParam.sort_order=='DESC')?'fa-sort-desc':((DesParam.sort_field=='added_date'&&DesParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						
						
					</tr>
				</thead>
				<tbody>
					<tr ng-if="DescriptionList.length > 0" ng-repeat="description in DescriptionList">
						<td data-ng-bind="::description.description_key"></td>
						<td data-ng-bind="::description.english_description"></td>
						<td data-ng-bind="::description.portuguese_description"></td>
						<td data-ng-bind="::description.added_date"></td>
					</tr>
					<tr ng-if="DescriptionList.length == 0">
						<td colspan="9" align="center" data-ng-bind="lang.no_record_found"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="DescriptionList.length>0">
			<pagination boundary-links="true"  ng-if="DesParam.total_items>10" total-items="DesParam.total_items" ng-model="DesParam.current_page" ng-change="getDescriptionList()" items-per-page="DesParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /User Listing -->
	
</div>
<!-- /Page content -->