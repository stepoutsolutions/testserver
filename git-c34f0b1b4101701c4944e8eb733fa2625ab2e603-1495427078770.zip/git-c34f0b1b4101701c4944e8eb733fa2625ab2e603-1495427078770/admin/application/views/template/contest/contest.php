<!-- Page content -->
<div class="content" data-ng-init="initObject();getAllLeagueGame();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.contest_list}}</h5>
	</div>
	<!-- /page title -->	

	<!-- Filter Section -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>			
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.league"></th>
						<th data-ng-bind="lang.contest_status"></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center">
							<select id="league_id" name="league_id" placeholder="{{lang.select_league}}" ng-model="gameParam.league_id" class="select-full" data-ng-change="filterGameList()" select-two="minimumResultsForSearch:'-2',width:'100%'">
								<option value="">All Leauges</option>
								<option value="{{::league.league_id}}" ng-repeat="league in leagues">{{::league.league_abbr}}</option>
							</select>
						</td>
						<td class="text-center">
							<select data-placeholder="{{lang.select_contest_status}}" id="game_type" data-placeholder="lang.select_contest_status" ng-model="gameParam.game_type" class="select-full"  data-ng-change="filterGameList()" select-two="minimumResultsForSearch:'-2',width:'100%'">
								<option value="" data-ng-bind="lang.select_contest_status"></option>
								<option value="current_game" data-ng-bind="lang.current_contest"></option>
								<option value="completed_game" data-ng-bind="lang.completed_contest"></option>
								<option value="cancelled_game" data-ng-bind="lang.cancelled_contest"></option>
							</select>
						</td>
						<td class="text-center">
							<select id="contest_feature" name="contest_feature" ng-change="filterGameList();" data-placeholder="{{lang.select_contest_type}}" ng-model="gameParam.contest_feature" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
                                                                <option value="" ng-bind="lang.select_contest_type"></option>
                                                                <option ng-repeat="(key,value) in lang.contest_feature_option" value="{{key}}">{{value}}</option>
                                                        </select>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="clearFilter();"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /Filter Section  -->
	<!-- Game List Section -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.contest"></h6>
			<h6 class="panel-title pull-right">{{lang.total_record_count}} : <span ng-bind="gameParam.total_items"></span></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered">
				<thead>
					<tr ng-if="gameList.length==0">
						<td align="center" colspan="7" data-ng-bind="lang.no_contest "></td>
					</tr>
					<tr ng-if="gameList.length>0">
						<th class="pointer" ng-click="sortGameList('contest_name');">
							{{lang.contest_name}}
							<i ng-class="(gameParam.sort_field=='contest_name'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='contest_name'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('minimum_size');">
							{{lang.minimum_participant}}
							<i ng-class="(gameParam.sort_field=='minimum_size'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='minimum_size'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('size');">
							{{lang.maximum_participant}}
							<i ng-class="(gameParam.sort_field=='size'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='size'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('total_user_joined');">
							{{lang.entrants_participants}}
							<i ng-class="(gameParam.sort_field=='total_user_joined'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='total_user_joined'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('entry_fee');">
							{{lang.fees}}
							<i ng-class="(gameParam.sort_field=='entry_fee'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='entry_fee'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" >
							{{lang.total_entry_fees}}
						</th>
						<th class="pointer" ng-click="sortGameList('prize_pool');">
							{{lang.prize_pool}}
							<i ng-class="(gameParam.sort_field=='prize_pool'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='prize_pool'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('season_scheduled_date');">
							{{lang.start_time}}
							<i ng-class="(gameParam.sort_field=='season_scheduled_date'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='season_scheduled_date'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<?php /*
						<th class="pointer" ng-click="sortGameList('is_feature');">
							{{lang.is_feature_contest}}
							<i ng-class="(gameParam.sort_field=='is_feature'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='is_feature'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<!-- <th class="pointer" ng-click="sortGameList('auto_recurrent_id');">
							{{lang.auto_recurrent_contest}}
							<i ng-class="(gameParam.sort_field=='auto_recurrent_id'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='auto_recurrent_id'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th> -->
						<th class="pointer" ng-click="sortGameList('is_uncapped');">
							{{lang.uncapped_contest}}
							<i ng-class="(gameParam.sort_field=='is_uncapped'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='is_uncapped'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortGameList('guaranteed_prize');">
							{{lang.guaranteed_prize_contest}}
							<i ng-class="(gameParam.sort_field=='guaranteed_prize'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='guaranteed_prize'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						*/ ?>
                        </th>
                        <!-- <th class="pointer" ng-click="sortGameList('is_turbo_lineup');">
							{{lang.turbo_lineup}}
							<i ng-class="(gameParam.sort_field=='is_turbo_lineup'&&gameParam.sort_order=='DESC')?'fa-sort-desc':((gameParam.sort_field=='is_turbo_lineup'&&gameParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th> -->
						<th>
							{{lang.action}}
						</th>
					</tr>
				</thead>
				<tbody ng-if="gameList.length>0">
					<tr ng-repeat="game in gameList">
						<td data-ng-bind="game.contest_name" ng-hide="contestObj.showSaveContest  == game.contest_unique_id"></td>
						<td ng-show="contestObj.showSaveContest  == game.contest_unique_id">
							<input type="text" name="contest_name" class="form-control" ng-model="contest_names[$index]" value="{{game.contest_name}}" ng-init="contest_names[$index]=game.contest_name">
						</td>
						<td>
							{{game.minimum_size}}
						</td>
						<td>
							<label ng-if="game.size!=-1">{{game.size}}</label>
							<label ng-if="game.size==-1">&#8734</label>
						</td>
						<td>
							{{game.total_user_joined}}
						</td>
						<td data-ng-bind-html="game.entry_fee | salaryFormat"></td>
						<td>{{game.total_user_joined *  game.entry_fee | salaryFormat}}</td>
						<td data-ng-bind-html="game.prize_pool | salaryFormat"></td>
						<td data-ng-bind="::game.season_schedule_date"></td>
						<?php /*
						<td>
							<label ng-if="game.is_feature==0" data-ng-bind="lang.no"></label>
							<label ng-if="game.is_feature==1" data-ng-bind="lang.yes"></label>
						</td>
						<!--<td>
							<label ng-if="game.auto_recurrent_id =='' ||game.auto_recurrent_id == '0'" data-ng-bind="lang.no"></label>
							<label ng-if="game.auto_recurrent_id !='' && game.auto_recurrent_id != '0'" data-ng-bind="lang.yes"></label>
						</td>-->
						<td>
							<label ng-if="game.is_uncapped == '0'" data-ng-bind="lang.no"></label>
							<label ng-if="game.is_uncapped == '1'" data-ng-bind="lang.yes"></label>
						</td>
						<td>
							<label ng-if="game.guaranteed_prize == '0'" data-ng-bind="lang.no"></label>
							<label ng-if="game.guaranteed_prize == '1'" data-ng-bind="lang.yes"></label>
						</td>
						 */ ?>
                        <!--<td>
							<label ng-if="game.is_turbo_lineup==0" data-ng-bind="lang.no"></label>
							<label ng-if="game.is_turbo_lineup==1" data-ng-bind="lang.yes"></label>
						</td>-->
						<td>
							<a href="contest_detail/{{game.contest_unique_id}}">
								<i class="fa fa-eye" title="{{lang.contest_detail}}"></i>
							</a>
							<a href="javascript:void(0);" ng-click="contestObj.showSaveContest =game.contest_unique_id" ng-hide="contestObj.showSaveContest  == game.contest_unique_id">
								<i class="fa fa-pencil-square" title="Edit Contest Name"></i>
							</a>
							<a href="javascript:void(0);" ng-show="contestObj.showSaveContest  == game.contest_unique_id" ng-click="saveContestName(game.contest_unique_id,$index)">
								<i class="fa fa-save" title="Save Contest"></i>
							</a>
							<a href="javascript:void(0);" ng-click="removeContest(game.contest_unique_id,$index)" ng-if="game.total_user_joined==0">
								<i class="fa fa-trash-o" title="Delete Contest"></i>
							</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="gameParam.total_items>10">
			<pagination boundary-links="true" total-items="gameParam.total_items" ng-model="gameParam.current_page" ng-change="getGameList()" items-per-page="gameParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- User Transaction History End -->
</div>
<!-- /Page content -->