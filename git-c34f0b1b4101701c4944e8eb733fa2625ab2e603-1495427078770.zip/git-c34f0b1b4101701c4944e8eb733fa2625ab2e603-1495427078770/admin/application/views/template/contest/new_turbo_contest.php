<!--Page content -->
<div class="content" data-ng-init="getAllLeague();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>{{lang.create_new_turbo_contest}}</h5>
	</div>
	<!-- page title -->

	<!-- User Detail Section Start -->
	<form class="form-horizontal" role="form" contest-form submit-handle="createTurboContest()">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.contest"></h6>
			</div>
			<div class="panel-body">
                                <div class="form-group">					
					<div class="col-md-6">
                                                <div class="row">
							<label class="col-md-3 control-label" for="league_id">{{lang.league}}<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<select id="league_id" name="league_id" data-placeholder="{{lang.select_league}}" ng-model="contestParam.league_id" data-ng-change="getAllContestData();doBlur('league_id');"  class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_league"></option>
                                                                        <option ng-if="league.league_id==8" value="{{::league.league_id}}" ng-repeat="league in leagues track by league.league_id">{{::league.league_abbr}}</option>
								</select>
								<label for="league_id" class="error hide" id="league_id_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">					
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label">{{lang.turbo_contest_type}}<span class="mandatory">*</span> </label>							
							<div class="col-md-9">
                                                                <select id="turbo_contest_type" name="turbo_contest_type" data-placeholder="{{lang.select_turbo_type}}" ng-model="contestParam.turbo_contest_type" data-ng-change="doBlur('turbo_contest_type');" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
                                                                        <option value="" ng-bind="lang.select_turbo_type"></option>
									<option value="{{position.position}}" ng-repeat="position in all_position track by position.position">{{position.position_name}}</option>
                                                                </select>
                                                                <label for="turbo_contest_type" class="error hide" id="turbo_contest_type_error"></label>
                                                        </div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="game_name" data-ng-bind="lang.contest_name"></label>
							<div class="col-md-9">
								<div class="input-group">
									<span class="input-group-addon">
										<input type="checkbox" for="game_name" class="styled" ng-model="contestParam.custom_name" ng-change="createGameName()" title="Custom Game Name" uniform="radioClass:'choice', selectAutoWidth:false">
									</span>
									<input id="game_name" name="game_name" maxlength="50" type="text" ng-model="contestParam.game_name" class="form-control" ng-disabled="!contestParam.custom_name" focus="game_name_focus" ng-trim="true">
									<label for="game_name" class="error hide" id="game_name_error"></label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label">{{lang.contest_type}}<span class="mandatory">*</span> </label>							
							<div class="col-md-9">
								<select id="contest_type" name="contest_type" ng-change="getPrizeList();doBlur('contest_type');" data-placeholder="{{lang.select_contest_type}}" ng-model="contestParam.contest_type" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_contest_type"></option>
									<option ng-repeat="(key,value) in contest_types" value="{{key}}">{{value}}</option>
								</select>
								<label for="contest_type" class="error hide" id="contest_type_error"></label>							
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="league_duration_id">{{lang.duration}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
                                                                <select id="league_duration_id" name="league_duration_id" data-placeholder="{{lang.select_duration}}" ng-model="contestParam.league_duration_id" data-ng-change="getAllDraftingStyle(true);doBlur('league_duration_id');" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_duration"></option>
									<option value="{{duration.league_duration_id}}" ng-repeat="duration in all_duration track by duration.league_duration_id">{{duration.duration_desc}}</option>
								</select>
								<label for="league_duration_id" class="error hide" id="league_duration_id_error"></label>
							</div>
						</div>
					</div>
				</div>
<!--				<div class="form-group" ng-if="contestParam.league_duration_id==1">-->
				<div class="form-group" ng-if="duration_ids[ contestParam.league_duration_id]==1">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="date">{{lang.date}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="date" name="date" type="text" ng-change="createGameName()" class="form-control" placeholder="Select Date" ng-model="contestParam.season_scheduled_date" date-picker="minDate:'{{mindate}}',yearRange:'{{yearrange}}'" before-showday="availableSeasonDates(date)" on-select="getAvailableMatchByDay(date)" readonly>
								<label for="date" class="error hide" id="date_error"></label>
							</div>
						</div>
					</div>
				</div>	
				<div class="form-group" ng-if="duration_ids[ contestParam.league_duration_id]==2">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="week">{{lang.week}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="week" name="week" data-placeholder="{{lang.select_week}}" ng-model="contestParam.season_week" data-ng-change="getAvailiableGameOfTheDayOrWeek();doBlur('week');" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_week"></option>
									<option value="{{season_week.week}}" ng-repeat="season_week in all_available_week">{{season_week.week_detail}}</option>
								</select>
								<label for="week" class="error hide" id="week_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group" ng-if="duration_ids[ contestParam.league_duration_id]==3">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="week">{{lang.start_week}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="start_week" name="start_week" data-placeholder="{{lang.select_start_week}}" ng-model="contestParam.season_start_week" data-ng-change="resetSeasonEndWeek()" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_start_week"></option>
									<option value="{{value}}" ng-repeat="(key, value) in notSorted(custom_weeks) track by key" ng-if="value>0" ng-bind="custom_weeks[value]"></option>
								</select>
								<label for="week" class="error hide" id="week_error"></label>
							</div>
						</div>
					</div>

					<div class="col-md-6" ng-if="contestParam.season_start_week">
						<div class="row">
							<label class="col-md-3 control-label" for="week">{{lang.end_week}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="end_week" name="end_week" data-placeholder="{{lang.select_end_week}}" ng-model="contestParam.season_end_week" data-ng-change="custom_weekly_games()" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_end_week"></option>
									<option ng-repeat="(key, value) in notSorted(custom_weeks) track by key" 
									ng-if="value>0 && value*1>contestParam.season_start_week" value="{{value}}" ng-bind="custom_weeks[value]"></option>
								</select>
								<label for="week" class="error hide" id="week_error"></label>
							</div>
						</div>
					</div>
				</div>	
				<div class="form-group" ng-if="duration_ids[ contestParam.league_duration_id]!=3&&contest_list.length>0">
					<label class="col-md-12 control-label">{{lang.games}}<span class="mandatory">*</span> 
						<input type="checkbox" name="contests" id="contests" ng-model="contestObj.selectall" value="{{contestObj.selectall}}" ng-checked="contestObj.selectall" ng-click="toggleContest($event);" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false">
					</label>
				</div>
				<div class="form-group" ng-if="duration_ids[ contestParam.league_duration_id]!=3&&contest_list.length>0">					
					<div class="col-md-12">
						<div class="widget-inner">
							<div class="checkbox-inline contest-list" ng-repeat="contest in contest_list">
								<label>
									<!-- <input type="checkbox" name="contest" id="contest" value="{{contest.season_game_unique_id}}" ng-model="contestParam.contests[contest.season_game_unique_id]" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false"> -->
									<input type="checkbox" name="contest_unique_id" id="contest_unique_id" value="{{contest.season_game_unique_id}}" ng-checked="contests[contest.season_game_unique_id]" ng-model="contests[contest.season_game_unique_id]" ng-click="selectContest($event)" uniform="radioClass:'choice', selectAutoWidth:false"/>
									<span ng-bind="contest.home"></span> @
									<span ng-bind="contest.away"></span>
									<span ng-bind="contest.game_date"></span>
									<span ng-bind="contest.season_scheduled_date"></span>
								</label>
							</div>
						</div>
						<label for="contest_unique_id" class="error hide" id="contest_unique_id_error"></label>
					</div>
				</div>
				<!-- Custome weekly section start-->
				<div ng-if="duration_ids[ contestParam.league_duration_id]==3&&contest_list.length>0">
				
					<div class="form-group">
						<label class="col-md-12 control-label">{{lang.select_all_teams}}
							<input type="checkbox" name="all_teams" id="all_teams" ng-model="selectallteams" ng-click="selectAllTeams($event)" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false">
						</label>
					</div>

					<div class="form-group contest-list" ng-if="!selectallteams" style="width: 100%;">
						<label class="col-md-12 control-label">{{lang.teams}} </label>
						<label ng-repeat="(key, value) in leagueTeams track by key">
							<input type="checkbox" name="teamslist[]" id="team_id" value="{{value}}" 
							ng-model="teamslist[value]" ng-checked="teamslist[value]" ng-click="selectTeams($event)" uniform="radioClass:'choice', selectAutoWidth:false"/>
							<span ng-bind="value"></span>
						</label>
					</div>

					<div class="form-group">
						<label class="col-md-12 control-label">{{lang.games}}<span class="mandatory">*</span> 
							<input type="checkbox" name="contests" id="contests" ng-model="contestObj.selectall" value="{{contestObj.selectall}}" ng-checked="contestObj.selectall" ng-click="toggleContest($event);" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false">
						</label>
					</div>

					<div class="form-group">					
						<div class="col-md-12">
							<div class="widget-inner">
								<div class="checkbox-inline contest-list" ng-repeat="(key, value) in contest_list | groupBy: 'week'"  style="width: 100%;">
									<h4 ng-bind="'Week '+custom_weeks[key]"></h4>
									<label ng-repeat="contest in value track by $index">
										<input type="checkbox" name="contest_unique_id" id="contest_unique_id" value="{{contest.season_game_unique_id}}" ng-checked="contests[contest.season_game_unique_id]" ng-model="contests[contest.season_game_unique_id]" ng-click="selectContest($event)" uniform="radioClass:'choice', selectAutoWidth:false"/>
										<span ng-bind="contest.home"></span> @
										<span ng-bind="contest.away"></span>
										<span ng-bind="contest.game_date"></span>
										<span ng-bind="contest.season_scheduled_date"></span>
									</label>
								</div>
							</div>
							<label for="contest_unique_id" class="error hide" id="contest_unique_id_error"></label>
						</div>
					</div>
				</div>
				<!-- Custome weekly section end-->
				<div class="form-group">

                                        <div class="col-md-6 ">
                                                <div class="row">
							<label class="col-md-3 control-label" for="drafting_style">{{lang.drafting_style}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="drafting_style" name="drafting_style" data-placeholder="{{lang.select_drafting}}" ng-change="createGameName(); doBlur('drafting_style');" ng-model="contestParam.drafting_style" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
                                                                        <option value="" ng-bind="lang.select_drafting"></option>
									<option value="{{drafting_style.league_drafting_styles_id}}"  ng-repeat="drafting_style in all_drafting_style track by drafting_style.league_drafting_styles_id">{{drafting_style.drafting_styles_desc}}</option>
								</select>
								<label for="drafting_style" class="error hide" id="drafting_style_error"></label>
							</div>
						</div>
					</div>
<!--                                        <div class="col-md-6 ">
                                            <div class="row">
                                                <input type="text" class="form-control" id="drafting_style" name="drafting_style" ng-model="contestParam.drafting_style" value="{{ all_drafting_style[0].league_drafting_styles_id }}" intiger-only >
                                            </div>
                                        </div>-->
				</div>
				<div class="form-group" ng-show="contestParam.contest_type==1 || contestParam.contest_type==2">
					<div class="col-md-6">											
						<div class="row">
							<label class="col-md-3 control-label" for="size_min">{{lang.size_min}}<span class="mandatory">*</span>
							</label>
							<div class="col-md-9">
								<input type="text" id="size_min" name="size_min" autocomplete="off"  maxlength="5" ng-change="getPrizeDetails()" ng-model="contestParam.size_min" class="form-control" intiger-only>
								<label for="size_min"  autocomplete="off" class="error hide" id="size_min_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="size">{{lang.size}}(Maximum)<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<input type="text" id="size" name="size" autocomplete="off" maxlength="5" ng-model="contestParam.size" class="form-control" intiger-only min="{{contestParam.size_min}}">
								<label for="size" class="error hide" id="size_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6" ng-show="contestParam.contest_type==0 || contestParam.contest_type==3">
						<div class="row" ng-if="contestParam.contest_type==0">
							<label class="col-md-3 control-label" for="size">{{lang.size}}<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<span class="form-control" ng-model="contestParam.size">{{contestParam.size}}</span>
								<label for="size" class="error hide" id="size_error"></label>
							</div>
						</div>
						<div class="row" ng-if="contestParam.contest_type==3">
							<label class="col-md-3 control-label" for="size_min">{{lang.size_min}}<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.size_min_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input type="text" id="size_min" name="size_min" autocomplete="off"  maxlength="5" ng-change="getPrizeDetails()" ng-model="contestParam.size_min" class="form-control" intiger-only >
								<label for="size_min"  autocomplete="off" class="error hide" id="size_min_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="entry_fee">{{lang.entry_fee}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="entry_fee" name="entry_fee" maxlength="10" type="text" autocomplete="off" ng-change="getPrizeDetails()" ng-model="contestParam.entry_fee" class="form-control" intiger-only>
								<label for="entry_fee" class="error hide" id="entry_fee_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
							<div class="row">
							<label class="col-md-3 control-label">{{lang.prize_pool}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<div class="widget-inner">
									<div class="radio-inline">
										<label for="auto_prize">
											<input type="radio" name="prize_selection" id="auto_prize" value="auto" class="styled" ng-checked="contestParam.prize_selection=='auto'" ng-model="contestParam.prize_selection" uniform="radioClass:'choice', selectAutoWidth:false" ng-change="resetPrizePool();">
											{{lang.auto}}
											<a href="#" data-placement="top" title="{{lang.auto_prize_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
										</label>
									</div>
									<div class="radio-inline">
										<label for="prize_selection">
											<input type="radio" name="prize_selection" id="prize_selection" value="custom" class="styled" ng-checked="contestParam.prize_selection=='custom'" ng-model="contestParam.prize_selection" uniform="radioClass:'choice', selectAutoWidth:false" ng-change="resetPrizePool();">
											{{lang.custom}}
											<a href="#" data-placement="top" title="{{lang.prize_selection_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="select_prize">{{lang.select_prize}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="select_prize" name="select_prize" data-placeholder="{{lang.select_prize}}" ng-model="contestParam.number_of_winner_id" data-ng-change="getPrizeDetails();doBlur('select_prize');" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_prize"></option>
									<option value="{{all.league_contest_type_id}}" ng-repeat="all in all_number_of_winner">{{all.master_contest_type_desc}}</option>
								</select>
								<label for="select_prize" class="error hide" id="select_prize_error"></label>
							</div>
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="custom_prize">
								{{lang.prize_detail}}
							</label>
							<div class="col-md-9" ng-if="contestParam.prize_selection=='auto'">
								<span class="form-control" id="prize_detail" ng-if="prizePool!=''" ng-bind="prizePool | salaryFormat"></span>
								<span class="form-control" id="prize_detail" ng-if="contestParam.is_uncapped" ng-bind="uncappedPrizePool"></span>
							</div>
							<div class="col-md-9" ng-if="contestParam.prize_selection=='custom'">
								<input id="custom_prize" name="custom_prize" type="text" intiger-only ng-model="contestParam.custom_prize" class="form-control" maxlength="7">
								<label for="custom_prize" class="error hide" id="custom_prize_error"></label>
							</div>
							
						</div>
					</div>
				</div>
				<div class="form-group"  ng-if="contestParam.contest_type!=3">
					<div class="col-md-6">
						<div class="row">
							<div class="col-md-9">
								<label for="is_auto_recurrent">
									<input type="checkbox" id="is_auto_recurrent" value="1" ng-change="updateUi()" name="is_auto_recurrent" class="styled" ng-model="contestParam.is_auto_recurrent" uniform="radioClass:'choice', selectAutoWidth:false">
									{{lang.auto_recurrent}}
								</label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success"><i class=""></i>{{lang.save_contest}}</button>
				</div>
			</div>
		</div>
	</form>
	<!-- User Detail Section End -->
</div>
<!-- Page content 