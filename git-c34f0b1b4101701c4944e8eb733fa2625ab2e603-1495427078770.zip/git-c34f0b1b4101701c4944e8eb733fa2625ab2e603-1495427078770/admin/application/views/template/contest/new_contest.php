<!--Page content -->
<div class="content" data-ng-init="getAllLeague();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>{{lang.create_new_contest}}</h5>
	</div>
	<!-- page title -->

	<!-- User Detail Section Start -->
	<form class="form-horizontal" role="form" contest-form submit-handle="createContest()">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.contest"></h6>
			</div>
			<div class="panel-body">
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label">&nbsp;</label>
							<div class="col-md-9">
								<div class="">
									<div class="checkbox-inline">
										<label for="is_feature">
											<input type="checkbox" id="is_feature" class="styled" ng-model="contestParam.is_feature" uniform="radioClass:'choice', selectAutoWidth:false">
											{{lang.featured}}
											<a href="#" data-placement="top" title="{{lang.featured_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6" ng-if="contestParam.is_feature">
						<div class="row">
							<label class="col-md-3 control-label" for="feature_img">{{lang.featured_image}}<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<span upload-file="post_url:'contest/do_upload'" callback="getFileRosterDetail(data);" id="feature_img" class="label label-success">Upload Image</span>
								<a href="#" data-placement="top" title="{{lang.featured_image_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
								<label for="feature_img" class="error hide" id="feature_img_error"></label>
							</div>
							</br>
							<img ng-if="feature_img" ng-src="{{feature_img}}" alt="">
						</div>
					</div>
				</div>
				<div class="form-group">					
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="league_id">{{lang.league}}<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<select id="league_id" name="league_id" data-placeholder="{{lang.select_league}}" ng-model="contestParam.league_id" data-ng-change="getAllContestData();doBlur('league_id');"  class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_league"></option>
									<option value="{{::league.league_id}}" ng-repeat="league in leagues track by league.league_id">{{::league.league_abbr}}</option>
								</select>
								<label for="league_id" class="error hide" id="league_id_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="game_name" data-ng-bind="lang.contest_name"></label>
							<div class="col-md-9">
								<div class="input-group">
									<span class="input-group-addon">
										<input type="checkbox" for="game_name" class="styled" ng-model="contestParam.custom_name" ng-change="createGameName()" title="Custom Game Name" uniform="radioClass:'choice', selectAutoWidth:false">
									</span>
									<input id="game_name" name="game_name" maxlength="50" type="text" ng-model="contestParam.game_name" class="form-control" ng-disabled="!contestParam.custom_name" focus="game_name_focus" ng-trim="true">
									<label for="game_name" class="error hide" id="game_name_error"></label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label">{{lang.contest_type}}<span class="mandatory">*</span> </label>							
							<div class="col-md-9">
								<select id="contest_type" name="contest_type" ng-change="getPrizeList();doBlur('contest_type');" data-placeholder="{{lang.select_contest_type}}" ng-model="contestParam.contest_type" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_contest_type"></option>
									<option ng-repeat="(key,value) in contest_types" value="{{key}}">{{value}}</option>
								</select>
								<label for="contest_type" class="error hide" id="contest_type_error"></label>							
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="league_duration_id">{{lang.duration}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
                                                                <select id="league_duration_id" name="league_duration_id" data-placeholder="{{lang.select_duration}}" ng-model="contestParam.league_duration_id" data-ng-change="getAllDraftingStyle();doBlur('league_duration_id');" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_duration"></option>
									<option value="{{duration.league_duration_id}}" ng-repeat="duration in all_duration track by duration.league_duration_id">{{duration.duration_desc}}</option>
								</select>
								<label for="league_duration_id" class="error hide" id="league_duration_id_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group" >
					<div class="col-md-6" ng-if="duration_ids[contestParam.league_duration_id]==1">
						<div class="row">
							<label class="col-md-3 control-label" for="date">{{lang.date}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="date" name="date" type="text" ng-change="createGameName()" class="form-control" placeholder="Select Date" ng-model="contestParam.season_scheduled_date" date-picker="minDate:'{{mindate}}'" before-showday="availableSeasonDates(date)" on-select="getAvailableMatchByDay(date)" readonly>
								<label for="date" class="error hide" id="date_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6" ng-if="contestParam.contest_type != 0">
						<div class="row">
							<label class="col-md-3 control-label" for="is_multiple_lineup">
								{{lang.multiple_lineup}}
								<a href="#" data-placement="top" title="{{lang.is_multiple_lineup_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<div class="input-group">
									<span class="input-group-addon">
										<input type="checkbox" id="is_multiple_lineup" class="styled" ng-model="contestParam.is_multiple_lineup" title="Multiple Lineup" uniform="radioClass:'choice', selectAutoWidth:false" ng-change="is_multiple_lineup()">
									</span>
									<input id="multiple_lineup" name="multiple_lineup" type="text"   intiger-only ng-model="contestParam.multiple_lineup" class="form-control" ng-disabled="!contestParam.is_multiple_lineup" ng-blur="check_valid_min_size()">
								</div>
								<label for="multiple_lineup" class="error hide" id="multiple_lineup_error"></label>
							</div>
						</div>
					</div>
				</div>	
				<div class="form-group" ng-if="duration_ids[contestParam.league_duration_id]==2">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="date">From {{lang.date}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="from_date" name="from_date" type="text" class="form-control" todate='1' placeholder="Select Date" ng-model="contestParam.from_date" date-picker="minDate:'{{mindate}}',yearRange:'{{yearrange}}'" before-showday="availableAllSeasonDates(date)" on-select="getAvailableMatchByFromDay(date)" readonly>
								<label for="from_date" class="error hide" id="from_date_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="date">To {{lang.date}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="to_date" name="to_date" type="text" class="form-control" placeholder="Select Date" ng-model="contestParam.to_date" date-picker="minDate:'{{contestParam.from_date}}',yearRange:'{{yearrange}}'" before-showday="availableAllSeasonDates(date)" on-select="getAvailableMatchByToDay(date)" readonly>
								<label for="to_date" class="error hide" id="to_date_error"></label>
							</div>
						</div>
					</div>
				</div>

				<div class="form-group" ng-if="duration_ids[contestParam.league_duration_id]!=3&&contest_list.length>0">
					<label class="col-md-12 control-label">{{lang.games}}<span class="mandatory">*</span> 
						<input type="checkbox" name="contests" id="contests" ng-model="contestObj.selectall" value="{{contestObj.selectall}}" ng-checked="contestObj.selectall" ng-click="toggleContest($event);" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false">
					</label>
				</div>
				<div class="form-group" ng-if="duration_ids[contestParam.league_duration_id]!=3&&contest_list.length>0">					
					<div class="col-md-12">
						<div class="widget-inner">
							<div class="checkbox-inline contest-list" ng-repeat="contest in contest_list">
								<label>
									<!-- <input type="checkbox" name="contest" id="contest" value="{{contest.season_game_uid}}" ng-model="contestParam.contests[contest.season_game_uid]" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false"> -->
									<input type="checkbox" name="contest_unique_id" id="contest_unique_id" value="{{contest.season_game_uid}}" ng-checked="contests[contest.season_game_uid]" ng-model="contests[contest.season_game_uid]" ng-click="selectContest($event)" uniform="radioClass:'choice', selectAutoWidth:false"/>
									<span ng-bind="contest.home"></span> @
									<span ng-bind="contest.away"></span>
									<span ng-bind="contest.game_date"></span>
									<span ng-bind="contest.season_scheduled_date"></span>
								</label>
							</div>
						</div>
						<label for="contest_unique_id" class="error hide" id="contest_unique_id_error"></label>
					</div>
				</div>
				<!-- Custome weekly section start-->
				<div ng-if="duration_ids[contestParam.league_duration_id]==3&&contest_list.length>0">
				
					<div class="form-group">
						<label class="col-md-12 control-label">{{lang.select_all_teams}}
							<input type="checkbox" name="all_teams" id="all_teams" ng-model="selectallteams" ng-click="selectAllTeams($event)" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false">
						</label>
					</div>

					<div class="form-group contest-list" ng-if="!selectallteams" style="width: 100%;">
						<label class="col-md-12 control-label">{{lang.teams}} </label>
						<label ng-repeat="(key, value) in leagueTeams track by key">
							<input type="checkbox" name="teamslist[]" id="contest_unique_id" value="{{value}}" 
							ng-model="teamslist[value]" ng-checked="teamslist[value]" ng-click="selectTeams($event)" uniform="radioClass:'choice', selectAutoWidth:false"/>
							<span ng-bind="value"></span>
						</label>
					</div>

					<div class="form-group">
						<label class="col-md-12 control-label">{{lang.games}}<span class="mandatory">*</span> 
							<input type="checkbox" name="contests" id="contests" ng-model="contestObj.selectall" value="{{contestObj.selectall}}" ng-checked="contestObj.selectall" ng-click="toggleContest($event);" class="styled" uniform="radioClass:'choice', seletcAutoWidth:false">
						</label>
					</div>

					<div class="form-group">					
						<div class="col-md-12">
							<div class="widget-inner">
								<div class="checkbox-inline contest-list" ng-repeat="(key, value) in contest_list | groupBy: 'week'"  style="width: 100%;">
									<h4 ng-bind="'Week '+custom_weeks[key]"></h4>
									<label ng-repeat="contest in value track by $index">
										<input type="checkbox" name="contest_unique_id[]" id="contest_unique_id" value="{{contest.season_game_uid}}" 
										ng-model="contests[contest.season_game_uid]" ng-checked="contests[contest.season_game_uid]" ng-click="selectContest($event)" uniform="radioClass:'choice', selectAutoWidth:false"/>
										<span ng-bind="contest.home"></span> @
										<span ng-bind="contest.away"></span>
										<span ng-bind="contest.game_date"></span>
										<span ng-bind="contest.season_scheduled_date"></span>
									</label>
								</div>
							</div>
							<label for="contest_unique_id" class="error hide" id="contest_unique_id_error"></label>
						</div>
					</div>
				</div>
				<!-- Custome weekly section end-->
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="site_rake">Site Rake<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input type="hidden" name="drafting_style" id="drafting_style" ng-model="contestParam.drafting_style" value="1">
								<input id="site_rake" name="site_rake" type="text" class="form-control" ng-model="contestParam.site_rake" intiger-only ng-change="getPrizeDetails()">
								<label for="site_rake" class="error hide" id="site_rake_error"></label>
								<!-- <select id="drafting_style" name="drafting_style" data-placeholder="{{lang.select_drafting}}" ng-change="createGameName();doBlur('drafting_style');" ng-model="contestParam.drafting_style" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_drafting"></option>
									<option value="{{drafting_style.league_drafting_styles_id}}"  ng-repeat="drafting_style in all_drafting_style track by drafting_style.league_drafting_styles_id">{{drafting_style.drafting_styles_desc}}</option>
								</select> 
								<label for="drafting_style" class="error hide" id="drafting_style_error"></label>-->
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="salary_cap">{{lang.salary_cap}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="salary_cap" name="salary_cap" data-placeholder="{{lang.select_salary_cap}}" ng-model="contestParam.salary_cap" ng-change="createGameName();doBlur('salary_cap');"  class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="">{{lang.select_salary_cap}}</option>
									<option value="{{salary_cap.master_salary_cap_id}}" ng-repeat="salary_cap in all_salary_cap">{{salary_cap.salary_cap}}</option>
								</select>
								<label for="salary_cap" class="error hide" id="salary_cap_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group" ng-if="contestParam.contest_type != 2 && contestParam.contest_type != 1">
					<div class="col-md-6">					
						<div class="row" ng-if="contestParam.contest_type==0">
							<label class="col-md-3 control-label" for="size">{{lang.size}}<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<span class="form-control" ng-model="contestParam.size">{{contestParam.size}}</span>
								<label for="size" class="error hide" id="size_error"></label>
							</div>
						</div>
						<div class="row" ng-if="contestParam.contest_type==3">
							<label class="col-md-3 control-label" for="size_min">{{lang.size_min}}<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.size_min_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input type="text" id="size_min" name="size_min" autocomplete="off"  maxlength="7" ng-change="getPrizeDetails()" ng-model="contestParam.size_min" class="form-control" intiger-only ng-blur="check_valid_min_size()">
								<label for="size_min"  autocomplete="off" class="error hide" id="size_min_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="entry_fee">{{lang.entry_fee}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="entry_fee" name="entry_fee" max="10000" type="text" autocomplete="off" ng-change="getPrizeDetails()" ng-model="contestParam.entry_fee" class="form-control" intiger-only>
								<label for="entry_fee" class="error hide" id="entry_fee_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group" ng-show="contestParam.contest_type==1 || contestParam.contest_type==2">
					<div class="col-md-6">											
						<div class="row">
							<label class="col-md-3 control-label" for="size_min">{{lang.size_min}}<span class="mandatory">*</span>
							</label>
							<div class="col-md-9">
								<input type="text" id="size_min" name="size_min" autocomplete="off"  maxlength="7" ng-change="getPrizeDetails()" ng-model="contestParam.size_min" class="form-control" intiger-only>
								<label for="size_min"  autocomplete="off" class="error hide" id="size_min_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="size">{{lang.size}}(Maximum)<span class="mandatory">*</span></label>
							<div class="col-md-9">
								<input type="text" id="size" name="size" autocomplete="off" maxlength="7" ng-model="contestParam.size" class="form-control" intiger-only min="{{contestParam.size_min}}">
								<label for="size" class="error hide" id="size_error"></label>
							</div>
						</div>
					</div>
					<br/>
					<br/>
					<br/>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="entry_fee">{{lang.entry_fee}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<input id="entry_fee" name="entry_fee" maxlength="10" type="text" autocomplete="off" ng-change="getPrizeDetails()" ng-model="contestParam.entry_fee" class="form-control" intiger-only>
								<label for="entry_fee" class="error hide" id="entry_fee_error"></label>
							</div>
						</div>
					</div>
				</div>

				<div class="form-group">
					<div class="col-md-6">
							<div class="row">
							<label class="col-md-3 control-label">{{lang.prize_pool}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<div class="widget-inner">
									<div class="radio-inline">
										<label for="auto_prize">
											<input type="radio" name="prize_selection" id="auto_prize" value="auto" class="styled" ng-checked="contestParam.prize_selection=='auto'" ng-model="contestParam.prize_selection" uniform="radioClass:'choice', selectAutoWidth:false" ng-change="resetPrizePool();">
											{{lang.auto}}
											<a href="#" data-placement="top" title="{{lang.auto_prize_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
										</label>
									</div>
									<div class="radio-inline">
										<label for="prize_selection">
											<input type="radio" name="prize_selection" id="prize_selection" value="custom" class="styled" ng-checked="contestParam.prize_selection=='custom'" ng-model="contestParam.prize_selection" uniform="radioClass:'choice', selectAutoWidth:false" ng-change="resetPrizePool();">
											{{lang.custom}}
											<a href="#" data-placement="top" title="{{lang.prize_selection_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="select_prize">{{lang.select_prize}}<span class="mandatory">*</span> </label>
							<div class="col-md-9">
								<select id="select_prize" name="select_prize" data-placeholder="{{lang.select_prize}}" ng-model="contestParam.number_of_winner_id" data-ng-change="getPrizeDetails();doBlur('select_prize');" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
									<option value="" ng-bind="lang.select_prize"></option>
									<option value="{{all.league_contest_type_id}}" ng-repeat="all in all_number_of_winner">{{all.master_contest_type_desc}}</option>
								</select>
								<label for="select_prize" class="error hide" id="select_prize_error"></label>
							</div>
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="custom_prize">
								{{lang.prize_detail}}
							</label>
							<div class="col-md-9" ng-if="contestParam.prize_selection=='auto'">
								<span class="form-control" id="prize_detail" ng-if="prizePool!=''" ng-bind="prizePool | salaryFormat"></span>
								<span class="form-control" id="prize_detail" ng-if="contestParam.is_uncapped" ng-bind="uncappedPrizePool"></span>
							</div>
							<div class="col-md-9" ng-if="contestParam.prize_selection=='custom'">
								<input id="custom_prize" name="custom_prize" type="text" intiger-only ng-model="contestParam.custom_prize" class="form-control" maxlength="7">
								<label for="custom_prize" class="error hide" id="custom_prize_error"></label>
							</div>
							
						</div>
					</div>
				</div>
				<div class="form-group"  ng-if="contestParam.contest_type!=3 || (contestParam.contest_type==3 && contestObj.selectall)">
					<div class="col-md-6">
						<div class="row">
							<div class="col-md-9">
								<label for="is_auto_recurrent">
									<input type="checkbox" id="is_auto_recurrent" value="1" ng-change="updateUi()" name="is_auto_recurrent" class="styled" ng-model="contestParam.is_auto_recurrent" uniform="radioClass:'choice', selectAutoWidth:false">
									{{lang.auto_recurrent}}
								</label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success"><i class=""></i>{{lang.save_contest}}</button>
				</div>
			</div>
		</div>
	</form>
	<!-- User Detail Section End -->
</div>
<!-- Page content 