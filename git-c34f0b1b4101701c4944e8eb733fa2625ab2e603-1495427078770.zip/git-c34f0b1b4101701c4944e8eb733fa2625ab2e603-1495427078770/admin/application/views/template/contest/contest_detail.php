<!--Page content -->
<div class="content" data-ng-init="getGameDetail();">
	<!-- Game Detail Section Start -->
	<div class="col-md-12">
		<!-- Page title -->
		<div class="page-title">
			<h5><i class="fa fa-bars"></i>{{lang.contest_detail_informations}}</h5>
		</div>
		<!-- /page title -->
		<form class="form-horizontal" action="#" role="form" ng-if="gameDetail">
			<div class="panel panel-default">
				<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.contest_detail"></h6></div>
				<div class="panel-body">
					<div class="form-group">
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.contest_name+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.contest_name"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.league+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.league_abbr"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.duration+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.duration_desc"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.drafting_style+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.drafting_styles_desc"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.salary_cap+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="gameDetail.salary_cap | salaryFormat"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.entrants_participants+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label">
										{{gameDetail.total_user_joined}}/
										<label ng-if="gameDetail.size!=-1">{{gameDetail.size}}</label>
										<label ng-if="gameDetail.size==-1">&#8734</label>
									</label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.entry_fee+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="gameDetail.entry_fee | salaryFormat"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.site_rake+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.site_rake"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.prizing+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.master_contest_type_desc"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.guaranteed_prize_contest+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-if="gameDetail.guaranteed_prize == '0'" ng-bind="lang.no"></label>
									<label class="control-label" ng-if="gameDetail.guaranteed_prize == '1'" ng-bind="lang.yes"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">						
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.is_feature_contest+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-if="gameDetail.is_feature == '0'" ng-bind="lang.no"></label>
									<label class="control-label" ng-if="gameDetail.is_feature == '1'" ng-bind="lang.yes"></label>
								</div>
							</div>
						</div>
						<!-- <div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.auto_recurrent_contest+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-if="gameDetail.auto_recurrent_id =='' ||gameDetail.auto_recurrent_id == '0'" ng-bind="lang.no"></label>
									<label class="control-label" ng-if="gameDetail.auto_recurrent_id !='' && gameDetail.auto_recurrent_id != '0'" ng-bind="lang.yes"></label>
								</div>
							</div>
						</div> -->

						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.uncapped_contest+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-if="gameDetail.is_uncapped == '0'" ng-bind="lang.no"></label>
									<label class="control-label" ng-if="gameDetail.is_uncapped == '1'" ng-bind="lang.yes"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.scheduled_date+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.scheduled_date"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.created_date+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="::gameDetail.added_date"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.created_by+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-if="gameDetail.user_name" ng-bind="::gameDetail.user_name"></label>
									<label class="control-label" ng-if="gameDetail.user_name&&gameDetail.email" ng-bind="::'('+gameDetail.email+')'"></label>
									<label class="control-label" ng-if="gameDetail.user_name===null" ng-bind="lang.admin"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.status+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="gameDetail.status | titleCase"></label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.prize_distributed+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-if="gameDetail.prize_distributed == '0'" ng-bind="lang.no"></label>
									<label class="control-label" ng-if="gameDetail.prize_distributed == '1'" ng-bind="lang.yes"></label>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<label class="col-sm-4 control-label text-right" data-ng-bind="lang.prize_pool_label+' : '"></label>
								<div class="col-sm-8">
									<label class="control-label" ng-bind="gameDetail.prize_pool | salaryFormat"></label>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
		<div class="page-title" ng-if="!gameDetail">
			<h5><i class="fa fa-bars"></i>{{lang.no_contest_detail}}</h5>
		</div>
	</div>
	<!-- Auto Recurrent Contest Tab -->
	<div class="col-md-12" ng-if="autoRecurrentDetail">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.auto_recurrent_contest"></h6>
				<a href="javascript:void(0)" class="btn btn-info pull-right" ng-click="showAutoRecurrentEdit()">{{lang.edit}}</a>
			</div>
			<div class="panel-body">
				<div class="form-group" ng-show="!autorecurrenteditmode">
					<div class="col-md-4" ng-if="autoRecurrentDetail.period_type!=0">
						<div class="row">
							<label class="col-sm-4 control-label text-right" ng-if="autoRecurrentDetail.period_type!=1">{{lang.period}}</label>
							<div class="col-sm-4" ng-if="autoRecurrentDetail.period_type!=1">
								<label class="control-label" ng-bind="::autoRecurrentDetail.period_value"></label>
							</div>
							<div class="col-sm-4">
								<label class="control-label" ng-if="autoRecurrentDetail.period_type==0">--</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_type==1">{{lang.auto_recurrent_whole_league}}</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_type==2">{{lang.week}}</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_type==3">{{lang.month}}</label>								
							</div>
						</div>
					</div>
					<div class="col-md-4" ng-if="gameDetail.is_uncapped!=1">
						<div class="row">
							<label class="col-sm-4 control-label text-right">{{lang.no_of_game}}</label>
							<div class="col-sm-8">
								<label class="control-label" ng-bind="autoRecurrentDetail.no_of_game"></label>
							</div>
						</div>
					</div>
					<div class="col-md-4" ng-if="gameDetail.is_uncapped!=1">
						<div class="row">
							<label class="col-sm-4 control-label text-right">{{lang.auto_recurrent_stop_time}}</label>
							<div class="col-sm-4">
								<label class="control-label" ng-bind="autoRecurrentDetail.period_stop_value"></label>
							</div>
							<div class="col-sm-4">
								<label class="control-label" ng-if="autoRecurrentDetail.period_stop_type==0">--</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_stop_type==1">{{lang.auto_recurrent_min}}</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_stop_type==2">{{lang.auto_recurrent_hours}}</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_stop_type==3">{{lang.auto_recurrent_day}}</label>
								<label class="control-label" ng-if="autoRecurrentDetail.period_stop_type==4">{{lang.auto_recurrent_never}}</label>
							</div>
						</div>
					</div>
				</div>		
				<!-- Edit mode section start here -->
 				<div class="form-group col-md-12" ng-if="autorecurrenteditmode && (autorecurrentupdateForm.is_period_of_recurrent==1 || autorecurrentupdateForm.is_period_of_recurrent==2)">
					<div class="col-md-2">
						<label ng-bind="lang.duration"></label>
						<div class="raw">
		                    <div class="checkbox-inline">
								<label for="period_of_recurrent">
									<input type="radio" id="whole_league" ng-checked="autorecurrentupdateForm.is_period_of_recurrent==1" value="1" name="period_of_recurrent" class="styled" ng-model="autorecurrentupdateForm.is_period_of_recurrent" uniform="radioClass:'choice', selectAutoWidth:false">
									{{lang.auto_recurrent_whole_league}}
								</label>
							</div>
						    <div class="checkbox-inline">
								<label for="period_of_recurrent">
									<input type="radio" id="period" name="period_of_recurrent" class="styled" value="2" ng-model="autorecurrentupdateForm.is_period_of_recurrent" uniform="radioClass:'choice', selectAutoWidth:false">
									{{lang.period}}
								</label>
							</div>
						</div>
	                </div>
				</div>
				<div class="form-group col-md-12" ng-if="autorecurrenteditmode && autorecurrentupdateForm.is_period_of_recurrent ==2">
					<div class="col-md-2">
						<input id="period_of_recurrent_value" name="autorecurrentupdateForm.period_of_recurrent_value"  placeholder="Enter Value" maxlength="2" type="text" autocomplete="off" ng-model="autorecurrentupdateForm.period_of_recurrent_value" class="form-control" intiger-only>
					</div>
					<div class="col-md-2">
						<select id="period_of_recurrent_type" name="period_of_recurrent_type" data-placeholder="" ng-model="autorecurrentupdateForm.period_of_recurrent" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
							<option value="">Select Type</option>
							<option value="2">Week</option>
							<option value="3">Month</option>
						</select>
					</div>
				</div>
				<div class="form-group col-md-12" ng-if="autorecurrenteditmode && gameDetail.is_uncapped!=1">
					<div class="col-md-2">
	                    <label ng-bind="lang.no_of_game"></label>
	                    <input id="no_of_game" name="no_of_game" class="form-control" maxlength="2" max="30" type="text" placeholder="No of game limit" autocomplete="off" ng-model="autorecurrentupdateForm.no_of_game" intiger-only>
	                </div>
	                <div class="col-md-2" ng-hide="autorecurrentupdateForm.auto_recurrent_stop_type==4">
	                    <label ng-bind="lang.auto_recurrent_stop_time"></label>
	                    <input id="auto_recurrent_stop_value" name="auto_recurrent_stop_value" placeholder="Enter Value" maxlength="2" type="text" autocomplete="off" ng-model="autorecurrentupdateForm.auto_recurrent_stop_value" class="form-control" intiger-only>
	                </div>
	                <div class="col-md-2">
	                	<label>&nbsp;</label>
						<select id="auto_recurrent_stop_type" name="auto_recurrent_stop_type" data-placeholder="" ng-model="autorecurrentupdateForm.auto_recurrent_stop_type" class="select-full" select-two="minimumResultsForSearch:'-2',width:'100%'">
							<option value="">Select Type</option>
							<option value="1">Minutes</option>
							<option value="2">Hours</option>
							<option value="3">Day</option>
							<option value="4">Never</option>
						</select>
					</div>
				</div>
				<div class="form-group col-md-12" ng-if="autorecurrenteditmode">
					<div class="col-md-2">
						<label>&nbsp;</label>
						<div class="form-actions text-left">
							<button type="submit" class="btn btn-success" ng-click="AutoReccUpdate()"><i class=""></i>{{lang.save_contest}}</button>
						</div>
					</div>
				</div>
				<!-- Edit mode section start here -->
				</div>	
		</div>			
	</div>	
	<!-- Auto Recurrent Contest Tab -->
	<div class="col-md-12" ng-if="gameLineupDetail.length > 0">
		<div class="col-md-4">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.participants"></h6>
			</div>
			<div class="table-responsive" style="overflow:auto;">
				<table class="table table-striped table-bordered">
					<thead>
						<tr>
							<th data-ng-bind="lang.user_name"></th>
							<th data-ng-bind="lang.score"></th>
							<th ng-if="gameDetail.prize_distributed=='1'" ng-bind="lang.winning"></th>
							<th width="25%" data-ng-bind="lang.action"></th>
						</tr>
					</thead>
					<tbody>
						<tr ng-repeat="lineup in gameLineupDetail">
							<td data-ng-bind="::lineup.user_name"></td>
							<td data-ng-bind="::lineup.total_score"></td>
							<td ng-if="gameDetail.prize_distributed=='1'">{{gameLineupPrize[lineup.user_id].prize_amount|salaryFormat}}</td>
							<td>
								<a href="javascript:void(0);" ng-click="getLineupDetail(lineup.lineup_master_id,gameDetail.league_id)">
									<span class="label label-success" ng-if="lineup.lineup_master_id!=currentLineupMasterID" data-ng-bind="lang.lineup_detail"></span>
									<span class="label label-info" ng-if="lineup.lineup_master_id==currentLineupMasterID" data-ng-bind="lang.reload"></span>
								</a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="table-footer" ng-if="gameDetailParam.total_items>10">
				<pagination  boundary-links="true" total-items="gameDetailParam.total_items" ng-model="gameDetailParam.current_page" ng-change="getGameLineupDetail(gameDetailParam.game_id)" items-per-page="gameDetailParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
			</div>
		</div>
		</div>
		<div class="col-md-8">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.participant_lineup_detail"></h6>
			</div>
			<div class="table-responsive" >
				<table class="table table-striped table-bordered">
					<thead>
						<tr>
							<th data-ng-bind="lang.position"></th>
							<th data-ng-bind="lang.player_name"></th>
							<th data-ng-bind="lang.team_name"></th>
							<th data-ng-bind="lang.player_salary"></th>
							<th data-ng-bind="lang.score"></th>
						</tr>
					</thead>
					<tbody>
						<tr ng-repeat="lineup in LineupDetail">
							<td data-ng-bind="::lineup.position"></td>
							<td data-ng-bind="::lineup.full_name"></td>
							<td data-ng-bind="::lineup.team_abbreviation"></td>
							<td data-ng-bind="lineup.salary | salaryFormat"></td>
							<td data-ng-bind="::lineup.score"></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		</div>
	</div>
	<div class="col-md-12" ng-if="playerSalaries.length>0">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.player_roster"></h6>
			</div>
			<div class="table-responsive">
				<table class="table table-hover table-striped table-bordered table-check">
					<thead>
						<tr ng-if="playerSalaries.length>0">
							<th class="pointer" class="pointer" ng-click="sortPlayerLastSalaries('full_name');" width="20%">
								{{lang.full_name}}
								<i ng-class="(playerSalaryDetailParam.sort_field=='full_name'&&playerSalaryDetailParam.sort_order=='DESC')?'fa-sort-desc':((playerSalaryDetailParam.sort_field=='full_name'&&playerSalaryDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
							</th>
							<th class="pointer" class="pointer" ng-click="sortPlayerLastSalaries('team_name');">
								{{lang.team}}
								<i ng-class="(playerSalaryDetailParam.sort_field=='team_name'&&playerSalaryDetailParam.sort_order=='DESC')?'fa-sort-desc':((playerSalaryDetailParam.sort_field=='team_name'&&playerSalaryDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
							</th>
							<th class="pointer" class="pointer" ng-click="sortPlayerLastSalaries('position');">
								{{lang.position}}
								<i ng-class="(playerSalaryDetailParam.sort_field=='position'&&playerSalaryDetailParam.sort_order=='DESC')?'fa-sort-desc':((playerSalaryDetailParam.sort_field=='position'&&playerSalaryDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
							</th>
							<th class="pointer" class="pointer" ng-click="sortPlayerLastSalaries('salary');">
								{{lang.score}}
								<i ng-class="(playerSalaryDetailParam.sort_field=='salary'&&playerSalaryDetailParam.sort_order=='DESC')?'fa-sort-desc':((playerSalaryDetailParam.sort_field=='salary'&&playerSalaryDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
							</th>
							<th ng-bind="lang.player_score"></th>
						</tr>
						<tr ng-if="playerSalaries.length==0">
							<td align="center" colspan="4" data-ng-bind="lang.no_player"></td>
						</tr>
					</thead>
					<tbody>
						<tr ng-repeat="roster in playerSalaries">
							<td ng-bind="::roster.full_name" width="20%" style="text-align: left !important;"></td>
							<td ng-bind="::roster.team_name"></td>
							<td ng-bind="::roster.position"></td>
							<td ng-bind="roster.score"></td>
							<td>
								<a href="javascript:void(0);" ng-click="getPlayerScore(gameDetail.contest_unique_id,roster.player_uid,gameDetail.league_id,gameDetail.player_salary_master_id,gameDetail.sports_id)" ng-if="roster.break_down">
									<span class="label label-info" ng-bind="lang.player_score"></span>
								</a>
								<a href="javascript:void(0);" ng-if="!roster.break_down">
									<span class="label label-default" ng-bind="lang.player_score"></span>
								</a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="table-footer" ng-if="playerSalaryDetailParam.total_items>10">
				<pagination boundary-links="true" total-items="playerSalaryDetailParam.total_items" ng-model="playerSalaryDetailParam.current_page" ng-change="getPlayerLastSalaries(gameDetail.contest_unique_id,gameDetail.league_id)" items-per-page="playerSalaryDetailParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
			</div>
		</div>
	</div>

	<!-- All Inactive User modal -->
	<div id="roster_json" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" ng-bind="lang.player_score"></h5>
				</div>
				<!-- Inactive User modal -->
				<!-- <form  role="form" banuser-form submit-handle="changeSelectedUserStatus()">
					<div class="modal-body has-padding">
						
						<div class="form-group">
							<textarea class="form-control" id="reason" name="reason" readonly="" ng-bind="roster_json | json:4" rows="10"></textarea>
						</div>
					</div>
				</form> -->
				<div ng-repeat="(key,value) in playerScoring">
					<h6 ng-bind="key|uppercase"></h6>
					<table class="table table-hover table-striped table-bordered table-check">
						<thead>
							<th width="80%">Score Description</th>
							<th width="20%">Score</th>
						</thead>
						<tbody>
							<tr ng-repeat="item in value">
								<td ng-bind="item.desc"></td>
								<td ng-bind="item.value"></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!-- /Inactive User modal -->
	<!-- Game Detail Section End -->
</div>
<!-- /Page content