<!--Page content -->
<div class="content" data-ng-init="initObject();getAllLeague()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.feeds}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.league" width="25%"></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center" width="25%">
							<select data-placeholder="{{lang.select_league}}" id="league_id" ng-options="league.league_id as league.league_abbr for league in leagues track by league.league_id" class="select-full" ng-model="feedsParam.league_id" data-ng-change="filterResult()" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value=""></option>
							</select>
						</td>
						<td  width="50%">
							<div class="col-sm-6">
								<input type="text" class="from-date form-control" name="from" date-picker-range="to-date" placeholder="{{lang.from}}" ng-model="feedsParam.fromdate" readonly="">
							</div>
							<div class="col-sm-6">
								<input type="text" class="to-date form-control" name="to" date-picker-range placeholder="{{lang.to}}" ng-model="feedsParam.todate" data-ng-change="filterResult()" readonly="">
							</div>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="clearFilter()"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.feed_list"></h6>
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="feedsList.length>0">
						<th width="2%">
							#
						</th>
						<th data-ng-bind="lang.feed_name">
						</th>
						<th data-ng-bind="lang.league">
						</th>
						<th data-ng-bind="lang.feed_url">
						</th>
						<th data-ng-bind="lang.created_date">
						</th>
						<th data-ng-bind="lang.action">
						</th>
					</tr>
					<tr ng-if="feedsList.length==0">
						<td align="center" colspan="4" data-ng-bind="lang.no_feeds"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="feedsList.length>0" ng-repeat="feed in feedsList">
						<td ng-bind="((feedsParam.current_page*10)+$index)-9"></td>
						<td ng-bind="::feed.feed_name"></td>
						<td ng-bind="::feed.league_abbr"></td>
						<td>
						<a ng-href="feed.feed_url">URL</a>
						</td>
						<td ng-bind="::feed.created_date"></td>
						<td><a href="javascript:void(0);" ng-click="getFeedData(feed.id)" title="Feed Date"><i class="fa fa-crosshairs"></i></a></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="feedsList.length>0">
			<pagination ng-if="feedsParam.total_items>10" boundary-links="true" total-items="feedsParam.total_items" ng-model="feedsParam.current_page" ng-change="getFeedsList()" items-per-page="feedsParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->

	<!-- Raw Data modal -->

	<div id="raw_data_modal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h5 class="modal-title" data-ng-bind="lang.feed_raw_data"></h5>
				</div>
				<div class="modal-body has-padding">
					<div class="form-group">
						<label>Feed Raw Data</label>
					<div class="raw_data">
						<json-formatter json="feedData" open="1"></json-formatter>
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- / Raw Data modal -->
</div>
<!-- /Page content-->
