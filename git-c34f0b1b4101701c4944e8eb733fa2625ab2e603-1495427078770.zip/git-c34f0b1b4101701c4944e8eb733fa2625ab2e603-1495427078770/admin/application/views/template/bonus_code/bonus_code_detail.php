<!-- Page content -->
<div class="content" data-ng-init="getBonusCodeDetail()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.bonus_code_detail_list}}</h5>
	</div>
	<!-- /page title -->

	<!-- bonus code detail End Section -->
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.bonus_code_detail">bonus Code Detail</h6></div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="bonusCodeDetailList.length==0">
				<thead>
					<tr>
						<td align="center" data-ng-bind="lang.no_bonus_code_detail"></td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="bonusCodeDetailList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortbonusCodeDetailList('bonus_code');">
							{{lang.bonus_code}}
							<i ng-class="(bonusCodeDetailParam.sort_field=='bonus_code'&&bonusCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeDetailParam.sort_field=='bonus_code'&&bonusCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th  class="pointer" ng-click="sortbonusCodeDetailList('full_name');">
							{{lang.full_name}}
							<i ng-class="(bonusCodeDetailParam.sort_field=='full_name'&&bonusCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeDetailParam.sort_field=='full_name'&&bonusCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortbonusCodeDetailList('payment_request');">
							{{lang.deposit_amount}}
							<i ng-class="(bonusCodeDetailParam.sort_field=='payment_request'&&bonusCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeDetailParam.sort_field=='payment_request'&&bonusCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortbonusCodeDetailList('bonus_amount');">
							{{lang.bonus_amount}}
							<i ng-class="(bonusCodeDetailParam.sort_field=='bonus_amount'&&bonusCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeDetailParam.sort_field=='bonus_amount'&&bonusCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortbonusCodeDetailList('added_date');">
							{{lang.bonuscode_used_date}}
							<i ng-class="(bonusCodeDetailParam.sort_field=='added_date'&&bonusCodeDetailParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeDetailParam.sort_field=='added_date'&&bonusCodeDetailParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="bonuscode in bonusCodeDetailList">
						<td data-ng-bind="bonuscode.bonus_code"></td>
						<td data-ng-bind="bonuscode.full_name"></td>
						<td data-ng-bind="bonuscode.payment_request | salaryFormat">
						<td data-ng-bind="bonuscode.bonus_amount | salaryFormat"></td>
						<td data-ng-bind="bonuscode.added_date"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="bonusCodeDetailParam.total_items>10">
			<pagination boundary-links="true" total-items="bonusCodeDetailParam.total_items" ng-model="bonusCodeDetailParam.current_page" ng-change="getbonusCodeDetail()" items-per-page="bonusCodeDetailParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- bonus code detail End -->
</div>
<!-- /Page content -->