<!-- Page content -->
<div class="content" data- ng-init="getBonusCodes();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.bonus_code_list}}</h5>
	</div>
	<!-- /page title -->

	<!-- Promocode Section -->
	<div class="panel panel-default">
		<div class="panel-heading"><h6 class="panel-title" data-ng-bind="lang.bonus_code"></h6></div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered" ng-show="bonusCodeList.length==0">
				<thead>
					<tr>
						<td align="center" data-ng-bind="lang.no_bonus_code"></td>
					</tr>
				</thead>
			</table>
			<table class="table table-hover table-striped table-bordered" ng-show="bonusCodeList.length>0">
				<thead>
					<tr>
						<th class="pointer" ng-click="sortBonusCodesList('bonus_name');">
							{{lang.name_of_bonus_code}}
							<i ng-class="(bonusCodeParam.sort_field=='bonus_name'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='bonus_name'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortBonusCodesList('bonus_code');">
							{{lang.bonus_code}}
							<i ng-class="(bonusCodeParam.sort_field=='bonus_code'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='bonus_code'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortBonusCodesList('discount');">
							{{lang.discount}}
							<i ng-class="(bonusCodeParam.sort_field=='discount'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='discount'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortBonusCodesList('cycle');">
							Cycle
							<i ng-class="(bonusCodeParam.sort_field=='cycle'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='cycle'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortBonusCodesList('start_date');">
							{{lang.start_date}}
							<i ng-class="(bonusCodeParam.sort_field=='start_date'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='start_date'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortBonusCodesList('expiry_date');">
							{{lang.end_date}}
							<i ng-class="(bonusCodeParam.sort_field=='expiry_date'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='expiry_date'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortBonusCodesList('status');">
							{{lang.status}}
							<i ng-class="(bonusCodeParam.sort_field=='status'&&bonusCodeParam.sort_order=='DESC')?'fa-sort-desc':((bonusCodeParam.sort_field=='status'&&bonusCodeParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th data-ng-bind="lang.action">
						</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="bonus in bonusCodeList">
						<td data-ng-bind="::bonus.bonus_name"></td>
						<td data-ng-bind="::bonus.bonus_code"></td>
						<td data-ng-bind="::bonus.discount"></td>
						<td data-ng-bind="bonus.cycle"></td>
						<td data-ng-bind="::bonus.start_date"></td>
						<td data-ng-bind="::bonus.expiry_date"></td>
						<td>
							<i class="fa fa-lock danger" ng-show="bonus.status==0" title="Sales Person Activation Pending"></i>
							<i class="fa fa-unlock success" ng-show="bonus.status==1" title="Sales Person Active"></i>
						</td>
						<td>
							<a href="bonus_code_detail/{{bonus.bonus_code}}">
								<span class="label label-primary" data-ng-bind="lang.detail_view"></span>
							</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-show="bonusCodeParam.total_items>10">
			<pagination boundary-links="true" total-items="bonusCodeParam.total_items" ng-model="bonusCodeParam.current_page" ng-change="getPromoCodes()" items-per-page="bonusCodeParam.items_perpage" class="pagination-sm pull-right" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!--Promocode End -->
</div>
<!-- /Page content -->