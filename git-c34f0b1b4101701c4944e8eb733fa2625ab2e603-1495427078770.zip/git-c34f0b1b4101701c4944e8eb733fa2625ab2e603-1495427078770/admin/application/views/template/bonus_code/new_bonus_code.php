<style type="text/css">
	.select2-container.select-full{width: 100%;}
</style>
<!--Page content -->
<div class="content">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-align-justify"></i>{{lang.create_bonus_code}}</h5>
	</div>
	<!-- page title -->

	<!-- New Promocode Section Start -->
	<form class="form-horizontal" role="form" bonuscode-form submit-handle="newBonusCode()">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title" data-ng-bind="lang.bonus_code"></h6></div>
			<div class="panel-body">
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="bonus_code">{{lang.name_of_bonus_code}}
								<span class="mandatory">*</span>								
							</label>
							<div class="col-md-9">
								<input id="bonus_name" name="bonus_name" type="text" ng-model="newBonusCodeParam.bonus_name" class="form-control">
								<label for="bonus_name" class="error hide" id="bonus_name_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="bonus_code">{{lang.bonus_code}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.bonus_code_help}}" tool-tip><i class="fa fa-info-circle help"></i></a> 
							</label>
							<div class="col-md-9">
								<input id="bonus_code" name="bonus_code" type="text" ng-model="newBonusCodeParam.bonus_code" class="form-control" maxlength="7">
								<label for="bonus_code" class="error hide" id="bonus_code_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="discount">{{lang.discount}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="{{lang.discount_help}}" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input id="discount" name="discount" intiger-only maxlength="2" type="text" ng-model="newBonusCodeParam.discount" class="form-control">
								<label for="discount" class="error hide" id="discount_error"></label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="cycle">{{lang.cycle}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="How many times you want this bonus cash to be utilized by users. 0 for unlimited" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input id="cycle" name="cycle" intiger-only maxlength="3" type="text" ng-model="newBonusCodeParam.cycle" class="form-control">
								<label for="cycle" class="error hide" id="cycle_error"></label>
							</div>
						</div>
						<!-- <div class="row">
							<label class="col-md-3 control-label" for="benefit_cap">{{lang.benefit_cap}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="Maximum bonus value of the discount." tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input id="benefit_cap" name="benefit_cap" intiger-only maxlength="5" type="text" ng-model="newBonusCodeParam.benefit_cap" class="form-control">
								<label for="benefit_cap" class="error hide" id="benefit_cap_error"></label>
							</div>
						</div> -->
					</div>
				</div>
				<div class="form-group">
					<!-- <div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="cycle">{{lang.cycle}}
								<span class="mandatory">*</span>
								<a href="#" data-placement="top" title="How many times you want this bonus cash to be utilized by users. 0 for unlimited" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-9">
								<input id="cycle" name="cycle" intiger-only maxlength="3" type="text" ng-model="newBonusCodeParam.cycle" class="form-control">
								<label for="cycle" class="error hide" id="cycle_error"></label>
							</div>
						</div>
					</div> -->
					<div class="col-md-6">
						<div class="row">
							<label class="col-md-3 control-label" for="start_date">{{lang.bonus_code_date}} 
								<span class="mandatory">*</span> 
								<a href="#" data-placement="top" title="Bonus code start and end date" tool-tip><i class="fa fa-info-circle help"></i></a>
							</label>
							<div class="col-md-4">
								<input type="text" class="from-date form-control" name="start_date" id="start_date" min-date="from-date" date-picker-range="to-date" placeholder="{{lang.start_date}}" ng-model="newBonusCodeParam.start_date" readonly="">
								<label for="start_date" class="error hide" id="start_date_error"></label>
							</div>
							<div class="col-md-4">
								<input type="text" class="to-date form-control" name="expiry_date" id="expiry_date" date-picker-range placeholder="{{lang.end_date}}" ng-model="newBonusCodeParam.expiry_date" readonly="">
								<label for="expiry_date" class="error hide" id="expiry_date_error"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success"><i class=""></i>{{lang.submit}}</button>
					<a ng-href="bonus_code"><button type="button" class="btn btn-warning"></i>{{lang.cancel}}</button></a>
				</div>
			</div>
		</div>
	</form>
	<!-- New Promocode Section End -->
</div>
<!-- Page content -->