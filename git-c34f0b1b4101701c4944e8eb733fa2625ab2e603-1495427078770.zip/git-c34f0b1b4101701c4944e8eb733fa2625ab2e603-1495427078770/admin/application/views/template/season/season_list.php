<style>
    .ui-datepicker {
        z-index: 9999 !important; background:#3c9ac9;
    }
    .ui-datepicker .ui-timepicker-div{padding:10px;}
    .ui-datepicker .ui-datepicker-buttonpane button{background:#fff; color:#333; border:0px; margin-left:10px; margin-bottom:10px;}
</style>
<!--Page content -->
<div class="content" data-ng-init="getFilterData();getAllLeague();initObject();">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.seasons}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.league"></th>
						<th data-ng-bind="lang.team"></th>
						<th data-ng-bind="lang.season_schedule"></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center">
							<select id="league_id" data-placeholder="{{lang.select_league}}" ng-options="league.league_id as league.league_abbr for league in leagues track by league.league_id"  class="select-full" ng-model="seasonParam.league_id" data-ng-change="getAllTeam()" select-two="minimumResultsForSearch:'-2',width:'100%'">
								<option value=""></option>
							</select>
						</td>
						<td class="text-center">
							<select id="team_league_id" data-placeholder="{{lang.all_team}}" ng-options="team.team_league_id as team.team_name+'('+team.team_abbreviation+')' for team in teams track by team.team_league_id" class="select-full" ng-model="seasonParam.team_league_id" ng-change="filterResult()" select-two="minimumResultsForSearch:'-2',width:'100%'">
								<option value=""></option>
							</select>
						</td>
						<td  width="25%">
							<div class="col-sm-6">
								<input type="text" class="from-date form-control" name="from" date-picker-range="to-date" placeholder="{{lang.from}}" ng-model="seasonParam.fromdate" readonly="">
							</div>
							<div class="col-sm-6">
								<input type="text" class="to-date form-control" name="to" date-picker-range placeholder="{{lang.to}}" ng-model="seasonParam.todate" data-ng-change="filterResult()" readonly="">
							</div>
						</td>
					</tr>
					<tr>
						<td colspan="4">
							<a href="javascript:void(0);" ng-click="clearFilter()"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.season_schedule"></h6>
			<h6 class="panel-title pull-right">Total Record Count : <span ng-bind="seasonParam.total_items"></span></h6>
        </div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="seasonList.length>0">
						<th width="15%">
							{{lang.season_game_id}}
						</th>
						<th class="pointer" ng-click="sortSeasonList('type');">
							{{lang.season_type}}
							<i ng-class="(seasonParam.sort_field=='type'&&seasonParam.sort_order=='DESC')?'fa-sort-desc':((seasonParam.sort_field=='type'&&seasonParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSeasonList('home');">
							{{lang.home}}
							<i ng-class="(seasonParam.sort_field=='home'&&seasonParam.sort_order=='DESC')?'fa-sort-desc':((seasonParam.sort_field=='home'&&seasonParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSeasonList('away');">
							{{lang.away}}
							<i ng-class="(seasonParam.sort_field=='away'&&seasonParam.sort_order=='DESC')?'fa-sort-desc':((seasonParam.sort_field=='away'&&seasonParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSeasonList('season_scheduled_date');">
							{{lang.season_schedule}}
							<i ng-class="(seasonParam.sort_field=='season_scheduled_date'&&seasonParam.sort_order=='DESC')?'fa-sort-desc':((seasonParam.sort_field=='season_scheduled_date'&&seasonParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSeasonList('year');">
							{{lang.year}}
							<i ng-class="(seasonParam.sort_field=='year'&&seasonParam.sort_order=='DESC')?'fa-sort-desc':((seasonParam.sort_field=='year'&&seasonParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortSeasonList('status');">
							{{lang.status}}
							<i ng-class="(seasonParam.sort_field=='status'&&seasonParam.sort_order=='DESC')?'fa-sort-desc':((seasonParam.sort_field=='status'&&seasonParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th>
							{{lang.season_stats}}
						</th>
					</tr>
					<tr ng-if="seasonList.length==0">
						<td align="center" colspan="9" data-ng-bind="lang.no_season_schedule"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="seasonList.length>0" ng-repeat="season in seasonList">
						<td ng-bind="::season.season_game_uid" align="left"></td>
						<td ng-bind="::season.type"></td>
						<td ng-bind="::season.home"></td>
						<td ng-bind="::season.away"></td>
						<td ng-bind="::season.season_scheduled_dates"></td>
						<td ng-bind="::season.year"></td>
						<td ng-bind="::season.status"></td>
						<td>
                            <a href="seasonstats/{{season.season_game_uid}}/{{seasonParam.league_id}}">
								<span class="label label-primary" data-ng-bind="lang.stats_detail"></span>
							</a>
                            
	                    </td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="seasonParam.total_items>10">
			<pagination  boundary-links="true" total-items="seasonParam.total_items" ng-model="seasonParam.current_page" ng-change="getSeasonList()" items-per-page="seasonParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->
