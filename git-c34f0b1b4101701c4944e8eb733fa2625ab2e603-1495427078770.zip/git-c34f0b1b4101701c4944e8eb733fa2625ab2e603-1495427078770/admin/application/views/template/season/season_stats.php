<!--Page content -->
<div class="content" data-ng-init="getSeasonStatsList()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>Season Stats</h5>
	</div>	
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title">Season Stats List <span class="" ng-if="summaries!=''"> ({{summaries}})</span> </h6>
                        <a ng-if="seasonStatsParam.league_id == 5" href="javascript:void(0);" ng-click="showAddStatisticsPopup()">
                            <span class="pull-right label label-success ">Add Statistics</span>
                        </a>
		</div>
		<div class="table-responsive" style="overflow:auto;">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="season_stats.length>0">
						<th ng-repeat="stats in fields" ng-click="sortSeasonStatsList(stats);">
							{{stats | removeUnderScore}}
							<i ng-class="(seasonStatsParam.sort_field==stats&&seasonStatsParam.sort_order=='DESC')?'fa-sort-desc':((seasonStatsParam.sort_field==stats&&seasonStatsParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
					<tr ng-if="season_stats.length==0">
						<td align="center" colspan="{{fields.length}}">No Season Schedule</td>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="stats in season_stats">
						<td ng-repeat="fi in fields">{{stats[fi]}}</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="seasonStatsParam.total_items>10">
			<pagination  boundary-links="true" total-items="seasonStatsParam.total_items" ng-model="seasonStatsParam.current_page" ng-change="getSeasonStatsList()" items-per-page="seasonStatsParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->

<!-- Add Statistics Popup START -->
<div id="add_statistics_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" style="width: 80%;">
                <div class="modal-content">
                        <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h5 class="modal-title">Add Statistics</h5>
                        </div>

                    <form role="form">
                                <div class="modal-body has-padding">
                                        <div class="table-responsive">
                                                <table class="table table-striped table-bordered">
                                                        <thead>
                                                                <tr>
                                                                        <th width="15%">Team Name</th>
                                                                        <th width="20%">Player Name</th>
                                                                        <th width="20%">Scoring Type</th>
                                                                        <th width="20%">Event</th>
                                                                        <th width="10%">Score</th>
                                                                        <th width="10%">Minutes</th>
                                                                        <th width="5%"></th>
                                                                </tr>
                                                        </thead>
                                                        <tbody>
                                                                <tr ng-repeat="statistic in statistics_data.statistics track by $index">
                                                                        <td class="text-center">
                                                                                <select data-placeholder="Select Team" id="team_id_{{$index}}" ng-options="team.team_id as team.team_name+' ('+team.team_abbr+')' for team in teams track by team.team_id" 
                                                                                        ng-model="statistic.team_id" ng-change="onChangeTeam($index)" class="select-full" select-two="minimumResultsForSearch:'2',width:'100%'">
                                                                                        <option value=""></option>
                                                                                </select>
                                                                                <label for="team_id_{{$index}}" class="error hide" id="team_id_{{$index}}_error"></label>
                                                                        </td>

                                                                        <td class="text-center">
                                                                            <!--ng-options="player.player_unique_id as player.full_name for player in players track by player.player_unique_id  | filter:{team_id: statistic.team_id}" -->
                                                                                <select data-placeholder="Select Player" id="player_id_{{$index}}" class="select-full" ng-model="statistic.player_unique_id" select-two="minimumResultsForSearch:'2',width:'100%',vasl:'{{$index}}'">
                                                                                        <option value=""></option>
                                                                                        <option ng-repeat="player in players  | filter:{team_id:statistic.team_id}:strict" value="{{player.player_unique_id}}"  ng-bind="player.full_name"></option>
                                                                                </select>
                                                                                <label for="player_id_{{$index}}" class="error hide" id="player_id_{{$index}}_error"></label>
                                                                                {{statistic.team_id}} || {{statistic.player_unique_id}}
                                                                        </td>

                                                                        <td class="text-center">
                                                                                <select data-placeholder="Select Scoring Type" id="scoring_category_{{$index}}" ng-options="scategory.master_scoring_category_id as scategory.scoring_category_name | removeUnderScore for scategory in scoring_category track by scategory.master_scoring_category_id" class="select-full" 
                                                                                        ng-model="statistic.master_scoring_category_id" ng-change="onChangeScoringCategory($index)" select-two="minimumResultsForSearch:'2',width:'100%'">
                                                                                        <option value=""></option>
                                                                                </select>
                                                                                <label for="scoring_category_{{$index}}" class="error hide" id="scoring_category_{{$index}}_error"></label>
                                                                        </td>
                                                                        <td class="text-center">
                                                                                <!-- ng-options="srule.stats_key as srule.stats_key for srule in scoring_rule track by srule.stats_key" -->
                                                                                <select data-placeholder="Select Event" id="scoring_rule_{{$index}}" class="select-full" ng-model="statistic.stats_key" select-two="minimumResultsForSearch:'2',width:'100%'">
                                                                                        <option value=""></option>
                                                                                        <option ng-repeat="srule in scoring_rule  | filter:{master_scoring_category_id:statistic.master_scoring_category_id}:strict | unique:'stats_key'" value="{{srule.stats_key}}"  ng-bind="srule.stats_key"></option>
                                                                                </select>
                                                                                {{statistic.master_scoring_category_id}}
                                                                                <label for="scoring_rule_{{$index}}" class="error hide" id="scoring_rule_{{$index}}_error"></label>
                                                                        </td>
                                                                        <td class="text-center">
                                                                                <input type="text" placeholder="Score" id="score_{{$index}}" name="score" ng-model="statistic.stats_value" class="form-control">
                                                                                <label for="score_{{$index}}" class="error hide" id="score_{{$index}}_error"></label>
                                                                        </td>
                                                                        <td class="text-center">
                                                                                <input type="text" placeholder="Minute" id="minute_{{$index}}" name="minute" ng-model="statistic.minute" class="form-control">
                                                                                <label for="minute_{{$index}}" class="error hide" id="minute_{{$index}}_error"></label>
                                                                        </td>
                                                                        <td class="text-center">
                                                                            <a ng-show="statistics_data.statistics.length > 1" ng-click="RemoveStatisticRow($index)">
                                                                                <i class="fa fa-times" title="Remove"></i>
                                                                            </a>
                                                                            <input type="hidden" id="row_{{$index}}" name="row" ng-model="statistic.row" ng-init="statistic.row = $index;">
                                                                        </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="7">
                                                                        <a href="javascript:void(0);" ng-click="AddStatisticRow()">
                                                                            <span class="label label-info">Add More</span>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                        </tbody>
                                                </table>
                                        </div>
                                </div>

                                <div class="modal-footer">
                                        <button type="button" class="btn btn-success" ng-click="SaveStatistics();">Save</button>
                                        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
                                </div>
                        </form>
                </div>
        </div>
</div>
<!-- Add Statistics Popup END -->
