<!--Page content -->
<div class="content" data-ng-init="getAllLeague()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>{{lang.manage_team}}</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
        </div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th data-ng-bind="lang.league"></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center" width="30%">
							<select data-placeholder="{{lang.select_league}}" id="league_id" ng-options="league.league_id as league.league_abbr for league in leagues track by league.league_id" class="select-full" ng-model="teamrosterParam.league_id" data-ng-change="filterResult()" select-two="minimumResultsForSearch:'2',width:'100%'">
								<option value=""></option>
							</select>
						</td>
						<td>
							&nbsp;
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="clearFilter()"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.team_list"></h6>
			<h6 class="panel-title pull-right">Total Record Count : <span ng-bind="teamrosterParam.total_items"></span></h6>
                        
                      
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="teamrosterList.length>0">
						<th width="2%">
							#
						</th>
						<th width="7%" data-ng-bind="lang.team_id">
						</th>
						<th class="pointer" ng-click="sortTeamrosterList('team_name');">
							{{lang.team_name}}
							<i ng-class="(teamrosterParam.sort_field=='team_name'&&teamrosterParam.sort_order=='DESC')?'fa-sort-desc':((teamrosterParam.sort_field=='team_name'&&teamrosterParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortTeamrosterList('team_abbr');">
							{{lang.team_abbr}}
							<i ng-class="(teamrosterParam.sort_field=='team_abbr'&&teamrosterParam.sort_order=='DESC')?'fa-sort-desc':((teamrosterParam.sort_field=='team_abbr'&&teamrosterParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
					</tr>
					<tr ng-if="teamrosterList.length==0">
						<td align="center" colspan="4" data-ng-bind="lang.no_team"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="teamrosterList.length>0" ng-repeat="teamroster in teamrosterList">
						<td ng-bind="((teamrosterParam.current_page*10)+$index)-9"></td>
						<td ng-bind="::teamroster.team_id"></td>
						<td ng-bind="::teamroster.team_name"></td>
						<td ng-bind="::teamroster.team_abbr" ng-hide="teamObj.showSaveTeam  == teamroster.team_id"></td>
						<td ng-show="teamObj.showSaveTeam  == teamroster.team_id">
							<input type="text" name="contest_name" class="form-control" ng-model="team_abbrs[$index]" value="{{teamroster.team_abbr}}" ng-init="team_abbrs[$index]=teamroster.team_abbr">
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="teamrosterList.length>0">
			<pagination ng-if="teamrosterParam.total_items>10" boundary-links="true" total-items="teamrosterParam.total_items" ng-model="teamrosterParam.current_page" ng-change="getTeamList()" items-per-page="teamrosterParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->



