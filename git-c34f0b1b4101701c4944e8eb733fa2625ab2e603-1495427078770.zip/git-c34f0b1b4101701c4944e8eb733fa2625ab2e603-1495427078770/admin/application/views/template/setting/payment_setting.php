<!--Page content -->
<div class="content">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>Setting</h5>
	</div>
	<!-- Change Password -->
		<form class="form-horizontal" role="form" paymentconfig-form name="paymentconfig_form" id="paymentconfig_form">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h6 class="panel-title">Payment Setting</h6>
				</div>
				<div class="panel-body" ng-init="getPaymentSetting()">
						
						<!-- <div class="form-group" ng-repeat="config in configObj">
							<label class="col-md-2 control-label" for="date">{{lang.payment_config_array[config.meta_key]}} :
								<span class="mandatory">*</span> 
							</label>
							<div class="col-md-5">
								<div class="col-md-5">
								 <input type="text" id="{{config.meta_key}}" name="{{config.meta_key}}" value="{{config.meta_value}}" class="form-control required">
								 <label for="{{config.meta_key}}" class="error hide" id="{{config.meta_key+'_error'}}"></label>
								</div>
							</div>
						</div> -->	
					<div class="form-group">
						<div class="col-md-6">
							<div class="row">
								<label class="col-md-3 control-label">&nbsp;</label>
								<div class="col-md-9">
									<div class="">
										<div class="checkbox-inline">
											<label for="is_feature">
												<input type="checkbox" id="paypal" class="styled" ng-model="contestParam.paypal" uniform="radioClass:'choice', selectAutoWidth:false">
												PayPal
											</label>
											&nbsp
											<label for="is_feature">
												<input type="checkbox" id="conekta" class="styled" ng-model="contestParam.conekta" uniform="radioClass:'choice', selectAutoWidth:false">
												Conekta
											</label>
											&nbsp
											<label for="is_feature">
												<input type="checkbox" id="ripple" class="styled" ng-model="contestParam.ripple" uniform="radioClass:'choice', selectAutoWidth:false">
												Ripple
											</label>
											&nbsp
											<label for="is_feature">
												<input type="checkbox" id="paysafe" class="styled" ng-model="contestParam.paysafe" uniform="radioClass:'choice', selectAutoWidth:false">
												Paysafe
											</label>
											&nbsp
											<label for="is_feature">
												<input type="checkbox" id="payumoney" class="styled" ng-model="contestParam.payumoney" uniform="radioClass:'choice', selectAutoWidth:false">
												Payumoney
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>	
						
					<div class="form-actions text-left">
						<button type="submit" class="btn btn-success" ng-click="updatepayment()"><i class=""></i>{{lang.update}}</button>
					</div>
			</div>
		</form>

	<!-- Change Password -->
</div>
<!-- /Page content-->
