<!--Page content -->
<div class="content">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>Setting</h5>
	</div>
	<!-- Change Password -->
	<form class="form-horizontal" role="form">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title">Update Referral Setting</h6>
			</div>
			<div class="panel-body" ng-init="getReferralAmount()">
				<div class="form-group">
					<label class="col-md-2 control-label" for="date">Referral Discount (in %) :
						<span class="mandatory">*</span> 
						<!-- <a href="#" data-placement="top" title="{{lang.invest_money_help}}" tool-tip><i class="fa fa-info-circle help"></i></a> -->
					</label>
					<div class="col-md-5">
						<div class="col-md-5">
						<input type="text" id="referral_discount" name="referral_discount" ng-model="settingObj.referral_discount" class="form-control" intiger-only>						
					</div>
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-2 control-label" for="date">Referral Threshold Amount :
						<span class="mandatory">*</span>
						<!-- <a href="#" data-placement="top" title="{{lang.referral_amount_help}}" tool-tip><i class="fa fa-info-circle help"></i></a> -->
					</label>
					<div class="col-md-5">
						<div class="col-md-5">
						<input type="text" id="referral_threshold_amount" name="referral_threshold_amount" ng-model="settingObj.referral_threshold_amount" class="form-control" intiger-only>						
					</div>
					</div>
				</div>
				<div class="form-actions text-left">
					<button type="submit" class="btn btn-success" ng-click="updateReferralAmount()"><i class=""></i>{{lang.update}}</button>
				</div>
			</div>
		</div>
	</form>
	<!-- Change Password -->
</div>
<!-- /Page content-->
