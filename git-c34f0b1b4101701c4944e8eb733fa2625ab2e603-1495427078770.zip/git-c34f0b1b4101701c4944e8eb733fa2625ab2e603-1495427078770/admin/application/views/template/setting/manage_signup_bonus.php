<!--Page content -->
<div class="content">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>Setting</h5>
	</div>
	<!-- Change Password -->
		<form class="form-horizontal" role="form" signupbonus-form name="signupbonus_form" id="signupbonus_form" submit-handle="updateSignupBonus()">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h6 class="panel-title">Manage Signup Bonus</h6>
				</div>
				<div class="panel-body" ng-init="getSingupBonus()">
					<div class="form-group">
						<label class="col-md-2 control-label" for="date">Signup Bonus Amount :
							<span class="mandatory">*</span> 
							<a href="#" data-placement="top" title="Bonus Amount" tool-tip><i class="fa fa-info-circle help"></i></a>
						</label>
						<div class="col-md-5">
							<div class="col-md-5">
							<input type="text" id="signup_bonus_amount" name="signup_bonus_amount" ng-model="singupBonusObj.signup_bonus_amount" class="form-control" intiger-only>						
						</div>
						</div>
					</div>
					<div class="form-actions text-left">
						<button type="submit" class="btn btn-success"><i class=""></i>{{lang.update}}</button>
					</div>
			</div>
		</form>

	<!-- Change Password -->
</div>
<!-- /Page content-->
