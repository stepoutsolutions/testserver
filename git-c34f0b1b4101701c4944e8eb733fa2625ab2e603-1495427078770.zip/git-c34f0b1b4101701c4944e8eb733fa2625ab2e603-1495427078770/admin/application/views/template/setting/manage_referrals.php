<!--Page content -->
<div class="content" data-ng-init="initReferralObject()">
	<!-- Page title -->
	<div class="page-title">
		<h5><i class="fa fa-bars"></i>Manage Referrals</h5>
	</div>
	<!-- Table elements -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title" data-ng-bind="lang.filters"></h6>
        </div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Search by Email</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="text-center" width="30%">
							<input type="text" placeholder="Search by email" id="keyword" name="keyword" ng-model="referralParam.keyword" class="form-control" data-ng-change="searchByEmail()">
						</td>
						<td>
							&nbsp;
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<a href="javascript:void(0);" ng-click="clearFilter()"><span class="label label-info" data-ng-bind="lang.clear_filters"></span></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /table elements -->
	<!-- Table with footer -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<h6 class="panel-title">Referrals</h6>
			<h6 class="panel-title pull-right">Total Record Count : <span ng-bind="referralParam.total_items"></span></h6>
                        
                      
		</div>
		<div class="table-responsive">
			<table class="table table-hover table-striped table-bordered table-check">
				<thead>
					<tr ng-if="referralList.length>0">
						<th width="2%">
							#
						</th>
						<th class="pointer" ng-click="sortreferralList('from_user');">
							Send By
							<i ng-class="(referralParam.sort_field=='from_user'&&referralParam.sort_order=='DESC')?'fa-sort-desc':((referralParam.sort_field=='from_user'&&referralParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortreferralList('to_email');">
							Send To
							<i ng-class="(referralParam.sort_field=='to_email'&&referralParam.sort_order=='DESC')?'fa-sort-desc':((referralParam.sort_field=='to_email'&&referralParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortreferralList('invite_date_time');">
							Send Date
							<i ng-class="(referralParam.sort_field=='invite_date_time'&&referralParam.sort_order=='DESC')?'fa-sort-desc':((referralParam.sort_field=='invite_date_time'&&referralParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortreferralList('is_registered');">
							Status
							<i ng-class="(referralParam.sort_field=='is_registered'&&referralParam.sort_order=='DESC')?'fa-sort-desc':((referralParam.sort_field=='is_registered'&&referralParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortreferralList('is_referral_bonus');">
							Referral Bonus
							<i ng-class="(referralParam.sort_field=='is_referral_bonus'&&referralParam.sort_order=='DESC')?'fa-sort-desc':((referralParam.sort_field=='is_referral_bonus'&&referralParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						<th class="pointer" ng-click="sortreferralList('source');">
							Source
							<i ng-class="(referralParam.sort_field=='source'&&referralParam.sort_order=='DESC')?'fa-sort-desc':((referralParam.sort_field=='source'&&referralParam.sort_order=='ASC')?'fa-sort-asc':'')" class="fa"></i>
						</th>
						
					</tr>
					<tr ng-if="referralList.length==0">
						<td align="center" colspan="10" data-ng-bind="lang.no_team"></td>
					</tr>
				</thead>
				<tbody>
					<tr ng-if="referralList.length>0" ng-repeat="referrals in referralList">
						<td ng-bind="((referralParam.current_page*10)+$index)-9"></td>
						<td ng-bind="::referrals.from_user"></td>
						<td ng-bind="::referrals.to_email"></td>
						<td ng-bind="::referrals.invite_date_time"></td>
						<td>
								<span ng-if="referrals.is_registered == 0">Not Accepted</span>
								<span ng-if="referrals.is_registered == 1">Accepted</span>
						</td>
						<td>
								<span ng-if="referrals.is_referral_bonus == 0">NO</span>
								<span ng-if="referrals.is_referral_bonus == 1">YES</span>
						</td>
						<td ng-bind="::referrals.source"></td>
						
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table-footer" ng-if="referralList.length>0">
			<pagination ng-if="referralParam.total_items>10" boundary-links="true" total-items="referralParam.total_items" ng-model="referralParam.current_page" ng-change="getReferralList()" items-per-page="referralParam.items_perpage" class="pagination" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
		</div>
	</div>
	<!-- /table with footer -->
</div>
<!-- /Page content-->



