<?php $auth_key = $this->config->item('rest_key_name');?>
<script type="text/javascript">
	var mOxie = {};
	Object.defineProperty(window, 'site_url', {value:'<?php echo site_url()?>', writable:false});
	Object.defineProperty(window, 'base_url', {value:'<?php echo base_url()?>', writable:false});
	Object.defineProperty(window, 'AUTH_KEY', {value:'<?php echo $auth_key?>', writable:false});
	Object.defineProperty(window, 'CURRENCY_CODE', {value:'<?php echo CURRENCY_CODE ;?>', writable:false});
	Object.defineProperty(window, 'SERVER_GLOBAL', {value:{}, writable:true});
	Object.defineProperty(window, 'YEAR_RANGE', {value:'1945:<?php echo format_date("Y")+1;?>', writable:false});
	<?php if($this->session->userdata($auth_key)){ ?>
		sessionStorage.setItem('<?php echo $auth_key; ?>', '<?php echo $this->session->userdata($auth_key); ?>');
	<?php } ?>
</script>