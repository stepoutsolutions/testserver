<?php echo $this->load->view('emailer/emailer_header'); ?>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="padding:0 30px 0 30px; background-color:#ffffff;"><p style="color:#F36D00; font-size:30px; font-family:Calibri; margin:0px; padding:0; font-weight:bold; line-height:50px; ">#PlayZoFunFact</p>Money withdrawn is money spent, money kept is money saved!! </br>
          ~ RaghuLaxman Rajan </br>
      Distant cousin of you know who!
      </td>
    </tr> 
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>  
    <tr>
      <td style="padding:0 30px 10px 30px;background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:18px;">
      Hi <?php echo $full_name;?></td>
    </tr>
     <tr>
      <td style="padding:0 30px 10px 30px;background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
         <?php if($status == 1) { ?>
            Your withdrawal request for amount <?php echo CURRENCY_CODE_EMAILER.$amount;?> has been Approved.
         <?php } else { ?>
             Your withdrawal request for amount <?php echo CURRENCY_CODE_EMAILER.$amount;?> has been Rejected.
           <a href=""></a>  
         <?php } ?>
      </td>
    </tr>
      <?php if($status == 1) { ?>
    <tr>
      <td style="padding:0 30px 10px 30px;background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
         Please reach out to <a href="mailto:<?php echo SUPPORT_EMAIL;?>" style="color:#F36D00; text-decoration:underline; cursor:pointer;"><?php echo SUPPORT_EMAIL;?></a> for any clarifications.
      </td>
    </tr>
     <?php } ?>
    <tr>
      <td style="padding:0 30px 10px 30px; background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
     <td style="padding:0 30px 10px 30px; background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
      Thanks,<br/>
      Team <?php echo SITE_TITLE;?> <br/>
      #FantasyMeetsReality
      </td>    
      </tr>
       <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>     
    <tr>
      <td>&nbsp;</td>
    </tr>
<?php echo $this->load->view('emailer/emailer_footer'); ?>   