<?php $base_url = IMAGE_PATH;?>
<table width="110" border="0" cellspacing="0" cellpadding="0" style="margin:0 auto; text-align:center;" class="social-link">        
<tr>
  <td valign="middle">
      <a href="javascript:void(0);" target="_blank">
         <img src="<?php echo $base_url; ?>assets/img/instagram-icon.png" border="0" alt="Instagram"/>
      </a>
   </td>
    <td valign="middle">
      <a href="javascript:void(0);" target="_blank">
         <img src="<?php echo $base_url;?>assets/img/f-logo.png" border="0" alt="Facebook"/>
      </a>
   </td>
  <td valign="middle">
      <a href="javascript:void(0);" target="_blank">
      <img src="<?php echo $base_url; ?>assets/img/youtube-icon.png" border="0" alt="YouTube"/>
      </a>
  </td>
</tr>
</table>