<!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo SITE_TITLE;?></title>
<style type="text/css">
table, tr, td, th {
	margin: 0;
	padding: 0;
}
img {
	border: none;
}
a {
	text-decoration: none;
	color:#F36D00 !important;
}
table[class="main-tbl"] {
	max-width:711px;
	margin:0px auto;
	
}
 @media only screen and (max-width:767px) {
body {
padding:0;
}
table[class="main-tbl"] {
 width:94%;
 margin:0px auto;
}
}
</style>
</head>
<body style="margin: 0;	padding: 0;	background-color:#EEEEEE;font-size:16px;color:#000;font-family:Arial, Helvetica, sans-serif;line-height:25px;">
<table cellpadding="0" cellspacing="0" width="100%" style="margin: 0;padding: 0;background-color:#EEEEEE;font-size:16px;color:#000;font-family:Arial, Helvetica, sans-serif;line-height:25px;">
<tr>
<td>
<table border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto;" class="main-tbl">

    <tr>
    <td valign="middle" align="left" style="height:80px; background-color:#ffffff; border-bottom:solid 3px #F36D00;"><a style="margin-left:auto;margin-right: auto;display: table;" href="<?php echo PATH_URL;?>"><img style="vertical-align: middle;" src="<?php echo PATH_URL.'assets/img/emailer/logo.png';?>" alt="<?php echo SITE_TITLE;?>" title="<?php echo SITE_TITLE;?>" /></a></td>
  </tr>