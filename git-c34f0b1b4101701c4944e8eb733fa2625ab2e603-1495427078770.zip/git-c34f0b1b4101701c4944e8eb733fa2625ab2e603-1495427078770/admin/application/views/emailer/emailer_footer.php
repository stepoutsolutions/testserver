 <tr>
      <td valign="middle" style="background-color:#eee; height:40px; text-align:center;font-size: 14px;font-weight: bold;color:#333333;">
   &copy; <?php echo date('Y').'   '.SITE_TITLE; ?> .All Rights Reserved.
    </td>
     </tr> 
     <tr>
      <td valign="middle" style="background-color:#eee; height:25px; text-align:center;font-size: 14px;font-weight: bold;color:#333333;">
      <a style="margin-left:auto;margin-right: 14px;display:inline-block;" href="<?php echo SITE_FB_URL;?>"><img style="vertical-align: middle;" src="<?php echo base_url('assets/img/emailer/facebook.png');?>" alt="facebook" title="facebook" /></a>
      <a style="margin-left:14px;margin-right: 14px;display:inline-block;" href="<?php echo SITE_TW_URL;?>"><img style="vertical-align: middle;" src="<?php echo base_url('assets/img/emailer/twitter.png');?>" alt="twitter" title="twitter" /></a>        
      </td>
     </tr> 
     <tr>
      <td>&nbsp;</td>
    </tr>

  </table>
    </td>  
    </tr>   
</table>
</body>
</html>