<?php echo $this->load->view('emailer/emailer_header'); ?>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="padding:0 30px 0 30px; background-color:#ffffff;"><p style="color:#F36D00; font-size:30px; font-family:Calibri; margin:0px; padding:0; font-weight:bold; line-height:50px; ">Thanks Edward,</p></td>
    </tr>   
    <tr>
      <td style="padding:0 30px 10px 30px;background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
      For registering with Playzo.com</td>
    </tr>
     <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
     <tr>
      <td style="padding:0 30px 10px 30px;background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
      This is to confirm that your registration was successful. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip........... Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip... Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip...</td>
    </tr>
    <tr>
      <td style="padding:0 30px 10px 30px;background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">Questions?<br/> 
Please send us an email at <a href="mailto" style="color:#F36D00; text-decoration:none; cursor:pointer;">emailme@gmail.com</a> and we will revert as soon as possible.
      </td>
    </tr> 
    <tr>
      <td style="padding:0 30px 10px 30px; background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
     <td style="padding:0 30px 10px 30px; background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
      Regards,<br/>
      Playzo Team
      </td>    
      </tr>
      <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>
    <tr>
      <td style="background-color:#ffffff;">&nbsp;</td>
    </tr>     
    <tr>
      <td>&nbsp;</td>
    </tr>
<?php echo $this->load->view('emailer/emailer_footer'); ?>   