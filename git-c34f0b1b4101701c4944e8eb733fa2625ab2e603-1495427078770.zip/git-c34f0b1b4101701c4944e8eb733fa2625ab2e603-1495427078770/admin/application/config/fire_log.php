<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['fire_log_strip_tags'] = TRUE;
$config['fire_log_param_dilem'] = "::";
$config['fire_log_pagination_settings'] = array('num_links' => 8, 'full_tag_open' => '<div class="paginationWrapper">', 'full_tag_close' => '</div>');