<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once('../config/config.php');

$config['language']	= 'english';
$config['sess_cookie_name'] = 'admin_playzo';

switch (ENVIRONMENT) {
	case 'production':
		$config['base_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/admin/';
	break;

	case 'staging':
		$config['base_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/playzo/admin/';
	break;

	default:
		$config['base_url'] = '';
	break;
}