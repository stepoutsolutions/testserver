<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*Season Stats Columns*/
/*$config['season_stats_common_field'] = array(
		"player_name"		=> "Player Name",
		"position"			=> "Position",
		"team_name"			=> "Team Name",
		"DATE_FORMAT(scheduled_date,'%d-%b-%Y %H:%i') as scheduled_dates"	=> "Schedule",
		"home"				=> "Home",
		"away"				=> "Away"
	);*/
$config['season_stats_common_field'] = array(
		"position"=>"position",
		"player_name"=>"player_name",
		"team_name"=>"team_name",
		"scheduled_date"=>'DATE_FORMAT(scheduled_date, "'.MYSQL_DATE_FORMAT.'") AS scheduled_date',
		"home"=>"home",
		"away"=>"away",
		//"home_team_goals"=>"home_team_goals",
		//"away_team_goals"=>"away_team_goals"
	);

$config['season_stats_field'] =  array(
		"1" => array(
			"yellow_card"      => "yellow_card",
			"red_card"         => "red_card",
			"minutes"          => "minutes",
			"goals_minutes"    => "goals_minutes",
			"goals"            => "goals",
			"assist"           => "assist",
			"clean_sheet"      => "clean_sheet",
			"save"             => "save",
			"penalty_saved"    => "penalty_saved",
			"penalty_missed"   => "penalty_missed",
			"goals_conceded"   => "goals_conceded",
			"own_goal"         => "own_goal",
			"shot_on_goal"     => "shot_on_goal",
			"shot_on_woodwork" => "shot_on_woodwork",
			"shot_off_target"  => "shot_off_target",
			"incorrect_pass"   => "incorrect_pass",
			"offside"          => "offside",
			"foul_suffered"    => "foul_suffered",
			"steal"            => "steal"
		),
		"2" => array(
			"yellow_card"      => "yellow_card",
			"red_card"         => "red_card",
			"minutes"          => "minutes",
			"goals_minutes"    => "goals_minutes",
			"goals"            => "goals",
			"assist"           => "assist",
			"clean_sheet"      => "clean_sheet",
			"save"             => "save",
			"penalty_saved"    => "penalty_saved",
			"penalty_missed"   => "penalty_missed",
			"goals_conceded"   => "goals_conceded",
			"own_goal"         => "own_goal",
			"shot_on_goal"     => "shot_on_goal",
			"shot_on_woodwork" => "shot_on_woodwork",
			"shot_off_target"  => "shot_off_target",
			"incorrect_pass"   => "incorrect_pass",
			"offside"          => "offside",
			"foul_suffered"    => "foul_suffered",
			"steal"            => "steal"
		),
		"3" => array(
			"yellow_card"      => "yellow_card",
			"red_card"         => "red_card",
			"minutes"          => "minutes",
			"goals_minutes"    => "goals_minutes",
			"goals"            => "goals",
			"goal_assist"      => "goal_assist",
			"clean_sheet"      => "clean_sheet",
			"saves"            => "saves",
			"penalty_save"     => "penalty_save",
			"penalty_conceded" => "penalty_conceded",
			"goals_conceded"   => "goals_conceded",
			"own_goals"        => "own_goals",
			"shot_off_target"  => "shot_off_target",
			"hit_woodwork"     => "hit_woodwork",
			"shot_off_target"  => "shot_off_target",
			"accurate_pass"    => "accurate_pass",
			"total_offside"    => "total_offside",
			"fouls"            => "fouls"
		),
		"4" => array(
			"yellow_card"      => "yellow_card",
			"red_card"         => "red_card",
			"minutes"          => "minutes",
			"goals_minutes"    => "goals_minutes",
			"goals"            => "goals",
			"goal_assist"      => "goal_assist",
			"clean_sheet"      => "clean_sheet",
			"saves"            => "saves",
			"penalty_save"     => "penalty_save",
			"penalty_conceded" => "penalty_conceded",
			"goals_conceded"   => "goals_conceded",
			"own_goals"        => "own_goals",
			"shot_off_target"  => "shot_off_target",
			"hit_woodwork"     => "hit_woodwork",
			"shot_off_target"  => "shot_off_target",
			"accurate_pass"    => "accurate_pass",
			"total_offside"    => "total_offside",
			"fouls"            => "fouls"
		),
		"5" => array(
			"yellow_card"      => "yellow_card",
			"red_card"         => "red_card",
			"minutes"          => "minutes",
			"goals_minutes"    => "goals_minutes",
			"goals"            => "goals",
			"goal_assist"      => "goal_assist",
			"clean_sheet"      => "clean_sheet",
			"saves"            => "saves",
			"penalty_save"     => "penalty_save",
			"penalty_conceded" => "penalty_conceded",
			"goals_conceded"   => "goals_conceded",
			"own_goals"        => "own_goals",
			"shot_off_target"  => "shot_off_target",
			"hit_woodwork"     => "hit_woodwork",
			"shot_off_target"  => "shot_off_target",
			"accurate_pass"    => "accurate_pass",
			"total_offside"    => "total_offside",
			"fouls"            => "fouls"
		)
	);

$config['language_list'] = array(
		'english' => 'English'
	);

/* End of file vconfig.php */
/* Location: ./application/config/vconfig.php/ */