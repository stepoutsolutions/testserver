<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*Roster Section*/
$lang["update_status_success"]		= "Status updated successfully";
$lang["no_change"]					= "No change";
$lang["player_release_success"]		= "Player release successfully.";
$lang["salary_length_less"]			= "Salary should be less then 7 digit.";
$lang["valid_salary"]				= "Enter only numeric salary";
$lang["roster_successfull_import"]	= "Player roster successfully imported";

/*Withdrawal Section*/
$lang["enter_required_field"]			= "Entered required field.";
$lang["insufficient_balance"]			= "Insufficient balance";
$lang["balance_update_success"]			= "User balance updated successfully";
$lang["select_withdrawal_transaction"]	= "Select withdrawal transaction";

/*New Contest*/
$lang["no_contest_list"]				= "Not found conetst list";
$lang["invalid_parameter"]				= "Invalid Parameter";
$lang["contest_create_successfully"]	= "Contest has been successfully created.";
$lang["contest_updated_successfully"]			= "Contest has been successfully updated.";
$lang["player_relase_error"]					= "Please relase first.";
$lang["successfully_update_name"]				= "Contest name successfully changed";
$lang["contest_not_deleted"]					= "This contest already joined by user so this contest can't be deleted";
$lang["successfully_remove_contest"]			= "Contest have been successfully deleted";
$lang["game_name"]								= "Contest Name";
$lang["league"]									= "League";
$lang["league_duration_id"]						= "Duration";
$lang["entry_fee"]								= "Entery Fees";
$lang["drafting_style"]							= "Drafting Style";
$lang["salary_cap"]								= "Salary Cap";
$lang["number_of_winner_id"]					= "Prize";
$lang["contest_type"]							= "Contest Type";
$lang["season_scheduled_date"]					= "Date";
$lang["period_of_recurrent_value"]				= "Period Value";
$lang["auto_recurrent_stop_type"]				= "Period to stop recurring type";
$lang["auto_recurrent_stop_value"]				= "Period to stop recurring value";
$lang["invalid_auto_reucrrent_duration"]		= "Selected period exceeded season schedule, please change it";
$lang["invalid_auto_stop_reucrrent_duration"]	= "You can't select Stop Recurring Period before Game Creation time";
$lang["no_of_game"]								= "No of game";
$lang["period_of_recurrent"]					= "Period Type";
$lang["invalid_game_size"]					= "Please select games";

/*User Section*/
$lang["email_send"]	= "Email has been send successfully";

/*Setting Section*/
$lang["change_password_success"]	= "Password has been changed successfully";
$lang["change_password_error"]		= "Not Match Old Password / Old Password and New Password Same";

/*Bonus code Section*/
$lang["create_bonus_code"]				= "Bonus code has been created successfully";
$lang["already_exists"]					= "Bonus code is alredy exists";

/*Team Roster Section*/
$lang["successfully_update_team_abbr"]	= "Team abbr successfully updated";

$lang['team_english'] 			  					= SITE_TITLE.' Team';
$lang['team_portuguese'] 			  				= "Time ".SITE_TITLE;

$lang['email_thanks_english'] 	  					= "Thanks";
$lang['email_thanks_portuguese'] 	  				= "Obrigado";

$lang['email_hi_english'] 		  					= "Hi";
$lang['email_hi_portuguese'] 		  				= "Olá";

$lang['withdrawal_request_message_english'] 		= "Your withdrawal request for amount ".CURRENCY_CODE."{withdrawal_amount} has been {action}.";
$lang['withdrawal_request_message_portuguese'] 		= "Sua solicitação de resgate no valor de ".CURRENCY_CODE."{withdrawal_amount} foi {action}.";

$lang['withdrawal_request_subject_english'] 		= "Withdrawal Request {action}.";
$lang['withdrawal_request_subject_portuguese'] 		= "Solicitação de resgate {action}.";

$lang['withdrawal_request_approved_english'] 		= "Approved";
$lang['withdrawal_request_approved_portuguese'] 	= "aprovada";

$lang['withdrawal_request_rejected_english'] 		= "Rejected";
$lang['withdrawal_request_rejected_portuguese'] 	= "rejeitado";

$lang['duration']									= "Duration";
$lang['size']										= "Size";
$lang['date']										= "Date";
$lang['week']										= "Week";
$lang['site_rake']									= "Site Rake";

/*New variables */
$lang['ad_created_success'] 		= "Advertisement successfully created.";
$lang['ad_try_again'] 				= "Please try again.";
$lang['ad_image_invalid_size'] 		= 'Please upload image of size should be {max_width}x{max_height} .';
$lang['ad_image_removed'] 			= "image removed successfully.";
$lang['ad_status_updated']			= "Advertisement Status Updated Successfully.";

$lang['withdrawal_request_approve_para1_portuguese'] = "O valor será pago de acordo com as regras de pagamento constantes no Termo de Uso do ".SITE_TITLE.".";
$lang['withdrawal_request_approve_para1_english'] = "The amount will be paid in accordance with the rules laid down payment on ".SITE_TITLE." of Use Agreement.";
$lang['withdrawal_request_approve_para2_portuguese'] = "Qualquer dúvida entre em contato com";
$lang['withdrawal_request_approve_para2_english'] 	 = "Any questions contact";
$lang['withdrawal_request_reject_para2_portuguese']  = "Favor entrar em contato no email";
$lang['withdrawal_request_reject_para2_english']     = "Please contact the email";
$lang['payment_config_array']						 = array("paypal_conversion_rate"=>"Paypal Conversion Rate","paypal_fee_per"=>"Paypal Fee (percentage)","paypal_fixed_fee"=>"Paypal Fee (fixed)","astro_conversion_rate"=>"Astro Conversion Rate", "astro_fee_per"=>"Astro Fee (percentage)");

$lang['score_updated_success']			= "Scoring points updated.";
$lang['score_updated_error']			= "Scoring points not updated.";
$lang['multiple_lineup']				= "Multiple Lineup";
$lang['manage_leagues']					= "Manage Leagues";
$lang['successfully_update_league']		= "League status updated successfully.";
$lang['order_message_array'] 			= array
										  (
											'0' => "Amount {{admin_action}} by admin",
											'1' => "Entry fee for {{contest_name}}",
											'2' => "Fee Refund {{contest_name}}",
											'3' => "Won Contest {{contest_name}}",
											'4' => "Referral fund",
											'5' => "Bonus expired",
											"6" => "Promo code bonus",
											"7" => "Amount deposited",
											"8" => "Amount withdrawal",
											"9" => "Signup Bonus"
										  );




/* End of file general.php */
/* Location: ./application/language/english/general.php */
