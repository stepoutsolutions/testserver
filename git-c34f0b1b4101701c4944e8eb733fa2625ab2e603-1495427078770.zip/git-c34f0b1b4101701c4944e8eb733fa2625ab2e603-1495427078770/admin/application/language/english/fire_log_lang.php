<?php


$lang[ 'fire_log_home' ] = 'Back to Today';
$lang[ 'fire_log_view' ] = 'View File';
$lang[ 'fire_log_delete' ] = 'Delete File';
$lang[ 'fire_log_today' ] = 'Today';
$lang[ 'fire_log_not_found' ] = 'I&#x27;m sorry, I could not find %log_file%.';
$lang[ 'fire_log_file_deleted' ] = 'Fire Log successfully removed ';
$lang[ 'fire_log_show_debug' ] = 'Show Debug Messages';
$lang[ 'fire_log_show_info' ] = 'Show Info Messages';
$lang[ 'fire_log_show_error' ] = 'Show Error Messages';
$lang[ 'fire_log_show_all' ] = 'Show All';
$lang[ 'fire_log_no_results_found' ] = 'There were no results that matched your filter criteria.';