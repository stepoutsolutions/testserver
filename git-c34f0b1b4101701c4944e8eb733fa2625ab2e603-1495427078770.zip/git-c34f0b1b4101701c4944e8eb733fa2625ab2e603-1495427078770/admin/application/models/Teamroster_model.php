<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Teamroster_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}	

	/**
	 * [get_all_teamrosters description]
	 * @MethodName get_all_teamrosters
	 * @Summary This function used for get all team list and return filter team list
	 * @return     [type]
	 */
	public function get_all_teamrosters()
	{
		$sort_field	= 'team_name';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;
		$post_data	= $this->input->post();
		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('team_name','team_abbr')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$league_id	= isset($post_data['league_id']) ? $post_data['league_id'] : "";

		$sql = $this->db->select("T.team_id, T.team_abbr, T.team_name",FALSE)
						->from(TEAM.' AS T')
						->join(TEAM_LEAGUE." AS TL","T.team_id=  TL.team_id","left")
						->order_by($sort_field, $sort_order);

		if(!empty($league_id))
		{
			$this->db->where("TL.league_id",$post_data['league_id']);
		}

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [change_team_abbr description]
	 * @MethodName change_team_abbr
	 * @Summary This function used to update team abbr
	 * @param      array  post data
	 * @return     boolean
	 */
	public function change_team_abbr($post_data)
	{
		$data_array = array("team_abbr"=>$post_data['team_abbr']);
		$this->db->where("team_id", $post_data["team_id"])->update(TEAM,$data_array);

		return $this->db->affected_rows();
	}
        
        public function is_team_abbr_exist($team_abbr_list, $league_id='', $t_id='', $season_year=''){       
		$this->db->select('T.team_abbr', FALSE)
                                ->from(TEAM . " AS T");
                
                if (!empty($team_abbr_list)) {
			$this->db->where_in('T.team_abbr', $team_abbr_list);
		}
                if (!empty($league_id)) {
			$this->db->where('T.league_id', $league_id);
		}
                if (!empty($season_year)) {
			$this->db->where('T.year', $season_year);
		}
                if (!empty($t_id)) {
                        $this->db->where('T.t_id != ', $t_id);
                }
                
                $sql = $this->db->get();
                //echo $this->db->last_query(); die;
		$abbr_array = $sql->result_array();

		return ($abbr_array) ? $abbr_array : array();
	}
}
/* End of file Teamroster_model.php */
/* Location: ./application/models/Teamroster_model.php */