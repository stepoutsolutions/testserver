<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Setting_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}

	public function chnage_password($data_arr)
	{
		$this->db->where('password',md5($data_arr['old_password']))
				->where('admin_id',$this->admin_id)
				->update(ADMIN,array('password'=>md5($data_arr['new_password'])));
		// echo $this->db->last_query();die;
		return $this->db->affected_rows();
	}

	public function get_referral_current_amount()
	{
		$sql = $this->db->select("referral_discount, referral_threshold_amount")
						->from(REFERRAL_FUND)
						->where('referral_fund_id',1)
						->get();
		$result = $sql->row_array();
		return $result;
	}
	public function update_referral_amount($data_arr)
	{
		$this->db->where('referral_fund_id',1)
				->update(REFERRAL_FUND,array('referral_discount'=>$data_arr['referral_discount'], 'referral_threshold_amount'=>$data_arr['referral_threshold_amount'],'last_update_date'=>format_date()));
		// echo $this->db->last_query();die;
		return $this->db->affected_rows();
	}

	public function get_payment_setting()
	{
		$sql = $this->db->select("payment_gateway_setting_id as payment_method")
						->from(PAYMENT_GATEWAY_SETTING)
						->where('is_active','1')
						->get();
		$result = $sql->row_array();
		return $result;
	}

	public function update_payment_setting($data_arr)
	{
		$this->db->update(PAYMENT_GATEWAY_SETTING,array('is_active'=>'0'));

		$this->db->where('payment_gateway_setting_id',$data_arr['payment_method'])
				->update(PAYMENT_GATEWAY_SETTING,array('is_active'=>'1'));
		// echo $this->db->last_query();die;
		return $this->db->affected_rows();
	}

	public function get_payment_config(){
		$sql = $this->db->select("payment_config_id,meta_key,meta_value")
						->from(PAYMENT_CONFIG)
						->where('meta_key !=','')
						->get();
		$result = $sql->result_array();
		return $result;
	}

	public function update_payment_config($config_array){

		foreach ($config_array as $key => $value) {
			$this->db->where($value['where_array'])
				->update(PAYMENT_CONFIG,$value['update_array']);
		}


	}

	public function get_singup_bonus_data()
	{
		$sql = $this->db->select("signup_bonus_id,signup_bonus_amount")
						->from(SIGNUP_BONUS)
						->get();
		$result = $sql->row_array();
		return $result;
	}

	public function update_signup_bonus_data($update_arr,$update_cond)
	{
		$this->db->where($update_cond)
				->update(SIGNUP_BONUS,$update_arr);
		return $this->db->affected_rows();		
	}

	/**
	 * [get_all_teamrosters description]
	 * @MethodName get_all_teamrosters
	 * @Summary This function used for get all team list and return filter team list
	 * @return     [type]
	 */
	public function get_all_referrals()
	{
		$sort_field	= 'to_email';
		$sort_order	= 'ASC';
		$limit		= 10;
		$page		= 0;
		$post_data	= $this->input->post();
		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('from_user','to_email','is_registered','invite_date_time','is_referral_bonus','source')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$search_email	= isset($post_data['keyword']) ? $post_data['keyword'] : "";

		$sql = $this->db->select("U.user_name AS from_user,R.to_email,R.is_referral_bonus,R.source,R.is_registered,DATE_FORMAT(R.invite_date_time, '%d-%b-%Y %H:%i') AS invite_date_time",FALSE)
						->from(REFERRAL.' AS R')
						->join(USER." AS U","U.user_id = R.from_user_id","INNER")
						->order_by($sort_field, $sort_order);

		if(!empty($search_email))
		{
			$this->db->like("R.to_email",$search_email);
		}

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}


}	
/* End of file Teamroster_model.php */
/* Location: ./application/models/Teamroster_model.php */