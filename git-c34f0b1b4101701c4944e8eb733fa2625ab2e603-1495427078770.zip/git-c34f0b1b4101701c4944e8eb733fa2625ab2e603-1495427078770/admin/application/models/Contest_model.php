<?php defined('BASEPATH') OR exit('No direct script access allowed');
require_once "../package/Api_credential_model.php";
class Contest_model extends MY_Model {

	private $api;

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
		$this->load->model('api_credential_model');
		$this->api = $this->api_credential_model->cricket_cricketapi();
	}

	/**
	 * [get_season_date description]
	 * @MethodName get_season_date
	 * @Summary This function used to get all season date by league id
	 * @param      [int]  $league_id
	 * @return     [array]
	 */
	public function get_season_date($league_id)
	{
		$season_year = $this->api['year'];
		$sql = $this->db->select('scheduled_date')
						->from(SEASON . " AS S")
						->where_in('S.league_id', $league_id)
						//->where('S.type', $season_type)
						->where('S.year', $season_year)
						->where('S.season_scheduled_date >', format_date())
						// ->where('S.season_scheduled_date <', date('Y-m-d H:i:s', strtotime(format_date() . "+14 days")))
						->group_by('scheduled_date')
						->order_by('scheduled_date', 'ASC')
						->get();
		$result = $sql->result_array();

		$season_time = array();

		foreach ($result as $key => $value)
		{
			$seasone_date_time_format = $value['scheduled_date'];
			$timestamp = strtotime($seasone_date_time_format);
			$season_time[] = $seasone_date_time_format;
		}

		return $season_time;
	}

	/**
	 * [get_all_available_week description]
	 * @MethodName get_all_available_week
	 * @Summary This function used to get all week by league id
	 * @param      [int]  $league_id
	 * @return     [array]
	 */
	public function get_all_available_week($league_id)
	{
		$season_year = $this->api['year'];

		$sql = $this->db->select('season_week, season_week_start_date_time, season_week_end_date_time')
						->from(SEASON_WEEK . " AS SW")
						->where('SW.league_id', $league_id)
						//->where('SW.season_week_start_date_time > ',format_date( 'today' , 'Y-m-d H:i:s' ) )
						->where('SW.season_week_close_date_time > ',format_date() )
						// ->where('SW.season_week_close_date_time <', date('Y-m-d H:i:s', strtotime(format_date() . "+14 days")))
						->order_by('SW.season_week', 'ASC')
						->get();
		$result = $sql->result_array();
		$final_result = array();
		foreach ($result as $key => $value)
		{
			$season_week = $value['season_week'];
			$season_week_start_date_time = $value['season_week_start_date_time'];
			$season_week_end_date_time = $value['season_week_end_date_time'];
			$final_result[] = array("week"=>$season_week,"week_detail"=>$season_week . ' ( ' . date('d-M-y', strtotime($season_week_start_date_time)) . ' ' . date('d-M-y', strtotime($season_week_end_date_time)) . ' )');
		}
		// echo "<pre>";print_r($final_result);die;
		return $final_result;
	}
	
	/**
	 * [get_all_duration description]
	 * @MethodName get_all_duration
	 * @Summary This function used to get all league duration by league id
	 * @param      [int]  $league_id
	 * @return     [array]
	 */
	public function get_all_duration($league_id)
	{
		$sql = $this->db->select('MD.duration_desc,MD.duration_id AS league_duration_id, MD.duration_id')
						->from(MASTER_DURATION . " AS MD")
						//->where('LD.active', ACTIVE)
						->get();
		$result = $sql->result_array();
		return $result;
	}

	/**
	 * [get_all_salary_cap description]
	 * @MethodName get_all_salary_cap
	 * @Summary This functin used to get all salary cap by league id
	 * @param      [int]  $league_id
	 * @return     [array]
	 */
	public function get_all_salary_cap($league_id='')
	{
		$sql = $this->db->select('salary_cap, master_salary_cap_id')
						->from(MASTER_SALARY_CAP . " AS MSC")
						->where('MSC.admin_active', ACTIVE)
						->get();
		$result = $sql->result_array();
		return $result;
	}

	/**
	 * [get_all_number_of_winner description]
	 * @MethodName get_all_number_of_winner
	 * @Summary This function used for get all prizing list and prize validation
	 * @param [int] $league_id
	 * @return     [array]
	 */
	public function get_all_number_of_winner($league_id,$contest_type)
	{
		$sql = $this->db->select('MNOW.master_contest_type_id,master_contest_type_id as league_contest_type_id,master_contest_type_desc,position_or_percentage,places')
						->from(MASTER_CONTEST_TYPE . " AS MNOW")
						->where('MNOW.status', ACTIVE)
						->order_by('MNOW.order', 'ASC')
						->get();
		$result = $sql->result_array();
		$all_number_of_winner = array();
		foreach($result as $rs)
		{
			if($contest_type == 2 && ($rs['master_contest_type_id']==6))
			{
				$all_number_of_winner[] = array(
										"master_contest_type_desc"=>$rs['master_contest_type_desc'],
										"league_contest_type_id"=>$rs['master_contest_type_id']
										);
			}
			elseif($contest_type == 0 && $rs['master_contest_type_id']==1)
			{
				$all_number_of_winner[] = array(
										"master_contest_type_desc"=>$rs['master_contest_type_desc'],
										"league_contest_type_id"=>$rs['master_contest_type_id']
										);
			}
			elseif($contest_type != 0 && $contest_type != 2)
			{
				$all_number_of_winner[] = array(
										"master_contest_type_desc"=>$rs['master_contest_type_desc'],
										"league_contest_type_id"=>$rs['master_contest_type_id']
										);
			}
			//elseif($contest_type == 3 && ($rs['master_contest_type_id'] == 5 || $rs['master_contest_type_id'] == 6))
			// {
			// 	$all_number_of_winner[] = array(
			// 							"master_contest_type_desc"=>$rs['master_contest_type_desc'],
			// 							"league_contest_type_id"=>$rs['league_contest_type_id']
			// 							);
			// }

		}
		// $all_number_of_winner = array_column($rs, 'master_contest_type_desc', 'league_contest_type_id', 'master_contest_type_id');
		
		return array('all_number_of_winner' => $all_number_of_winner, 'number_of_winner_validation' => $result);
	}
	

	/**
	 * [get_all_drafting_style description]
	 * @MethodName get_all_drafting_style
	 * @Summary This function used to getting all drafting style 
	 * @param 	[int] $league_duration_id
	 * @return     [array]
	 */
	public function get_all_drafting_style()
	{
              
		$sql = $this->db->select('drafting_styles_id AS league_drafting_styles_id, drafting_styles_desc')
						->from(MASTER_DRAFTING_STYLES)
						->get();
		$result = $sql->result_array();
		return $result;
	}

	/**
	 * [get_available_game_of_the_day_or_week description]
	 * @MethodName get_available_game_of_the_day_or_week
	 * @Summary This function used to get all match daily or weekly
	 * @param      array  [data array]
	 * @return     array
	 */
	public function get_available_game_of_the_day_or_week($data)
	{
		$result = array();

		$league_id = $data['league_id'];
		$current_date = format_date(); 


		$sql = $this->db->select('season_game_uid,T1.team_abbr as home,T2.team_abbr as away, DATE_FORMAT(S.season_scheduled_date, "%l:%i %p") AS season_scheduled_date,
									DATE_FORMAT(S.scheduled_date,"%W") AS day_name,DATE_FORMAT(S.season_scheduled_date, "%a, %d %b %Y") AS game_date')
		->from(SEASON." AS S")
		->join(TEAM_LEAGUE.' TL1','TL1.team_uid = S.home_uid AND TL1.league_id = S.league_id','INNER')
		->join(TEAM.' T1','T1.team_id = TL1.team_id','INNER')
		->join(TEAM_LEAGUE.' TL2','TL2.team_uid = S.away_uid AND TL2.league_id = S.league_id','INNER')
		->join(TEAM.' T2','T2.team_id = TL2.team_id','INNER')
		->where('S.league_id',$league_id)
		->where('(S.season_scheduled_date > "'.$current_date.'" || S.season_scheduled_date="'.$current_date.'")');
		
		if (isset($data['season_scheduled_date']) && $data['league_duration_id']==1) //Daily
		{
			$season_scheduled_date = $data['season_scheduled_date'];
			$this->db->where('S.scheduled_date',$season_scheduled_date);
		}
		else if(isset($data['from_date']) && isset($data['to_date']) && $data['league_duration_id']==2)//Custom
		{
			$from_date = $data['from_date'];
			$to_date = $data['to_date'];
			$this->db->where('S.scheduled_date >=',$from_date)
					 ->where('S.scheduled_date <=',$to_date);
		}	

		$sql = $this->db->group_by('S.season_game_uid')
				 ->order_by('S.season_scheduled_date', 'ASC')
				 ->get();
		$result = $sql->result_array();	

		return $result;
	}

	/**
	 * [get_list_game_date_wise description]
	 * @MethodName get_list_game_date_wise
	 * @Summary This function used to get game list with game detail order by scheduled date
	 * @param      array  game list array
	 * @param      int    league id
	 * @return     array
	 */
	public function get_list_game_date_wise($gamelist ,$league_id)
	{
		$game_ids = array();
		foreach ($gamelist as $key => $value) {
			$game_ids[] = $value;
		}	
		$sql = $this->db->select('S.season_game_uid,T1.team_abbr as home,T2.team_abbr as away, S.season_scheduled_date')
						->from(SEASON." AS S")
						->join(TEAM_LEAGUE.' TL1','TL1.team_uid = S.home_uid AND TL1.league_id = S.league_id','INNER')
						->join(TEAM.' T1','T1.team_id = TL1.team_id','INNER')
						->join(TEAM_LEAGUE.' TL2','TL2.team_uid = S.away_uid AND TL2.league_id = S.league_id','INNER')
						->join(TEAM.' T2','T2.team_id = TL2.team_id','INNER')
						->where_in('S.season_game_uid',$game_ids)
						->where('S.league_id',$league_id)
						->group_by('S.season_game_uid')
						->order_by('S.season_scheduled_date','ASC')
						->get();
		$result = $sql->result_array();
		return $result;
	}

	/**
	 * [get_season_scheduled_date description]
	 * @MethodName get_season_scheduled_date
	 * @Summary This function used to get season date by season game unique id
	 * @param      varchar  season_game_unique_id
	 * @param      int 	league id
	 * @return     datetime
	 */
	public function get_season_scheduled_date($season_game_unique_id, $league_id)
	{
		$sql = $this->db->select('season_scheduled_date')
						->from(SEASON)
						->where('season_game_uid',$season_game_unique_id)
						->where('league_id',$league_id)
						->group_by('season_scheduled_date')
						->order_by('season_scheduled_date','ASC')
						->limit(1)
						->get();
		$result = $sql->row_array();
		$season_scheduled_date = '0000-00-00 00:00:00';
		if (isset($result['season_scheduled_date']))
			$season_scheduled_date = $result['season_scheduled_date'];
		return $season_scheduled_date;
	}
        
        /**
	 * [get_list_game_date_wise description]
	 * @MethodName get_list_game_date_wise
	 * @Summary This function used to get game list with game detail order by scheduled date
	 * @param      array  game list array
	 * @param      int    league id
	 * @return     array
	 */
	public function get_season_game_detail($season_game_unique_id ,$league_id)
	{
		$sql = $this->db->select('S.season_game_unique_id, S.season_scheduled_date, S.home_id, S.away_id, T1.team_abbr as home, T2.team_abbr as away')
						->from(SEASON." AS S")
						->join(TEAM.' T1','T1.team_id = S.home_id AND T1.league_id = S.league_id','LEFT')
						->join(TEAM.' T2','T2.team_id = S.away_id AND T2.league_id = S.league_id','LEFT')
						->where('S.season_game_unique_id',$season_game_unique_id)
						->where('S.league_id',$league_id)
						->get();
		$result = $sql->row_array();
		return $result;
	}
        
	/**
	 * [get_player_salary_master description]
	 * @MethodName get_player_salary_master
	 * @Summary This function used get player salary master by league id
	 * @param      int  league id 
	 * @return     array
	 */
	public function get_player_salary_master($league_id)
	{
		$sql = $this->db->select('player_salary_master_id')
						->from(PLAYER_SALARY_MASTER)
						->where('league_id',$league_id)
						->order_by('player_salary_master_id','DESC')
						->get();
		return $sql->row_array();
	}

	/**
	 * [prize_details_by_size_fee_prizing description]
	 * @MethodName prize_details_by_size_fee_prizing
	 * @Summary This function used to calculate prize detail
	 * @param      int   game size
	 * @param      float  entery fees
	 * @param      int   league_contest_type_id
	 * @param      string   prize_pool
	 * @param      boolean  desc
	 * @return     prize detail
	 */
	public function prize_details_by_size_fee_prizing($size,$fee,$league_contest_type_id,$site_rake,$prize_pool = '0',$desc=FALSE)
	{
		$collected_amount	= $size * $fee;
		$site_rake_amount	= ($collected_amount * $site_rake)/100; 
		$prize_pool_amount	= $collected_amount - $site_rake_amount;

		if($prize_pool != '0')
		{
			$prize_pool_amount = $prize_pool;
		}

		$sql = $this->db->select("MNOW.master_contest_type_id,MNOW.master_contest_type_desc,MNOW.places")
						->from(MASTER_CONTEST_TYPE." AS MNOW")
						->where("MNOW.master_contest_type_id",$league_contest_type_id)
						->get();
		
		$result			= $sql->row_array();
		$file			= prize_json();
		$winner_array	= json_decode($file,true);
		$prize_details	= array();
		//for Top 1 Place
		if($result['master_contest_type_id'] == 1)
		{
			$prize_percent		= $winner_array[$result['master_contest_type_desc']];
			$amt				= (($prize_pool_amount*$prize_percent['1'])/100);
			$prize_details[0]	= truncate_number($amt,2);
		}
		//Top 3,10,20 Place
		elseif( $result['master_contest_type_id'] == 2 || $result['master_contest_type_id'] == 3
				|| $result['master_contest_type_id'] == 4
				) 
		{
			$prize_percent = $winner_array[$result['master_contest_type_desc']];
			for($i=0;$i<count($prize_percent);$i++)
			{
				$amt				= (($prize_pool_amount*$prize_percent[$i+1])/100);
				$prize_details[$i]	= truncate_number($amt,2);
			}
		}
		//for Top 30% 0r 50%
		elseif($result['master_contest_type_id'] == 5 || $result['master_contest_type_id'] == 6)
		{
			$prize_percent = $winner_array[$result['master_contest_type_desc']];

			if((isset($prize_percent['30']) && $prize_percent['30']== 100) || (isset($prize_percent['50']) && $prize_percent['50'] == 100))
			{
				$place = floor(($size*$result['places'])/100);
				$amt = $prize_pool_amount/$place;

				if($desc)
				{
					$prize_details = array($amt.' - TOP '.$place);
				}
				else
				{
					for($i=0;$i<$place;$i++)
					{
						$amt				= $prize_pool_amount/$place;
						$prize_details[$i]	= truncate_number($amt);
					}
				}
			} 
		}
		else
		{
			$prize_details = "";
		}
		return  $prize_details;
	}
	/**
	 * [save_contest description]
	 * @MethodName save_contest
	 * @Summary This function used to create new contest
	 * @param      array  data array
	 * @return     int
	 */
	public function save_contest($data)
	{
		$this->db->insert(CONTEST,$data);
		return $this->db->insert_id();
	}
	/**
	 * [save_auto_recurrent_contest description]
	 * @MethodName save_auto_recurrent_contest
	 * @Summary This function used to create auto recurrent of contest
	 * @param      array  data array
	 * @return     int
	 */
	public function save_auto_recurrent_contest($data)
	{
		$this->db->insert(AUTO_RECURRENT_CONTEST,$data);
		return $this->db->insert_id();
	}

	/**
	 * [contest_list description]
	 * @MethodName contest_list
	 * @Summary This function used for get all contest List
	 * @return     [array]
	 */
	public function contest_list()
	{
		$sort_field = 'season_scheduled_date';
		$sort_order = 'DESC';
		$limit      = 10;
		$page       = 0;
		
		$post_data = $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('contest_name','size','minimum_size','total_user_joined','entry_fee','season_scheduled_date','prize_pool', 'is_feature','auto_recurrent_id','guaranteed_prize','is_uncapped', 'is_turbo_lineup')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		
		$offset	= $limit * $page;
		$this->db->select('G.contest_unique_id, G.contest_name, G.contest_access_type, G.entry_fee, G.prize_pool, G.total_user_joined, G.size,  G.minimum_size, 
							G.is_feature,G.status,IFNULL(G.auto_recurrent_id,"") as auto_recurrent_id,LM.lineup_master_id, 
							DATE_FORMAT(G.season_scheduled_date, "%d-%b-%Y %H:%i") AS season_schedule_date,G.guaranteed_prize,G.is_uncapped, G.is_turbo_lineup', FALSE)
						->from(CONTEST . " AS G")
						->join(LINEUP_MASTER." AS LM","LM.contest_id=G.contest_id","left");
		if(isset($post_data['league_id'])&&$post_data['league_id']!="")
		{
			$this->db->where('G.league_id',$post_data['league_id']);
		}
		$game_type = isset($post_data['game_type'])?$post_data['game_type']:"";

		switch ($game_type)
		{
			case 'current_game':
				$this->db->where('G.is_cancel','0');
				$this->db->where('G.prize_distributed','0');
				break;
			case 'completed_game':
				$this->db->where('G.prize_distributed','1');
				break;
			case 'cancelled_game':
				$this->db->where('G.is_cancel','1');
				break;
			default:
				break;
		}
                
                // Check Contest Type condition
                if(!empty($post_data['contest_feature']))
		{
			switch ($post_data['contest_feature'])
                        {
                                case '1':
                                        $this->db->where('G.is_feature','1');
                                        break;
                                case '2':
                                        $this->db->where('G.auto_recurrent_id','1');
                                        break;
                                case '3':
                                        $this->db->where('G.is_uncapped','1');
                                        break;
                                case '4':
                                        $this->db->where('G.guaranteed_prize','1');
                                        break;
                                case '5':
                                        $this->db->where('G.is_turbo_lineup', '1');
                                        break;
                                default:
                                        break;
                        }
		}
                
		$this->db->group_by('contest_unique_id');
		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit, $offset)
						->get();
		// echo $tempdb->last_query();die;
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result, 'total'=>$total);
	}

	public function get_game_detail($game_unique_id)
	{
		$sql = $this->db->select('G.season_scheduled_date, G.player_salary_master_id, U.user_name, U.email, G.contest_id, G.contest_unique_id, G.contest_name, G.league_id, DATE_FORMAT(season_scheduled_date,"%d-%b-%Y %H:%i") as scheduled_date, G.season_week, G.league_drafting_styles_id, G.league_salary_cap_id, G.size, G.entry_fee, 
								G.prize_pool, G.is_cancel, G.status, L.league_abbr,IFNULL(G.auto_recurrent_id,"") as auto_recurrent_id, MD.duration_desc, DATE_FORMAT(G.added_date,"%d-%b-%Y %H:%i") as added_date,
								MDS.drafting_styles_desc, MSC.salary_cap, MNW.master_contest_type_desc, G.prize_distributed, G.site_rake, G.total_user_joined,G.guaranteed_prize,G.is_uncapped,G.is_feature,IFNULL(G.auto_recurrent_id,"") as auto_recurrent_id,MS.sports_id')
						->from(CONTEST . " AS G")
						->join(USER . " AS U", "U.user_id = G.user_id", 'LEFT')
						->join(LEAGUE . " AS L", "L.league_id = G.league_id", 'INNER')
						->join(MASTER_SPORTS . " AS MS", "MS.sports_id = L.sports_id", 'INNER')
						//->join(LEAGUE_DURATION . " AS LD", 'LD.league_duration_id = G.league_duration_id', 'INNER')
						->join(MASTER_DURATION . " AS MD", 'MD.duration_id = G.league_duration_id', 'INNER')
						//->join(LEAGUE_DRAFTING_STYLES . " AS LDS", 'LDS.league_drafting_styles_id = G.league_drafting_styles_id', 'INNER')
						->join(MASTER_DRAFTING_STYLES . " AS MDS", 'MDS.drafting_styles_id = G.league_drafting_styles_id', 'INNER')
						->join(MASTER_SALARY_CAP . " AS MSC", 'MSC.master_salary_cap_id = G.league_salary_cap_id', 'INNER')
						//->join(LEAGUE_CONTEST_TYPE . " AS LNW", 'LNW.league_contest_type_id = G.league_contest_type_id', 'LEFT')
						->join(MASTER_CONTEST_TYPE . " AS MNW", 'MNW.master_contest_type_id = G.league_contest_type_id', 'LEFT')
						->where('G.contest_unique_id', $game_unique_id)
						->get();
                // echo $this->db->last_query();die;
		$result = $sql->row_array();
		return $result;
	}

	public function get_lineup_users_by_game()
	{
		$limit      = 50;
		$page       = 0;
		
		$post_data = $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}
		

		$offset	= $limit * $page;

		$this->db->select("U.user_id,U.user_name,LM.total_score,LM.lineup_master_id")
						->from(LINEUP_MASTER." AS LM")
						->join(USER." AS U", "U.user_id=LM.user_id","inner")
						->where("contest_id", $post_data['game_id']);

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->limit($limit, $offset)
						->order_by("LM.total_score","DESC")
						->get();
		// echo $tempdb->last_query();die;
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result, 'total'=>$total);
	}

	/**
	 * [get_lineup_detail description]
	 * @MethodName get_lineup_detail
	 * @Summary This function used get all user lineup detail
	 * @param      [type]  [description]
	 * @return     [type]
	 */
	public function get_lineup_detail($lineup_master_id,$league_id)
	{
		$sql = $this->db->select("P.full_name,PT.position,T.team_abbr as team_abbreviation,PT.salary,L.score")
						->from(LINEUP." AS L")
						->join(PLAYER_TEAM." AS PT","PT.player_team_id = L.player_team_id","INNER")
						->join(PLAYER." AS P","P.player_id = PT.player_id","INNER")
						->join(TEAM_LEAGUE.' TL', 'TL.team_league_id = PT.team_league_id', 'INNER')	
        				->join(TEAM.' T', 'T.team_id = TL.team_id', 'INNER')	
						->where("L.lineup_master_id", $lineup_master_id)
						->where("TL.league_id", $league_id)
						->group_by('PT.player_team_id')
						->order_by("PT.position","ASC")
						->get();
		return $sql->result_array();
	}

	public function get_all_player_last_salaries($player_salary_master_id, $league_id)
	{
		$sort_field = 'full_name';
		$sort_order = 'DESC';
		$limit      = 50;
		$page       = 0;
		
		$post_data = $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}
		
		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('full_name', 'team_name', 'position', 'salary', 'player_status')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(($post_data['sort_order']) && in_array($post_data['sort_order'], array('DESC', 'ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$rs = $this->get_single_row('selected_matches', CONTEST, array('contest_unique_id'=>$post_data['contest_unique_id']));
		$selected_matches = explode(",", $rs['selected_matches']);
		$this->db->select("P.full_name,P.player_uid,TL.team_league_id,T.team_name,PT.position,PT.salary,IFNULL(GPS.break_down,'') AS break_down,GPS.score")

						->from(TEAM_LEAGUE." AS TL")
						->join(SEASON." AS S", "S.home_uid = TL.team_uid OR S.away_uid = TL.team_uid AND S.league_id = '".$league_id."'", "inner")
						->join(TEAM." AS T","T.team_id = TL.team_id","INNER")
						->join(PLAYER_TEAM." AS PT","PT.team_league_id = TL.team_league_id","INNER")
						->join(PLAYER." AS P","P.player_id = PT.player_id","INNER")
						->join(GAME_PLAYER_SCORING." AS GPS", "GPS.season_game_uid= S.season_game_uid AND GPS.player_uid = P.player_uid AND GPS.league_id='".$league_id."'", "LEFT")
						->where_in("S.season_game_uid",$selected_matches)
						->where("TL.league_id", $league_id)
						->where("PT.is_deleted",0)
						->where("PT.player_status",1)
						->group_by("PT.player_id");


						// ->from(PLAYER." P")
						// ->join(SEASON." AS S", "S.home_id = P.team_id OR S.away_id = P.team_id AND S.league_id = '".$league_id."'", "inner")
						// ->join(GAME_PLAYER_SCORING." AS GPS", "GPS.season_game_unique_id= S.season_game_unique_id AND GPS.player_unique_id = P.player_unique_id AND GPS.league_id='".$league_id."'", "LEFT")
						// ->where_in("S.season_game_uid", $selected_matches, FALSE)
						// ->where("P.league_id", $league_id)
						// ->where("P.is_deleted", '0')
						// ->where("P.player_status", '1')
						// ->group_by("P.player_unique_id");

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit, $offset)
						->get();
		// echo $tempdb->last_query();die;
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result, 'total'=>$total);
	}

	/**
	 * [get_roster_score description]
	 * @MethodName get_roster_score
	 * @Summary This function used to get metch score.
	 * @param      player_uid
	 * @return     array
	 */
	public function get_roster_score($contest_unique_id,$player_uid,$league_id,$player_salary_master_id,$sports_id)
	{
		$rs = $this->get_single_row('selected_matches', CONTEST, array('contest_unique_id'=>$contest_unique_id));
		$selected_matches = explode(',', $rs['selected_matches']);

		$this->db->select("IFNULL(GPS.break_down,'') AS break_down")
						->from(GAME_PLAYER_SCORING." GPS")
						->where_in("GPS.season_game_uid", $selected_matches)
						->where("GPS.league_id", $league_id)
						->where("GPS.player_uid", $player_uid);

		$query = $this->db->get();
		$result	= $query->row_array();

		$format = $this->get_contest_format($selected_matches);

		$scoring_cat = $this->Contest_model->get_all_table_data('scoring_category_name',MASTER_SCORING_CATEGORY,array('sports_id'=>$sports_id));
		$scr = array();

		// Get scoring rules descriptions.
		if(count($result)>0)
		{
			$total_scoring_keys = array();
			$total_scroing_values = array();
			$total_scoring = array();
			$total_scr = array();
			if(!empty(json_decode($result['break_down'], true)))
			{
				$scr = json_decode($result['break_down']);	
				//print_r($scr);die;			
				foreach ($scoring_cat as $key => $value) 
				{


					if(property_exists($scr,$value['scoring_category_name'] )) 
					{

						$all_keys = (array) $scr->{$value['scoring_category_name']};
						if(!empty($all_keys))
						{
							foreach($all_keys as $inning => $ining_scr)
							{
								$keys = (array) $ining_scr;
								foreach($keys as $k => $v)
								{
									if(in_array($k,$total_scroing_values))
									{
										$total_scroing_values[$k] = $total_scroing_values[$k]+$v; 
									}
									else
									{
										$total_scroing_values[$k] = $v; 
									}	
								}	
								$total_scoring_keys[$value['scoring_category_name']] = array_keys($keys);
							}
						}
					}
				}

			
				foreach ($total_scoring_keys as $key => $value) 
				{
					foreach ($total_scoring_keys[$key] as $j => $v) 
					{
						$this->db->select('meta_key,IFNULL(score_position,"") AS score_position')
								->from(MASTER_SCORING_RULES)
								->where('meta_key',$v)
								->where('format',$format);
						$scr_query = $this->db->get();
						$res = $scr_query->row_array();
						///echo $this->db->last_query();
						if(!empty($res['meta_key']))
						{	
							$total_scoring[$key][] =  array('key'=>$res['meta_key'],'desc'=>$res['score_position'],'value'=>$total_scroing_values[$v]);
						}
					}
				}
				$result['scorings'] = $total_scoring;
			}
		}
		unset($result['break_down']);
		return $result;				
	}

	/**
	 * [get_all_user_by_key description]
	 * @MethodName get_all_user_by_key
	 * @Summary This function used to get all user match by search key
	 * @param      varchar  search key
	 * @return     array
	 */
	public function get_all_user_by_key($search_key,$user_ids)
	{
		$this->db->select("user_id,CONCAT_WS(' ',first_name,last_name) as full_name")
						->from(USER);

		if($user_ids!="")
		{
			$user_ids = explode(',', $user_ids);
			$this->db->where_not_in('user_id', $user_ids);
		}
		$sql = $this->db->like("CONCAT(first_name, last_name)", $search_key)
						->limit(20)
						->get();
		$result = $sql->result_array();
		$data_arr = array();
		foreach ($result as $rs) 
		{
			$data_arr[] = array(
				"id"	=> $rs['user_id'],
				"text"	=> $rs['full_name']
				);
		}
		return $data_arr;
	}

	/**
	 * [get_all_email_by_user_id description]
	 * @MethodName get_all_email_by_user_id
	 * @Summary This function used to get all email ids using by user id
	 * @param      string 	user ids 
	 * @return     array
	 */
	public function get_all_email_by_user_id($user_ids)
	{
		$users = explode(",", $user_ids);
		$sql = $this->db->select("email,user_id")
						->from(USER)
						->where_in("user_id", $users)
						->get();
		return $sql->result_array();
	}

	/**
	 * [get_all_user_id_by_email description]
	 * @MethodName get_all_user_id_by_email
	 * @Summary This function used to get all user id using by email
	 * @param      string 	email
	 * @return     array
	 */
	public function get_all_user_id_by_email($emails)
	{
		$emails = explode(",", $emails);
		$sql = $this->db->select("email,user_id")
						->from(USER)
						->where_in("email", $emails)
						->get();
		return $sql->result_array();
	}

	/**
	 * [change_contest_name description]
	 * @MethodName change_contest_name
	 * @Summary This function used to update contest name
	 * @param      array  post data
	 * @return     boolean
	 */
	public function change_contest_name($post_data)
	{
		$data_array = array("contest_name"=>$post_data['contest_name']);
		$this->db->where("contest_unique_id", $post_data["contest_unique_id"])->update(CONTEST,$data_array);

		return $this->db->affected_rows();
	}

	/**
	 * [remove_contest description]
	 * @MethodName remove_contest
	 * @Summary This function used to remove contest by contest unique id
	 * @param      string  contest unique id
	 * @return     boolean
	 */
	public function remove_contest($contest_unique_id)
	{
		$game_join_detail = $this->db->select("contest_unique_id")
									->from(LINEUP_MASTER)
									->where("contest_unique_id", $contest_unique_id)
									->get()
									->num_rows();		
		if(!$game_join_detail)
		{
			$this->db->where("contest_unique_id", $contest_unique_id)->delete(CONTEST);
			return $this->db->affected_rows();
		}
		return 0;
	}



	/**
	 * [get_auto_recurring_contest_detail]
	 * @MethodName get_auto_recurring_contest_detail
	 * @Summary This function used to get information of auto recurring type contest
	 * @param      string  auto_recurrent_id
	 * @return     array
	 */
	public function get_auto_recurring_contest_detail($auto_recurrent_id)
	{
		$auto_recurrent_detail = $this->db->select("*")
									->from(AUTO_RECURRENT_CONTEST)
									->where("auto_recurrent_id", $auto_recurrent_id)
									->get()
									->row_array();
		return $auto_recurrent_detail;
	}	

	public function get_all_season_month_and_week($league_id)
	{
		$week = $this->db->select("MAX(season_week) as end_week")->from(SEASON_WEEK)->where("league_id", $league_id)->get()->row_array();
		$month = $this->db->select("MONTH(MAX(scheduled_date)) as end_month")->from(SEASON)->where("league_id", $league_id)->get()->row_array();
		$result_array = array_merge($week, $month);
		return $result_array;
	}

	public function get_all_auto_recurrent_contest()
	{
		$sql = $this->db->select("*")
						->from(AUTO_RECURRENT_CONTEST)
						->where("status", '0')
						->get();
		return $sql->result_array();
	}

	public function get_all_contest_by_auto_re_id($auto_recurrent_id, $season_scheduled_date)
	{
		$sql = $this->db->select("auto_recurrent_id")
						->where("auto_recurrent_id", $auto_recurrent_id)
						->where("season_scheduled_date > ", "$season_scheduled_date")
						->from(CONTEST)
						->get();
		return $sql->num_rows();
	}

	public function change_auto_recurrent_status($auto_recurrent_id)
	{
		$this->db->where("auto_recurrent_id", $auto_recurrent_id)->update(AUTO_RECURRENT_CONTEST, array("status"=>'1'));
		return $this->db->affected_rows();
	}

	public function get_auto_recurrent_last_contest($auto_recurrent_id)
	{
		$sql = $this->db->select("size, minimum_size, total_user_joined, season_scheduled_date, season_week, selected_matches,is_uncapped")
						->from(CONTEST)
						->where("auto_recurrent_id", $auto_recurrent_id)
						->order_by("contest_id","DESC")
						->limit(0)
						->get();
		return $sql->row_array();
	}

	public function get_all_match_by_date($league_id, $season_scheduled_date)
	{
		$sql = $this->db->select('scheduled_date')
						->from(SEASON . " AS S")
						->where('S.league_id', $league_id)
						->where('S.season_scheduled_date =', "$season_scheduled_date")
						->group_by('scheduled_date')
						->order_by('scheduled_date', 'ASC')
						->get();
		$result = $sql->result_array();

		$season_time = array();

		foreach ($result as $key => $value)
		{
			$seasone_date_time_format = $value['scheduled_date'];
			$timestamp = strtotime($seasone_date_time_format);
			$season_time[] = $seasone_date_time_format;
		}

		return $season_time;
	}

	public function update_auto_recurrent_contest($data,$condition)
	{
		if(!empty($data) && !empty($condition)){

			$this->db->where($condition);
			$this->db->update(AUTO_RECURRENT_CONTEST, $data);
			return true;

		} else {
			return false;
		} 
	}

	public function show_winning_amount_weekly()
	{
		$post_data = $this->input->post();

		$sql = "SELECT 
					LD.transaction_amount,LD.user_id
				FROM
					vi_leaderboard AS LD
				INNER JOIN 
					vi_contest as G ON G.contest_id = LD.contest_id						
				AND
					G.contest_id = '".$post_data['game_id']."'
				ORDER BY 
					LD.transaction_amount DESC     
				";
				
			$rs     = $this->db->query($sql);
			$result = $rs->result_array();
			//print_r($result);
			//echo $result[0]['transaction_amount'];
		
			$prize_details = array();
			$omo_prize_details = array();
			foreach ($result as $key => $subvalue) 
			{
				$prize_details[] = $subvalue['transaction_amount'];
				$omo_prize_details[ $subvalue[ 'user_id' ] ] = $subvalue['transaction_amount'];
			}
			$position = 1;
			$temp_array = array();
			$k = 1;
			for($i=0;$i<=count($result);$i++)
			{
				if(!isset($result[$i]))
				{
					break;
				}
				if(isset($result[$k]) && $result[$i]['transaction_amount']==$result[$k]['transaction_amount'])
				{
					$temp_array[$result[$i]['user_id']] = array("prize_amount"=> $result[$i]['transaction_amount'], "position"=>$position);
				}
				else
				{
					$temp_array[$result[$i]['user_id']] = array("prize_amount"=> $result[$i]['transaction_amount'], "position"=>$position);					
					$position++;
				}
				$k++;
			}
// echo "<pre>";print_r($temp_array);die;
		return $temp_array;
	}


	/**
	 * [get_all_salary_cap description]
	 * @MethodName get_all_salary_cap
	 * @Summary This functin used to get all salary cap by league id
	 * @param      [int]  $league_id
	 * @return     [array]
	 */
	public function get_all_custome_weeks_game()
	{
		$result = array();

		$league_id = $this->input->post('league_id');
		$current_date = format_date(); 

		$sql = $this->db->select('S.week,season_game_unique_id, T1.team_id AS home_id,T2.team_id AS away_id, T1.team_abbr as home,T2.team_abbr as away, DATE_FORMAT(S.season_scheduled_date, "%l:%i %p") AS season_scheduled_date,
									DATE_FORMAT(S.scheduled_date,"%W") AS day_name,DATE_FORMAT(S.season_scheduled_date, "%a, %d %b %Y") AS game_date')
							//->select('CONCAT(DATE_FORMAT(S.season_scheduled_date, "%a, %d %b %Y"))')
							->from(SEASON." AS S")
							->join(TEAM.' T1','T1.team_id = S.home_id AND T1.league_id = S.league_id','LEFT')
							->join(TEAM.' T2','T2.team_id = S.away_id AND T2.league_id = S.league_id','LEFT')
							//->join(SEASON_WEEK.' SW','SW.season_week=S.week','INNER')
							->where('S.week BETWEEN '.$this->input->post('start_week').' AND '.$this->input->post('end_week').'')
							->where('S.league_id',$league_id)
							->where('(S.season_scheduled_date > "'.$current_date.'" || S.season_scheduled_date="'.$current_date.'")')
							->order_by('S.season_scheduled_date', 'ASC')
							->group_by('S.season_game_unique_id')
							->get();
		$result = $sql->result_array();
		//echo $this->db->last_query();
		return $result;
	}


/**
	 * [get_season_date description]
	 * @MethodName get_all_season_date
	 * @Summary This function used to get all season date by league id
	 * @param      [int]  $league_id
	 * @return     [array]
	 */
	public function get_all_season_date($league_id)
	{
		$season_year = $this->api['year'];

		$sql = $this->db->select('scheduled_date')
						->from(SEASON . " AS S")
						->where_in('S.league_id', $league_id)
						->where('S.year', $season_year)
						->where('S.season_scheduled_date >', format_date())
						->group_by('scheduled_date')
						->order_by('scheduled_date', 'DESC')
						->get();
		$result = $sql->result_array();

		$season_time = array();

		foreach ($result as $key => $value)
		{
			$seasone_date_time_format = $value['scheduled_date'];
			$timestamp = strtotime($seasone_date_time_format);
			$season_time[] = $seasone_date_time_format;
		}

		return $season_time;
	}

	function get_contest_format($selected_matches)
	{
		if(!is_array($selected_matches))
		{
			$selected_matches = explode(",",$selected_matches);
		}

		$sql = $this->db->select('format')
						->from(SEASON)
						->where_in('season_game_uid',$selected_matches)
						->get();
		$format_rs = $sql->row_array();
		return (!empty($format_rs)) ? $format_rs['format'] : 3; 					
	}


}
/* End of file Contest_model.php */
/* Location: ./application/models/Contest_model.php */