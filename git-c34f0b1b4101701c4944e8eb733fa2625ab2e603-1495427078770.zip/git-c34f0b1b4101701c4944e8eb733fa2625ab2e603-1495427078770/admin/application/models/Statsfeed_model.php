<?php defined('BASEPATH') OR exit('No direct script access allowed');
require_once "../package/Api_credential_model.php";
class Statsfeed_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}
        
        
        function insert($table, $data){
                
		$this->db->insert($table, $data);         
		if ($this->db->affected_rows() == 1)
		{
			return $this->db->insert_id();
		}
		return FALSE;       
	}
        
        /**
	 * [update_feed description]
	 * @MethodName  update_feed
	 * @Summary     This function used to update feed data
	 * @param       [string] table name, [string] where condition, [array]  data array, [boolean] copy column or new value
	 * @return      boolean
	 */
        public function update_feed($table, $where, $data, $col_copy = FALSE) {

                $data_arr = [];
                
                foreach($data as $d_key => $d_val){
                    
                        if($col_copy){
                                $data_str[] = "$d_key = $d_val";
                        } 
                        else {
                                $data_str[] = "$d_key = '$d_val'";
                        }
                }

                $data_str = implode(',', $data_str);
                $sql = "update ".$this->db->dbprefix($table)." set $data_str where $where";
                $this->db->query($sql);
                return true;
        }


        
        
        #############################
        # SEASON FEED START
        #############################
        /**
	 * [get_all_team description]
	 * @MethodName get_all_team
	 * @Summary This function is used to get all team by league id 
	 * @param      [array]  [league_id]
	 * @return     [array]
	 */
//        public function get_all_team($param)
//	{
//		$this->db->select('T.team_id, T.team_name, T.team_abbr');
//                $this->db->from(TEAM ." AS T");
//                
//                if($param['league_id']){
//                        $this->db->where('T.league_id', $param['league_id']);
//                }
//                
//                $this->db->order_by('team_name','ASC');
//                $sql = $this->db->get();
//                
//		$team_array = $sql->result_array();
//
//		return ($team_array) ? $team_array : array();
//	}
        
        public function export_season_template($league_id, $season_year){
            
                $league_detail = $this->get_league_detail($league_id);
                
                $sheet_heading = "Season List (".$league_detail['league_abbr']." - ".$season_year.")";
                
                $rule_list     = array();
                
                ## Get players of selected teams
                $team_result = $this->get_all_team($league_id);
                
                ## Column Heading Array
                $heading_list = array(
                        "A"=> "Home Team (Abbr) | Team ID", 
                        "B"=> "Away Team (Abbr) | Team ID",
                        "C"=> "Type",
                        "D"=> "Schedule Date (yyyy-mm-dd HH:mm)"
                );
                
                ## Column Dropdown Value  Array
                $value_list = array(
                        "A"=> true,
                        "B"=> true,
                        "C"=> true, //array_unique($rule_list),
                        "D"=> ""
                );
                
                $file_name = $league_detail['league_abbr'].'_Season_'.$season_year.'.xlsx';
                
                $this->load->library('PHPExcel');
                
		$obj_excel = new PHPExcel(); 

                
                $formulaWorkSheet = $obj_excel->createSheet(1);
                
                $formulaWorkSheet->setTitle('Mapping Formula');
                
                $formulaWorkSheet->getColumnDimension('A')->setWidth(30);
                $formulaWorkSheet->getColumnDimension('B')->setWidth(30);
                
                if(!empty($team_result)){
                        $p_r = 1;
                        foreach($team_result as $team) {
                                $team_name = str_replace('_', ' ', $team['team_name']." (".$team['team_abbr'].")")."_".$team['team_id'];
                                
                                $formulaWorkSheet->SetCellValue("A$p_r", $team_name);
                                $p_r++;
                        }
                        
                        // create name range for Home Team list
                        $obj_excel->addNamedRange( 
                            new PHPExcel_NamedRange(
                                'home_team', 
                                $formulaWorkSheet, 
                                "A1:A".(($p_r>1)?$p_r-1:$p_r)
                            ) 
                        );
                        // create name range for Away Team list
                        $obj_excel->addNamedRange( 
                            new PHPExcel_NamedRange(
                                'away_team', 
                                $formulaWorkSheet, 
                                "A1:A".(($p_r>1)?$p_r-1:$p_r)
                            ) 
                        );
                }         
                
                $t_r = 1;
                $type_arr = array('REG','PST','PRE');
                foreach($type_arr as $type) {

                        $formulaWorkSheet->SetCellValue("B$t_r", $type);
                        $t_r++;
                }

                // create name range for Home Team list
                $obj_excel->addNamedRange( 
                    new PHPExcel_NamedRange(
                        'type', 
                        $formulaWorkSheet, 
                        "B1:B".(($t_r>1)?$t_r-1:$t_r)
                    ) 
                );
                
                ## Hide Formula sheet
                $formulaWorkSheet->setSheetState(PHPExcel_Worksheet::SHEETSTATE_HIDDEN);
                
                
		// writer already created the first sheet for us, let's get it
		$obj_sheet = $obj_excel->getActiveSheet();

		$obj_sheet->setTitle("Season (".$league_detail['league_name'].")");
                
                // Set Main Heading
                $obj_sheet->mergeCells("A1:D1");
                $obj_sheet->getCell("A1")->setValue($sheet_heading);
                $obj_sheet->getRowDimension(1)->setRowHeight(30);
                
                ## Note content
                $obj_sheet->mergeCells("A2:D2");
                $obj_sheet->getCell("A2")->setValue('NOTE: Date format should be yyyy-mm-dd HH:mm ('.date('Y-m-d H:i').', 24 hour format).');
                $obj_sheet->getRowDimension(2)->setRowHeight(24);
                
                $style1 = array(
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                        'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
                    ),
                    'font'  => array(
                        'bold' => true,
                        'size'  => 16
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'c6d3db')
                    )
                );
                $obj_sheet->getStyle('A1')->applyFromArray($style1);
                
                ## Row 2 Style
                $obj_sheet->getRowDimension(2)->setRowHeight(16);
                $style2 = array(
                    'alignment' => array(
                        'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
                    ),
                    'font'  => array(
                        'size'  => 10,
                        'color' => array('rgb' => 'FF0000')
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'c6d3db')
                    )
                );

                $obj_sheet->getStyle('A2:D2')->applyFromArray($style2);
                
                ## Row 3 Style
                $obj_sheet->getRowDimension(3)->setRowHeight(16);
                $style3 = array(
                    
                    'font'  => array(
                        'bold' => true
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '838080')
                    )
                );

                $obj_sheet->getStyle('A3:D3')->applyFromArray($style3);
                
                foreach($heading_list as $h_key => $heading){
                    
                        $obj_sheet->getColumnDimension($h_key)->setWidth(30);
                        
                        ## Set Column Heading
                        $obj_sheet->getCell($h_key."3")->setValue($heading);
                        
                        ## Set Column Value Dropdown 
                        if(!empty($value_list[$h_key])){
                            
                                for($r = 4; $r <= 100; $r++) {
                                    
                                        $objValidation = $obj_sheet->getCell($h_key.$r)->getDataValidation();
                                        $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
                                        $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
                                        $objValidation->setAllowBlank(false);
                                        $objValidation->setShowInputMessage(true);
                                        $objValidation->setShowErrorMessage(true);
                                        $objValidation->setShowDropDown(true);
                                        $objValidation->setErrorTitle('Input error');
                                        $objValidation->setError('Value is not in list.');
                                        //$objValidation->setPromptTitle('Pick from list');
                                        //$objValidation->setPrompt('Pick a value from the drop-down list.');
                                            
                                        if($h_key == 'A'){
                                                // Render dropdown option from Away Team
                                                $objValidation->setFormula1("=home_team"); 
                                        }
                                        else if($h_key == 'B'){
                                                // Render dropdown option from Away Team
                                                $objValidation->setFormula1("=away_team"); 
                                        }
                                        else if($h_key == 'C'){
                                                // Render dropdown option from Away Team
                                                $objValidation->setFormula1("=type"); 
                                        }
                                }
                        }
                }
                $obj_excel->setActiveSheetIndex(0);
                
		//header('Content-Type: application/vnd.ms-excel');
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="'.$file_name.'"');
		header('Cache-Control: max-age=0');
                
		$obj_writer = PHPExcel_IOFactory::createWriter($obj_excel, 'Excel2007');
    
		$obj_writer->save('php://output');
                exit;
        }
        
        #############################
        # SEASON FEED END
        #############################
        
        
        #############################
        # SCORE STATISTICS START
        #############################
        
        /**
	 * [get_season_statisctics_feed description]
	 * @MethodName get_season_statisctics_feed
	 * @Summary This function used for get all season statisctics feed list
	 * @return     [array]
	 */
	public function get_season_statisctics_feed()
	{
		$post_data = $this->input->post();

		$sort_field = '';
		$sort_order = '';
		$limit      = 10;
		$page       = 0;
		$summary 	= '';

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field'])) // && in_array($post_data['sort_field'], $tableheader)
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select('PS.feed_match_statistics_id, PS.player_unique_id, PS.scoring_type, PS.stats_key, PS.stats_value, PS.minute', FALSE);
		$this->db->select('MS.league_id, MS.season_game_unique_id, MS.season_scheduled_date, MS.home, MS.away', FALSE);
		$this->db->select('SC.scoring_category_name, SC.master_scoring_category_id, P.full_name AS player_name, PS.team_id, P.position AS player_position,  PT.team_name AS player_team_name, PT.team_abbr AS player_team_abbr, T1.team_abbr AS home_abbr,T2.team_abbr AS away_abbr, T1.team_name AS home_team_name, T2.team_name AS away_team_name', FALSE)
                        ->from(FEED_PLAYER_STATISTICS . ' AS PS')
                        ->join(FEED_MATCH_STATISTICS . ' MS','MS.feed_match_statistics_id = PS.feed_match_statistics_id','LEFT')
                        ->join(MASTER_SCORING_CATEGORY.' SC','SC.master_scoring_category_id = PS.scoring_type','LEFT')
                        ->join(PLAYER.' P','P.player_unique_id = PS.player_unique_id','LEFT')
                        ->join(TEAM.' PT','PT.team_id = PS.team_id AND PT.league_id = MS.league_id','LEFT')
                        ->join(TEAM.' T1','T1.team_id = MS.home AND T1.league_id = MS.league_id','LEFT')
                        ->join(TEAM.' T2','T2.team_id = MS.away AND T2.league_id = MS.league_id','LEFT')
                        ->where('MS.league_id', $post_data['league_id'])
                        ->where('MS.season_game_unique_id', $post_data['season_game_unique_id']);
                
                if(!empty($post_data['player_unique_id'])){
                        $this->db->where('PS.player_unique_id', $post_data['player_unique_id']);
                }
                
                if(!empty($post_data['team_id'])){
                        $this->db->where('PS.team_id', $post_data['team_id']);
                }
                
                if(!empty($post_data['position'])){
                        $this->db->where('P.position', $post_data['position']);
                }
                
		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();
                
		if($sort_field!="" && $sort_order!="")
		{
			$tempdb->order_by($sort_field, $sort_order);
		}
		$tempdb->limit($limit,$offset);
		$sql = $tempdb->get();
		//echo $tempdb->last_query();die;
		$result	= $sql->result_array();
		if(!empty($result))
		{
			$summary = $result[0]['home_abbr']." vs ".$result[0]['away_abbr']." - ".date(PHP_DATE_FORMAT, strtotime($result[0]['season_scheduled_date']));
		}
		$result = ($result) ? $result : array();

		return array('result'=>$result, 'total'=>$total,'summary'=>$summary, 'sort_field'=>$sort_field, 'sort_order'=>$sort_order);
	}

	/**
	 * [get_season_game_team description]
	 * @MethodName get_season_game_team
	 * @Summary This function is used to get all team by league id and season game unique id in database
	 * @param      [array]  [league_id, season_game_unique_id]
	 * @return     [array]
	 */
	public function get_season_game_team($param)
	{
		$this->db->select('T.team_id, T.team_name, T.team_abbr, S.home AS home_abbr, S.away AS away_abbr, S.season_scheduled_date');
                $this->db->from(TEAM ." AS T")
                        ->join(SEASON . " AS S", "S.away_id = T.team_id OR S.home_id = T.team_id", 'LEFT');
                
                if($param['league_id']){
                        $this->db->where('T.league_id', $param['league_id']);
                }
                
                if($param['season_game_unique_id']){
                        $this->db->where('S.season_game_unique_id', $param['season_game_unique_id']);
                }
                
                $this->db->order_by('team_name','ASC');
                $sql = $this->db->get();
                
		$team_array = $sql->result_array();
//		foreach ($team_array as $rc)
//		{
//			$result[] = $rc;
//		}
		return ($team_array) ? $team_array : array();
	}
	
        /**
	 * [get_team_player description]
	 * @MethodName get_team_player
	 * @Summary This function is used to get all players by team in database
	 * @param      [array]  [array of team_id]
	 * @return     [array]
	 */
	public function get_team_player($team_ids, $league_id)
	{       
		$this->db->select('P.player_unique_id, P.full_name, P.first_name, P.last_name, P.position,
                                IFNULL(P.salary,0) as salary,IFNULL(P.player_status,0) as player_status,
                                T.team_id, T.team_abbr', FALSE)
                                ->from(PLAYER . " AS P")
                                ->join(TEAM.' T','T.team_id = P.team_id AND T.league_id = P.league_id','inner')
                                ->where("P.league_id", $league_id)
                                ->where("P.is_deleted", "0");
                
                if (!empty($team_ids) && $team_ids != 'all') {
			$this->db->where_in('T.team_id', $team_ids);
		}
                
                $this->db->order_by('P.full_name','ASC');
                $sql = $this->db->get();
                //echo $this->db->last_query(); die;
		$player_array = $sql->result_array();

		return ($player_array) ? $player_array : array();
	}
        
        /**
	 * [get_scoring_category description]
	 * @MethodName get_scoring_category
	 * @Summary This function is used to get all players by team in database
	 * @param      [int]  [league_id]
	 * @return     [array]
	 */
	public function get_scoring_category($league_id)
	{       
		$this->db->select('SC.scoring_category_name, SC.sports_id, SC.master_scoring_category_id', FALSE)
                                ->from(MASTER_SCORING_CATEGORY . " AS SC")
                                ->join(LEAGUE.' L','L.sports_id = SC.sports_id','INNER');
                
                if (!empty($league_id)) {
			$this->db->where_in('L.league_id', $league_id);
		}
                
                $this->db->order_by('SC.scoring_category_name','ASC');
                $sql = $this->db->get();
                //echo $this->db->last_query(); die;
		$category_array = $sql->result_array();

		return ($category_array) ? $category_array : array();
	}
        
        /**
	 * [get_scoring_rule description]
	 * @MethodName get_scoring_rule
	 * @Summary This function is used to get all scoring rule by scoring category in database
	 * @param      [array]  [array of category_ids]
	 * @return     [array]
	 */
	public function get_scoring_rule($category_ids)
	{       
		$this->db->select('SR.master_scoring_id, SR.master_scoring_category_id, SR.meta_key_alias AS stats_key', FALSE)
                                ->from(MASTER_SCORING_RULES . " AS SR")
                                ->join(MASTER_SCORING_CATEGORY.' SC','SC.master_scoring_category_id = SR.master_scoring_category_id','INNER');
                
                if (!empty($category_ids) && $category_ids != 'all') {
			$this->db->where_in('SR.master_scoring_category_id', $category_ids);
		}
                
                $this->db->order_by('SR.meta_key_alias','ASC');
                $sql = $this->db->get();
                //echo $this->db->last_query(); die;
		$rule_array = $sql->result_array();

		return ($rule_array) ? $rule_array : array();
	}
        
        /**
	 * [get_feed_match_statistics description]
	 * @MethodName  get_feed_match_statistics
	 * @Summary     This function is used to get match feed statistics data of selected match by $season_game_id and $league_id in database
	 * @param       [int]  [season_game_unique_id, league_id]
	 * @return      [array]
	 */
	public function get_feed_match_statistics($season_game_id, $league_id)
	{       
		$this->db->select('MS.feed_match_statistics_id, MS.league_id, MS.season_game_unique_id, MS.home_total_score, MS.away_total_score, MS.match_status', FALSE)
                                ->from(FEED_MATCH_STATISTICS . " AS MS");
                
                $this->db->where('MS.season_game_unique_id', $season_game_id);
                $this->db->where('MS.league_id', $league_id);

                $sql = $this->db->get();
                //echo $this->db->last_query(); die;
		$category_array = $sql->row_array();

		return ($category_array) ? $category_array : array();
	}
        
        /**
	 * [save_feed_match_statistics description]
	 * @MethodName  save_feed_match_statistics
	 * @Summary     This function used to save feed match statistics
	 * @param       [array]  data array
	 * @return      int
	 */
	public function save_feed_match_statistics($data)
	{
		$this->db->insert(FEED_MATCH_STATISTICS, $data);
		return $this->db->insert_id();
	}
        
        /**
	 * [delete_stats description]
	 * @MethodName  delete_stats
	 * @Summary     This function used to delete feed data
	 * @param       [string] table nanme, [array]  where array
	 * @return      boolean
	 */
        public function delete_stats($table, $where) {
            $this->table_name = $table;
            $result = $this->delete($where);
            return $result;
        }

    
    public function delete_team_from_league($post)
    {
        if(is_array($post["team_id"]))
        {
            $this->db->where_in('team_id', $post["team_id"]);
        }
        else
        {
            $this->db->where('team_id', $post["team_id"]);  
        }
        if(!empty($post["league_id"]))
        {
            $this->db->where('league_id', $post["league_id"]);      
        }
        
        $this->db->delete(TEAM_LEAGUE);
        return true;
    }
    
        
        /**
	 * [get_league_detail description]
	 * @MethodName get_league_detail
	 * @Summary This function used to get league detail by league id
	 * @param      [int] league id
	 * @return     [xlsx]
	 */
	public function get_league_detail($league_id)
	{
		$sql =  $this->db->select("*")->from(LEAGUE)->where("league_id", $league_id)->get();
		return $league_detail = $sql->row_array();
	}
        
        public function export_score_stats_template($season_game_id, $league_id){
            
                $league_detail = $this->get_league_detail($league_id);
                
		$team_result = $this->get_season_game_team(array('season_game_unique_id' => $season_game_id, 'league_id'=>$league_id));
                if(!empty($team_result)){
                        $sheet_heading = "Season Stats List (".$team_result[0]['home_abbr']." vs ".$team_result[0]['away_abbr']." - ".date(PHP_DATE_FORMAT, strtotime($team_result[0]['season_scheduled_date'])).")";
                } else {
                        $sheet_heading = "Season Stats List ";
                }
                
                $rule_list     = array();
                
                ## Get players of selected teams
                $team_ids = array_column($team_result, 'team_id');
                $player_result = $this->get_team_player($team_ids, $league_id);
                
                ## Get Scoring Category
                $scoring_cat_result = $this->get_scoring_category($league_id);
                
                ## Get Scoring Rule
                $category_ids = array_column($scoring_cat_result, 'master_scoring_category_id');
                $scoring_rule_result = $this->get_scoring_rule($category_ids);
                
                if(!empty($scoring_rule_result)){
                        foreach ($scoring_rule_result as $rule){
                                //$rule_list[] = $rule['stats_key'];
                                $rule_list[$rule['master_scoring_category_id']][] = $rule['stats_key'];
                        }
                }
                
                ## Column Heading Array
                $heading_list = array(
                        "A"=> "Player Name (Position) (Team) | Player ID", 
                        "B"=> "Scoring Type | Type ID",
                        "C"=> "Event",
                        "D"=> "Score",
                        "E"=> "Minutes"
                );
                
                ## Column Dropdown Value  Array
                $value_list = array(
                        "A"=> true,
                        "B"=> true,
                        "C"=> true, //array_unique($rule_list),
                        "D"=> "",
                        "E"=> ""
                );
                
                ## Create sheet column name array (A-Z)
                $column_arr = range('A', 'Z');
                
                $file_name = $league_detail['league_abbr'].'_feed_'.$season_game_id.'.xlsx';
                
                $this->load->library('PHPExcel');
                
		$obj_excel = new PHPExcel(); 

                
                $formulaWorkSheet = $obj_excel->createSheet(1);
                
                $formulaWorkSheet->setTitle('Mapping Formula');
                
                if(!empty($player_result)){
                        $p_r = 1;
                        foreach($player_result as $player) {
                                $player_name = str_replace('_', ' ', $player['full_name']." (".$player['position'].") (".$player['team_abbr'].")")."_".$player['player_unique_id'];
                                
                                $formulaWorkSheet->SetCellValue("A$p_r", $player_name);
                                $p_r++;
                        }
                        
                        // create name range for scoring category list
                        $obj_excel->addNamedRange( 
                            new PHPExcel_NamedRange(
                                'player_list', 
                                $formulaWorkSheet, 
                                "A1:A".(($p_r>1)?$p_r-1:$p_r)
                            ) 
                        );
                }                
                
                if(!empty($scoring_cat_result)){
                        
                         $c_cnt = 1;
                         $col_index = 2;
                        
                        foreach ($scoring_cat_result as $category){
                                $category_list = str_replace(' ', '',ucwords(str_replace('_', ' ', $category['scoring_category_name']))) . "_" . $category['master_scoring_category_id'];
                                
                                $formulaWorkSheet->SetCellValue("B$c_cnt", "$category_list");
                                        
                                $r_cnt = 1;
                                
                                // Get Rule list of selected category
                                if(!empty($rule_list[$category['master_scoring_category_id']])){
                                    
                                        $unique_rule_list = array_unique($rule_list[$category['master_scoring_category_id']]);
                                        
                                        foreach($unique_rule_list as $rule) {
                                                
                                                $formulaWorkSheet->SetCellValue("$column_arr[$col_index]$r_cnt", "$rule");
                                                
                                                $r_cnt++;
                                        }
                                }
                                
                                // Create name range for selected category and selected category rule list
                                
                                $obj_excel->addNamedRange( 
                                            new PHPExcel_NamedRange(
                                                $category_list, 
                                                $formulaWorkSheet, 
                                                '$'.$column_arr[$col_index].'$1:$'.$column_arr[$col_index].'$'.(($r_cnt>1)?$r_cnt-1:$r_cnt)
                                            ) 
                                        );
                                
                                   $c_cnt++;
                                   $col_index++;
                        }
                        
                        // create name range for scoring category list
                        $obj_excel->addNamedRange( 
                            new PHPExcel_NamedRange(
                                'scoring_category', 
                                $formulaWorkSheet, 
                                "B1:B".(($c_cnt>1)?$c_cnt-1:$c_cnt)
                            ) 
                        );
                        
                }
                ## Hide Formula sheet
                $formulaWorkSheet->setSheetState(PHPExcel_Worksheet::SHEETSTATE_HIDDEN);
                
                
		// writer already created the first sheet for us, let's get it
		$obj_sheet = $obj_excel->getActiveSheet();

		$obj_sheet->setTitle($league_detail['league_name']);
                
                // Set Main Heading
                $obj_sheet->mergeCells("A1:E1");
                $obj_sheet->getCell("A1")->setValue($sheet_heading);
                $obj_sheet->getRowDimension(1)->setRowHeight(30);
                
                $style1 = array(
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                        'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
                    ),
                    'font'  => array(
                        'bold' => true,
                        'size'  => 16
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'c6d3db')
                    )
                );
                $obj_sheet->getStyle('A1')->applyFromArray($style1);
                
                
		//$obj_sheet->getStyle('A2:E2')->getFont()->setBold(true);
                $obj_sheet->getRowDimension(2)->setRowHeight(16);
                $style2 = array(
                    
                    'font'  => array(
                        'bold' => true
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '838080')
                    )
                );

                $obj_sheet->getStyle('A2:E2')->applyFromArray($style2);
                
                foreach($heading_list as $h_key => $heading){
                    
                        if($h_key != 'D' && $h_key != 'E'){
                                            
                                //$obj_sheet->getColumnDimensionByColumn($h_key)->setAutoSize(false);
                                if($h_key == 'A'){
                                        $obj_sheet->getColumnDimension($h_key)->setWidth(30);
                                } else {
                                        $obj_sheet->getColumnDimension($h_key)->setWidth(24);
                                }
                        }
                        
                        ## Set Column Heading
                        $obj_sheet->getCell($h_key."2")->setValue($heading);
                        
                        ## Set Column Value Dropdown 
                        if(!empty($value_list[$h_key])){
                            
                                for($r = 3; $r <= 200; $r++) {
                                    
                                        $objValidation = $obj_sheet->getCell($h_key.$r)->getDataValidation();
                                        $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
                                        $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
                                        $objValidation->setAllowBlank(false);
                                        $objValidation->setShowInputMessage(true);
                                        $objValidation->setShowErrorMessage(true);
                                        $objValidation->setShowDropDown(true);
                                        $objValidation->setErrorTitle('Input error');
                                        $objValidation->setError('Value is not in list.');
                                        //$objValidation->setPromptTitle('Pick from list');
                                        //$objValidation->setPrompt('Pick a value from the drop-down list.');
                                            
                                        if($h_key == 'B'){
                                                // Render dropdown option from category name range
                                                $objValidation->setFormula1("=scoring_category"); //note this!
                                        } 
                                        else if($h_key == 'C'){
                                                // Render dropdown option from rule ranges
                                                $objValidation->setFormula1("=INDIRECT(B$r)"); 
                                        }
                                        else if($h_key == 'A'){
                                                
                                                $objValidation->setFormula1("=player_list"); 
                                        }
                                }
                        }
                }
                $obj_excel->setActiveSheetIndex(0);
                
		//header('Content-Type: application/vnd.ms-excel');
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="'.$file_name.'"');
		header('Cache-Control: max-age=0');
                
		$obj_writer = PHPExcel_IOFactory::createWriter($obj_excel, 'Excel2007');
    
		$obj_writer->save('php://output');
                exit;
        }
        #############################
        # SCORE STATISTICS END
        #############################
        
        #############################
        # TEAM STATISTICS START
        #############################
        
        public function export_team_template($league_id, $season_year){
            
                $league_detail = $this->get_league_detail($league_id);
                
                $sheet_heading = "Team List (".$league_detail['league_abbr']." - ".$season_year.")";
                
                ## Column Heading Array
                $heading_list = array(
                        "A"=> "Team Name", 
                        "B"=> "Team Abbreviation"
                );
                
                $file_name = $league_detail['league_abbr'].'_team_'.$season_year.'.xlsx';
                
                $this->load->library('PHPExcel');
                
		$obj_excel = new PHPExcel(); 

		// writer already created the first sheet for us, let's get it
		$obj_sheet = $obj_excel->getActiveSheet();

		$obj_sheet->setTitle($league_detail['league_name']);
                
                // Set Main Heading
                $obj_sheet->mergeCells("A1:B1");
                $obj_sheet->getCell("A1")->setValue($sheet_heading);
                $obj_sheet->getRowDimension(1)->setRowHeight(30);
                
                $style1 = array(
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                        'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
                    ),
                    'font'  => array(
                        'bold' => true,
                        'size'  => 16
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'c6d3db')
                    )
                );
                $obj_sheet->getStyle('A1')->applyFromArray($style1);
                
                
		//$obj_sheet->getStyle('A2:E2')->getFont()->setBold(true);
                $obj_sheet->getRowDimension(2)->setRowHeight(16);
                $style2 = array(
                    
                    'font'  => array(
                        'bold' => true
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '838080')
                    )
                );

                $obj_sheet->getStyle('A2:B2')->applyFromArray($style2);
                
                foreach($heading_list as $h_key => $heading){
                    
                                            
                                //$obj_sheet->getColumnDimensionByColumn($h_key)->setAutoSize(false);
                                if($h_key == 'A'){
                                        $obj_sheet->getColumnDimension($h_key)->setWidth(30);
                                } 
                                else if($h_key == 'B'){
                                        $obj_sheet->getColumnDimension($h_key)->setWidth(20);
                                }
                        
                        ## Set Column Heading
                        $obj_sheet->getCell($h_key."2")->setValue($heading);
                        
                }
                $obj_excel->setActiveSheetIndex(0);
                
		//header('Content-Type: application/vnd.ms-excel');
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="'.$file_name.'"');
		header('Cache-Control: max-age=0');
                
		$obj_writer = PHPExcel_IOFactory::createWriter($obj_excel, 'Excel2007');
    
		$obj_writer->save('php://output');
                exit;
        }
        
        #############################
        # TEAM STATISTICS END
        #############################
        
        
        #############################
        # ROSTER STATISTICS START
        #############################
        
        public function export_roster_template($league_id){
            
                $league_detail = $this->get_league_detail($league_id);
                
                $sheet_heading = "Roster List (".$league_detail['league_abbr'].")";
                
                ## Get players of selected teams
                $team_result = $this->get_all_team($league_id);
                
                ## Get players of selected teams
                $position_result = $this->get_all_position($league_id);
                
                ## Column Heading Array
                $heading_list = array(
                        "A"=> "Team (Abbr) | Team ID", 
                        "B"=> "Position",
                        "C"=> "First Name",
                        "D"=> "Last Name",
                        "E"=> "Nick Name",
                        "F"=> "Salary",
                        "G"=> "Injury"
                );
                
                ## Column Dropdown Value  Array
                $value_list = array(
                        "A"=> true,
                        "B"=> true,
                        "C"=> "",
                        "D"=> "",
                        "E"=> "",
                        "F"=> "",
                        "G"=> ""
                );
                
                $file_name = $league_detail['league_abbr'].'_Roster.xlsx';
                
                $this->load->library('PHPExcel');
                
		$obj_excel = new PHPExcel(); 

                
                $formulaWorkSheet = $obj_excel->createSheet(1);
                
                $formulaWorkSheet->setTitle('Mapping Formula');
                
                $formulaWorkSheet->getColumnDimension('A')->setWidth(30);
                $formulaWorkSheet->getColumnDimension('B')->setWidth(30);
                
                if(!empty($team_result)){
                        $t_r = 1;
                        foreach($team_result as $team) {
                                $team_name = str_replace('_', ' ', $team['team_name']." (".$team['team_abbr'].")")."_".$team['team_id'];
                                
                                $formulaWorkSheet->SetCellValue("A$t_r", $team_name);
                                $t_r++;
                        }
                        
                        // create name range for Team list
                        $obj_excel->addNamedRange( 
                            new PHPExcel_NamedRange(
                                'team', 
                                $formulaWorkSheet, 
                                "A1:A".(($t_r>1)?$t_r-1:$t_r)
                            ) 
                        );
                }         
                
                if(!empty($position_result)){
                        $p_r = 1;
                        foreach($position_result as $position) {

                                //$position_name = str_replace('_', ' ', $position['position_display_name']." (".$position['position'].")")."_".$position['position'];

                                $formulaWorkSheet->SetCellValue("B$p_r", trim($position['position']));
                                $p_r++;
                        }

                        // create name range for Position list
                        $obj_excel->addNamedRange( 
                            new PHPExcel_NamedRange(
                                'position', 
                                $formulaWorkSheet, 
                                "B1:B".(($p_r>1)?$p_r-1:$p_r)
                            ) 
                        );
                }
                
                ## Hide Formula sheet
                $formulaWorkSheet->setSheetState(PHPExcel_Worksheet::SHEETSTATE_HIDDEN);
                
                
		// writer already created the first sheet for us, let's get it
		$obj_sheet = $obj_excel->getActiveSheet();

		$obj_sheet->setTitle("Roster (".$league_detail['league_name'].")");
                
                // Set Main Heading
                $obj_sheet->mergeCells("A1:G1");
                $obj_sheet->getCell("A1")->setValue($sheet_heading);
                $obj_sheet->getRowDimension(1)->setRowHeight(30);
                
                
                $style1 = array(
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                        'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
                    ),
                    'font'  => array(
                        'bold' => true,
                        'size'  => 16
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'c6d3db')
                    )
                );
                $obj_sheet->getStyle('A1')->applyFromArray($style1);
                
                ## Row 2 Style
                $obj_sheet->getRowDimension(2)->setRowHeight(16);
                $style2 = array(
                    
                    'font'  => array(
                        'bold' => true
                    ),
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '838080')
                    )
                );

                $obj_sheet->getStyle('A2:G2')->applyFromArray($style2);
                
                
                foreach($heading_list as $h_key => $heading){
                    
                        $obj_sheet->getColumnDimension($h_key)->setWidth(24);
                        
                        ## Set Column Heading
                        $obj_sheet->getCell($h_key."2")->setValue($heading);
                        
                        ## Set Column Value Dropdown 
                        if(!empty($value_list[$h_key])){
                            
                                for($r = 3; $r <= 200; $r++) {
                                    
                                        $objValidation = $obj_sheet->getCell($h_key.$r)->getDataValidation();
                                        $objValidation->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
                                        $objValidation->setErrorStyle( PHPExcel_Cell_DataValidation::STYLE_INFORMATION );
                                        $objValidation->setAllowBlank(false);
                                        $objValidation->setShowInputMessage(true);
                                        $objValidation->setShowErrorMessage(true);
                                        $objValidation->setShowDropDown(true);
                                        $objValidation->setErrorTitle('Input error');
                                        $objValidation->setError('Value is not in list.');
                                        //$objValidation->setPromptTitle('Pick from list');
                                        //$objValidation->setPrompt('Pick a value from the drop-down list.');
                                            
                                        if($h_key == 'A'){
                                                // Render dropdown option from Away Team
                                                $objValidation->setFormula1("=team"); 
                                        }
                                        else if($h_key == 'B'){
                                                // Render dropdown option from Away Team
                                                $objValidation->setFormula1("=position"); 
                                        }
                                }
                        }
                }
                $obj_excel->setActiveSheetIndex(0);
                
		//header('Content-Type: application/vnd.ms-excel');
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="'.$file_name.'"');
		header('Cache-Control: max-age=0');
                
		$obj_writer = PHPExcel_IOFactory::createWriter($obj_excel, 'Excel2007');
    
		$obj_writer->save('php://output');
                exit;
        }
        
        #############################
        # SEASON FEED END
        #############################
        
        
}
/* End of file Statsfeed_model.php */
/* Location: ./application/models/Statefeed_model.php */