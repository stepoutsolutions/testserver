<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}

	
	/**
	 * [get_all_transaction description]
	 * @MethodName get_all_transaction
	 * @Summary This function used for get all transaction history
	 * @param      boolean  [transaction history or Return Only Count]
	 * @return     [type]
	 */
	public function get_all_transaction()
	{
		$sort_field	= 'date_added';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;
		$post_data = $this->input->post();

		if(($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(($post_data['sort_field']) && in_array($post_data['sort_field'],array('user_name','real_amount','bonus_amount','date_added','status','type')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("IFNULL(U.user_name,CONCAT_WS(' ',U.first_name,U.last_name)) AS user_name,U.user_id,O.real_amount,O.bonus_amount,O.type,DATE_FORMAT(O.date_added, '".MYSQL_DATE_FORMAT."') AS date_added,O.order_id,O.source,O.source_id,O.status,IFNULL(C.contest_name,'') AS contest_name,IFNULL(C.contest_unique_id,'') AS contest_unique_id,IFNULL(T.transaction_status,0) as transaction_status,O.source,O.source_id",FALSE)
		->from(USER.' AS U')
		->join(ORDER.' AS O','O.user_id = U.user_id','INNER')
		->join(TRANSACTION.' T','T.order_id = O.order_id AND O.source = '.ORDER_SOURCE_DEPOSIT,'LEFT')
		->join(CONTEST.' C','C.contest_id = O.source_id AND O.source = '.ORDER_SOURCE_JOIN_GAME.' OR O.source = '.ORDER_SOURCE_GAME_CANCEL.' OR O.source = '.ORDER_SOURCE_GAME_WON,'LEFT');

		if(isset($post_data['payment_type']) && $post_data['payment_type'] != "all")
		{
			$this->db->where("O.type",$post_data['payment_type']);
		}

		if(isset($post_data['fromdate']) && $post_data['fromdate']!="" && isset($post_data['todate']) && $post_data['todate']!="")
		{
			$this->db->where("DATE_FORMAT(O.date_added,'%Y-%m-%d') >= '".$post_data['fromdate']."' and DATE_FORMAT(O.date_added,'%Y-%m-%d') <= '".$post_data['todate']."'");
		}

		// $this->db->select("PHT.*,IFNULL(U.user_name,CONCAT_WS(' ',U.first_name,U.last_name)) AS user_name,DATE_FORMAT(PHT.created_date,'%d-%b-%Y') as created_date, MD.english_description,C.contest_name")
		// 				->from(PAYMENT_HISTORY_TRANSACTION." AS PHT")
		// 				->join(MASTERDESCRIPTION." AS MD","MD.master_description_id = PHT.master_description_id","LEFT")
		// 				->join(CONTEST." AS C","C.contest_unique_id = PHT.contest_unique_id","LEFT")
		// 				->join(USER." AS U","U.user_id = PHT.user_id","inner");
		
		
		

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
					  ->order_by('O.order_id','DESC')
					  ->limit($limit,$offset)
					  ->get();
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}


	public function get_all_descriptions(){


		$sort_field	= 'added_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;
		$post_data = $this->input->post();

		if($post_data['items_perpage'])
		{
			$limit = $post_data['items_perpage'];
		}

		if($post_data['current_page'])
		{
			$page = $post_data['current_page']-1;
		}

		if($post_data['sort_field'] && in_array($post_data['sort_field'],array('added_date','description_key','english_description','portuguese_description')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if($post_data['sort_order'] && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$sql = $this->db->select("MD.master_description_id, MD.description_key,MD.english_description,MD.portuguese_description,DATE_FORMAT(MD.added_date,'%d-%b-%Y') AS added_date",FALSE)
						->from(MASTERDESCRIPTION.' AS MD')
						->order_by($sort_field, $sort_order);
		

		
		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();
		

		$records	= array();
		$result=($result)?$result:array();
		return array('result'=>$result,'total'=>$total);
	


	}

}
/* End of file Transaction_model.php */
/* Location: ./application/models/Transaction_model.php */