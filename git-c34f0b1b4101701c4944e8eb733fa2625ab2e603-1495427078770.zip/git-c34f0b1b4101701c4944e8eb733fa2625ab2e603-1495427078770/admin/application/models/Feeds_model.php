<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Feeds_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}	

	/**
	 * [get_all_raw_feed description]
	 * @MethodName get_all_raw_feed
	 * @Summary This function used for get all feeds raw data listing
	 * @return     [type]
	 */
	public function get_all_raw_feed()
	{
		$limit		= 10;
		$page		= 0;
		$post_data	= $this->input->post();
		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		$offset	= $limit * $page;
		$league_id	= isset($post_data['league_id']) ? $post_data['league_id'] : "";
		$fromdate	= isset($post_data['fromdate']) ? $post_data['fromdate'] : "";
		$todate		= isset($post_data['todate']) ? $post_data['todate'] : "";

		$this->db->select("FRD.id, FRD.feed_name, FRD.league_id, FRD.feed_url, DATE_FORMAT(FRD.created_date,'%d-%b-%Y %H:%i') as created_date, L.league_abbr")
				->from(FEED_RAW_DATA." AS FRD")
				->join(LEAGUE." AS L", "L.league_id = FRD.league_id","inner");

		if ($league_id != '') 
		{
			$this->db->where('FRD.league_id', $league_id);
		}

		if($fromdate != "" && $todate != "")
		{
			$this->db->where("DATE_FORMAT(created_date,'%Y-%m-%d') >= '".$fromdate."' and DATE_FORMAT(created_date,'%Y-%m-%d') <= '".$todate."'");
		}

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by("created_date", "DESC")
					->limit($limit,$offset)
					->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [get_feed_detail description]
	 * @MethodName get_feed_detail
	 * @Summary This function used to get feed raw by feed id
	 * @param      [int]  feed id
	 * @return     array
	 */
	public function get_feed_detail($feed_id)
	{
		$sql = $this->db->select("raw_data")
						->from(FEED_RAW_DATA)
						->get();
		return $sql->row_array();
	}
}
/* End of file Teamroster_model.php */
/* Location: ./application/models/Teamroster_model.php */