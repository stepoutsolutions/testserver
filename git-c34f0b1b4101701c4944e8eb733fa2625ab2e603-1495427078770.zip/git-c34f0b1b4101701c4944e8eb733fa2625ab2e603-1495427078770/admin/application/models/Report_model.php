<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Report_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}

	/**
	 * [get_all_user_report description]
	 * @MethodName get_all_user_report
	 * @Summary This function used get all user report by from to to date list
	 * @return     array
	 */
	public function get_all_user_report()
	{
		$sort_field	= 'first_name';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if(($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(($post_data['sort_field']) && in_array($post_data['sort_field'],array('user_name','first_name','email', 'balance', 'country_name','dob','name')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$from_date = $post_data['from_date'];
		$to_date = $post_data['to_date'];

		//echo 'okkkk';die;

		#Get User Withdral List
		/*$withdraw_by_user = "SELECT SUM(transaction_amount) FROM ".$this->db->dbprefix(PAYMENT_HISTORY_TRANSACTION)." WHERE user_id = U.user_id and payment_type = 
		'1' and DATE_FORMAT(created_date, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."'";*/
		
		$withdraw_by_user = "(SELECT (SUM(real_amount)+SUM(winning_amount)) AS withdraw_by_user,user_id FROM ".$this->db->dbprefix(ORDER)." WHERE source = ".ORDER_SOURCE_WITHDRAW." and status = 1 and DATE_FORMAT(date_added, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."' GROUP BY user_id) ";



		#Get User Deposit List
		// $deposit_by_user = "SELECT SUM(transaction_amount) FROM ".$this->db->dbprefix(PAYMENT_HISTORY_TRANSACTION)." WHERE user_id = U.user_id and payment_type = 
		// '2' and DATE_FORMAT(created_date, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."'";
		/*$deposit_by_user = "SELECT SUM(real_amount) FROM ".$this->db->dbprefix(ORDER)." WHERE user_id = U.user_id and source = ".ORDER_SOURCE_DEPOSIT." and status = 1 and DATE_FORMAT(date_added, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."'";*/
		$deposit_by_user = "( SELECT SUM(real_amount) AS deposit_by_user,user_id FROM ".$this->db->dbprefix(ORDER)." WHERE source = ".ORDER_SOURCE_DEPOSIT." and status = 1 and DATE_FORMAT(date_added, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."' GROUP BY user_id) ";

		#Get User Matches Played List
		$matches_played = "(SELECT COUNT(LM.contest_unique_id) AS matches_played,LM.user_id FROM ".$this->db->dbprefix(LINEUP_MASTER)." AS LM INNER JOIN ".$this->db->dbprefix(CONTEST)." G ON G.contest_unique_id = LM.contest_unique_id WHERE G.is_cancel = '0' and DATE_FORMAT(G.season_scheduled_date, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."' GROUP BY LM.user_id) ";

		#Get User Matches Won List
		//$matches_won = "(SELECT COUNT(LM.lineup_master_id) AS matches_won,LM.user_id FROM ".$this->db->dbprefix(LINEUP_MASTER)." AS LM INNER JOIN ".$this->db->dbprefix(CONTEST)." AS G ON G.contest_unique_id = LM.contest_unique_id WHERE G.is_cancel = '0' AND LM.is_winner = '1' AND DATE_FORMAT(O.date_added, '%Y-%m-%d') BETWEEN '$from_date' AND '$to_date' GROUP BY LM.user_id) ";

		#Get User Matches Lost List
		//$matches_lost = "(SELECT COUNT(LM.lineup_master_id) AS matches_lost,LM.user_id FROM ".$this->db->dbprefix(LINEUP_MASTER)." AS LM INNER JOIN ".$this->db->dbprefix(CONTEST)." AS G ON G.contest_unique_id = LM.contest_unique_id WHERE G.is_cancel = '0' AND LM.is_winner = '0' AND DATE_FORMAT(O.date_added, '%Y-%m-%d') BETWEEN '$from_date' AND '$to_date') ";

		#Get User Prize Amount Won List
		$prize_amount_won = "(SELECT SUM(winning_amount) AS prize_amount_won,O.user_id,COUNT(LM.lineup_master_id) AS matches_won FROM ".$this->db->dbprefix(ORDER)." AS O INNER JOIN ".$this->db->dbprefix(LINEUP_MASTER)." AS LM ON LM.lineup_master_id = O.lineup_master_id AND LM.contest_id = O.source_id WHERE LM.is_winner = '1' AND O.source = ".ORDER_SOURCE_GAME_WON." AND O.status = 1 AND  DATE_FORMAT(O.date_added, '%Y-%m-%d') BETWEEN '$from_date' AND '$to_date' GROUP BY O.user_id) ";

		#Get User Prize Amount Lost List
		$prize_amount_lost = "(SELECT SUM(winning_amount) AS prize_amount_lost,O.user_id,COUNT(LM.lineup_master_id) AS matches_lost FROM ".$this->db->dbprefix(ORDER)." AS O INNER JOIN ".$this->db->dbprefix(LINEUP_MASTER)." AS LM ON LM.lineup_master_id = O.lineup_master_id AND LM.contest_id = O.source_id WHERE LM.is_winner = '0' AND O.source = ".ORDER_SOURCE_JOIN_GAME." AND O.status = 1 AND  DATE_FORMAT(O.date_added, '%Y-%m-%d') BETWEEN '$from_date' AND '$to_date' GROUP BY O.user_id) ";

		$this->db->select("CONCAT(U.first_name, ' ', U.last_name) AS name, U.user_name, MC.country_name, U.email, DATE_FORMAT(U.dob, '%Y-%m-%d') AS dob, MS.name AS state_name,(U.balance+U.winning_balance+U.bonus_balance) AS balance,WBU.withdraw_by_user, DBU.deposit_by_user,MP.matches_played,PAW.matches_won,PAL.matches_lost,PAW.prize_amount_won,PAL.prize_amount_lost", FALSE)
				->from(USER." AS U")
				->join(MASTER_STATE." MS","MS.master_state_id = U.master_state_id", "left")
				->join(MASTER_COUNTRY." MC","MC.master_country_id = U.master_country_id", "left")
				->join(ORDER." O","O.user_id = U.user_id", "inner")
				->join($deposit_by_user." DBU","DBU.user_id = U.user_id", "left")
				->join($withdraw_by_user." WBU","WBU.user_id = U.user_id", "left")
				->join($matches_played." MP","MP.user_id = U.user_id", "left")
				//->join($matches_won." MW","MW.user_id = U.user_id", "left")
				//->join($matches_lost." ML","ML.user_id = U.user_id", "left")
				->join($prize_amount_won." PAW","PAW.user_id = U.user_id", "left")
				->join($prize_amount_lost." PAL","PAL.user_id = U.user_id", "left")
				->where("DATE_FORMAT(O.date_added, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."'")
				->group_by('U.user_id');
				//->having("deposit_by_user != '' OR withdraw_by_user != ''")

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
//echo $tempdb->last_query();die;
		if(!$post_data['csv'])
		{
			$result	= $sql->result_array();
			$result = ($result) ? $result : array();
			return array('result'=>$result,'total'=>$total);
		}
		else
		{			
			$this->load->dbutil();
			$this->load->helper('download');
			$data = $this->dbutil->csv_from_result($query);
			$data = "Created on " . format_date('today', 'Y-m-d') . "\n\n" . "From Date $from_date\nTo Date $to_date\n\n" . html_entity_decode($data);
			$name = 'file.csv';
			force_download($name, $data);
			return exit;
		}
	}

	/**
	 * [get_all_contest_report description]
	 * @MethodName get_all_contest_report
	 * @Summary This function used get all contest report by from to To date list
	 * @return     array
	 */
	public function get_all_contest_report()
	{
		$sort_field	= 'first_name';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if(($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(($post_data['sort_field']) && in_array($post_data['sort_field'],array('user_name', 'first_name', 'balance', 'country_name', 'name', 'league_abbr', 'entry_fee', 'size')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$from_date = $post_data['from_date'];
		$to_date = $post_data['to_date'];

		$this->db->select("CONCAT(U.first_name, ' ', U.last_name) AS name, U.user_name, MC.country_name, G.contest_unique_id, G.size, G.entry_fee, L.league_abbr, LSC.salary_cap, MNW.master_contest_type_desc AS prize_type,
					CASE
						WHEN G.is_cancel = '1' THEN 'Cancelled'
						WHEN G.prize_distributed = '1' THEN 'Completed'
						ELSE 'In Progress' 
						END AS game_status,
					CASE
						WHEN LM.is_winner = '0' THEN 'No'
						WHEN LM.is_winner = '1' THEN 'Yes'
						END AS won ,
			PC.promo_code, PCE.amount_received, (G.entry_fee - PCE.amount_received) AS promo_code_benefit", FALSE)
				->from(USER." AS U")
				->join(LINEUP_MASTER." LM", "LM.user_id = U.user_id", "inner")
				->join(MASTER_COUNTRY." MC","MC.master_country_id = U.master_country_id", "inner")
				->join(CONTEST." G", "G.contest_unique_id = LM.contest_unique_id", "inner")
				->join(LEAGUE_DURATION . " AS LD", 'LD.league_duration_id = G.league_duration_id', 'LEFT')
				->join(MASTER_DURATION . " AS MD", 'MD.duration_id = LD.duration_id', 'LEFT')
				->join(LEAGUE_SALARY_CAP . " AS LSC", 'LSC.league_salary_cap_id = G.league_salary_cap_id', 'LEFT')
				->join(LEAGUE_CONTEST_TYPE . " AS LNW", 'LNW.league_contest_type_id = G.league_contest_type_id', 'LEFT')
				->join(MASTER_CONTEST_TYPE . " AS MNW", 'MNW.master_contest_type_id = LNW.master_contest_type_id', 'LEFT')
				->join(LEAGUE . " AS L", 'L.league_id = G.league_id', 'LEFT')
				->join(PROMO_CODE . " AS PC", 'PC.promo_code_id = PCE.promo_code_id`', 'LEFT')
				->where("DATE_FORMAT(G.season_scheduled_date, '%Y-%m-%d') BETWEEN '".$from_date."' AND '".$to_date."'");

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
		if(!$post_data['csv'])
		{
			$result	= $sql->result_array();
			$result = ($result) ? $result : array();
			return array('result'=>$result,'total'=>$total);
		}
		else
		{			
			$this->load->dbutil();
			$this->load->helper('download');
			$data = $this->dbutil->csv_from_result($query);
			$data = "Created on " . format_date('today', 'Y-m-d') . "\n\n" . "From Date $from_date\nTo Date $to_date\n\n" . html_entity_decode($data);
			$name = 'file.csv';
			force_download($name, $data);
			return exit;
		}
	}


	/**
	 * [get_all_contest_users_report description]
	 * @MethodName get_all_contest_users_report
	 * @Summary This function used get all contest users report by from to to date list
	 * @return     array
	 */
	public function get_all_contest_users_report()
	{
		$sort_field	= 'first_name';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if(($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		$offset	= $limit * $page;
		$from_date = $post_data['from_date'];
		$to_date = $post_data['to_date'];

		#Get total contest created
		$total_contest_created = "SELECT COUNT(contest_id) FROM ".$this->db->dbprefix(CONTEST)." AS G1 WHERE DATE_FORMAT(G1.created_date, '%Y-%m-%d') BETWEEN 
		'".$from_date."' AND '".$to_date."' AND CASE
									WHEN contest_created_by = 'Admin' THEN G1.user_id = '0'
									WHEN contest_created_by = 'User' THEN G1.user_id != '0'
								END";

		#Get total contest completed
		$total_contest_completed = "SELECT COUNT(contest_id) FROM ".$this->db->dbprefix(CONTEST)." AS G2 WHERE  DATE_FORMAT(G2.created_date, '%Y-%m-%d') BETWEEN 
		'".$from_date."' AND '".$to_date."' AND
									CASE
										WHEN contest_created_by = 'Admin' THEN G2.prize_distributed = '1' AND G2.user_id = '0'
										WHEN contest_created_by = 'User' THEN G2.prize_distributed = '1' AND G2.user_id != '0'
									END";

		#Get total contest cancelled
		$total_contest_cancelled = "SELECT COUNT(contest_id) FROM ".$this->db->dbprefix(CONTEST)." AS G3 WHERE DATE_FORMAT(G3.created_date, '%Y-%m-%d') BETWEEN 
		'".$from_date."' AND '".$to_date."' AND
									CASE
										WHEN contest_created_by = 'Admin' THEN G3.is_cancel = '1' AND G3.user_id = '0'
										WHEN contest_created_by = 'User' THEN G3.is_cancel = '1' AND G3.user_id != '0'
									END";

		#Get total contest in progress
		$total_contest_in_progress = "SELECT COUNT(contest_id) FROM ".$this->db->dbprefix(CONTEST)." AS G4 WHERE DATE_FORMAT(G4.created_date, '%Y-%m-%d') BETWEEN 
		'".$from_date."' AND '".$to_date."' AND
									CASE
										WHEN contest_created_by = 'Admin' THEN G4.is_cancel = '0' AND G4.prize_distributed = '0' AND G4.user_id = '0'
										WHEN contest_created_by = 'User' THEN G4.is_cancel = '0' AND G4.prize_distributed = '0' AND G4.user_id != '0'
									END";
		
		$this->db->select("
						CASE
							WHEN G.user_id = '0' THEN 'Admin'
							WHEN G.user_id != '0' THEN 'User'
						END AS contest_created_by, ($total_contest_created) as total_contest_created, ($total_contest_completed) as total_contest_completed, ($total_contest_cancelled) as total_contest_cancelled, ($total_contest_in_progress) as total_contest_in_progress", FALSE)
				->from(CONTEST." AS G")
				->group_by('contest_created_by');

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->limit($limit,$offset)
					->get();
		if(!$post_data['csv'])
		{
			$result	= $sql->result_array();
			$result = ($result&&$to_date!=''&&$from_date!='') ? $result : array();
			return array('result'=>$result,'total'=>$total);
		}
		else
		{			
			$this->load->dbutil();
			$this->load->helper('download');
			$data = $this->dbutil->csv_from_result($query);
			$data = "Created on " . format_date('today', 'Y-m-d') . "\n\n" . "From Date $from_date\nTo Date $to_date\n\n" . html_entity_decode($data);
			$name = 'file.csv';
			force_download($name, $data);
			return exit;
		}
	}

	/**
	 * [get_all_userlocation description]
	 * @MethodName get_all_suserlocation
	 * @Summary This function used for get all user list location wise under reporting section 
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_all_userlocation($count_only=FALSE)
	{
		$sort_field	= 'added_date';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if($post_data['items_perpage'])
		{
			$limit = $post_data['items_perpage'];
		}

		if($post_data['current_page'])
		{
			$page = $post_data['current_page']-1;
		}

		if($post_data['sort_field'] && in_array($post_data['sort_field'],array('added_date','first_name','user_name','email','country','state','city','balance','status','last_login')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if($post_data['sort_order'] && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$sql = $this->db->select("U.user_unique_id, U.user_id, CONCAT_WS(' ',U.first_name,U.last_name) AS name,U.image,MC.country_name,MS.name AS state_name,U.balance,U.email,U.status,U.city,DATE_FORMAT(U.added_date,'%d-%b-%Y') AS member_since,U.user_name,DATE_FORMAT(U.last_login, '%d-%b-%Y %H:%i') as last_login",FALSE)
						->from(USER.' AS U')
						->join(MASTER_COUNTRY." AS MC","MC.master_country_id=  U.master_country_id","left")
						->join(MASTER_STATE." AS MS","MS.master_state_id=  U.master_state_id","left")
						->order_by($sort_field, $sort_order);
		if(isset($post_data['country']) && $post_data['country']!="")
		{
			$this->db->where("U.master_country_id",$post_data['country']);
		}
		if(isset($post_data['state']) && $post_data['state'] != '')
		{
			$this->db->where("U.master_state_id",$post_data['state']);
		}

		if(isset($post_data['keyword']) && $post_data['keyword'] != "")
		{
			$this->db->like('city',$post_data['keyword']);
		}
		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();

		$records	= array();
		foreach($result as $rs)
		{
			if($rs['image'] == "")
			{
				$rs['image'] = base_url()."assets/images/default_user.png";
			}
			$records[] = $rs;
		}
		
		$result=($records)?$records:array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [get_all_userlocation description]
	 * @MethodName get_all_suserlocation
	 * @Summary This function used for get all user list location wise under reporting section 
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_all_useractivity($count_only=FALSE)
	{
		$sort_field	= 'last_login';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if($post_data['items_perpage'])
		{
			$limit = $post_data['items_perpage'];
		}

		if($post_data['current_page'])
		{
			$page = $post_data['current_page']-1;
		}

		if($post_data['sort_field'] && in_array($post_data['sort_field'],array('added_date','first_name','user_name','email','country','login_date_time','login_count','balance','status')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if($post_data['sort_order'] && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$sql = $this->db->select("U.user_unique_id, U.user_id, CONCAT_WS(' ',U.first_name,U.last_name) AS name,U.image,MC.country_name,U.balance,U.email,U.status,DATE_FORMAT(U.added_date,'%d-%b-%Y') AS member_since,U.user_name,DATE_FORMAT(U.last_login, '%d-%b-%Y %H:%i') as last_login,COUNT(AU.analytics_user_login_id) AS login_count",FALSE)
						->from(USER.' AS U')
						->join(MASTER_COUNTRY." AS MC","MC.master_country_id=  U.master_country_id","left")
						->join(ANALYTICS_USER_LOGIN." AS AU","AU.user_id=  U.user_id","left")
						->group_by('U.user_id')
						->order_by($sort_field, $sort_order);
		

		if(isset($post_data['activity_duration']) && $post_data['activity_duration']!="")
		{
			
			//if today
			if($post_data['activity_duration'] == 1){
				$today = date('Y-m-d');
				//$today = format_date('today','Y-m-d');
				$this->db->where("DATE_FORMAT(last_login, ('%Y-%m-%d')) = '$today'", NULL, FALSE);
			}

			//if this month
			if($post_data['activity_duration'] == 2){
				$year = date('Y');
				$month = date('m');
				$this->db->where("YEAR(last_login) = '$year' AND MONTH(last_login) = '$month'");
			}

			//if this year
			if($post_data['activity_duration'] == 3){
				$year = date('Y');
				$this->db->where("YEAR(last_login) = '$year'");
			}


			$fromdate	= isset($post_data['fromdate']) ? $post_data['fromdate'] : "";
			$todate		= isset($post_data['todate']) ? $post_data['todate'] : "";
			//if custom date range
			if($post_data['activity_duration'] == 4 && $fromdate != '' && $todate != ''){
				
				$this->db->where("DATE_FORMAT(last_login,'%Y-%m-%d') >= '".$fromdate."' and DATE_FORMAT(last_login,'%Y-%m-%d') <= '".$todate."'");
			}


		}

		
		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();
		//echo $this->db->last_query();exit;

		$records	= array();
		foreach($result as $rs)
		{
			if($rs['image'] == "")
			{
				$rs['image'] = base_url()."assets/images/default_user.png";
			}
			$records[] = $rs;
		}
		
		$result=($records)?$records:array();
		return array('result'=>$result,'total'=>$total);
	}


	/**
	 * [get_report_money_paid_by_user description]
	 * @MethodName get_report_money_paid_by_user
	 * @Summary This function used for get all money paid by users
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_report_money_paid_by_user($count_only=FALSE)
	{
		$sort_field	= 'U.added_date';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if($post_data['items_perpage'])
		{
			$limit = $post_data['items_perpage'];
		}

		if($post_data['current_page'])
		{
			$page = $post_data['current_page']-1;
		}

		if($post_data['sort_field'] && in_array($post_data['sort_field'],array('added_date','first_name','user_name','email','country','login_date_time','login_count','balance','status')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if($post_data['sort_order'] && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$sql = $this->db->select("U.user_unique_id, U.user_id,U.user_name, CONCAT_WS(' ',U.first_name,U.last_name) AS name,U.image, (U.balance+U.winning_balance+U.bonus_balance) as balance,U.email,U.status,DATE_FORMAT(U.added_date,'%d-%b-%Y') AS member_since,SUM(O.real_amount+O.winning_amount+O.bonus_amount) AS money_paid",FALSE)
						->from(USER.' AS U')
						->join(ORDER." AS O","O.user_id =  U.user_id and O.source =".ORDER_SOURCE_JOIN_GAME." and O.type=1","INNER")
						->join(CONTEST." AS C","C.contest_id =  O.source_id and C.prize_distributed='1'","INNER")
						->group_by('U.user_id')
						->order_by($sort_field, $sort_order);

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();
		//echo $this->db->last_query();exit;

		$records	= array();
		foreach($result as $rs)
		{
			if($rs['image'] == "")
			{
				$rs['image'] = base_url()."assets/images/default_user.png";
			}
			$records[] = $rs;
		}
		
		$result=($records)?$records:array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [get_report_user_deposit_amount description]
	 * @MethodName get_report_user_deposit_amount
	 * @Summary This function used for get all deposited by user and which payment method
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_report_user_deposit_amount($count_only=FALSE)
	{
		$sort_field	= 'U.added_date';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if($post_data['items_perpage'])
		{
			$limit = $post_data['items_perpage'];
		}

		if($post_data['current_page'])
		{
			$page = $post_data['current_page']-1;
		}

		if($post_data['sort_field'] && in_array($post_data['sort_field'],array('added_date','first_name','user_name','email','country','login_date_time','login_count','balance','status','real_amount')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if($post_data['sort_order'] && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$sql = $this->db->select("O.real_amount,U.user_unique_id,U.user_id,U.user_name,CONCAT_WS(' ',U.first_name,U.last_name) AS name,U.image,U.email,U.status,DATE_FORMAT(U.added_date,'%d-%b-%Y') AS member_since",FALSE)
						->from(ORDER." AS O")
						->join(USER.' AS U',"U.user_id = O.user_id","INNER")
						->where("O.source",ORDER_SOURCE_DEPOSIT)
						->where("O.type",0)//0=credit,1=debit
						->where("O.status",1)//success
						->group_by("O.order_id")
						->order_by($sort_field, $sort_order);

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();
		$detail_rs = $query->result_array();
		$sql = $tempdb->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();
		//echo $this->db->last_query();exit;
		$total_deposit = 0;
		$total_deposit = array_sum(array_column($detail_rs, 'real_amount'));
		$records	= array();
		foreach($result as $rs)
		{
			if($rs['image'] == "")
			{
				$rs['image'] = base_url()."assets/images/default_user.png";
			}
			$records[] = $rs;
		}
		
		$result=($records)?$records:array();
		return array('result'=>$result,'total'=>$total,'total_deposit'=>$total_deposit);
	}

}
/* End of file Transaction_model.php */
/* Location: ./application/models/Transaction_model.php */