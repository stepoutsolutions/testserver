<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Promocode_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}	

	/**
	 * [get_sales_person description]
	 * @MethodName get_sales_person
	 * @Summary This function used for get all sales person list
	 * @return     [type]
	 */
	public function get_sales_person()
	{
		$sort_field	= 'first_name';
		$sort_order	= 'ASC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('first_name', 'last_name', 'email', 'dob', 'added_date', 'status')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$this->db->select("COALESCE(SUM(PCE.amount_received),0) as amount_received, sales_person_unique_id, first_name, last_name, email, DATE_FORMAT(dob,'%d-%b-%Y') as dob, DATE_FORMAT(SP.added_date,'%d-%b-%Y %H:%i') as added_date, SP.status")
				->from(SALES_PERSON." AS SP")
				->join(PROMO_CODE." AS PC", "PC.sales_person_id = SP.sales_person_id", "left")
				->join(PROMO_CODE_EARNING." AS PCE", "PCE.promo_code_id = PC.promo_code_id", "left");

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->group_by("SP.sales_person_id")
						->limit($limit,$offset)
						->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [new_sales_person description]
	 * @MethodName new_sales_person
	 * @Summary This function used to create new sales person
	 * @param      [array]  [data_array]
	 * @return     [boolean]
	 */
	public function new_sales_person($data_array)
	{		
		$this->db->insert(SALES_PERSON,$data_array);
		return $this->db->insert_id();
	}

	/**
	 * [get_sales_person description]
	 * @MethodName get_sales_person
	 * @Summary This function used for get all sales person list
	 * @return     [type]
	 */
	/*CASE 
  					WHEN PC.type = 1 THEN U.email
 					WHEN PC.type = 0 THEN SP.email
 					END AS sales_person_email,*/
	public function get_promo_codes()
	{
		$sort_field	= 'expiry_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('discount', 'benefit_cap', 'sales_person_commission', 'start_date', 'expiry_date', 'type', 'status')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("PC.*, DATE_FORMAT(PC.start_date,'%d-%b-%Y') as start_date, DATE_FORMAT(PC.expiry_date,'%d-%b-%Y') as expiry_date,
 							CONCAT_WS(' ',SP.first_name,SP.last_name) as sales_person_name, COALESCE(SUM(PCE.amount_received),0) as amount_received",FALSE)
				->from(PROMO_CODE." AS PC")
				->join(SALES_PERSON." AS SP","SP.sales_person_id = PC.sales_person_id","inner")
				->join(PROMO_CODE_EARNING." PCE", "PCE.promo_code_id = PC.promo_code_id", "left");

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
					  ->group_by("PC.promo_code_id")
					  ->limit($limit,$offset)
					  ->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [new_promo_code description]
	 * @MethodName new_promo_code
	 * @Summary This function used to create new promo code
	 * @param      [array]  [data_array]
	 * @return     [boolean]
	 */
	public function new_promo_code($data_array)
	{
		$this->db->insert(PROMO_CODE,$data_array);
		return $this->db->insert_id();
	}

	/**
	 * [get_all_user_by_key description]
	 * @MethodName get_all_user_by_key
	 * @Summary This function used to get all user match by search key
	 * @param      varchar  search key
	 * @return     array
	 */
	public function get_all_user_by_key($search_key)
	{
		$sql = $this->db->select("user_id,CONCAT_WS(' ',first_name,last_name) as full_name")
						->from(USER)
						->like("CONCAT(first_name, last_name)", $search_key)
						->limit(20)
						->get();
		$result = $sql->result_array();
		$data_arr = array();
		foreach ($result as $rs) 
		{
			$data_arr[] = array(
				"id"	=> $rs['user_id'],
				"text"	=> $rs['full_name']
				);
		}
		return $data_arr;
	}


	/**
	 * [get_all_sales_person description]
	 * @MethodName get_all_sales_person
	 * @Summary This function used to get all sales person by key
	 * @param      varchar  search key
	 * @return     array
	 */
	public function get_all_sales_person($search_key)
	{
		$sql = $this->db->select("sales_person_id,CONCAT_WS(' ',first_name,last_name) as full_name")
						->from(SALES_PERSON)
						->like("CONCAT(first_name, last_name)", $search_key)
						->limit(20)
						->get();
		$result = $sql->result_array();
		$data_arr = array();
		foreach ($result as $rs) 
		{
			$data_arr[] = array(
					"id"	=> $rs['sales_person_id'],
					"text"	=> $rs['full_name']
				);
		}
		return $data_arr;
	}

	/**
	 * [get_commission_payout description]
	 * @MethodName get_commission_payout
	 * @Summary This functin used get all calculated commission payout detail
	 * @param      string  [description]
	 * @return     [array]
	 */
	public function get_commission_payout()
	{

		$sort_field	= 'PCE.added_date';
		$sort_order	= 'ASC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('first_name', 'email', 'promo_code','added_date')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("
					PCE.promo_code_earning_id,PCE.is_processed,DATE_FORMAT(PCE.added_date,'%M,%Y') as date,SUM( PCE.amount_received ) AS amount_received,PC.promo_code,PC.sales_person_commission,
						TRUNCATE((sum(PC.sales_person_commission)*PCE.amount_received)/100,2) as commission_payout,PC.promo_code_id,
						CONCAT(PSP.first_name,' ',PSP.last_name) AS sales_person_name, PSP.email AS sales_person_email
	 					",FALSE)
 					->from(PROMO_CODE_EARNING." AS PCE")
 					->join(PROMO_CODE." AS PC", "PCE.promo_code_id=PC.promo_code_id", "inner")
 					->join(CONTEST." AS G", "G.contest_unique_id = PCE.contest_unique_id", "inner")
 					->join(SALES_PERSON." AS PSP", "PSP.sales_person_id = PC.sales_person_id", "left");

 		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->group_by('PCE.promo_code_id')
						->limit($limit,$offset)
						->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [get_promo_code_detail description]
	 * @MethodName get_promo_code_detail
	 * @Summary This function used for get all promo code by promocode
	 * @return     [array]
	 */
	public function get_promo_code_detail()
	{
		$sort_field	= 'PCE.added_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('first_name', 'promo_code', 'entry_fee', 'size', 'added_date', 'season_scheduled_date', 'amount_received', 'game_name')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("CONCAT_WS(' ',U.first_name,U.last_name) as full_name, PC.promo_code, G.contest_name, G.entry_fee, G.size, G.total_user_joined,
						DATE_FORMAT(G.season_scheduled_date,'%d-%b-%Y %H:%i') as season_scheduled_date, G.status, DATE_FORMAT(PCE.added_date,'%d-%b-%Y') as added_date, 
						PCE.amount_received")
				->from(PROMO_CODE." PC")
				->join(PROMO_CODE_EARNING." AS PCE", "PCE.promo_code_id = PC.promo_code_id","inner")
				->join(SALES_PERSON." AS SP", "SP.sales_person_id = PC.sales_person_id", "inner")
				->join(CONTEST." AS G", "G.contest_unique_id = PCE.contest_unique_id","inner")
				->join(USER." AS U", "U.user_id = PCE.user_id","inner")
				->where('promo_code', $post_data['promo_code']);

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();

		$result	= $sql->result_array();
		$sql = $this->db->select("CONCAT_WS(' ',first_name,last_name) as sales_person_name, email")
						->from(SALES_PERSON." AS SP")
						->join(PROMO_CODE." AS PC", "PC.sales_person_id = SP.sales_person_id", "inner")
						->where("PC.promo_code", $post_data['promo_code'])
						->get();
		$sales_person_detail = $sql->row_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result, 'total'=>$total, 'sales_person_detail'=>$sales_person_detail);
	}

	/**
	 * [get_sales_person_detail description]
	 * @MethodName get_sales_person_detail
	 * @Summary This function used to get sales person detail by sales person id
	 * @param      [varchar]  [saler person id]
	 * @return     [type]
	 */
	public function get_sales_person_detail($sales_person_id)
	{
		$sql = $this->db->select("sales_person_unique_id, first_name, last_name, email, dob, paypal_id, address, 
								IF(master_country_id = 0, '', master_country_id) as master_country_id,	
								IF(master_state_id = 0, '', master_state_id) as master_state_id,							
								, city, IF(zip_code=0, '', zip_code) as zip_code, status, added_date",FALSE)
						->from(SALES_PERSON)
						->where("sales_person_unique_id", $sales_person_id)
						->get();
		return $sql->row_array();
	}

	/**
	 * [update_sales_person_detail description]
	 * @MethodName update_sales_person_detail
	 * @Summary This function used to update sales person detail
	 * @param      [array]  $data_array
	 * @return     [int]
	 */
	public function update_sales_person_detail($data_array)
	{
		$this->db->where("sales_person_unique_id",$data_array['sales_person_unique_id'])
				->update(SALES_PERSON,$data_array);
		return $this->db->affected_rows();
	}

	/**
	 * [get_sales_person_payout description]
	 * @MethodName get_sales_person_payout
	 * @Summary This functin used get all calculated sales person payout detail
	 * @param      string  [description]
	 * @return     [array]
	 */
	public function get_sales_person_payout()
	{
		$sort_field	= 'PCE.added_date';
		$sort_order	= 'ASC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('first_name', 'email', 'promo_code','added_date')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("
						PSP.sales_person_id, PCE.promo_code_earning_id,PCE.is_processed,DATE_FORMAT(PCE.added_date,'%M,%Y') as date,SUM( PCE.amount_received ) AS amount_received,PC.promo_code,PC.sales_person_commission,
						TRUNCATE((sum(PC.sales_person_commission)*PCE.amount_received)/100,2) as commission_payout,PC.promo_code_id, PC.discount, PC.benefit_cap, PC.sales_person_commission,
						CONCAT(PSP.first_name,' ',PSP.last_name) AS sales_person_name, PSP.email AS sales_person_email, DATE_FORMAT(PC.start_date,'%d-%b-%Y') as start_date, DATE_FORMAT(PC.expiry_date,'%d-%b-%Y') as expiry_date
	 					",FALSE)
 					->from(PROMO_CODE_EARNING." AS PCE")
 					->join(PROMO_CODE." AS PC", "PCE.promo_code_id=PC.promo_code_id", "inner")
 					->join(CONTEST." AS G", "G.contest_unique_id = PCE.contest_unique_id", "inner")
 					->join(SALES_PERSON." AS PSP", "PSP.sales_person_id = PC.sales_person_id", "left")
 					->where("PSP.sales_person_unique_id" , $post_data['sales_person_unique_id']);

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->group_by('PCE.promo_code_id')
						->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		$sales_person_detail = array();
		$sql = $this->db->select("sales_person_id,CONCAT_WS(' ',first_name,last_name) as sales_person_name, email")
						->from(SALES_PERSON)
						->where("sales_person_unique_id", $post_data['sales_person_unique_id'])
						->get();
		$sales_person_detail = $sql->row_array();

		return array('result'=>$result, 'total'=>$total, 'sales_person_detail'=>$sales_person_detail);
	}

	/**
	 * [check_sales_person_email description]
	 * @MethodName  check_sales_person_email
	 * @Summary This function used to checking sales person email duplication 
	 * @param      [varchar]  [email address]
	 * @param      varchar  [sales person id]
	 * @return     [int]
	 */
	public function check_sales_person_email($eamil,$sales_person_id = "")
	{
		$this->db->select("email")
				->from(SALES_PERSON)
				->where("email", $eamil);
		if($sales_person_id!="")
		{
			$this->db->where("sales_person_unique_id !=", $sales_person_id);
		}

		$sql = $this->db->get();

		return $sql->num_rows();
	}

	/**
	 * [get_sales_person_earning description]
	 * @MethodName get_sales_person_earning
	 * @Summary This function used to get all earning on sales person
	 * @param      [int]  [sales_person_id]
	 * @return     [array]
	 */
	public function get_sales_person_earning($sales_person_id)
	{
		$sql = $this->db->select("sum(amount_received) as total_earning")
						->from(PROMO_CODE." AS PC")
						->join(PROMO_CODE_EARNING." AS PCE", "PCE.promo_code_id = PC.promo_code_id", "inner")
						->where("PC.sales_person_id", $sales_person_id)
						->get();
		$total_amout_arr = $sql->row_array();
		
		$total_earning = isset($total_amout_arr['total_earning']) ? $total_amout_arr['total_earning'] : 0;

 		$sql1 = $this->db->select("sum(amount_paid) as amount_paid")
						->from(PROMO_CODE_PAID_EARNING)
						->where("sales_person_id", $sales_person_id)
						->get();
		$result = $sql1->row_array();
		$amount = isset($result['amount_paid']) ? $result['amount_paid'] : 0;
		$unpaid_amount = $total_earning - $amount;
		return array("total_earning"=>$total_earning, "unpaid_amount"=>$unpaid_amount);
	}

	/**
	 * [update_sales_person_earning description]
	 * @MethodName update_sales_person_earning
	 * @Summary This function used to add sales person paid earning
	 * @param      [array]  [data_array]
	 * @return     [int]
	 */
	public function update_sales_person_earning($data_array)
	{
		$this->db->insert(PROMO_CODE_PAID_EARNING,$data_array);
		return $this->db->affected_rows();
	}

	/**
	 * [get_sales_person_earning_history description]
	 * @MethodName get_sales_person_earning_history
	 * @Summary This functin used get all sales person paid earning detail
	 * @return     [array]
	 */
	public function get_sales_person_earning_history()
	{
		$sort_field	= 'added_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('amount_paid', 'comment','added_date')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("amount_paid, comment,DATE_FORMAT(added_date,'%d-%b-%Y %H:%i') as added_date")
 					->from(PROMO_CODE_PAID_EARNING)
 					->where("sales_person_id" , $post_data['sales_person_id']);

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();

		return array('result'=>$result, 'total'=>$total);
	}
}
/* End of file Promocode_model.php */
/* Location: ./application/models/Promocode_model.php */