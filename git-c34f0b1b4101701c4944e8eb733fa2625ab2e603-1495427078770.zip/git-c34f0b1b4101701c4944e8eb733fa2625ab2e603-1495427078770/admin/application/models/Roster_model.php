<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Roster_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}	

	/**
	 * [get_all_site_user_detail description]
	 * @MethodName get_all_site_user_detail
	 * @Summary This function used for get all user list and return filter user list
	 * @return     [type]
	 */
	public function get_all_rosters()
	{
		$sort_field	= 'full_name';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;
		$post_data	= $this->input->post();
		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('full_name','team_name','position','salary','player_status','nick_name')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset				= $limit * $page;
		$position			= isset($post_data['position']) ? $post_data['position'] : "";
		$team_league_id		= isset($post_data['team_league_id']) ? $post_data['team_league_id'] : "";
		$league_id			= isset($post_data['league_id']) ? $post_data['league_id'] : "";
		$player_name		= isset($post_data['player_name']) ? $post_data['player_name'] : "";
        $roster_category 	= isset($post_data['category_id']) ? $post_data['category_id'] : "";

		$this->db->select('P.player_id,P.player_uid,T.team_name,T.team_abbr as team_abbreviation,P.injury_status, IFNULL(P.injury_status,"") as injury,P.full_name,P.first_name,P.last_name,PT.position,IFNULL(PT.salary,0) as salary,IFNULL(PT.player_status,0) as player_status,IFNULL(P.nick_name,"") as nick_name,PT.player_team_id, TL.team_league_id', FALSE)
		->from(PLAYER_TEAM . " AS PT")
		->join(PLAYER.' P','P.player_id = PT.player_id','INNER')
        ->join(TEAM_LEAGUE.' TL', 'TL.team_league_id = PT.team_league_id', 'INNER')	
        ->join(TEAM.' T', 'T.team_id = TL.team_id', 'INNER')	
        ->where("PT.is_deleted",0);
        
		if ($position != '' && $position != 'all') 
		{
			$this->db->where('PT.position', $position);
		}

		if ($team_league_id != '' && $team_league_id != 'all') 
		{
			$this->db->where('PT.team_league_id', $team_league_id);
		}

		if ($league_id != '') 
		{
			$this->db->where('TL.league_id', $league_id);
		}

		if ($player_name != '') 
		{
			$this->db->like('P.full_name', $player_name, 'both');
		}
       
       /* if ($roster_category != '' && $roster_category != 'all') {
               $this->db->where('RC.category_id', $roster_category);
        }*/

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [release_player description]
	 * @MethodName release_player
	 * @Summary This function used for relase player salary
	 * @param      int  [league_id]
	 * @return     [boolean]
	 */
	public function release_player($league_id)
	{
		$sql = $this->db->select('PT.player_team_id,PT.salary')
		->from(PLAYER_TEAM . " AS PT")
		->join(TEAM_LEAGUE.' TL', 'TL.team_league_id = PT.team_league_id', 'INNER')	
        ->where("PT.player_status",1)
        ->where("TL.league_id",$league_id)
        ->get();
        
        $player_temp_data = $sql->result_array();
		 
		if ( !empty( $player_temp_data ) )
		{
			$config['league_id']  = $league_id;
			$config['date_added'] = format_date();
			$config['updated_by'] = 1;

			$this->db->insert(PLAYER_SALARY_MASTER,$config);

			$player_salary_master_id = $this->db->insert_id();

			foreach ( $player_temp_data as $key => $temp )
			{
				$player_temp_data[ $key ][ 'player_salary_master_id' ] = $player_salary_master_id;
			}
	 
			$this->db->insert_batch(PLAYER_SALARY_TRANSACTION, $player_temp_data);
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}

	/**
	 * [update_roster_batch description]
	 * @MethodName update_roster_batch
	 * @Summary This function used update multiple player salary and status
	 * @param      [array]  [data_arr]
	 * @return     [boolean]
	 */
	public function update_roster_batch($data_arr)
	{
		if(empty($data_arr))
		{
			return FALSE;
		}

		$this->db->update_batch(PLAYER_TEAM, $data_arr, 'player_team_id');
		return $this->db->affected_rows();
	}

	/**
	 * [update_roster_injury description]
	 * @MethodName update_roster_injurys
	 * @Summary This function used to update injury status of multiple player
	 * @param      [array]  [data_arr]
	 * @return     [boolean]
	 */
	public function update_roster_injury($data_arr)
	{
		if(empty($data_arr))
		{
			return FALSE;
		}

		$this->db->update_batch(PLAYER,$data_arr,'player_id');
		return $this->db->affected_rows();
	}



	public function get_player_ids($players)
	{
		
		if(empty($players))
		{
			return FALSE;
		}

		$sql = $this->db->select('player_id,player_team_id')
						->from(PLAYER_TEAM)
						->where_in('player_team_id',$players)
						->get();

		$result = $sql->result_array();
		return ($result) ? $result : array();
	}


	/**
	 * [update_roster description]
	 * @MethodName update_roster
	 * @Summary This function used update multiple player salary and status
	 * @param      [int]  [league_id]
	 * @param      [array]  [data_arr]
	 * @return     [boolean]
	 */
	public function update_roster($league_id,$data_arr)
	{
		$this->db->where("league_id",$league_id);
		$this->db->update_batch(PLAYER, $data_arr, 'player_unique_id');

		return $this->db->affected_rows();
	}

	/**
	 * [change_player_status description]
	 * @MethodName change_player_status
	 * @Summary This function used to player status
	 * @param      [varchar]  [player_team_id]
	 * @param      [int]  [player_status]
	 * @return     [boolean]
	 */
	public function change_player_status($player_team_id,$player_status)
	{
		$this->db->where("player_team_id",$player_team_id);
		$this->db->update(PLAYER_TEAM,array('player_status'=>$player_status));

		return $this->db->affected_rows();
	}

	/**
	 * [export_roster_csv description]
	 * @MethodName export_roster_csv
	 * @Summary This function used generat selected league all player roter in csv from
	 * @param      [int]  [league id]
	 * @return     [csv]
	 */
	public function export_roster_csv($league_id)
	{
		$sql =  $this->db->select("league_abbr")->from(LEAGUE)->where("league_id", $league_id)->get();
		$league_detail = $sql->row_array();
		

		$sql = $this->db->select('PT.player_team_id as PlayerUniqueID,PT.position as Position,P.full_name as PlayerName')
						->select("IF(P.nick_name!='',P.nick_name,CONCAT(P.first_name,' ',P.last_name)) as NickName,T.team_name as PlayerTeam,PT.salary as Salary,'".$league_detail['league_abbr']."' as LeagueName,'".$league_id."' as LeagueID",FALSE)			
						->from(PLAYER_TEAM . " AS PT")
						->join(PLAYER.' P', 'P.player_id = PT.player_id', 'INNER')	
						->join(TEAM_LEAGUE.' TL', 'TL.team_league_id = PT.team_league_id', 'INNER')	
						->join(TEAM.' T', 'T.team_id = TL.team_id', 'INNER')
				        ->where("PT.is_deleted",0)
				        ->where("TL.league_id",$league_id)
				        ->order_by('P.full_name', 'ASC')
				        ->get();

		$this->load->dbutil();
		$this->load->helper('download');
		$query = $sql;
		$data = $this->dbutil->csv_from_result($query);
		$data = html_entity_decode($data);
		$name = str_replace(' ', '_', $league_detail['league_abbr']).'rosters.csv';
		force_download($name, $data);
		
	}

	/**
	 * [export_roster_xlsx description]
	 * @MethodName export_roster_xlsx
	 * @Summary This function used generat selected league all player roter in xlsx from
	 * @param      [int]  [league id]
	 * @return     [xlsx]
	 */
	public function export_roster_xlsx($league_id)
	{
		$sql =  $this->db->select("league_abbr")->from(LEAGUE)->where("league_id", $league_id)->get();
		$league_detail = $sql->row_array();
		

		$sql = $this->db->select('PT.player_team_id as PlayerUniqueID,PT.position as Position,P.full_name as PlayerName')
						->select("IF(P.nick_name!='',P.nick_name,CONCAT(P.first_name,' ',P.last_name)) as NickName,T.team_name as PlayerTeam,PT.salary as Salary,'".$league_detail['league_abbr']."' as LeagueName,'".$league_id."' as LeagueID",FALSE)			
						->from(PLAYER_TEAM . " AS PT")
						->join(PLAYER.' P', 'P.player_id = PT.player_id', 'INNER')	
						->join(TEAM_LEAGUE.' TL', 'TL.team_league_id = PT.team_league_id', 'INNER')	
						->join(TEAM.' T', 'T.team_id = TL.team_id', 'INNER')
				        ->where("PT.is_deleted",0)
				        ->where("TL.league_id",$league_id)
				        ->order_by('P.full_name', 'ASC')
				        ->get();
				        
		$results = $sql->result_array();

		$this->load->library('PHPExcel');
		$obj_excel = new PHPExcel(); 

		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'.str_replace(' ', '_', $league_detail['league_abbr']).'rosters.xlsx"');
		header('Cache-Control: max-age=0');

		// writer already created the first sheet for us, let's get it
		$obj_sheet = $obj_excel->getActiveSheet();

		$obj_sheet->setTitle($league_detail['league_abbr']);
		$obj_sheet->getStyle('A1:AD1')->getFont()->setBold(true)->setSize(10);

		$obj_sheet->getCell('A1')->setValue('Player Unique ID');
		$obj_sheet->getCell('B1')->setValue('Position');
		$obj_sheet->getCell('C1')->setValue('Player Name');
		$obj_sheet->getCell('D1')->setValue('Nick Name');
		$obj_sheet->getCell('E1')->setValue('Player Team');
		$obj_sheet->getCell('F1')->setValue('Salary');
		$obj_sheet->getCell('G1')->setValue('League Name');
		$obj_sheet->getCell('H1')->setValue('League ID');
		
		$i = 2;
		foreach ($results as $key => $value) 
		{
			$obj_sheet->getCell('A'.$i)->setValue($value['PlayerUniqueID']);
			$obj_sheet->getCell('B'.$i)->setValue($value['Position']);
			$obj_sheet->getCell('C'.$i)->setValue($value['PlayerName']);
			$obj_sheet->getCell('D'.$i)->setValue($value['NickName']);
			$obj_sheet->getCell('E'.$i)->setValue($value['PlayerTeam']);
			$obj_sheet->getCell('F'.$i)->setValue($value['Salary']);
			$obj_sheet->getCell('G'.$i)->setValue($value['LeagueName']);
			$obj_sheet->getCell('H'.$i)->setValue($value['LeagueID']);
			$i++;
		}

		$obj_writer = PHPExcel_IOFactory::createWriter($obj_excel, 'Excel2007');
		$obj_writer->save('php://output');
	}

	public function import_roster($roster_array)
	{		
		if(empty($roster_array))
		{
			return TRUE;
		}	

		$this->db->update_batch(PLAYER_TEAM,$roster_array,'player_team_id');
		return TRUE;
	}
}
/* End of file Roster_model.php */
/* Location: ./application/models/Roster_model.php */