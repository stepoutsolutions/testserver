<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Bonuscode_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}

	/**
	 * [get_bonus_codes description]
	 * @MethodName get_bonus_codes
	 * @Summary This function used for get all bonus person list
	 * @return     [type]
	 */
	public function get_bonus_codes()
	{
		$sort_field	= 'expiry_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('bonus_name', 'cycle', 'discount', 'start_date', 'expiry_date', 'status')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("BC.*, DATE_FORMAT(BC.start_date,'%d-%b-%Y') as start_date, DATE_FORMAT(BC.expiry_date,'%d-%b-%Y') as expiry_date", FALSE)
				->from(BONUS_CODE." AS BC");

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
					  ->group_by("BC.bonus_code_id")
					  ->limit($limit,$offset)
					  ->get();

		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [new_promo_code description]
	 * @MethodName new_promo_code
	 * @Summary This function used to create new promo code
	 * @param      [array]  [data_array]
	 * @return     [boolean]
	 */
	public function new_promo_code($data_array)
	{
		$this->db->insert(BONUS_CODE,$data_array);
		return $this->db->insert_id();
	}

	/**
	 * [get_all_user_by_key description]
	 * @MethodName get_all_user_by_key
	 * @Summary This function used to get all user match by search key
	 * @param      varchar  search key
	 * @return     array
	 */
	public function get_all_user_by_key($search_key)
	{
		$sql = $this->db->select("user_id,CONCAT_WS(' ',first_name,last_name) as full_name")
						->from(USER)
						->like("CONCAT(first_name, last_name)", $search_key)
						->limit(20)
						->get();
		$result = $sql->result_array();
		$data_arr = array();
		foreach ($result as $rs) 
		{
			$data_arr[] = array(
				"id"	=> $rs['user_id'],
				"text"	=> $rs['full_name']
				);
		}
		return $data_arr;
	}

	/**
	 * [get_promo_code_detail description]
	 * @MethodName get_promo_code_detail
	 * @Summary This function used for get all promo code by promocode
	 * @return     [array]
	 */
	public function get_bonus_code_detail()
	{
		$sort_field	= 'BCE.added_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;

		$post_data	= $this->input->post();

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('first_name', 'bonus_code', 'added_date', 'payment_request', 'bonus_amount')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("CONCAT_WS(' ',U.first_name,U.last_name) as full_name, BC.bonus_code,DATE_FORMAT(BCE.added_date,'%d-%b-%Y') as added_date,O.real_amount as payment_request,BCE.bonus_amount")
				->from(BONUS_CODE_EARNING." BCE")
				->join(BONUS_CODE." AS BC", "BC.bonus_code_id = BCE.bonus_code_id","INNER")
				->join(USER." AS U", "U.user_id = BCE.user_id","INNER")
				//->join(TRANSACTION." AS T", "T.bonus_code_id = BCE.bonus_code_id","INNER")
				->join(ORDER." AS O", "O.order_id = BCE.order_id AND O.source = ".ORDER_SOURCE_DEPOSIT,"INNER")
				->where('BC.bonus_code', $post_data['bonus_code'])
				->where('BCE.amount_type', BONUS_AMOUNT_TYPE_CASH)
				//->where('T.transaction_status',1)
				->where('O.status',1)
				->group_by('BCE.bonus_code_earning_id');


		$tempdb = clone $this->db;
		$query = $this->db->get();


		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
						//echo $this->db->last_query();die;
		$result	= $sql->result_array();		

		$result = ($result) ? $result : array();
		return array('result'=>$result, 'total'=>$total);
	}

	/**
	 * [get_bonus_code_by_id description]
	 * @MethodName get_bonus_code_by_id
	 * @Summary This function used to get bonus code detail
	 * @param      bonus_code  
	 * @return     array
	 */
	public function get_bonus_code_by_id($bonus_code)
	{
		$sql = $this->db->select("*")
						->from(BONUS_CODE)
						->where("bonus_code", $bonus_code)
						->get();
		$result = $sql->row_array();
		return $result;
	}
}
/* End of file Promocode_model.php */
/* Location: ./application/models/Promocode_model.php */