<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}
	/**
	 * [get_all_site_user_detail description]
	 * @MethodName get_all_site_user_detail
	 * @Summary This function used for get all user list and return filter user list 
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_all_user($count_only=FALSE)
	{
		$sort_field	= 'added_date';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data = $this->input->post();

		if($post_data['items_perpage'])
		{
			$limit = $post_data['items_perpage'];
		}

		if($post_data['current_page'])
		{
			$page = $post_data['current_page']-1;
		}

		if($post_data['sort_field'] && in_array($post_data['sort_field'],array('added_date','first_name','user_name','email','MC.country_name','balance','status','last_login','cpf_no','bonus_balance','phone_no')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if($post_data['sort_order'] && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$sql = $this->db->select("U.user_unique_id, U.user_id, CONCAT_WS(' ',U.first_name,U.last_name) AS name,U.image,MC.country_name,
									U.balance,U.bonus_balance,U.email,U.status,DATE_FORMAT(U.added_date,'%d-%b-%Y %H:%i') AS member_since,cpf_no,
									U.user_name,DATE_FORMAT(U.last_login, '%d-%b-%Y %H:%i') as last_login,IFNULL(U.pan_card,'') as pan_card,U.verify,IFNULL(U.phone_no,'') AS phone_no",FALSE)
						->from(USER.' AS U')
						->join(MASTER_COUNTRY." AS MC","MC.master_country_id=  U.master_country_id","left")
						->join(MASTER_STATE." AS MS","MS.master_state_id=  U.master_state_id","left")
						->order_by($sort_field, $sort_order);
		if(isset($post_data['country']) && $post_data['country']!="")
		{
			$this->db->where("U.master_country_id",$post_data['country']);
		}

		if(isset($post_data['frombalance']) && isset($post_data['tobalance']))
		{
			$this->db->where("U.balance >= ".$post_data['frombalance']." and U.balance <= ".$post_data['tobalance']."");
		}

		if(isset($post_data['keyword']) && $post_data['keyword'] != "")
		{
			$this->db->like('CONCAT(IFNULL(email,""),first_name,last_name,IFNULL(user_name,""),CONCAT_WS(" ",first_name,last_name))', $post_data['keyword']);
		}
		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();

		$records	= array();
		foreach($result as $key => $rs)
		{
			if(!$rs['image'])
			{
				$result[$key]['image'] = base_url("assets/images/default_user.png");
			}
		}

		$result=($result)?$result:array();
		return array('result'=>$result,'total'=>$total);
	}
	/**
	 * [get_user_detail_by_id description]
	 * @MethodName get_user_detail_by_id
	 * @Summary This function used for get user Detail
	 * @param      [int]  [User Id]
	 * @return     [array]
	 */
	public function get_user_detail_by_id($user_id)
	{
		$sql = $this->db->select("U.facebook_id, U.address, T.team_name,U.user_unique_id,U.user_id,U.first_name,U.last_name,U.image,MC.country_name,U.balance,U.email,DATE_FORMAT(U.dob,'%d-%b-%Y') as dob,U.city,U.language,U.status,DATE_FORMAT(U.added_date,'%d-%b-%Y') AS member_since,U.user_name,MS.name as state_name,IFNULL(U.cpf_no,'--') As cpf_no,IFNULL(U.zip_code,'--') As zip_code,IFNULL(U.phone_no,'--') AS phone_no,IFNULL(U.gender,'--') As gender",FALSE)
						->from(USER." AS U")
						->join(MASTER_COUNTRY." AS MC","MC.master_country_id = U.master_country_id","left")
						->join(MASTER_STATE." AS MS","MS.master_state_id = U.master_state_id","left")						
						->join(TEAM." AS T","T.team_id=  U.team_id","left")
						->where("U.user_unique_id",$user_id)
						->get();
		$result = $sql->row_array();
		return ($result)?$result:array();
	}

	/**
	 * [user_transaction_history description]
	 * @MethodName user_transaction_history
	 * @Summary This function used for get all transaction history
	 * @return     [array]
	 */
	public function user_transaction_history()
	{
		$sort_field	= 'payment_history_transaction_id';
		$sort_order	= 'DESC';
		$limit		= 50;
		$page		= 0;
		$post_data	= $this->input->post();

		$user_id = $post_data['user_id'];
		
		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('description','transaction_amount','status','created_date')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select('PHT.payment_history_transaction_id, MD.english_description as description, PHT.payment_type, PHT.transaction_amount, PHT.user_balance_at_transaction,
						G.contest_unique_id, PHT.payment_withdraw_transaction_id,PWT.withdraw_type,PWT.status,DATE_FORMAT(PHT.created_date , "%d-%b-%Y") AS created_date,G.contest_name,G.total_user_joined,MD.master_description_id, MD.english_description', FALSE)
						->from(PAYMENT_HISTORY_TRANSACTION . " AS PHT")
						->join(PAYMENT_WITHDRAW_TRANSACTION." AS PWT","PWT.payment_withdraw_transaction_id = PHT.payment_withdraw_transaction_id","left")
						->join(CONTEST." AS G","G.contest_unique_id = PHT.contest_unique_id","left")
						->join(MASTERDESCRIPTION." AS MD","MD.master_description_id = PHT.master_description_id","left")
						->where("PHT.user_id",$user_id);

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();

		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [game_history_by_user description]
	 * @MethodName game_history_by_user
	 * @Summary This function used for get all created by user and join game list
	 * @param  [array] [Data Array]
	 * @return     [array]
	 */
	public function game_history_by_user()
	{
		$sort_field = 'season_scheduled_date';
		$sort_order = 'DESC';
		$limit      = 50;
		$page       = 0;
		$user_id = $this->input->post('user_id');
		if(($this->input->post('items_perpage')))
		{
			$limit = $this->input->post('items_perpage');
		}

		if(($this->input->post('current_page')))
		{
			$page = $this->input->post('current_page')-1;
		}

		if(($this->input->post('sort_field')) && in_array($this->input->post('sort_field'),array('game_name', 'size', 'entry_fee', 'prize_pool', 'season_scheduled_date')))
		{
			$sort_field = $this->input->post('sort_field');
		}

		if(($this->input->post('sort_order')) && in_array($this->input->post('sort_order'),array('DESC','ASC')))
		{
			$sort_order = $this->input->post('sort_order');
		}

		$offset	= $limit * $page;
		$user_id = $this->input->post('user_id');
		$this->db->select('G.contest_unique_id, G.contest_name, G.contest_access_type, G.entry_fee, G.prize_pool, G.total_user_joined, G.size,
							G.status,LM.lineup_master_id, DATE_FORMAT(G.season_scheduled_date, "%d-%b-%Y %H:%i") AS season_scheduled_date', FALSE)
						->from(CONTEST . " AS G")
						->join(LINEUP_MASTER." AS LM","LM.contest_id=G.contest_id","left")
						->where("LM.user_id",$user_id);

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();
		$sql = $tempdb->order_by($sort_field, $sort_order)
						->limit($limit,$offset)
						->get();
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

	/**
	 * [change_user_status description]
	 * @MethodName update_user_detail
	 * @Summary This function used to update user detail
	 * @param      [varchar]  [User Unique ID]
	 * @param      [array]
	 * @return     [boolean]
	 */
	public function update_user_detail($user_unique_id,$data_arr)
	{
		$this->db->where("user_unique_id",$user_unique_id)
				->update(USER,$data_arr);
		return true;
	}

	/**
	 * [update_all_user_status description]
	 * @MethodName update_all_user_status
	 * @Summary This function used to change all user status
	 * @param      [array]  [data_array]
	 * @return     [boolean]
	 */
	public function update_all_user_status($data_arr)
	{
		$this->db->update_batch(USER,$data_arr,"user_unique_id");
		return true;
	}
	/**
	 * [make_payment_transaction description]
	 * @MethodName make_payment_transaction
	 * @Summary This function used to debit or credit user balance
	 * @param      array  $data_arr
	 * @return     int
	 */
	public function make_payment_transaction($data_arr)
	{
		$this->db->insert(ORDER,$data_arr);
		return $this->db->insert_id();
	}

	

	/**
	 * [get_max_user_balance description]
	 * @MethodName get_max_user_balance
	 * @Summary This function used to get user max balance
	 * @return  int
	 */
	public function get_max_min_user_balance()
	{
		$data_array = array();
		$this->db->select_max('balance','max_value');
		$this->db->select_min('balance','min_value');
		$result = $this->db->get(USER)->row();
		$data_array["max_value"] = $result->max_value;
		$data_array["min_value"] = $result->min_value;
		return $data_array;
	}

	/**
	 * [get_all_user_list description]
	 * @MethodName get_all_user_list
	 * @Summary This function used to get all user list
	 * @return     array
	 */
	public function get_all_user_list()
	{
		$sql = $this->db->select('GROUP_CONCAT(email) as emails')
						->from(USER)
						->where('status', '1')
						->get();
		$rs = $sql->row_array();
		return $rs;
	}

	public function export_users()
	{
		$sql = $this->db->select("U.first_name as FirstName,U.last_name AS LastName,U.email AS Email,U.user_name as UserName,U.balance AS DepositAmount,
									U.bonus_balance AS BonusAmount,U.winning_balance AS WinningAmount, U.status AS `Status (If 0 => Inactive,1 => Active,2 => Email Not Verified)`,
									DATE_FORMAT(U.dob,'%d-%b-%Y') AS DateOfBirth,U.phone_no as Phone,U.gender AS Gender,T.team_name AS FavoriteClub,
									 MC.country_name AS CountryName, MS.name as StateName, U.city AS City,U.address AS Street,U.zip_code as ZipCode, 
									 DATE_FORMAT(U.added_date,'%d-%b-%Y %H:%i') AS MemberSince, DATE_FORMAT(U.last_login, '%d-%b-%Y %H:%i') as LastLogin",FALSE)
						->from(USER.' AS U')
						->join(MASTER_COUNTRY." AS MC","MC.master_country_id=  U.master_country_id","left")
						->join(MASTER_STATE." AS MS","MS.master_state_id=  U.master_state_id","left")
						->join(TEAM." AS T","T.team_id=  U.team_id","left")
						->order_by('U.added_date', 'DESC')
						->group_by('U.user_id')
						->get();
		$this->load->dbutil();
		$this->load->helper('download');
		$data = $this->dbutil->csv_from_result($sql);
		$data = "Created on " . format_date('today', 'Y-m-d') . "\n\n" .html_entity_decode($data);
		$name = 'UserList.csv';
		force_download($name, $data);
		return exit;
	}

	public function remove_cpf($user_unique_id=FALSE)
	{
		$condition = array('user_unique_id'=>$user_unique_id);
		$data = array('cpf_no'=>NULL);
		$this->db->where($condition);
		$this->db->update(USER, $data);
		return $this->db->affected_rows();
	}
}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */