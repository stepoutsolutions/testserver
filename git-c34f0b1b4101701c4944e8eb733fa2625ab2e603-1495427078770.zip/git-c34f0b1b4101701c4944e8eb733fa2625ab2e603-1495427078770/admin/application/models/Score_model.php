<?php defined('BASEPATH') OR exit('No direct script access allowed');
require_once "../package/Api_credential_model.php";

class Score_model extends MY_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->admin_id = $this->session->userdata('admin_id');
	}
}	