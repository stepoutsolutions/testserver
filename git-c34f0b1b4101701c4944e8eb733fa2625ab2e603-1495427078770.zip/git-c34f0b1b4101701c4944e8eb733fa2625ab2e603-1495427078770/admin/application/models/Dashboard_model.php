<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}	

	/**
	 * [dashbaord_detail description]
	 * @MethodName dashbaord_detail
	 * @Summary This function used to get all header boxs value 
	 * @return  array
	 */
	public function dashbaord_detail()
	{
		$current_date = date('Y-m-d', strtotime(format_date()));
		$where_clause ="";
		$post_data = $this->input->post();
		/* -------------------------------Dashboard Filter------------------------------------------------------------ */
		$filter = $post_data['filter'];
		if ($filter == '')
		{
			$where_clause = "";
		}
		elseif ($filter == 'today')
		{
			$where_clause = "DATE_FORMAT(added_date,'%Y-%m-%d') = '$current_date'";
		}
		elseif ($filter == 'yesterday')
		{
			$where_clause = "DATE_FORMAT(added_date,'%Y-%m-%d') = '" . date('Y-m-d', strtotime('-1 day'. $current_date)) . "'";
		}
		elseif ($filter == 'week')
		{
			$where_clause = "WEEK(added_date) = WEEK('$current_date') and YEAR(added_date) = YEAR('$current_date')";
		}
		elseif ($filter == 'month')
		{
			$where_clause = "MONTH(added_date) = MONTH('$current_date') and YEAR(added_date) = YEAR('$current_date')";
		}
		elseif ($filter == 'threemonth')
		{
			$where_clause = "added_date BETWEEN DATE_SUB('$current_date', INTERVAL 3 MONTH) AND DATE_SUB('$current_date', INTERVAL 1 MONTH)";
		}
		elseif ($filter == 'year')
		{
			$where_clause = "YEAR(added_date) = YEAR('$current_date')";
		}
		elseif ($filter == 'custom')
		{
			if (isset($post_data['from_date']) && $post_data['from_date'] != '' && isset($post_data['to_date']) && $post_data['to_date'] != '')
			{
				$where_clause = "DATE_FORMAT(added_date,'%Y-%m-%d') BETWEEN '" . $post_data['from_date'] . "'  AND '" . $post_data['to_date'] . "'";
			}
		}
		$total_user_detail	= $this->_get_total_user_detail($where_clause);
		$total_earning		= $this->_get_total_earning($where_clause);
		$in_progress_game	= $this->_get_detail_in_progress_game($where_clause);
		$result = array_merge($total_earning,$total_user_detail,$in_progress_game);
		return $result;
	}

	/**
	 * [_get_total_user_detail description]
	 * @MethodName _get_total_user_detail
	 * @Summary This function used to get total user and average percent of users filter wise
	 * @param      string  filter conditions
	 * @return     array
	 */
	private function _get_total_user_detail($where_clause)
	{
		$this->db->select("user_id")
				->from(USER);

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total_users = $query->num_rows();

		if ($where_clause != '')
		{
			$tempdb->where($where_clause);
		}
		$sql = $tempdb->get();

		$filter_users = $sql->num_rows();

		$average_user = ($filter_users*100)/$total_users;

		$result  =  array('total_users'=>$total_users, 'average_user'=>$average_user);		
		return $result;
	}

	/**
	 * [_get_total_earning description]
	 * @MethodName _get_total_earning
	 * @Summary This function used to get total earning and filtered earning
	 * @param      string  filter conditions
	 * @return     array
	 */
	private function _get_total_earning($where_clause)
	{
		$this->db->select('(entry_fee*size) AS total_entry_fees,COUNT(LM.contest_unique_id) AS total_game_size,C.size AS size')
				->from(CONTEST." AS C")
				->join(LINEUP_MASTER." AS LM", "LM.contest_unique_id = C.contest_unique_id", "inner")
				->where("C.prize_distributed",'1');

		$tempdb = clone $this->db;

		if ($where_clause != '')
		{
			$this->db->where($where_clause);
		}

		$query = $this->db->group_by("C.contest_unique_id")->get()->result_array();

		$sql = $tempdb->group_by("C.contest_unique_id")->get()->result_array();

		$earning = array_sum(array_column($query, 'total_entry_fees'));
		$total_earning = array_sum(array_column($sql, 'total_entry_fees'));
		$result = array("earning"=>$earning, "total_earning"=>$total_earning);
		return $result;
	}

	/**
	 * [_get_detail_in_progress_game description]
	 * @MethodName _get_detail_in_progress_game
	 * @Summary This function used to get in progress game (count or commission) detail
	 * @param      string  filter conditions
	 * @return     array
	 */
	private function _get_detail_in_progress_game($where_clause)
	{
		$sql5 = $this->db->select("count(contest_unique_id) as in_progress, sum((((entry_fee*size)*site_rake)/100)) in_progress_comm")
						->from(CONTEST)
						->where('is_cancel', '0')
						->where('prize_distributed', '0');

		$tempdb = clone $this->db;

		if ($where_clause != '')
		{
			$this->db->where($where_clause);
		}
		$query = $this->db->get()->row_array();
		$sql = $tempdb->get()->row_array();

		$in_progress = isset($sql['in_progress']) ? $sql['in_progress'] : 0;
		$in_progress_comm = isset($query['in_progress_comm']) ? round($query['in_progress_comm'],2) : 0;
		$result = array("in_progress_total_game"=>$in_progress, "in_progress_game_commission"=>$in_progress_comm);
		return $result;
	}

	public function dashboard_graph_detail()
	{
		$post_data = $this->input->post();
		$current_date		= date('Y-m-d', strtotime(format_date()));
		$filter				= $post_data['filter'];
		$previous_where_clause	= "";
		$group_by			= "";
		$where_clause		= "";
		/* --------------------------------------Filter Section------------------------------------ */
		if ($filter == '')
		{
			$where_clause = "";
			$group_by    = 'DATE_FORMAT(season_scheduled_date,"%Y-%m-%d")';
		}
		elseif ($filter == 'today')
		{
			$where_clause			= "DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') = '" . $current_date . "'";
			$group_by				= "season_scheduled_date";
			$previous_where_clause	= "DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') = '" . date('Y-m-d', strtotime('-1 day ' . $current_date)) . "'";
		}
		elseif ($filter == 'yesterday')
		{
			$where_clause			= "DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') = '" . date('Y-m-d', strtotime('-1 day ' . $current_date)) . "'";
			$group_by				= "season_scheduled_date";
			$previous_where_clause	= "DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') = '" . date('Y-m-d', strtotime('-2 day ' . $current_date)) . "'";
		}
		elseif ($filter == 'week')
		{
			$where_clause			= "WEEK(season_scheduled_date) = WEEK('" . $current_date . "') AND YEAR(season_scheduled_date) = YEAR('" . $current_date . "')";
			$group_by				= "WEEK(season_scheduled_date)";
			$previous_where_clause	= "WEEK(season_scheduled_date) = '" . date('W', strtotime('-1 week ' . $current_date)) . "' and YEAR(season_scheduled_date) = YEAR('" . $current_date . "')";
		}
		elseif ($filter == 'month')
		{
			$where_clause			= "MONTH(season_scheduled_date) = MONTH('" . $current_date . "') AND YEAR(season_scheduled_date) = YEAR('" . $current_date . "') AND DATE(season_scheduled_date) <= DATE('" . $current_date . "')";
			$group_by				= "MONTH(season_scheduled_date)";
			$previous_where_clause	= "MONTH(season_scheduled_date) = '" . date('m', strtotime('-1 month ' . $current_date)) . "' AND YEAR(season_scheduled_date) = YEAR('" . $current_date . "')";
		}
		elseif ($filter == 'threemonth')
		{
			$where_clause			= "season_scheduled_date BETWEEN DATE_SUB('" . $current_date . "', INTERVAL 3 MONTH) AND DATE_SUB('" . $current_date . "', INTERVAL 1 MONTH)";
			$group_by				= "season_scheduled_date";
			$previous_where_clause	= "season_scheduled_date BETWEEN DATE_SUB('" . $current_date . "', INTERVAL 6 MONTH) AND DATE_SUB('" . $current_date . "', INTERVAL 4 MONTH)";
		}
		elseif ($filter == 'year')
		{
			$where_clause			= "YEAR(season_scheduled_date) = YEAR('" . $current_date . "')";
			$group_by				= "season_scheduled_date";
			$previous_where_clause	= "YEAR(season_scheduled_date) = '" . date('Y', strtotime('-1 year' . $current_date)) . "'";
		}
		elseif ($filter == 'custom')
		{
			if ($post_data['from_date'] != '' && $post_data['to_date'] != '')
			{
				$where_clause	= "DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') BETWEEN '" . $post_data['from_date'] . "'  AND '" . $post_data['to_date'] . "'";
				$group_by		= "season_scheduled_date";
			}
		}
		/*----------------------------------------------------------------------------------------------------------*/

		$contest_detail = $this->_get_created_contest_detail($where_clause, $group_by, $previous_where_clause);
		$entry_fee_detail = $this->_get_entry_fees_detail($where_clause, $group_by, $previous_where_clause);
		$prize_pool_detail = $this->_get_prize_pool_detail($where_clause, $group_by, $previous_where_clause);
		$general_contest_detail = $this->_get_genral_dashboard_information($where_clause, $group_by, $previous_where_clause);
		$result = array_merge($contest_detail, $entry_fee_detail, $prize_pool_detail, $general_contest_detail);
		return $result;
	}

	/**
	 * [_get_created_contest_detail description]
	 * @MethodName _get_created_contest_detail
	 * @Summary This function used to get contest detail
	 * @param      string  where condition
	 * @param      string  group by
	 * @param      string  radio where class
	 * @return     array
	 */
	private function _get_created_contest_detail($where_clause='', $group_by='', $previous_where_clause='')
	{
		$public_contest = 0;$private_contest = 0;$admin_contest = 0;$user_contest = 0;
		$public_previous_contest = 0;$private_previous_contest = 0; $admin_previous_contest = 0; $user_previous_contest = 0;
		$this->db->select("contest_unique_id, contest_access_type, user_id", FALSE)
				->from(CONTEST);
		$tempdb1 = clone $this->db;
		$tempdb2 = clone $this->db;

		if($where_clause != '')
		{
			$tempdb1->where($where_clause);
		}
		
		if($previous_where_clause != '')
		{
			$tempdb2->where($previous_where_clause);
		}

		$contest_created_1 = $this->db->get();
		$contest_created_2 = $tempdb1->get();
		$contest_created_3 = $tempdb2->get();


		$total_contest = $contest_created_1->result_array();

		$contest_detail = $contest_created_2->result_array();

		foreach ($contest_detail as $contest)
		{
			if ($contest['contest_access_type'] == 0)
			{
				$public_contest += 1;
			}
			else
			{
				$private_contest += 1;
			}
			if ($contest['user_id'] == 0)
			{
				$admin_contest += 1;
			}
			else
			{
				$user_contest += 1;
			}
		}
		/* ---------------------------Total Contest Previous history------------------------- */
		$previous_contest_detail = $contest_created_3->result_array();

		foreach ($previous_contest_detail as $contest)
		{
			if ($contest['contest_access_type'] == 0)
			{
				$public_previous_contest += 1;
			}
			else
			{
				$private_previous_contest += 1;
			}
			if ($contest['user_id'] == 0)
			{
				$admin_previous_contest+= 1;
			}
			else
			{
				$user_previous_contest += 1;
			}
		}

		$public_previous_contest = $public_previous_contest == 0 ? 0 : (($public_contest - $public_previous_contest) * 100) / $public_previous_contest;

		$private_previous_contest = $private_previous_contest == 0 ? 0 : (($private_contest - $private_previous_contest) * 100) / $private_previous_contest;

		$admin_previous_contest = $admin_previous_contest == 0 ? 0 : (($admin_previous_contest - $admin_previous_contest) * 100) / $admin_previous_contest;

		$user_previous_contest = $user_previous_contest == 0 ? 0 : (($user_previous_contest - $user_previous_contest) * 100) / $user_previous_contest;

		$result = array(
					"contest_graph"=>array(
						"contest_chart_user_admin" => array(
													"user"  => $user_contest, 
													"admin" => $admin_contest
													),
						"contest_chart_public_private" => array(
													"private" => $private_contest, 
													"public"  => $public_contest
													),
						"contest_detail" => array(
												"total_contest"				=> count($total_contest),
												"pervious_private_contest"	=> sprintf('%d', $private_previous_contest),
												"pervious_public_contest"	=> sprintf('%d', $public_previous_contest),
												"pervious_admin_contest"	=> sprintf('%d', $admin_previous_contest),
												"pervious_user_contest"		=> sprintf('%d', $user_previous_contest)
											)
						)
					);
		return $result;
	}

	/**
	 * [_get_entry_fees_detail description]
	 * @MethodName _get_entry_fees_detail
	 * @Summary This function used to get entry fees detail
	 * @param      string  where condition
	 * @param      string  group by
	 * @param      string  radio where class
	 * @return     array
	 */
	private function _get_entry_fees_detail($where_clause='', $group_by='', $previous_where_clause='')
	{
		$total_entry_fees = 0;$total_site_commission = 0;$entry_fee_public_contest = 0;$site_commission_public_contest = 0;
		$entry_fee_private_contest = 0;$site_commission_private_contest = 0;$entry_fee_admin = 0;$site_commission_admin = 0;
		$entry_fee_user = 0;$site_commission_user = 0;
		$entry_fee_public_contest_previous = 0;$site_commission_public_contest_previous = 0;$entry_fee_private_contest_previous = 0;$site_commission_private_contest_previous = 0;
		$entry_fee_admin_previous = 0;$site_commission_admin_previous = 0;$entry_fee_user_previous = 0;$site_commission_user_previous = 0;
		$entry_fee_public_contest_percent = 0;$entry_fee_private_contest_percent = 0;$site_commission_public_contest_percent = 0;$site_commission_private_contest_percent = 0;
		$entry_fee_admin_contest_percent = 0;$entry_fee_user_contest_percent = 0;$site_commission_admin_contest_percent	= 0;$site_commission_user_contest_percent = 0;

		$this->db->select("C.contest_unique_id, (entry_fee*size) AS total_entry_fees, (((entry_fee*size)*site_rake)/100) as total_entry_fees_commission, COUNT(LM.contest_unique_id) AS total_contest_size,C.size AS size,C.user_id,C.contest_access_type ")
				->from(CONTEST." AS C")
				->join(LINEUP_MASTER." AS LM", "LM.contest_unique_id = C.contest_unique_id", "inner")
				->where("C.prize_distributed",'1');
		$tempdb1 = clone $this->db;
		$tempdb2 = clone $this->db;

		if($where_clause != '')
		{
			$tempdb1->where($where_clause);
		}
		
		if($previous_where_clause != '')
		{
			$tempdb2->where($previous_where_clause);
		}

		$entry_fee1 = $this->db->group_by("C.contest_unique_id")->get()->result_array();
		$entry_fee2 = $tempdb1->group_by("C.contest_unique_id")->get()->result_array();
		$entry_fee3 = $tempdb2->group_by("C.contest_unique_id")->get()->result_array();


		$total_entry_fees = array_sum(array_column($entry_fee1, "total_entry_fees"));
		$total_site_commission  = array_sum(array_column($entry_fee1, "total_entry_fees_commission"));

		/* --------------------------------Entry Fee And Site Commission Current Data Calculation ----------------------- */

		foreach ($entry_fee2 as $entry_fee)
		{
			if ($entry_fee['contest_access_type'] == 0)
			{
				$entry_fee_public_contest += $entry_fee['total_entry_fees'];
				$site_commission_public_contest += $entry_fee['total_entry_fees_commission'];
			}
			else
			{
				$entry_fee_private_contest += $entry_fee['total_entry_fees'];
				$site_commission_private_contest += $entry_fee['total_entry_fees_commission'];
			}
			if ($entry_fee['user_id'] == 0)
			{
				$entry_fee_admin += $entry_fee['total_entry_fees'];
				$site_commission_admin += $entry_fee['total_entry_fees_commission'];
			}
			else
			{
				$entry_fee_user += $entry_fee['total_entry_fees'];
				$site_commission_user += $entry_fee['total_entry_fees_commission'];
			}
		}
		/* ---------------------------Entry Fee And Site Commission Previous Data Calculation--------------------------- */
		
		foreach ($entry_fee3 as $entry_fee)
		{
			if ($entry_fee['contest_access_type'] == 0)
			{
				$entry_fee_public_contest_previous += $entry_fee['total_entry_fees'];
				$site_commission_public_contest_previous += $entry_fee['total_entry_fees_commission'];
			}
			else
			{
				$entry_fee_private_contest_previous += $entry_fee['total_entry_fees'];
				$site_commission_private_contest_previous += $entry_fee['total_entry_fees_commission'];
			}
			if ($entry_fee['user_id'] == 0)
			{
				$entry_fee_admin_previous += $entry_fee['total_entry_fees'];
				$site_commission_admin_previous += $entry_fee['total_entry_fees_commission'];
			}
			else
			{
				$entry_fee_user_previous += $entry_fee['total_entry_fees'];
				$site_commission_user_previous += $entry_fee['total_entry_fees_commission'];
			}
		}

		$entry_fee_public_contest_percent			= $entry_fee_public_contest_previous == 0 ? 0.00 : (($entry_fee_public_contest - $entry_fee_public_contest_previous) * 100) / $entry_fee_public_contest_previous;
		$entry_fee_private_contest_percent			= $entry_fee_private_contest_previous == 0 ? 0.00 : (($entry_fee_private_contest - $entry_fee_private_contest_previous) * 100) / $entry_fee_private_contest_previous;
		$site_commission_public_contest_percent		= $site_commission_public_contest_previous == 0 ? 0.00 : (($site_commission_public_contest - $site_commission_public_contest_previous) * 100) / $site_commission_public_contest_previous;
		$site_commission_private_contest_percent	= $site_commission_private_contest_previous == 0 ? 0.00 : (($site_commission_private_contest - $site_commission_private_contest_previous) * 100) / $site_commission_private_contest_previous;
			
		$entry_fee_admin_contest_percent		= $entry_fee_admin_previous == 0 ? 0.00 : (($entry_fee_admin - $entry_fee_admin_previous) * 100) / $entry_fee_admin_previous;
		$entry_fee_user_contest_percent			= $entry_fee_user_previous == 0 ? 0.00 : (($entry_fee_user - $entry_fee_user_previous) * 100) / $entry_fee_user_previous;
		$site_commission_admin_contest_percent	= $site_commission_admin_previous == 0 ? 0.00 : (($site_commission_admin - $site_commission_admin_previous) * 100) / $site_commission_admin_previous;
		$site_commission_user_contest_percent	= $site_commission_user_previous == 0 ? 0.00 : (($site_commission_user - $site_commission_user_previous) * 100) / $site_commission_user_previous;

		$result = array(
					"entry_fee" =>array(
						"entry_fee_chart_user_admin" => array(
													"user"	=> sprintf('%0.2f', $entry_fee_user),
													"admin"	=> sprintf('%0.2f', $entry_fee_admin)
													),
						"entry_fee_chart_public_private" => array(
															"private"	=> sprintf('%0.2f', $entry_fee_private_contest),
															"public"	=> sprintf('%0.2f', $entry_fee_public_contest)
															),
						"entry_fee_detail" => array(
												'total_entry_fees'	=> $total_entry_fees,
												"pervious_private"	=> sprintf('%d', $entry_fee_private_contest_percent), 
												"pervious_public"	=> sprintf('%d', $entry_fee_private_contest_percent),
												"pervious_admin"	=> sprintf('%d', $entry_fee_admin_contest_percent), 
												"pervious_user"		=> sprintf('%d', $entry_fee_user_contest_percent)
												)
						),
					"site_commission" => array(
						"site_commission_chart_user_admin" => array(
													"user"	=> sprintf('%0.2f', $site_commission_user),
													"admin"	=> sprintf('%0.2f', $site_commission_admin)
													),
						"site_commission_chart_public_private" => array(
														"private"	=> sprintf('%0.2f', $site_commission_private_contest),
														"public"	=> sprintf('%0.2f', $site_commission_public_contest)
													),
						"site_commission_detail" => array(
											'total_commission'	=> sprintf('%0.2f', $total_site_commission),
											"previous_private"	=> sprintf('%d', $site_commission_private_contest_percent), 
											"previous_public"	=> sprintf('%d', $site_commission_public_contest_percent),
											"previous_admin"	=> sprintf('%d', $site_commission_admin_contest_percent), 
											"previous_user"		=> sprintf('%d', $site_commission_user_contest_percent)
										)
							)
					);
		return $result;
	}

	/**
	 * [_get_prize_pool_detail description]
	 * @MethodName _get_prize_pool_detail
	 * @Summary This function used to get prize pool detail
	 * @param      string  where condition
	 * @param      string  group by
	 * @param      string  radio where class
	 * @return     array
	 */
	private function _get_prize_pool_detail($where_clause='', $group_by='', $previous_where_clause='')
	{
		$prize_detail_admin						= 0;
		$prize_detail_user						= 0;
		$prize_detail_public_contest			= 0;
		$prize_detail_private_contest			= 0;
		$prize_detail_public_contest_percent	= 0;
		$prize_detail_private_contest_percent	= 0;
		$prize_detail_user_contest_percent		= 0;
		$prize_detail_admin_contest_percent		= 0;
		$prize_detail_public_contest_previous	= 0;
		$prize_detail_private_contest_previous	= 0;
		$prize_detail_admin_contest_previous	= 0;
		$prize_detail_user_contest_previous		= 0;

		$this->db->select("C.prize_pool as total_prize, C.user_id, C.contest_access_type")
				->from(CONTEST.' AS C')
				->where("C.is_cancel", '0')
				->where("C.prize_distributed", '1');
		$tempdb1 = clone $this->db;
		$tempdb2 = clone $this->db;

		if ($where_clause != '')
		{
			$tempdb1->where($where_clause);
		}
		if ($previous_where_clause != '')
		{
			$tempdb2->where($previous_where_clause);
		}
		
		$prize_detail_1 = $this->db->get()->result_array();
		$prize_detail_2 = $tempdb1->get()->result_array();
		$prize_detail_3 = $tempdb2->get()->result_array();

		$tolal_prize = array_sum(array_column($prize_detail_1, 'total_prize'));

		/* -----------------------------Current Data Calculation--------------------------------- */

		foreach ($prize_detail_2 as $prize)
		{
			if ($prize['contest_access_type'] == 0)
			{
				$prize_detail_public_contest += $prize['total_prize'];
			}
			else
			{
				$prize_detail_private_contest += $prize['total_prize'];
			}
			if ($prize['user_id'] == 0)
			{
				$prize_detail_admin += $prize['total_prize'];
			}
			else
			{
				$prize_detail_user += $prize['total_prize'];
			}
		}

		/* -----------------------------Prize Detail Previous Data Calculation--------------------- */
		foreach ($prize_detail_3 as $prize)
		{
			if ($prize['contest_access_type'] == 0)
			{
				$prize_detail_public_contest_previous += $prize['total_prize'];
			}
			else
			{
				$prize_detail_private_contest_previous += $prize['total_prize'];
			}

			if ($prize['user_id'] == 0)
			{
				$prize_detail_admin_contest_previous += $prize['total_prize'];
			}
			else
			{
				$prize_detail_user_contest_previous += $prize['total_prize'];
			}
		}

		$prize_detail_public_contest_percent = $prize_detail_public_contest_previous == 0 ? 0.00 : (($prize_detail_public_contest - $prize_detail_public_contest_previous) * 100) / $prize_detail_public_contest_previous;
		$prize_detail_private_contest_percent = $prize_detail_private_contest_previous == 0 ? 0.00 : (($prize_detail_private_contest - $prize_detail_private_contest_previous) * 100) / $prize_detail_private_contest_previous;
		$prize_detail_admin_contest_percent   = $prize_detail_admin_contest_previous == 0 ? 0.00 : (($prize_detail_admin - $prize_detail_admin_contest_previous) * 100) / $prize_detail_admin_contest_previous;
		$prize_detail_user_gcontest_percent = $prize_detail_user_contest_previous == 0 ? 0.00 : (($prize_detail_user - $prize_detail_user_contest_previous) * 100) / $prize_detail_user_contest_previous;

		$result = array("prize_chart"=>array(
					"prize_chart_user_admin" => array(
													"user"	=> sprintf('%0.2f', $prize_detail_user), 
													"admin"	=> sprintf('%0.2f', $prize_detail_admin)
												),
					"prize_chart_public_private"=> array(
													"private" => sprintf('%0.2f', $prize_detail_private_contest),
													"public"  => sprintf('%0.2f', $prize_detail_public_contest)
												),
					"prize_detail" => array(
								'total_prize'	=> $tolal_prize,
								"per_private"	=> sprintf('%d', $prize_detail_private_contest_percent), 
								"per_public"	=> sprintf('%d', $prize_detail_public_contest_percent),
								"per_admin"		=> sprintf('%d', $prize_detail_admin_contest_percent), 
								"per_user"		=> sprintf('%d', $prize_detail_user_gcontest_percent)
					  )
					)
				);
		return $result;
	}

	/**
	 * [_get_genral_dashboard_information description]
	 * @MethodName _get_genral_dashboard_information
	 * @Summary This function used to get general contest infomation
	 * @param      string  where condition
	 * @param      string  group by
	 * @param      string  radio where class
	 * @return     array
	 */
	private function _get_genral_dashboard_information($where_clause='', $group_by='', $previous_where_clause='')
	{
		$this->db->select("DATE_FORMAT(season_scheduled_date, '%Y-%m-%d') as date, count(contest_unique_id) as contest,sum(entry_fee*size) as earning")
						->from(CONTEST)
						->where("is_cancel", "0")
						->where("prize_distributed", "1");
		if ($where_clause != '')
		{
			$this->db->where($where_clause);
		}

		if ($group_by != '')
		{
			$this->db->group_by($group_by);
		}
		$sql =  $this->db->get();

		$general_chart = $sql->result_array();
        if (empty($general_chart))
        {
            $general_chart = array(array('date' => '', "contest" => 0, 'earning'=>0	));
        }
        $general_chart = array("general_graph"=>$general_chart);
        return $general_chart;
	}
}
/* End of file Dashboard_model.php */
/* Location: ./application/models/Dashboard_model.php */
