<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Season_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}

	
	/**
	 * [get_all_season_schedule description]
	 * @MethodName get_all_season_schedule
	 * @Summary This function used for get all season schedule
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_all_season_schedule($count_only=FALSE)
	{
		$sort_field	= 'season_scheduled_date';
        $sort_order	= 'DESC';
        $limit		= 10;
        $page		= 0;

        $post_data = $this->input->post();

        if(($post_data['items_perpage']))
        {
            $limit = $post_data['items_perpage'];
        }

        if(($post_data['current_page']))
        {
            $page = $post_data['current_page']-1;
        }

        if(($post_data['sort_field']) && in_array($post_data['sort_field'],array('year','type','season_scheduled_date','home','away','status','api_week')))
        {
            $sort_field = $this->input->post('sort_field');
        }

        if(($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
        {
            $sort_order = $post_data['sort_order'];
        }

        $offset	= $limit * $page;

        $league_id	= isset($post_data['league_id']) ? $post_data['league_id'] : "";
        $team_league_id	= isset($post_data['team_league_id']) ? $post_data['team_league_id'] : "";
        $fromdate	= isset($post_data['fromdate']) ? $post_data['fromdate'] : "";
        $todate		= isset($post_data['todate']) ? $post_data['todate'] : "";

        $this->db->select("season_id, season_game_uid, S.year, type, S.home as home,S.away as away, status, week, DATE_FORMAT(season_scheduled_date,'%d-%b-%Y %H:%i') as season_scheduled_dates")
            ->from(SEASON." AS S")
            ->join(TEAM_LEAGUE.' T1','T1.team_uid = S.home_uid','LEFT')
            ->join(TEAM_LEAGUE.' T2','T2.team_uid= S.away_uid','LEFT');
        if($league_id != "")
        {
            $this->db->where("S.league_id", "$league_id");
        }

        if($team_league_id != "" && $team_league_id!='all')
        {
            $this->db->where("(T1.team_league_id = '".$team_league_id."' or T2.team_league_id  = '".$team_league_id."')");
        }

        if($fromdate != "" && $todate != "")
        {
            $this->db->where("DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') >= '".$fromdate."' and DATE_FORMAT(season_scheduled_date,'%Y-%m-%d') <= '".$todate."'");
        }

        $tempdb = clone $this->db;
        $query  = $this->db->get();
        $total  = $query->num_rows();

        $sql =   $tempdb->group_by('S.season_game_uid')
            ->order_by($sort_field, $sort_order)
            ->limit($limit,$offset)
            ->get();

        $result	= $sql->result_array();

        $result = ($result) ? $result : array();
        return array('result'=>$result,'total'=>$total);
	}
	
	/**
	 * [update_roster description]
	 * @MethodName update_roster
	 * @Summary This function used update multiple player salary and status
	 * @param      [int]  [league_id]
	 * @param      [array]  [data_arr]
	 * @return     [boolean]
	 */
	public function update_withdrawal_request($data_arr)
	{
		$this->db->update_batch(PAYMENT_WITHDRAW_TRANSACTION, $data_arr, 'payment_withdraw_transaction_id');

		return $this->db->affected_rows();
	}

	/**
	 * [change_withdrawal_status description]
	 * @MethodName change_withdrawal_status
	 * @Summary This function used to withdrawal status
	 * @param      [varchar]  [withdraw_transaction_id]
	 * @param      [int]  [status]
	 * @return     [boolean]
	 */
	public function change_withdrawal_status($withdraw_transaction_id,$status)
	{
		$this->db->where("payment_withdraw_transaction_id",$withdraw_transaction_id);
		$this->db->update(PAYMENT_WITHDRAW_TRANSACTION,array('status'=>$status));
		
		return $this->db->affected_rows();
	}


	/**
	 * [get_all_season_stats description]
	 * @MethodName get_all_season_stats
	 * @Summary This function used for get all season stats
	 * @return     [type]
	 */
	public function get_all_season_stats()
	{
		$post_data = $this->input->post();

		$season_stats_common_field = array(
			"team_name"			=>"T.team_name AS team_name",
			"scheduled_date"	=>'DATE_FORMAT(GSC.scheduled_date, "'.MYSQL_DATE_FORMAT.'") AS scheduled_date',
			"home" 				=> "S.home as home",
			"away" 				=> "S.away as away",
			"player_name" 		=> "P.full_name as player_name",
		);

		// $columns = $this->db->list_fields(GAME_STATISTICS_CRICKET);
		// print_r($columns);die;

		$season_stats_field = array(
			"innings" 					=> "innings",
			"minute" 					=> "minute",
			"home_team_score" 			=> "home_team_score",
			"away_team_score" 			=> "away_team_score",
			"is_captain" 				=> "is_captain",
			"batting_runs" 				=> "batting_runs",
			"batting_dots" 				=> "batting_dots",
			"batting_balls_faced" 		=> "batting_balls_faced",
			"batting_fours"		 		=> "batting_fours",
			"batting_sixes" 			=> "batting_sixes",
			"batting_strike_rate" 		=> "batting_strike_rate",
			"bowling_overs" 			=> "bowling_overs",
			"bowling_runs_given" 		=> "bowling_runs_given",
			"bowling_runs_extra" 		=> "bowling_runs_extra",
			"bowling_balls_delivered" 	=> "bowling_balls_delivered",
			"bowling_maiden_overs" 		=> "bowling_maiden_overs",
			"bowling_wickets" 			=> "bowling_wickets",
			"bowling_wides" 			=> "bowling_wides",
			"bowling_noballs" 			=> "bowling_noballs",
			"bowling_strike_rate" 		=> "bowling_strike_rate",
			"catch" 					=> "catch",
			"stumping" 					=> "stumping",
			"run_out" 					=> "run_out",
			"run_out_throw" 			=> "run_out_throw",
			"run_out_catch" 			=> "run_out_catch",
			"innings" 					=> "innings",
			"innings" 					=> "innings",
		);
		// $this->load->config('vconfig');

		// $season_stats_common_field = $this->config->item('season_stats_common_field');
		// $season_stats_field = $this->config->item('season_stats_field')[$post_data['league_id']];
		
		 $fields		= array_merge($season_stats_common_field, $season_stats_field);
		 $column		= implode(',', $fields);

		 $season_stats_common_field = array_keys($season_stats_common_field);
		 $season_stats_field = array_keys($season_stats_field);
		 $tableheader		= array_merge($season_stats_common_field, $season_stats_field);

		$sort_field = 'player_name';
		$sort_order = 'ASC';
		$limit      = 10;
		$page       = 0;
		$summary 	= '';

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'], $tableheader))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;

		$this->db->select("$column", FALSE)
						->from(GAME_STATISTICS_CRICKET." AS GSC")
						->join(TEAM_LEAGUE.' TL','TL.team_uid = GSC.team_uid AND TL.league_id = GSC.league_id','INNER')
						->join(TEAM.' T','T.team_id = TL.team_id','INNER')
						->join(SEASON.' S','S.season_game_uid = GSC.season_game_uid','INNER')
						//->join(TEAM_LEAGUE.' TL2','TL2.team_uid = GSC.team_uid AND TL2.league_id = GSC.league_id','INNER')
						->join(PLAYER_TEAM.' PT','PT.team_league_id = TL.team_league_id','INNER')
						->join(PLAYER.' P','P.player_id = PT.player_id AND P.player_uid = GSC.player_uid','INNER')
						->where('GSC.season_game_uid', $post_data['game_unique_id']);

		$tempdb = clone $this->db;
		$query = $this->db->get();
		$total = $query->num_rows();
		if($sort_field!="" && $sort_order!="")
		{
			$tempdb->order_by($sort_field, $sort_order);
		}
		$tempdb->limit($limit,$offset);
		$sql = $tempdb->get();
		//echo $tempdb->last_query();die;
		$result	= $sql->result_array();
		if(!empty($result))
		{
			$summary = $result[0]['home']." vs ".$result[0]['away']." - ".date(PHP_DATE_FORMAT, strtotime($result[0]['scheduled_date']));
		}
		$result = ($result) ? $result : array();

		return array('fields'=>$tableheader, 'result'=>$result, 'total'=>$total,'summary'=>$summary, 'sort_field'=>$sort_field, 'sort_order'=>$sort_order);
	}
}
/* End of file Season_model.php */
/* Location: ./application/models/Season_model.php */