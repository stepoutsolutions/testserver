<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Withdrawal_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}

	
	/**
	 * [get_all_site_user_detail description]
	 * @MethodName get_all_site_user_detail
	 * @Summary This function used for get all user list and return filter user list 
	 * @param      boolean  [User List or Return Only Count]
	 * @return     [type]
	 */
	public function get_all_withdrawal_request($count_only=FALSE)
	{
		$sort_field	= 'O.date_added';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;
		$post_data	= $this->input->post();
		

		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('U.user_name','O.email','amount','O.status','O.type','O.date_added')))
		{
			$sort_field = $this->input->post('sort_field');
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
		$status	= isset($post_data['status']) ? $post_data['status'] : "";
		$type	= isset($post_data['type']) ? $post_data['type'] : "";

		$this->db->select("U.user_id,U.user_name,(O.real_amount+O.winning_amount) AS amount,O.type,DATE_FORMAT(O.date_added, '".MYSQL_DATE_FORMAT."') AS date_added,O.order_id,O.source,O.source_id,O.status,O.email AS email",FALSE)
			->from(USER.' AS U')
			->join(ORDER.' AS O','O.user_id = U.user_id','INNER')
			->where('O.source',ORDER_SOURCE_WITHDRAW)
			->where('O.type',1)
			->order_by($sort_field,$sort_order)
			->order_by('O.order_id','DESC');				







		if($status != "")
		{
			$this->db->where("O.status",$status);
		}
		
		$tempdb = clone $this->db;
		$query = $this->db->get();
		
		$total = $query->num_rows();


		$sql = $tempdb->limit($limit,$offset)
						->get();
		
		$result	= $sql->result_array();
			
		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}
	
	/**
	 * [update_roster description]
	 * @MethodName update_roster
	 * @Summary This function used update multiple player salary and status
	 * @param      [int]  [league_id]
	 * @param      [array]  [data_arr]
	 * @return     [boolean]
	 */
	public function update_withdrawal_request($data_arr)
	{		
		$this->db->update_batch(PAYMENT_WITHDRAW_TRANSACTION, $data_arr, 'payment_withdraw_transaction_id');

		return $this->db->affected_rows();
	}

	/**
	 * [change_withdrawal_status description]
	 * @MethodName change_withdrawal_status
	 * @Summary This function used to withdrawal status
	 * @param      [varchar]  [withdraw_transaction_id]
	 * @param      [int]  [status]
	 * @return     [boolean]
	 */
	public function change_withdrawal_status($date_array)
	{
		//,'description'=>$date_array['description']
		$this->db->where("order_id",$date_array['order_id']);
		$this->db->update(ORDER,array('status'=>$date_array['status']));
		
		return $this->db->affected_rows();
	}

	public function get_single_withdraw_request($order_id,$status='all'){
		$sql = $this->db->select("(O.real_amount+O.winning_amount) AS amount,O.real_amount,O.winning_amount,O.user_id,U.balance,U.winning_balance,CONCAT_WS(' ',U.first_name,U.last_name) AS full_name,U.email,U.language")
						->from(ORDER." AS O")
						->join(USER." AS U", "U.user_id = O.user_id", "INNER")
						->where('O.order_id', $order_id);
		
		if($status != 'all'){
			$sql = $this->db->where('O.status', $status);
		}				

						
		$sql = $this->db->get();				
		$result = $sql->row_array();
		return ($result)?$result:array();

	}

	public function update_user_balance($data,$where)
	{
		$this->db->where($where);
		$this->db->update(USER,$data);
		return $this->db->affected_rows();
	}


	/**
	 * @Summary: This function is used for add notification in databse
	 * @access: public
	 */
	function add_notification($notification_type_id, $sender_user_id = '0', $receiver_user_id,
		$notification = '', $game_id=0,$game_unique_id = '') {
		$data = array(
			'notification_type_id' => $notification_type_id,
			'sender_user_id'       => $sender_user_id,
			'receiver_user_id'     => $receiver_user_id,
			'notification'         => $notification,
			'contest_id'	       => $game_id,
			'contest_unique_id'    => $game_unique_id,
			'is_read'              => '0',
			'created_date'         => format_date(),
		);
		$this->db->insert($this->db->dbprefix(NOTIFICATION), $data);
		
	}
}
/* End of file Roster_model.php */
/* Location: ./application/models/Roster_model.php */