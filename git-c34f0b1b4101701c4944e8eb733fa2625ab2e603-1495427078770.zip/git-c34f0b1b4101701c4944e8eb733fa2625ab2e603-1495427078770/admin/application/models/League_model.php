<?php defined('BASEPATH') OR exit('No direct script access allowed');

class League_model extends MY_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->admin_id = $this->session->userdata('admin_id');
	}	

	/**
	 * [get_all_teamrosters description]
	 * @MethodName get_all_teamrosters
	 * @Summary This function used for get all team list and return filter team list
	 * @return     [type]
	 */
	public function get_all_leagues()
	{
		$sort_field	= 'league_schedule_date';
		$sort_order	= 'DESC';
		$limit		= 10;
		$page		= 0;
		$post_data	= $this->input->post();
		if(isset($post_data['items_perpage']))
		{
			$limit = $post_data['items_perpage'];
		}

		if(isset($post_data['current_page']))
		{
			$page = $post_data['current_page']-1;
		}

		if(isset($post_data['sort_field']) && in_array($post_data['sort_field'],array('league_schedule_date','league_name','league_abbr','league_uid','active','max_player_per_team')))
		{
			$sort_field = $post_data['sort_field'];
		}

		if(isset($post_data['sort_order']) && in_array($post_data['sort_order'],array('DESC','ASC')))
		{
			$sort_order = $post_data['sort_order'];
		}

		$offset	= $limit * $page;
	
		$sql = $this->db->select("league_id,league_uid,league_abbr,league_name,active,DATE_FORMAT(league_schedule_date,'%d-%b-%Y %H:%i') as league_date,league_schedule_date,max_player_per_team",FALSE)
						->from(LEAGUE)
						->order_by($sort_field, $sort_order);

		$tempdb = clone $this->db;
		$query = $this->db->get();

		$total = $query->num_rows();

		$sql = $tempdb->limit($limit,$offset)
						->get();
		//echo $tempdb->last_query();die;				
		$result	= $sql->result_array();

		$result = ($result) ? $result : array();
		return array('result'=>$result,'total'=>$total);
	}

public function update_league_status($data,$where)
	{
		$this->db->where($where);
		$this->db->update(LEAGUE,$data);
		return $this->db->affected_rows();
	}
}
/* End of file Teamroster_model.php */
/* Location: ./application/models/Teamroster_model.php */