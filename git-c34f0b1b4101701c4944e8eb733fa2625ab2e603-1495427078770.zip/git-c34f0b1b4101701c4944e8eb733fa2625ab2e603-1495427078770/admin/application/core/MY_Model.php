<?php
class MY_Model extends CI_Model {

        public $table_name="";
        
	function __construct()
	{
		parent::__construct();	
	}

        
	/**
	 * Replace into Batch statement
	 *
	 * Generates a replace into string from the supplied data
	 *
	 * @access    public
	 * @param    string    the table name
	 * @param    array    the update data
	 * @return    string
	 */
	public function replace_into_batch($table, $data)
	{
		$column_name	= array();
		$update_fields	= array();
		$append			= array();
		foreach($data as $i=>$outer)
		{
			$column_name = array_keys($outer);
			$coloumn_data = array();
			foreach ($outer as $key => $val) 
			{

				if($i == 0)
				{
					// $column_name[]   = "`" . $key . "`";
					$update_fields[] = "`" . $key . "`" .'=VALUES(`'.$key.'`)';
				}

				if (is_numeric($val)) 
				{
					$coloumn_data[] = $val;
				} 
				else 
				{
					$coloumn_data[] = "'" . replace_quotes($val) . "'";
				}
			}
			$append[] = " ( ".implode(', ', $coloumn_data). " ) ";
		}

		/*

			INSERT INTO `vi_player_temp` (`player_unique_id`, `salary`, `weightage`) VALUES ('000bc6c6-c9a8-4631-92d6-1cea5aaa1644',0,'')
			ON DUPLICATE KEY UPDATE `player_unique_id`=VALUES(`player_unique_id`), `salary`=VALUES(`salary`), `weightage`=VALUES(`weightage`)
		*/

		// $sql = "REPLACE INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES " . implode(', ', $append) ;

		$sql = "INSERT INTO " . $this->db->dbprefix($table) . " ( " . implode(", ", $column_name) . " ) VALUES " . implode(', ', $append) . " ON DUPLICATE KEY UPDATE " .implode(', ', $update_fields);
		// $sql = "INSERT INTO ". $this->db->dbprefix($table) ." (".implode(', ', $keys).") VALUES (".implode(', ', $values).") ON DUPLICATE KEY UPDATE ".implode(', ', $update_fields);

		
		$this->db->query($sql);
	}
	function get_single_row ($select = '*', $table, $where = "") {
		$this->db->select($select);
		$this->db->from($table);
		if ($where != "") {
			$this->db->where( $where );
		}
		$query = $this->db->get();
	    $this->db->last_query();
		return $query->row_array();
	}
	/**
	 * [get_all_team description]
	 * @MethodName get_all_team
	 * @Summary This function is used to get all team by league id in database
	 * @param      [int]  [league_id]
	 * @return     [array]
	 */
	public function get_all_team($league_id)
	{
		$result = array();
        $sql = $this->db->select('TL.team_league_id,T.team_abbr,T.team_abbr as team_abbreviation,T.team_name')
                        ->from(TEAM_LEAGUE." AS TL")
                        ->join(TEAM ." AS T", "T.team_id = TL.team_id", 'INNER')
                        ->where('TL.league_id', $league_id)
                        ->order_by('T.team_name','ASC')
                        ->get();
        $result = $sql->result_array();
        return ($result) ? $result : array();
	}

        /**
	 * [get_all_position description]
	 * @MethodName get_all_position
	 * @Summary This function is used to get all position by league id in database
	 * @param      [int]  [league_id]
	 * @return     [array]
	 */
	public function get_all_position($league_id)
	{
		$result = array();
		$sql = $this->db->select('position_name as position, position_name, position_display_name')
						->from(MASTER_LINEUP_POSITION)
						->where('sports_id',ACTIVE_SPORTS_ID)
						->where('position_name = allowed_position') // to avoid FLEX position
						->order_by('position_name','ASC')
						->get();
		$temp_array = $sql->result_array();
		foreach ($temp_array as $rc)
		{
			$result[] = $rc;
		}
		return ($result) ? $result : array();
	}
        
        /**
        * [get_all_roster_category description]
        * @MethodName get_all_roster_category
        * @Summary This function used for get all roster Category 
        * @param      [int]  [league_id]
        * @return     [array]
        */
        public function get_all_roster_category($league_id) {

           $sql = $this->db->select('RC.category_id, RC.league_id, RC.category_name, RC.no_of_lineup_player')
                   ->from(ROSTER_CATEGORY." AS RC")
                   ->where('league_id', $league_id)
                   ->order_by('category_name', 'ASC')
                   ->get();
           $result = $sql->result_array();
           return ($result) ? $result : array();
        }

/**
	 * [get_all_sports description]
	 * @Summary : Used to get list of all sports
	 * @return  [type]
	 */
	public function get_all_league()
	{
		$sql = $this->db->select('league_id, league_abbr')
						->from(LEAGUE . " AS L")
						->join(MASTER_SPORTS . " AS MS", "MS.sports_id = L.sports_id", 'INNER')
						->where('L.active', '1')
						->where('MS.active', '1')
						->order_by('L.order', 'ASC')
						->order_by('L.league_schedule_date', 'ASC')
						->get();
		$temp_array  = $sql->result_array();
		foreach ($temp_array as $rc)
		{
			$result[] = $rc;
		}
		$result = ($result)?$result:array();
		return $result;
	}

	/**
	 * [get_all_week description]
	 * @Summary : Used to get list of all week
	 * @return  [array]
	 */
	public function get_all_week($league_id)
	{
		  $sql = $this->db->select('season_week,season_week as week')
            ->from(SEASON_WEEK)
            ->where('league_id',$league_id)
            ->order_by('season_week', 'ASC')
            ->group_by('season_week')
            ->get();
        $result  = $sql->result_array();
        $result = ($result)?$result:array();
        return $result;
	}

	/**
	 * @Summary: This function for return current week from current date.
	 * @access: public
	 * @param:
	 * @return:
	 */
	public function get_current_week($league_id  , $date)
	{
		$sql = $this->db->select('season_week')
						->from(SEASON_WEEK)
						->where('league_id',$league_id)
						->where('season_week_close_date_time > "' . $date . '"')
						->limit(1)
						->get();
		$res = $sql->row_array();
		return $res['season_week'];
	}

	/**
	 * [get_all_country description]
	 * @MethodName get_all_country
	 * @Summary This function used to get all master country
	 * @return     [type]
	 */
	public function get_all_country()
	{
		$sql = $this->db->select("*")
						->from(MASTER_COUNTRY)
						->order_by("country_name","ASC")
						->get();
		return $sql->result_array();
	}

	/**
	 * [get_all_state description]
	 * @MethodName get_all_state
	 * @Summary This function used to get all master state
	 * @return     [type]
	 */
	public function get_all_state()
	{
		$sql = $this->db->select("*")
						->from(MASTER_STATE)
						->order_by("name","ASC")
						->get();
		return $sql->result_array();
	}

	/**
	 * [get_all_state_by_country description]
	 * @MethodName get_all_state_by_country
	 * @Summary This function used to get all master state by country id
	 * @return     [type]
	 */
	public function get_all_state_by_country($country)
	{
		$sql = $this->db->select("*")
						->from(MASTER_STATE)
						->where('master_country_id', $country)
						->order_by("name","ASC")
						->get();
		return $sql->result_array();
	}

	/**
	 * [get_all_table_data description]
	 * @MethodName get_all_table_data
	 * @param String $select
	 * @param String $table
	 * @param Array/String $where
	 * @param Array/String $group_by
	 * @param Array/String $order_by
	 * @param Array/String $offset
	 * @param Array/String $limit
	 * @Summary common function used to get all data from any table
	 * @return     [type]
	 **/

	function get_all_table_data($select = '*', $table, $where = "", $group_by = "", $order_by = "", $offset = '', $limit = '')
	{
		$this->db->select($select);
		$this->db->from($table);
		if ($where != "") {
			$this->db->where($where);
		}
		if ($group_by != "") {
			$this->db->group_by($group_by);
		}
		if ($order_by != "") {
			$this->db->order_by($order_by);
		}
		if ($limit != "") {
			$this->db->limit($offset, $limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		return $query->result_array();
	}

	/**
	 * [update_batch description]
	 * @MethodName get_all_table_data
	 * @param String $table
	 * @param String $key
	 * @param Array/String $update_data
	 * @Summary common function used to update batch
	 * @return     [type]
	 **/

	public function update_batch($table, $update_data, $key)
	{
		if(!empty($table) && !empty($update_data) && !empty($key))
		{
			if ($this->db->field_exists($key, $table))
			{
				$this->db->update_batch($table, $update_data, $key);
				return true; 
			}
			else
			{
				return false;		
			}
		}
		return false;
	}
        
        function delete($condition){
		if(is_array($condition)){
			$this->db->where($condition);
		}else{
			$this->db->where($this->primary_key,$condition);
		}
		$this->db->delete($this->table_name);
		if ($this->db->affected_rows() == 1)
		{
			return TRUE;
		}
		
		return FALSE;        
	}  
}
//End of file