<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MYREST_Controller extends REST_Controller {
	public $admin_role = "";
	public $admin_privilege = "";
	public $redirect_after_login = "dashboard";

	public function __construct()
	{
		parent::__construct();
		$_POST = $this->post();
		$this->custom_auth_override = $this->_custom_auth_override_check();

		//Do your magic here
		if ($this->custom_auth_override === FALSE)
		{
			$this->_custom_prepare_basic_auth();
		}
		if ($this->session->userdata()) {
			$this->admin_role  = $this->session->userdata('role');			
			$this->admin_privilege = ($this->admin_role == 2) ? $this->session->userdata('admin_privilege') : '';
		}
		// validate subadmin privilege
		if ($this->admin_role == SUBADMIN_ROLE) {
			$this->check_subadmin_acess_privilege();
		}
	}

	public function check_subadmin_acess_privilege()
	{
		$controller = $this->router->fetch_class();
		$is_allowed =  TRUE;
		
		switch ($controller) {
			case 'contest':
				break;
			case 'dashboard':
				$is_allowed = (empty($this->admin_privilege['dashboard'])) ? FALSE : TRUE;
				break;
			case 'user':				
				$is_allowed = (empty($this->admin_privilege['manage_users'])) ? FALSE : TRUE;
				break;
			case 'contest':
				$is_allowed = (empty($this->admin_privilege['manage_contest'])) ? FALSE : TRUE;
				break;
			case 'roster':
				$is_allowed = (empty($this->admin_privilege['roster_management'])) ? FALSE : TRUE;
				break;
			case 'withdrawal':
				$is_allowed = (empty($this->admin_privilege['manage_finance'])) ? FALSE : TRUE;
				break;
			case 'payment_transaction':	
				$is_allowed = (empty($this->admin_privilege['manage_finance'])) ? FALSE : TRUE;
				break;
			case 'report':
				$is_allowed = (empty($this->admin_privilege['reports'])) ? FALSE : TRUE;
				break;
			case 'teamroster':
				$is_allowed = (empty($this->admin_privilege['team_list'])) ? FALSE : TRUE;
				break;
			case 'season':
				$is_allowed = (empty($this->admin_privilege['season_schedule'])) ? FALSE : TRUE;
				break;
			case 'score':
				$is_allowed = (empty($this->admin_privilege['season_schedule'])) ? FALSE : TRUE;
				break;
			case 'advertisements':
				$is_allowed = (empty($this->admin_privilege['manage_advertisement'])) ? FALSE : TRUE;
				break;
			case 'promo_code':
				$is_allowed = (empty($this->admin_privilege['manage_promocode'])) ? FALSE : TRUE;
				break;
                        case 'subadmin':
                        	$is_allowed = ($this->admin_role == 2) ? FALSE : TRUE; 
				break;
                        default:				
				break;
		}
		
		if (in_array('manage_users', $this->admin_privilege)) {
			$next_uri = 'dashboard';
		}elseif (in_array('manage_scoring', $this->admin_privilege)) {
			$next_uri = 'contest';
		}elseif (in_array('manage_advertisement', $this->admin_privilege)) {
			$next_uri = 'advertisement';
		}elseif (in_array('user_report', $this->admin_privilege)) {
			$next_uri = 'user_report';
		}elseif (in_array('reports', $this->admin_privilege)) {
			$next_uri = 'user_report';
		}elseif (in_array('payment_setting', $this->admin_privilege)) {
			$next_uri = 'promo_code';
		}elseif (in_array('roster_management', $this->admin_privilege)) {
			$next_uri = 'roster';
		}
	
		if ($controller == 'auth') 
		{			
			$this->redirect_after_login = $next_uri;
		}
		
		if (!$is_allowed) 
		{			
			$this->response(array(config_item('rest_status_field_name')=>FALSE, 
				'global_error'=>$this->lang->line('game_entry_full'), 				
				'error'=>array('next_uri'=>$next_uri),
				'next_uri'=>$next_uri,
				'message'=>'You have no permission to access this control.') , rest_controller::HTTP_INTERNAL_SERVER_ERROR);
		}				
	}

	/**
	 * Retrieve the validation errors array and send as response.
	 * 26/12/2014 16:46
	 * @return none
	 */

	public function send_validation_errors()
	{	
		$errors = $this->form_validation->error_array();
		$message = $errors[array_keys($errors)[0]];
		$return[config_item('rest_status_field_name')]  = FALSE;
		$return[config_item('rest_message_field_name')] = $this->form_validation->error_array();
		$return['message'] = $message;
		$this->response($return, REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
	}

	/**
	 * [send_email description]
	 * @MethodName send_email 
	 * @Summary This function used send email
	 * @param      string  to email
	 * @param      string  Email subject
	 * @param      string  Email messge
	 * @param      string  From Email 
	 * @param      string  From Name
	 * @return     Boolean
	 */
	function send_email($to, $subject = "", $message = "", $from_email = FROM_ADMIN_EMAIL, $from_name = FROM_EMAIL_NAME)
	{
		//return false;
		$this->load->library('email');

		$config['wordwrap']		= TRUE;
		$config['mailtype']		= 'html';
		$config['charset']		= "utf-8";
		$config['protocol']		= PROTOCOL;
		$config['smtp_user']	= SMTP_USER;
		$config['smtp_pass']	= SMTP_PASS;
		$config['smtp_host']	= SMTP_HOST;
		$config['smtp_port']	= SMTP_PORT;
		$config['bcc_batch_mode']	= TRUE;
		$config['smtp_crypto']	= SMTP_CRYPTO;
		$config['newline']		= "\r\n";  // SES hangs with just \n

		$this->email->initialize($config);

		$this->email->clear();
		$this->email->from($from_email, $from_name);
		$this->email->to(ADMIN_EMAIL);
		$this->email->bcc($to);
		$this->email->subject($subject);
		$this->email->message($message);
		$this->email->send();
		//echo $email->print_debugger();
		return true;
	}

	/**
	 * [generate_active_login_key description]
	 * @MethodName generate_active_login_key
	 * @Summary This genrate new key and insert in database
	 * @param      [int]  [User Id]
	 * @return     [key]
	 */
	public function generate_active_login_key($admin_id = "", $device_type = "1")
	{
		$key = random_string('unique');
		$insert_data = array(
						'key'			=> $key,
						'admin_id'		=> $admin_id,
						'device_type'	=> $device_type,
						'added_date'	=> date('Y-m-d H:i:s')
					);		
		$this->db->insert(ADMIN_ACTIVE_LOGIN, $insert_data);
		return $key;
	}

	public function delete_active_login_key($key, $device_type = "1")
	{
		$this->db->where('key', $key)->where('device_type', $device_type)->delete(ADMIN_ACTIVE_LOGIN);
	}

	/**
	 * [seesion_initialization description]
	 * @MethodName seesion_initialization
	 * @Summary This function used for initialize user session
	 * @param      [array]  [User Data Array]
	 * @return     [boolean]
	 */
	public function seesion_initialization($data_arr)
	{		
		$this->session->set_userdata($data_arr);
		return true;
	}

	/**
	 * Check if there is a specific auth type set for the current class/method/HTTP-method being called
	 *
	 * @access protected
	 * @return bool
	 */
	protected function _custom_auth_override_check()
	{
		// Assign the class/method auth type override array from the config
		$auth_override_class_method = $this->config->item('auth_override_class_method');

		// Check to see if the override array is even populated
		if (!empty($auth_override_class_method))
		{
			// check for wildcard flag for rules for classes
			if (!empty($auth_override_class_method[$this->router->class]['*'])) // Check for class overrides
			{
				// None auth override found, prepare nothing but send back a TRUE override flag
				if ($auth_override_class_method[$this->router->class]['*'] === 'none')
				{
					return TRUE;
				}

				// Basic auth override found, prepare basic
				if ($auth_override_class_method[$this->router->class]['*'] === 'custom')
				{
					$this->_custom_prepare_basic_auth();

					return TRUE;
				}
			}

			// Check to see if there's an override value set for the current class/method being called
			if (!empty($auth_override_class_method[$this->router->class][$this->router->method]))
			{
				// None auth override found, prepare nothing but send back a TRUE override flag
				if ($auth_override_class_method[$this->router->class][$this->router->method] === 'none')
				{
					return TRUE;
				}

				// Basic auth override found, prepare basic
				if ($auth_override_class_method[$this->router->class][$this->router->method] === 'custom')
				{
					$this->_custom_prepare_basic_auth();

					return TRUE;
				}
			}
		}

		// Assign the class/method/HTTP-method auth type override array from the config
		$auth_override_class_method_http = $this->config->item('auth_override_class_method_http');

		// Check to see if the override array is even populated
		if (!empty($auth_override_class_method_http))
		{
			// check for wildcard flag for rules for classes
			if(!empty($auth_override_class_method_http[$this->router->class]['*'][$this->request->method]))
			{
				// None auth override found, prepare nothing but send back a TRUE override flag
				if ($auth_override_class_method_http[$this->router->class]['*'][$this->request->method] === 'none')
				{
					return TRUE;
				}

				// Basic auth override found, prepare basic
				if ($auth_override_class_method_http[$this->router->class]['*'][$this->request->method] === 'custom')
				{
					$this->_custom_prepare_basic_auth();

					return TRUE;
				}
			}

			// Check to see if there's an override value set for the current class/method/HTTP-method being called
			if(!empty($auth_override_class_method_http[$this->router->class][$this->router->method][$this->request->method]))
			{
				// None auth override found, prepare nothing but send back a TRUE override flag
				if ($auth_override_class_method_http[$this->router->class][$this->router->method][$this->request->method] === 'none')
				{
					return TRUE;
				}

				// Basic auth override found, prepare basic
				if ($auth_override_class_method_http[$this->router->class][$this->router->method][$this->request->method] === 'custom')
				{
					$this->_custom_prepare_basic_auth();

					return TRUE;
				}
			}
		}
		return FALSE;
	}

	/**
	 * Prepares for basic authentication
	 *
	 * @access protected
	 * @return void
	 */
	protected function _custom_prepare_basic_auth()
	{
		$key = $this->input->get_request_header(AUTH_KEY);
		if($key===NULL&&$this->session->userdata(AUTH_KEY)) $key = $this->session->userdata(AUTH_KEY);
		$this->load->model("Adminauth_model");
		$key_detail = $this->Adminauth_model->check_user_key($key);
		if(!empty($key_detail))
		{
			//re-initialize session and admin role.
			$where = array('admin_id'=>$key_detail['admin_id']);
			$admin_detail = $this->Adminauth_model->get_admin_details($where);

			$admin_detail['admin_privilege'] = json_decode($admin_detail['privilege']);
			
			if ($admin_detail['admin_privilege']) {
				$admin_detail['admin_privilege'] = array_combine(array_keys(array_flip($admin_detail['admin_privilege'])), $admin_detail['admin_privilege']);	
			}
			
			$this->seesion_initialization($admin_detail); // Initialize User Session
			if (($this->session->userdata('role') == 2)) {
				$this->admin_privilege = $this->session->userdata('admin_privilege');
			}
			return TRUE;
		}
		else
		{
			if($this->request->method==='get')
			{
				redirect('auth/logout');
			}
			else
			{
				$this->response([
					$this->config->item('rest_status_field_name') => FALSE,
					$this->config->item('rest_message_field_name') => $this->lang->line('text_rest_unauthorized')
				], self::HTTP_UNAUTHORIZED);
			}
		}
	}
}
/* End of file MYREST_Controller.php */
/* Location: ./application/controllers/MYREST_Controller.php */